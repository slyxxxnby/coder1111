import os
import re
import json
import random
import requests
import time
import concurrent.futures
import pandas as pd
from bs4 import BeautifulSoup
from urllib.parse import urlparse, quote, unquote
from datetime import datetime
from fake_useragent import UserAgent
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from stem import Signal
from stem.control import Controller
from PIL import Image
import io
import pytesseract
from multiprocessing import Pool, cpu_count
import dns.resolver
import socket
import whois
import phonenumbers
from email_validator import validate_email, EmailNotValidError
import warnings
warnings.filterwarnings("ignore")

# Configuración de Tesseract OCR (opcional para CAPTCHAs)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Ajustar según sistema

class AdvancedSocialRecon:
    def __init__(self, use_tor=False, headless=True, max_threads=15, use_ocr=False):
        self.ua = UserAgent()
        self.results = []
        self.max_threads = max_threads
        self.use_tor = use_tor
        self.use_ocr = use_ocr
        self.proxies = self._init_proxies()
        self.driver = self._init_selenium(headless)
        self.platforms = self._load_platform_config()
        self.cookies = {}
        self.rate_limits = {}
        self.session = requests.Session()
        
    def _init_proxies(self):
        """Configura proxies, incluyendo Tor si está activado"""
        if self.use_tor:
            try:
                with Controller.from_port(port=9051) as controller:
                    controller.authenticate()
                    controller.signal(Signal.NEWNYM)
                return {
                    'http': 'socks5h://127.0.0.1:9050',
                    'https': 'socks5h://127.0.0.1:9050'
                }
            except:
                print("Tor no disponible, continuando sin proxies")
                return None
        return None
    
    def _init_selenium(self, headless=True):
        """Inicializa WebDriver para Selenium"""
        options = Options()
        if headless:
            options.add_argument("--headless")
        options.add_argument("--disable-gpu")
        options.add_argument(f"user-agent={self.ua.random}")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        
        try:
            driver = webdriver.Chrome(options=options)
            return driver
        except Exception as e:
            print(f"No se pudo iniciar Selenium: {e}")
            return None
    
    def _load_platform_config(self):
        """Carga configuración avanzada para cada plataforma"""
        return {
            'twitter': {
                'url': 'https://twitter.com/{}',
                'search_url': 'https://twitter.com/search?q={}&f=user',
                'checker': self._check_twitter,
                'selenium': True,
                'api': 'https://api.twitter.com/2/users/by/username/{}'
            },
            'instagram': {
                'url': 'https://www.instagram.com/{}/',
                'search_url': 'https://www.instagram.com/web/search/topsearch/?query={}',
                'checker': self._check_instagram,
                'selenium': True
            },
            # Configuración similar para otras plataformas...
        }
    
    def _make_request(self, url, method='GET', headers=None, data=None, use_selenium=False):
        """Realiza una petición HTTP avanzada con rotación de agentes y manejo de errores"""
        if use_selenium and self.driver:
            try:
                self.driver.get(url)
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, 'body'))
                )
                return self.driver.page_source
            except Exception as e:
                print(f"Error en Selenium: {e}")
                return None
        
        if headers is None:
            headers = {
                'User-Agent': self.ua.random,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            }
        
        try:
            if method == 'GET':
                response = self.session.get(
                    url,
                    headers=headers,
                    proxies=self.proxies,
                    timeout=15,
                    allow_redirects=True
                )
            else:
                response = self.session.post(
                    url,
                    headers=headers,
                    data=data,
                    proxies=self.proxies,
                    timeout=15,
                    allow_redirects=True
                )
            
            # Manejo de CAPTCHAs con OCR si está activado
            if 'captcha' in response.text.lower() and self.use_ocr:
                return self._solve_captcha(response)
            
            return response
        except Exception as e:
            print(f"Error en la petición: {e}")
            return None
    
    def _solve_captcha(self, response):
        """Intenta resolver CAPTCHAs usando OCR (limitado)"""
        try:
            img = Image.open(io.BytesIO(response.content))
            captcha_text = pytesseract.image_to_string(img)
            return captcha_text
        except:
            return None
    
    def _extract_advanced_info(self, username, platform):
        """Extrae información avanzada específica de cada plataforma"""
        if platform == 'twitter':
            return self._get_twitter_details(username)
        elif platform == 'instagram':
            return self._get_instagram_details(username)
        # Añadir más plataformas...
    
    def _get_twitter_details(self, username):
        """Extrae metadatos avanzados de Twitter"""
        url = self.platforms['twitter']['url'].format(username)
        response = self._make_request(url, use_selenium=True)
        
        if not response:
            return None
        
        soup = BeautifulSoup(response, 'html.parser')
        data = {
            'platform': 'twitter',
            'username': username,
            'url': url,
            'timestamp': datetime.now().isoformat()
        }
        
        try:
            # Extraer bio, ubicación, sitio web
            bio = soup.find('div', {'data-testid': 'UserDescription'})
            if bio:
                data['bio'] = bio.text.strip()
            
            location = soup.find('span', {'data-testid': 'UserLocation'})
            if location:
                data['location'] = location.text.strip()
            
            website = soup.find('a', {'data-testid': 'UserUrl'})
            if website:
                data['website'] = website.text.strip()
            
            # Extraer estadísticas
            stats = soup.find_all('span', {'data-testid': True})
            for stat in stats:
                if 'followers' in stat['data-testid']:
                    data['followers'] = stat.text.strip()
                elif 'following' in stat['data-testid']:
                    data['following'] = stat.text.strip()
            
            return data
        except Exception as e:
            print(f"Error extrayendo datos de Twitter: {e}")
            return data
    
    def _get_instagram_details(self, username):
        """Extrae metadatos avanzados de Instagram"""
        url = self.platforms['instagram']['url'].format(username)
        response = self._make_request(url, use_selenium=True)
        
        if not response:
            return None
        
        soup = BeautifulSoup(response, 'html.parser')
        data = {
            'platform': 'instagram',
            'username': username,
            'url': url,
            'timestamp': datetime.now().isoformat()
        }
        
        try:
            # Extraer metadatos de OpenGraph
            meta = soup.find('meta', property='og:description')
            if meta:
                content = meta['content']
                data['followers'] = re.search(r'([\d,]+) Followers', content).group(1)
                data['following'] = re.search(r'([\d,]+) Following', content).group(1)
                data['posts'] = re.search(r'([\d,]+) Posts', content).group(1)
            
            # Extraer nombre completo
            name = soup.find('h1', class_=re.compile('.*Username.*'))
            if name:
                data['full_name'] = name.text.strip()
            
            # Extraer bio
            bio = soup.find('div', class_=re.compile('.*UserBio.*'))
            if bio:
                data['bio'] = bio.text.strip()
            
            return data
        except Exception as e:
            print(f"Error extrayendo datos de Instagram: {e}")
            return data
    
    def _check_twitter(self, username):
        """Verifica existencia de usuario en Twitter con múltiples métodos"""
        # Método 1: API no oficial
        api_url = self.platforms['twitter']['api'].format(username)
        response = self._make_request(api_url)
        
        if response and response.status_code == 200:
            return True
        
        # Método 2: Scraping tradicional
        url = self.platforms['twitter']['url'].format(username)
        response = self._make_request(url)
        
        if response and response.status_code == 200:
            return 'error' not in response.url
        
        return False
    
    def _check_instagram(self, username):
        """Verifica existencia de usuario en Instagram con múltiples métodos"""
        # Método 1: API no oficial
        api_url = self.platforms['instagram']['search_url'].format(username)
        response = self._make_request(api_url)
        
        if response and response.status_code == 200:
            try:
                data = response.json()
                return any(user['user']['username'] == username for user in data['users'])
            except:
                pass
        
        # Método 2: Scraping tradicional
        url = self.platforms['instagram']['url'].format(username)
        response = self._make_request(url, use_selenium=True)
        
        if response:
            soup = BeautifulSoup(response, 'html.parser')
            title = soup.find('title')
            if title and 'Page Not Found' not in title.text:
                return True
        
        return False
    
    def _enrich_with_osint(self, data):
        """Enriquece los datos con técnicas OSINT avanzadas"""
        if 'email' in data:
            try:
                # Validar email
                valid = validate_email(data['email'])
                data['email_valid'] = valid.email
                
                # Buscar breaches
                data['breaches'] = self._check_breaches(data['email'])
                
                # Extraer dominio
                domain = data['email'].split('@')[-1]
                data['domain_info'] = self._get_domain_info(domain)
            except EmailNotValidError:
                data['email_valid'] = False
        
        if 'phone' in data:
            try:
                parsed = phonenumbers.parse(data['phone'], None)
                data['phone_valid'] = phonenumbers.is_valid_number(parsed)
                data['phone_region'] = phonenumbers.region_code_for_number(parsed)
            except:
                data['phone_valid'] = False
        
        return data
    
    def _check_breaches(self, email):
        """Verifica si el email aparece en breaches conocidos (usando API de HaveIBeenPwned)"""
        try:
            url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
            headers = {
                'User-Agent': self.ua.random,
                'hibp-api-key': ''  # Añadir API key si se tiene
            }
            response = requests.get(url, headers=headers, timeout=10)
            return response.json() if response.status_code == 200 else []
        except:
            return []
    
    def _get_domain_info(self, domain):
        """Obtiene información WHOIS y DNS de un dominio"""
        try:
            info = {
                'whois': str(whois.whois(domain)),
                'dns': {}
            }
            
            # Consultar registros DNS comunes
            for record in ['A', 'MX', 'TXT', 'NS']:
                try:
                    answers = dns.resolver.resolve(domain, record)
                    info['dns'][record] = [str(r) for r in answers]
                except:
                    continue
            
            return info
        except Exception as e:
            print(f"Error obteniendo info de dominio: {e}")
            return None
    
    def search_by_username(self, username, platforms=None):
        """Busca un usuario en múltiples plataformas simultáneamente"""
        if not platforms:
            platforms = self.platforms.keys()
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = []
            for platform in platforms:
                if platform in self.platforms:
                    futures.append(executor.submit(
                        self._search_single_platform,
                        platform,
                        username
                    ))
            
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result:
                    self.results.append(result)
        
        return [r for r in self.results if r['username'] == username]
    
    def _search_single_platform(self, platform, username):
        """Busca en una sola plataforma y devuelve datos enriquecidos"""
        checker = self.platforms[platform].get('checker')
        if not checker:
            return None
        
        exists = checker(username)
        if not exists:
            return {
                'platform': platform,
                'username': username,
                'exists': False,
                'timestamp': datetime.now().isoformat()
            }
        
        # Obtener datos avanzados si existe
        details = self._extract_advanced_info(username, platform)
        if not details:
            details = {
                'platform': platform,
                'username': username,
                'exists': True,
                'timestamp': datetime.now().isoformat()
            }
        
        return details
    
    def search_by_email(self, email, deep_search=False):
        """Realiza búsqueda por email con técnicas avanzadas"""
        try:
            valid = validate_email(email)
            email = valid.email
        except EmailNotValidError:
            return {'error': 'Email inválido'}
        
        results = []
        
        # 1. Búsqueda directa en plataformas que permiten búsqueda por email
        platforms_with_email_search = ['facebook', 'linkedin', 'twitter']
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = []
            for platform in platforms_with_email_search:
                futures.append(executor.submit(
                    self._search_email_on_platform,
                    platform,
                    email
                ))
            
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result:
                    results.append(result)
        
        # 2. Búsqueda inversa en motores de búsqueda
        if deep_search:
            search_engines = [
                f"https://www.google.com/search?q=%22{email}%22+site:twitter.com",
                f"https://www.google.com/search?q=%22{email}%22+site:linkedin.com",
                # Añadir más sitios...
            ]
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_threads) as executor:
                futures = []
                for url in search_engines:
                    futures.append(executor.submit(
                        self._search_with_engine,
                        url,
                        email
                    ))
                
                for future in concurrent.futures.as_completed(futures):
                    result = future.result()
                    if result:
                        results.append(result)
        
        # 3. Verificar breaches
        breaches = self._check_breaches(email)
        if breaches:
            results.append({
                'type': 'breaches',
                'email': email,
                'breaches': breaches,
                'timestamp': datetime.now().isoformat()
            })
        
        # 4. Enriquecer datos con OSINT
        enriched_results = []
        for result in results:
            enriched = self._enrich_with_osint(result)
            enriched_results.append(enriched)
        
        self.results.extend(enriched_results)
        return enriched_results
    
    def _search_email_on_platform(self, platform, email):
        """Busca un email en una plataforma específica"""
        if platform == 'facebook':
            url = f"https://www.facebook.com/search.php?q={quote(email)}"
            response = self._make_request(url, use_selenium=True)
            
            if not response:
                return None
            
            soup = BeautifulSoup(response, 'html.parser')
            profiles = soup.find_all('div', class_='_401d')
            
            return {
                'platform': 'facebook',
                'email': email,
                'matches': len(profiles),
                'timestamp': datetime.now().isoformat()
            }
        
        # Implementaciones similares para otras plataformas...
    
    def _search_with_engine(self, url, query):
        """Busca en motores de búsqueda"""
        response = self._make_request(url)
        if not response:
            return None
        
        soup = BeautifulSoup(response.text, 'html.parser')
        results = soup.find_all('div', class_='g')  # Para Google
        
        profiles = []
        for result in results:
            link = result.find('a')
            if link and link.get('href'):
                profiles.append(link['href'])
        
        return {
            'search_engine': urlparse(url).netloc,
            'query': query,
            'results': profiles,
            'timestamp': datetime.now().isoformat()
        }
    
    def search_by_phone(self, phone_number):
        """Busca información por número de teléfono"""
        try:
            parsed = phonenumbers.parse(phone_number, None)
            if not phonenumbers.is_valid_number(parsed):
                return {'error': 'Número inválido'}
            
            formatted = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)
            region = phonenumbers.region_code_for_number(parsed)
            
            # Búsqueda en plataformas que permiten búsqueda por teléfono
            results = []
            
            # 1. WhatsApp (simulación de búsqueda)
            whatsapp_url = f"https://wa.me/{formatted}"
            results.append({
                'platform': 'whatsapp',
                'url': whatsapp_url,
                'exists': True,  # Asumimos que existe
                'timestamp': datetime.now().isoformat()
            })
            
            # 2. Búsqueda en redes sociales
            social_results = self._reverse_phone_search(formatted)
            results.extend(social_results)
            
            # 3. Enriquecer datos
            enriched = []
            for result in results:
                result['phone'] = formatted
                result['phone_region'] = region
                enriched.append(self._enrich_with_osint(result))
            
            self.results.extend(enriched)
            return enriched
        except Exception as e:
            print(f"Error en búsqueda por teléfono: {e}")
            return None
    
    def _reverse_phone_search(self, phone):
        """Búsqueda inversa de teléfono en redes sociales"""
        platforms = ['facebook', 'twitter', 'instagram']
        results = []
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = []
            for platform in platforms:
                futures.append(executor.submit(
                    self._search_phone_on_platform,
                    platform,
                    phone
                ))
            
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result:
                    results.append(result)
        
        return results
    
    def _search_phone_on_platform(self, platform, phone):
        """Busca un teléfono en una plataforma específica"""
        if platform == 'facebook':
            url = f"https://www.facebook.com/search.php?q={quote(phone)}"
            response = self._make_request(url, use_selenium=True)
            
            if not response:
                return None
            
            soup = BeautifulSoup(response, 'html.parser')
            profiles = soup.find_all('div', class_='_401d')
            
            return {
                'platform': 'facebook',
                'phone': phone,
                'matches': len(profiles),
                'timestamp': datetime.now().isoformat()
            }
        
        # Implementaciones similares para otras plataformas...
    
    def save_results(self, format='json', filename=None):
        """Guarda los resultados en múltiples formatos"""
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'social_intel_report_{timestamp}'
        
        if format == 'json':
            with open(f'{filename}.json', 'w', encoding='utf-8') as f:
                json.dump(self.results, f, indent=2, ensure_ascii=False)
        elif format == 'csv':
            df = pd.json_normalize(self.results)
            df.to_csv(f'{filename}.csv', index=False, encoding='utf-8-sig')
        elif format == 'excel':
            df = pd.json_normalize(self.results)
            df.to_excel(f'{filename}.xlsx', index=False)
        elif format == 'html':
            df = pd.json_normalize(self.results)
            df.to_html(f'{filename}.html', index=False)
        
        print(f"Reporte guardado como {filename}.{format}")
    
    def visualize_results(self):
        """Visualización básica de resultados (mejorable con Dash/Plotly)"""
        if not self.results:
            print("No hay resultados para visualizar")
            return
        
        df = pd.json_normalize(self.results)
        
        # Resumen estadístico
        print("\n=== RESUMEN ESTADÍSTICO ===")
        print(f"Total de resultados: {len(df)}")
        
        if 'platform' in df.columns:
            print("\nDistribución por plataforma:")
            print(df['platform'].value_counts())
        
        # Mostrar primeros resultados
        print("\n=== PRIMEROS RESULTADOS ===")
        print(df.head().to_string(index=False))
    
    def clear_results(self):
        """Limpia los resultados almacenados"""
        self.results = []
    
    def close(self):
        """Cierra recursos abiertos"""
        if self.driver:
            self.driver.quit()
        self.session.close()


# Ejemplo de uso avanzado
if __name__ == "__main__":
    print("=== SOCIAL INTELLIGENCE RECON TOOL (SIRT) ===")
    print("=== Versión Avanzada - Reconocimiento Extendido ===\n")
    
    # Configuración avanzada
    recon = AdvancedSocialRecon(
        use_tor=False,        # Usar Tor para anonimato (requiere configuración)
        headless=True,        # Ejecución sin interfaz gráfica
        max_threads=10,       # Hilos paralelos para búsquedas
        use_ocr=False         # Usar OCR para CAPTCHAs (requiere Tesseract)
    )
    
    try:
        # 1. Búsqueda por nombre de usuario en múltiples plataformas
        print("\n[+] Realizando búsqueda por nombre de usuario...")
        username = "elonmusk"
        recon.search_by_username(username)
        
        # 2. Búsqueda profunda por email
        print("\n[+] Realizando búsqueda por email...")
        email = "example@gmail.com"
        recon.search_by_email(email, deep_search=True)
        
        # 3. Búsqueda por número de teléfono
        print("\n[+] Realizando búsqueda por teléfono...")
        phone = "+1234567890"
        recon.search_by_phone(phone)
        
        # 4. Visualización y guardado de resultados
        print("\n[+] Generando reporte...")
        recon.visualize_results()
        recon.save_results(format='json')
        recon.save_results(format='csv')
        
    except KeyboardInterrupt:
        print("\n[!] Búsqueda interrumpida por el usuario")
    finally:
        recon.close()
        print("\n[+] Herramienta cerrada. Operación completada.")