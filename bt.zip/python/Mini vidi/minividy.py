#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import sys
import ssl
import socket
import random
import ipaddress
import logging
import subprocess
import warnings
import platform
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from rich.table import Table
from rich.progress import Progress, BarColumn, TimeRemainingColumn
from rich.console import Console
from colorama import Fore, init

# Suprimir advertencias de solicitudes HTTPS no verificadas
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# Configuración inicial
init(autoreset=True)
console = Console()
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')

# Constantes
VERSION = "5.0"
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/92.0.4515.107 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0'
]

# Vulnerabilidades conocidas por puerto
VULNERABILIDADES = {
    21: [{'CVE': 'CVE-2021-33194', 'Risk': 'Critical', 'Description': 'ProFTPd Remote Code Execution'}],
    22: [{'CVE': 'CVE-2018-15473', 'Risk': 'High', 'Description': 'OpenSSH User Enumeration'}],
    80: [{'CVE': 'CVE-2021-41773', 'Risk': 'High', 'Description': 'Apache Path Traversal'}],
    443: [{'CVE': 'CVE-2014-0160', 'Risk': 'Critical', 'Description': 'Heartbleed Vulnerability'}],
    445: [{'CVE': 'CVE-2017-0144', 'Risk': 'Critical', 'Description': 'EternalBlue SMB Exploit'}],
    3389: [{'CVE': 'CVE-2019-0708', 'Risk': 'Critical', 'Description': 'BlueKeep RDP Vulnerability'}],
    554: [{'CVE': 'CVE-2017-9999', 'Risk': 'High', 'Description': 'RTSP Stack Overflow'}],
    8080: [{'CVE': 'CVE-2020-13935', 'Risk': 'High', 'Description': 'Apache Tomcat RCE'}]
}

# Puertos y rutas comunes para cámaras
CAMERA_PORTS = {80, 8080, 554, 8554, 1935, 37777}
CAMERA_PATHS = ['/video', '/stream', '/cam', '/live', '/axis-cgi/mjpg/video.cgi']

# ========================
# Banner y Menú
# ========================
def mostrar_banner():
    """Muestra el banner de la herramienta."""
    console.print(f"""
    {Fore.GREEN}
    ██████╗  ██████╗ ███████╗    ██╗   ██╗██╗██████╗ ██╗ ██████╗ ██╗   ██╗
    ██╔══██╗██╔═══██╗██╔════╝    ██║   ██║██║██╔══██╗██║██╔════╝ ██║   ██║
    ██████╔╝██║   ██║█████╗      ██║   ██║██║██████╔╝██║██║  ███╗██║   ██║
    ██╔═══╝ ██║   ██║██╔══╝      ╚██╗ ██╔╝██║██╔══██╗██║██║   ██║██║   ██║
    ██║     ╚██████╔╝██║          ╚████╔╝ ██║██║  ██║██║╚██████╔╝╚██████╔╝
    ╚═╝      ╚═════╝ ╚═╝           ╚═══╝  ╚═╝╚═╝  ╚═╝╚═╝ ╚═════╝  ╚═════╝ 
    {Fore.CYAN}Versión {VERSION} -  the coded slyx for Mini-Vidy<3
    {Fore.YELLOW}=============================================================
    """)

def mostrar_menu():
    """Muestra el menú principal."""
    console.print(f"""
    {Fore.CYAN}=== clyxL ==={Fore.RESET}
    [1] Geolocalización Global por IP
    [2] Análisis de Sitio Web
    [3] Escaneo de Puertos
    [4] Fuerza Bruta de Puertow
    [5] Escaneo de Red de Dispositivos (incluye Cámaras)
    [0] Salir 
    """)

# ========================
# 1. Geolocalización Global por IP
# ========================
def geolocalizacion_ip():
    """Obtiene información global de la IP usando el servicio gratuito ip-api.com."""
    ip = console.input(f"\n[{Fore.YELLOW}?{Fore.RESET}] Introduce la dirección IP: ").strip()
    if not validar_ip(ip):
        console.print(f"[{Fore.RED}!{Fore.RESET}] Dirección IP inválida")
        return

    try:
        with console.status("[bold green]Obteniendo información geográfica..."):
            url = f"http://ip-api.com/json/{ip}"
            response = requests.get(url, timeout=10)
            data = response.json()
            if data.get("status") != "success":
                console.print(f"[{Fore.RED}!{Fore.RESET}] Error: {data.get('message', 'No se pudo obtener la información')}")
                return

            tabla = Table(title=f"Geolocalización - {ip}", show_header=True, header_style="bold magenta")
            tabla.add_column("Campo", style="cyan")
            tabla.add_column("Valor")
            campos = ["country", "regionName", "city", "zip", "lat", "lon", "timezone", "isp", "org", "as"]
            nombres = {
                "country": "País",
                "regionName": "Región",
                "city": "Ciudad",
                "zip": "Código Postal",
                "lat": "Latitud",
                "lon": "Longitud",
                "timezone": "Zona Horaria",
                "isp": "ISP",
                "org": "Organización",
                "as": "ASN"
            }
            for campo in campos:
                tabla.add_row(nombres.get(campo, campo), str(data.get(campo, "N/A")))
            console.print(tabla)
    except Exception as e:
        logger.exception("Error en geolocalización")
        console.print(f"[{Fore.RED}!{Fore.RESET}] Error: {str(e)}")

def validar_ip(ip):
    """Valida el formato de una dirección IP."""
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

# ========================
# 2. Análisis de Sitio Web
# ========================
def analisis_sitio_web():
    """Analiza un sitio web y muestra datos relevantes y vulnerabilidades."""
    url = console.input(f"\n[{Fore.YELLOW}?{Fore.RESET}] Introduce la URL: ").strip()
    if not url.startswith(('http://', 'https://')):
        url = f'http://{url}'

    try:
        with console.status("[bold green]Analizando sitio web..."):
            headers = {'User-Agent': random.choice(USER_AGENTS)}
            response = requests.get(url, headers=headers, timeout=15, verify=False)
            soup = BeautifulSoup(response.text, 'html.parser')
            info = {
                'Estado': f"{response.status_code} {response.reason}",
                'Servidor': response.headers.get('Server', 'Desconocido'),
                'Tecnologías': detectar_tecnologias(response, soup),
                'SSL': analizar_ssl(urlparse(url).hostname),
                'Enlaces': len(soup.find_all('a')),
                'Formularios': len(soup.find_all('form')),
                'Cookies': len(response.cookies),
                'Vulnerabilidades': escanear_vulnerabilidades_web(response)
            }
            tabla = Table(title=f"Análisis de {url}", show_header=True, header_style="bold blue")
            tabla.add_column("Categoría", style="cyan")
            tabla.add_column("Detalles")
            for cat, det in info.items():
                if isinstance(det, list):
                    tabla.add_row(cat, "\n".join(det))
                else:
                    tabla.add_row(cat, str(det))
            console.print(tabla)
    except Exception as e:
        logger.exception("Error en análisis de sitio web")
        console.print(f"[{Fore.RED}!{Fore.RESET}] Error: {str(e)}")

def analizar_ssl(hostname):
    """Obtiene información del certificado SSL del host."""
    try:
        ctx = ssl.create_default_context()
        with ctx.wrap_socket(socket.socket(), server_hostname=hostname) as s:
            s.settimeout(5)
            s.connect((hostname, 443))
            cert = s.getpeercert()
            not_after = cert.get('notAfter', 'N/A')
            issuer = cert.get('issuer', [('N/A', 'N/A')])[0][1]
            return f"Válido hasta: {not_after}\nEmisor: {issuer}"
    except Exception as e:
        logger.debug(f"Error en SSL para {hostname}: {e}")
        return "Certificado inválido o no encontrado"

def detectar_tecnologias(response, soup):
    """Detecta CMS, frameworks y otros detalles tecnológicos del sitio."""
    tecnologias = set()
    texto = response.text.lower()
    # Detección de CMS
    if 'wp-content' in texto:
        tecnologias.add('WordPress')
    if 'joomla' in texto:
        tecnologias.add('Joomla')
    # Detección de frameworks
    if 'react' in texto:
        tecnologias.add('React')
    for script in soup.find_all('script'):
        src = script.get('src', '').lower()
        if 'jquery' in src:
            tecnologias.add('jQuery')
            break
    # Agregar el header del servidor
    server = response.headers.get('Server', '')
    if server:
        tecnologias.add(server)
    return list(tecnologias) if tecnologias else ['No detectado']

def escanear_vulnerabilidades_web(response):
    """Revisa el sitio web en busca de cabeceras y configuraciones vulnerables."""
    vulnerabilidades = []
    if 'X-XSS-Protection' not in response.headers:
        vulnerabilidades.append('Falta X-XSS-Protection')
    if 'Content-Security-Policy' not in response.headers:
        vulnerabilidades.append('Falta Content-Security-Policy')
    soup = BeautifulSoup(response.text, 'html.parser')
    forms = soup.find_all('form')
    for form in forms:
        if not form.find('input', {'name': 'csrf_token'}):
            vulnerabilidades.append('Formulario sin protección CSRF')
            break
    return vulnerabilidades if vulnerabilidades else ['Ninguna detectada']

# ================================
# 3. Escaneo de Puertos (Zero-Day)
# ================================
def escaneo_puertos():
    """Escanea puertos indicados en una IP o dominio y muestra puertos abiertos con vulnerabilidades."""
    objetivo = console.input(f"\n[{Fore.YELLOW}?{Fore.RESET}] Introduce la IP/Dominio: ").strip()
    puertos = console.input(f"[{Fore.YELLOW}?{Fore.RESET}] Puertos a escanear (ej: 80,443,1-1000): ").strip()
    try:
        puertos_lista = parsear_puertos(puertos)
        console.print(f"\n[bold green][*] Escaneando {objetivo} - {len(puertos_lista)} puertos...")
        resultados = []
        with Progress(BarColumn(bar_width=None), "[progress.percentage]{task.percentage:>3.0f}%", TimeRemainingColumn()) as progress:
            task = progress.add_task("Escaneando...", total=len(puertos_lista))
            with ThreadPoolExecutor(max_workers=100) as executor:
                futures = {executor.submit(escanear_puerto, objetivo, puerto): puerto for puerto in puertos_lista}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    resultado = future.result()
                    if resultado:
                        resultados.append(resultado)
        tabla = Table(title=f"Resultados del Escaneo - {objetivo}", show_header=True, header_style="bold red")
        tabla.add_column("Puerto")
        tabla.add_column("Servicio")
        tabla.add_column("Estado")
        tabla.add_column("Vulnerabilidades")
        for res in resultados:
            vulns = detectar_vulnerabilidades(res['puerto'])
            tabla.add_row(
                str(res['puerto']),
                res['servicio'] if res['servicio'] else "Desconocido",
                "[green]ABIERTO[/green]",
                "\n".join([f"[red]{v['CVE']}[/red]: {v['Description']}" for v in vulns])
            )
        console.print(tabla)
    except Exception as e:
        logger.exception("Error en escaneo de puertos")
        console.print(f"[{Fore.RED}!{Fore.RESET}] Error: {str(e)}")

def escanear_puerto(ip, puerto):
    """Intenta conectarse a un puerto específico y retorna el resultado si está abierto."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            resultado = s.connect_ex((ip, puerto))
            if resultado == 0:
                try:
                    servicio = socket.getservbyport(puerto, 'tcp')
                except Exception:
                    servicio = 'Desconocido'
                return {'puerto': puerto, 'servicio': servicio, 'estado': 'open'}
            else:
                return None
    except Exception as e:
        logger.debug(f"Error escaneando puerto {puerto} en {ip}: {e}")
        return None

def parsear_puertos(entrada):
    """Convierte la entrada de puertos (con rangos) en una lista de enteros."""
    puertos = set()
    for parte in entrada.split(','):
        parte = parte.strip()
        if '-' in parte:
            try:
                inicio, fin = map(int, parte.split('-'))
                puertos.update(range(inicio, fin + 1))
            except ValueError:
                continue
        else:
            try:
                puertos.add(int(parte))
            except ValueError:
                continue
    return sorted(puertos)

def detectar_vulnerabilidades(puerto):
    """Devuelve vulnerabilidades conocidas para el puerto indicado."""
    return VULNERABILIDADES.get(puerto, [])

# =========================
# 4. Fuerza Bruta de Puertos
# =========================
def fuerza_bruta_puertos():
    """Realiza un escaneo de fuerza bruta de los 65535 puertos en la IP/Dominio indicado."""
    objetivo = console.input(f"\n[{Fore.YELLOW}?{Fore.RESET}] Introduce la IP/Dominio: ").strip()
    console.print(f"\n[bold red][!] Este proceso puede ser lento y detectable![/bold red]")
    if not confirmar_accion("¿Deseas continuar?"):
        return
    try:
        console.print(f"\n[bold green][*] Escaneando 65535 puertos en {objetivo}...")
        resultados = []
        with Progress(BarColumn(bar_width=None), "[progress.percentage]{task.percentage:>3.0f}%", TimeRemainingColumn()) as progress:
            task = progress.add_task("Escaneando...", total=65535)
            with ThreadPoolExecutor(max_workers=500) as executor:
                futures = {executor.submit(escanear_puerto, objetivo, puerto): puerto for puerto in range(1, 65536)}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    resultado = future.result()
                    if resultado:
                        resultados.append(resultado)
        tabla = Table(title=f"Puertos Abiertos - {objetivo}", show_header=True, header_style="bold yellow")
        tabla.add_column("Puerto")
        tabla.add_column("Servicio")
        tabla.add_column("Vulnerabilidades Detectadas")
        for res in resultados:
            vulns = detectar_vulnerabilidades(res['puerto'])
            tabla.add_row(
                str(res['puerto']),
                res['servicio'] if res['servicio'] else "Desconocido",
                str(len(vulns)) if vulns else "Ninguna"
            )
        console.print(tabla)
    except Exception as e:
        logger.exception("Error en fuerza bruta de puertos")
        console.print(f"[{Fore.RED}!{Fore.RESET}] Error: {str(e)}")

def confirmar_accion(mensaje):
    """Solicita confirmación del usuario para acciones críticas."""
    respuesta = console.input(f"\n[{Fore.YELLOW}?{Fore.RESET}] {mensaje} (s/n): ")
    return respuesta.strip().lower() == 's'

# ================================
# 5. Escaneo de Red de Dispositivos (incluye Cámaras)
# ================================
def escanear_red_dispositivos():
    """
    Realiza un escaneo de la red indicada mediante ping sweep para listar todos los dispositivos activos.
    Para cada host se verifica la apertura de puertos comunes de cámaras y se intenta detectar el tipo.
    """
    red = console.input(f"\n[{Fore.YELLOW}?{Fore.RESET}] Introduce la red (ej: 192.168.1.0/24): ").strip()
    try:
        console.print(f"\n[bold green][*] Escaneando red {red} en busca de dispositivos activos...")
        hosts_activos = escanear_hosts(red)
        dispositivos = []
        with Progress(BarColumn(bar_width=None), "[progress.percentage]{task.percentage:>3.0f}%", TimeRemainingColumn()) as progress:
            task = progress.add_task("Verificando dispositivos...", total=len(hosts_activos))
            with ThreadPoolExecutor(max_workers=50) as executor:
                futures = {executor.submit(verificar_dispositivo, host): host for host in hosts_activos}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    resultado = future.result()
                    if resultado:
                        dispositivos.append(resultado)
        if dispositivos:
            tabla = Table(title="Dispositivos Activos en la Red", show_header=True, header_style="bold red")
            tabla.add_column("IP")
            tabla.add_column("Puertos Abiertos (Cámaras)")
            tabla.add_column("Tipo")
            for disp in dispositivos:
                puertos_str = ", ".join(map(str, disp.get('puertos', []))) if disp.get('puertos') else "Ninguno"
                tabla.add_row(disp['ip'], puertos_str, disp['tipo'])
            console.print(tabla)
        else:
            console.print("[bold yellow][!] No se encontraron dispositivos activos[/bold yellow]")
    except Exception as e:
        logger.exception("Error en escaneo de red")
        console.print(f"[{Fore.RED}!{Fore.RESET}] Error: {str(e)}")

def escanear_hosts(red):
    """Realiza un ping sweep en la red para obtener una lista de hosts activos."""
    try:
        network = ipaddress.ip_network(red, strict=False)
    except ValueError as e:
        console.print(f"[{Fore.RED}!{Fore.RESET}] Red inválida: {e}")
        return []
    hosts = [str(host) for host in network.hosts()]
    activos = []
    sistema = platform.system().lower()
    count_flag = "-c" if sistema != "windows" else "-n"
    timeout_flag = "-W" if sistema != "windows" else "-w"
    timeout_value = "1"
    with Progress(BarColumn(bar_width=None), "[progress.percentage]{task.percentage:>3.0f}%", TimeRemainingColumn()) as progress:
        task = progress.add_task("Buscando hosts...", total=len(hosts))
        with ThreadPoolExecutor(max_workers=100) as executor:
            futures = {executor.submit(ping_host, host, count_flag, timeout_flag, timeout_value): host for host in hosts}
            for future in as_completed(futures):
                progress.update(task, advance=1)
                if future.result():
                    activos.append(futures[future])
    return activos

def ping_host(ip, count_flag, timeout_flag, timeout_value):
    """Realiza un ping a la IP indicada y retorna True si está activo."""
    try:
        comando = ['ping', count_flag, '1', timeout_flag, timeout_value, ip]
        subprocess.check_output(comando, stderr=subprocess.DEVNULL)
        return True
    except subprocess.CalledProcessError:
        return False
    except Exception as e:
        logger.debug(f"Error haciendo ping a {ip}: {e}")
        return False

def verificar_dispositivo(ip):
    """
    Para cada dispositivo activo, se intenta escanear puertos comunes de cámaras.
    Si se detecta algún puerto abierto, se intenta identificar el tipo (HTTP, RTSP).
    Si no hay puertos abiertos de cámaras, se marca como "No Cámara".
    """
    puertos_abiertos = []
    tipo = "No Cámara"
    try:
        for puerto in CAMERA_PORTS:
            if escanear_puerto(ip, puerto):
                puertos_abiertos.append(puerto)
        # Si se detectan puertos, intentar determinar si se trata de una cámara
        if puertos_abiertos:
            for puerto in puertos_abiertos:
                if puerto in [554, 8554]:
                    tipo = "RTSP Camera"
                    break
                if puerto in [80, 8080]:
                    try:
                        resp = requests.get(f"http://{ip}:{puerto}", timeout=3, verify=False)
                        contenido = resp.text.lower()
                        if 'camera' in contenido or any(path in contenido for path in CAMERA_PATHS):
                            tipo = "HTTP Camera"
                            break
                    except Exception:
                        continue
            else:
                tipo = "Dispositivo Activo"
        return {'ip': ip, 'puertos': puertos_abiertos, 'tipo': tipo}
    except Exception as e:
        logger.debug(f"Error verificando dispositivo en {ip}: {e}")
        return {'ip': ip, 'puertos': puertos_abiertos, 'tipo': "Error"}

# ========================
# Función Principal
# ========================
def main():
    """Función principal que gestiona el menú y la ejecución de opciones."""
    mostrar_banner()
    while True:
        mostrar_menu()
        opcion = console.input(f"[{Fore.YELLOW}?{Fore.RESET}] Selecciona una opción: ").strip()
        if opcion == '1':
            geolocalizacion_ip()
        elif opcion == '2':
            analisis_sitio_web()
        elif opcion == '3':
            escaneo_puertos()
        elif opcion == '4':
            fuerza_bruta_puertos()
        elif opcion == '5':
            escanear_red_dispositivos()
        elif opcion == '0':
            console.print(f"\n{Fore.GREEN}[+] Saliendo...")
            sys.exit()
        else:
            console.print(f"[{Fore.RED}!{Fore.RESET}] Opción inválida")
        console.input(f"\n[{Fore.YELLOW}?{Fore.RESET}] Presiona Enter para continuar...")

if __name__ == "__main__":
    main()
