#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import time
import sys
import requests
import socket
import ipaddress
import re
import json
import random
import threading
import subprocess
import platform
import urllib.parse
import ssl
import concurrent.futures
import queue
import logging
import whois
import dns.resolver
from datetime import datetime, timedelta
from colorama import Fore, Back, Style, init
from bs4 import BeautifulSoup
from tqdm import tqdm
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, TaskID
from rich.panel import Panel

# Inicializar colorama
init(autoreset=True)

# Configurar registro de logs
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='ojo_vigilante.log',
    filemode='a'
)

# Crear console Rich para salidas mejoradas
console = Console()

# Variables globales
VERSION = "2.0"
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 11.5; rv:91.0) Gecko/20100101 Firefox/91.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1"
]

COMMON_PORTS = {
    20: "FTP-data", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 
    80: "HTTP", 110: "POP3", 111: "RPCBIND", 135: "MSRPC", 139: "NetBIOS", 
    143: "IMAP", 443: "HTTPS", 445: "SMB", 993: "IMAPS", 995: "POP3S", 
    1723: "PPTP", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 
    8080: "HTTP-Proxy", 8443: "HTTPS-Alt", 27017: "MongoDB", 6379: "Redis",
    5672: "AMQP", 11211: "Memcached", 9200: "Elasticsearch", 9300: "Elasticsearch-Cluster",
    2375: "Docker", 2376: "Docker-TLS", 6443: "Kubernetes-API", 10250: "Kubelet",
    4444: "Metasploit", 1433: "MSSQL", 1521: "Oracle", 9090: "Prometheus", 9092: "Kafka",
    8888: "Jupyter Notebook", 8088: "Hadoop", 7077: "Spark-Master", 8983: "Solr",
    8086: "InfluxDB", 9100: "Node-Exporter", 3000: "Grafana", 9000: "SonarQube",
    6000: "X11", 873: "rsync", 161: "SNMP", 389: "LDAP", 636: "LDAPS"
}

VULNERABILIDADES_CONOCIDAS = {
    "21": [
        {"nombre": "ProFTPD 1.3.5 - 'mod_copy' Command Execution", "cve": "CVE-2015-3306"},
        {"nombre": "vsftpd 2.3.4 - Backdoor Command Execution", "cve": "CVE-2011-2523"}
    ],
    "22": [
        {"nombre": "OpenSSH < 7.7 - Username Enumeration", "cve": "CVE-2018-15473"},
        {"nombre": "OpenSSH 7.2p1 - Authenticated xauth Command Injection", "cve": "CVE-2016-10009"}
    ],
    "23": [
        {"nombre": "Multiple Telnet Implementations - Unspecified Remote Code Execution", "cve": "CVE-2011-4862"}
    ],
    "25": [
        {"nombre": "Exim < 4.90.1 - 'base64d' Remote Command Execution", "cve": "CVE-2018-6789"},
        {"nombre": "Postfix SMTP - 'Shellshock' Remote Command Injection", "cve": "CVE-2014-6271"}
    ],
    "53": [
        {"nombre": "BIND 9 - DNS Cache Poisoning", "cve": "CVE-2008-1447"},
        {"nombre": "BIND 9.x - Denial of Service", "cve": "CVE-2020-8617"}
    ],
    "80": [
        {"nombre": "Apache HTTP Server 2.4.49 - Path Traversal & RCE", "cve": "CVE-2021-41773"},
        {"nombre": "Nginx - Integer Overflow", "cve": "CVE-2017-7529"}
    ],
    "443": [
        {"nombre": "OpenSSL - Heartbleed", "cve": "CVE-2014-0160"},
        {"nombre": "OpenSSL - DROWN Attack", "cve": "CVE-2016-0800"}
    ],
    "445": [
        {"nombre": "Microsoft Windows - SMB Remote Code Execution (EternalBlue)", "cve": "CVE-2017-0144"},
        {"nombre": "Samba - Remote Code Execution", "cve": "CVE-2017-7494"}
    ],
    "3389": [
        {"nombre": "Microsoft Windows Remote Desktop - BlueKeep", "cve": "CVE-2019-0708"}
    ],
    "8080": [
        {"nombre": "Apache Tomcat - Remote Code Execution", "cve": "CVE-2017-12617"},
        {"nombre": "Jenkins - Arbitrary File Read", "cve": "CVE-2018-1000861"}
    ]
}

def mostrar_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    banner = f"""
    {Fore.GREEN}
    ATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULA
TIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONS
CONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGR
ATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULA
TIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONS
CONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGR
ATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULA
TIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONS
CONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGR
ATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULA
TIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONS
CONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGR
ATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULA
TIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONSCONGRATULATIONS
                                                                         {Fore.CYAN}v{VERSION}              
    {Fore.WHITE}Creado por: {Fore.CYAN}CodeCraftsman

    {Fore.GREEN}Bienvenido a 'Ojo Vigilante'!
    {Fore.YELLOW}Una herramienta multifunción para análisis de seguridad, reconocimiento y detección avanzada.
    {Fore.YELLOW}Desarrollada para proporcionar una manera rápida y eficiente de acceder a información crucial.
    """
    print(banner)

def confirmar_accion(mensaje="¿Deseas continuar?"):
    respuesta = input(f"\n{Fore.YELLOW}{mensaje} (s/n): {Fore.WHITE}").lower()
    return respuesta in ['s', 'si', 'yes', 'y']

def obtener_user_agent():
    return random.choice(USER_AGENTS)

def verificar_conectividad():
    try:
        requests.get("https://www.google.com", timeout=5)
        return True
    except requests.RequestException:
        return False

def guardar_resultados(nombre_archivo, datos):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    nombre_archivo = f"{nombre_archivo}_{timestamp}.txt"
    try:
        with open(nombre_archivo, 'w', encoding='utf-8') as f:
            f.write(datos)
        print(f"\n{Fore.GREEN}[✓] Resultados guardados en: {Fore.CYAN}{nombre_archivo}")
        return True
    except Exception as e:
        print(f"\n{Fore.RED}[✗] Error al guardar los resultados: {e}")
        return False

def mostrar_progreso(total, operacion="Procesando"):
    with Progress() as progress:
        task = progress.add_task(f"[cyan]{operacion}...", total=total)
        while not progress.finished:
            progress.update(task, advance=0.5)
            time.sleep(0.05)

def menu_principal():
    mostrar_banner()
    if not verificar_conectividad():
        print(f"\n{Fore.RED}[!] Advertencia: No se detecta conexión a Internet. Algunas funciones pueden no estar disponibles.")

    menu = f"""
    {Fore.CYAN}MENÚ PRINCIPAL - SELECCIONE UNA OPCIÓN:

    {Fore.GREEN}1. {Fore.WHITE}Análisis de Sitio Web
    {Fore.GREEN}2. {Fore.WHITE}Localización por IP
    {Fore.GREEN}3. {Fore.WHITE}Rastreo de perfiles en Redes Sociales
    {Fore.GREEN}4. {Fore.WHITE}Escaneo de Puertos
    {Fore.GREEN}5. {Fore.WHITE}Análisis de Seguridad DNS
    {Fore.GREEN}6. {Fore.WHITE}Detector de Tecnologías Web
    {Fore.GREEN}7. {Fore.WHITE}Verificación de Certificados SSL/TLS
    {Fore.GREEN}8. {Fore.WHITE}Análisis de Subred y Hosts Activos
    {Fore.GREEN}9. {Fore.WHITE}Configuración y Preferencias
    {Fore.GREEN}0. {Fore.WHITE}Salir
    
    {Fore.YELLOW}Digite el número de la opción deseada: {Fore.WHITE}"""
    
    choice = input(menu)
    return choice

def obtener_whois(dominio):
    try:
        return whois.whois(dominio)
    except Exception as e:
        logging.error(f"Error en whois para {dominio}: {e}")
        return None

def verificar_puerto(ip, puerto, timeout=1):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            return s.connect_ex((ip, puerto)) == 0
    except:
        return False

def extraer_metadatos(soup, url):
    metadatos = {}
    if soup.title:
        metadatos['titulo'] = soup.title.string.strip() or "No encontrado"
    meta_desc = soup.find("meta", attrs={"name": "description"})
    metadatos['descripcion'] = meta_desc.get("content", "No encontrado").strip() if meta_desc else "No encontrado"
    meta_keywords = soup.find("meta", attrs={"name": "keywords"})
    metadatos['keywords'] = meta_keywords.get("content", "No encontrado").strip() if meta_keywords else "No encontrado"
    html_tag = soup.find("html")
    metadatos['idioma'] = html_tag.get("lang", "No detectado").strip() if html_tag else "No detectado"
    favicon = soup.find("link", rel=lambda x: x and "icon" in x.lower())
    if favicon:
        href = favicon.get("href", "")
        metadatos['favicon'] = urllib.parse.urljoin(url, href)
    return metadatos

def detectar_tecnologias(response, soup):
    tecnologias = []
    headers = response.headers
    if 'wp-content' in response.text.lower():
        tecnologias.append(("CMS", "WordPress"))
    elif 'joomla' in response.text.lower():
        tecnologias.append(("CMS", "Joomla"))
    server = headers.get('Server', '')
    if server:
        tecnologias.append(("Servidor", server))
    x_powered_by = headers.get('X-Powered-By', '')
    if x_powered_by:
        tecnologias.append(("Tecnología", x_powered_by))
    scripts = soup.find_all("script", src=True)
    for script in scripts:
        src = script['src'].lower()
        if 'jquery' in src:
            tecnologias.append(("JavaScript", "jQuery"))
        elif 'react' in src:
            tecnologias.append(("JavaScript", "React"))
    return tecnologias

def rastrear_sitio():
    mostrar_banner()
    print(f"\n{Fore.CYAN}=== ANÁLISIS DE SITIO WEB ===")
    url = input(f"\n{Fore.YELLOW}Introduce la URL del sitio (ej: ejemplo.com): {Fore.WHITE}")
    if not url.startswith(('http://', 'https://')):
        url = f'https://{url}'
    
    resultados_completos = [f"==== ANÁLISIS DE SITIO WEB: {url} ====", f"Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"]
    tabla_resultados = Table(title=f"Análisis de {url}", show_header=True, header_style="bold cyan")
    tabla_resultados.add_column("Característica")
    tabla_resultados.add_column("Valor")

    try:
        headers = {"User-Agent": obtener_user_agent()}
        response = requests.get(url, headers=headers, timeout=10, verify=False)
        response.raise_for_status()
        
        dominio_base = urllib.parse.urlparse(url).netloc
        ip = socket.gethostbyname(dominio_base)
        tabla_resultados.add_row("IP del servidor", ip)
        resultados_completos.append(f"IP del servidor: {ip}")

        whois_info = obtener_whois(dominio_base)
        if whois_info:
            tabla_resultados.add_row("Registrador", whois_info.registrar or "No disponible")
            tabla_resultados.add_row("Fecha creación", str(whois_info.creation_date) if whois_info.creation_date else "No disponible")

        puertos_abiertos = [puerto for puerto in [80, 443, 22] if verificar_puerto(ip, puerto)]
        tabla_resultados.add_row("Puertos abiertos", ", ".join(map(str, puertos_abiertos)) or "Ninguno")
        
        soup = BeautifulSoup(response.text, 'html.parser')
        metadatos = extraer_metadatos(soup, url)
        for key, value in metadatos.items():
            tabla_resultados.add_row(f"Meta {key.capitalize()}", value)
        
        tecnologias = detectar_tecnologias(response, soup)
        if tecnologias:
            tech_str = "\n".join([f"{tipo}: {nombre}" for tipo, nombre in tecnologias])
            tabla_resultados.add_row("Tecnologías detectadas", tech_str)
        
        enlaces = soup.find_all('a', href=True)
        internos = []
        externos = []
        for enlace in enlaces:
            href = urllib.parse.urljoin(url, enlace['href'])
            parsed = urllib.parse.urlparse(href)
            if parsed.netloc == dominio_base:
                internos.append(href)
            else:
                externos.append(href)
        
        tabla_resultados.add_row("Enlaces internos", f"{len(internos)} encontrados")
        tabla_resultados.add_row("Enlaces externos", f"{len(externos)} encontrados")
        resultados_completos.extend(["\nEnlaces internos:", *internos[:5], "...", "\nEnlaces externos:", *externos[:5], "..."])
        
        console.print(tabla_resultados)
        guardar_resultados("analisis_sitio", "\n".join(resultados_completos))
        
    except Exception as e:
        console.print(f"{Fore.RED}Error durante el análisis: {e}")

def localizar_ip():
    mostrar_banner()
    print(f"\n{Fore.CYAN}=== LOCALIZACIÓN POR IP ===")
    ip = input(f"{Fore.YELLOW}Introduce la dirección IP: {Fore.WHITE}")
    try:
        respuesta = requests.get(f"http://ip-api.com/json/{ip}").json()
        tabla = Table(title=f"Información para {ip}", show_header=True, header_style="bold cyan")
        tabla.add_column("Campo")
        tabla.add_column("Valor")
        campos = ['country', 'regionName', 'city', 'zip', 'lat', 'lon', 'isp', 'org', 'as']
        for campo in campos:
            valor = respuesta.get(campo, "Desconocido")
            tabla.add_row(campo.capitalize(), str(valor))
        console.print(tabla)
        guardar_resultados("localizacion_ip", json.dumps(respuesta, indent=2))
    except Exception as e:
        console.print(f"{Fore.RED}Error: {e}")

def escanear_puertos():
    mostrar_banner()
    print(f"\n{Fore.CYAN}=== ESCANEO DE PUERTOS ===")
    objetivo = input(f"{Fore.YELLOW}Introduce la IP o dominio: {Fore.WHITE}")
    puertos = list(COMMON_PORTS.keys())
    abiertos = []
    console.print(f"\n[bold]Escaneando {objetivo}...[/bold]")
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=100) as executor:
        futures = {executor.submit(verificar_puerto, objetivo, puerto): puerto for puerto in puertos}
        for future in concurrent.futures.as_completed(futures):
            puerto = futures[future]
            if future.result():
                abiertos.append(puerto)
    
    tabla = Table(title=f"Puertos abiertos en {objetivo}", show_header=True)
    tabla.add_column("Puerto")
    tabla.add_column("Servicio")
    for puerto in abiertos:
        tabla.add_row(str(puerto), COMMON_PORTS.get(puerto, "Desconocido"))
    console.print(tabla)
    guardar_resultados("escan_puertos", "\n".join([f"{p}: {COMMON_PORTS.get(p, '')}" for p in abiertos]))

def main():
    while True:
        opcion = menu_principal()
        if opcion == '1':
            rastrear_sitio()
        elif opcion == '2':
            localizar_ip()
        elif opcion == '4':
            escanear_puertos()
        elif opcion == '0':
            print(f"\n{Fore.GREEN}¡Hasta luego!")
            sys.exit()
        else:
            print(f"\n{Fore.RED}Opción no implementada aún.")
        
        if not confirmar_accion("¿Deseas realizar otra operación?"):
            print(f"\n{Fore.GREEN}¡Hasta luego!")
            sys.exit()

if __name__ == "__main__":
    main()