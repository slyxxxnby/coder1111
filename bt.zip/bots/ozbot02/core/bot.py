# bots/core/bot.py
import os
import logging # Para logging
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    filters,
    ConversationHandler,
    PicklePersistence
)
from core import commands # Importa el módulo commands

# --- CONFIGURACIÓN DEL TOKEN ---
# Opción 1: Hardcodear el token directamente aquí (menos seguro, pero solicitado)
# ¡¡¡REEMPLAZA "TU_TOKEN_DE_TELEGRAM_AQUI" CON TU TOKEN REAL!!!
HARDCODED_TELEGRAM_TOKEN = "7644793001:AAFDLDkM_9o9Xryo-gpOaRXykxZ1YQUQUPw"

TELEGRAM_TOKEN = HARDCODED_TELEGRAM_TOKEN

if not TELEGRAM_TOKEN or TELEGRAM_TOKEN == "TU_TOKEN_DE_TELEGRAM_AQUI":
    # Este error se lanzará si no reemplazas el token placeholder.
    # Si el bot falla al iniciar, revisa esta línea.
    raise ValueError(
        "TELEGRAM_BOT_TOKEN no está configurado correctamente. "
        "Por favor, edita bots/core/bot.py y reemplaza 'TU_TOKEN_DE_TELEGRAM_AQUI' con tu token real."
    )

# Estados redefinidos según commands.py (debe coincidir)
(
    URL_SCAN, PORT_SCAN_TARGET, EMAIL_OSINT, 
    PHONE_OSINT, IP_GEOLOCATE, USERNAME_OSINT,
    API_KEY_SERVICE, API_KEY_VALUE
) = range(8)


def start_bot():
    """Construye y ejecuta el bot."""
    
    # Configuración de la persistencia de datos del bot
    # El archivo 'bot_persistence' se creará en el directorio desde donde se ejecuta main.py.
    # Por ejemplo, si ejecutas `python bots/main.py` desde la raíz del proyecto,
    # se creará en `raiz_del_proyecto/bot_persistence`.
    # Si prefieres una ruta fija dentro de la estructura del bot:
    # data_dir = os.path.join(os.path.dirname(__file__), '..', 'data') # bots/data/
    # os.makedirs(data_dir, exist_ok=True) # Asegura que el directorio exista
    # persistence_path = os.path.join(data_dir, "bot_persistence")
    
    # Usar el directorio de trabajo actual para el archivo de persistencia
    persistence_path = os.path.join(os.getcwd(), "bot_persistence")
    logging.info(f"Usando archivo de persistencia en: {persistence_path}")

    persistence = PicklePersistence(filepath=persistence_path)

    # Construcción de la aplicación del bot
    application = (
        ApplicationBuilder()
        .token(TELEGRAM_TOKEN)
        .persistence(persistence)
        .read_timeout(30)       # Timeout para leer respuestas del servidor de Telegram
        .write_timeout(30)      # Timeout para enviar mensajes al servidor de Telegram
        .connect_timeout(30)    # Timeout para establecer la conexión inicial
        .pool_timeout(60)       # Timeout para operaciones en el pool de la aplicación (ej: procesamiento de updates)
        .build()
    )
    
    # --- Handlers de Comandos Principales (no conversacionales) ---
    # Estos comandos se ejecutan directamente sin entrar en un flujo de conversación.
    application.add_handler(CommandHandler("start", commands.start_command))
    application.add_handler(CommandHandler("help", commands.help_command))
    application.add_handler(CommandHandler("my_api_keys", commands.my_api_keys_command))

    # --- Conversation Handlers ---
    # Definen flujos de conversación para comandos más complejos.
    # Cada uno tiene puntos de entrada, estados y puntos de salida (fallbacks).

    conv_url_scan = ConversationHandler(
        entry_points=[CommandHandler("scan_url", commands.scan_url_init)],
        states={
            commands.URL_SCAN: [MessageHandler(filters.TEXT & ~filters.COMMAND, commands.scan_url_process)]
        },
        fallbacks=[CommandHandler("cancel", commands.cancel)],
        persistent=True, name="conv_url_scan" # Nombre para la persistencia del estado de la conversación
    )
    
    conv_port_scan = ConversationHandler(
        entry_points=[CommandHandler("scan_port", commands.scan_port_init)],
        states={
            commands.PORT_SCAN_TARGET: [MessageHandler(filters.TEXT & ~filters.COMMAND, commands.scan_port_process)]
        },
        fallbacks=[CommandHandler("cancel", commands.cancel)],
        persistent=True, name="conv_port_scan"
    )
    
    conv_email_osint = ConversationHandler(
        entry_points=[CommandHandler("osint_email", commands.osint_email_init)],
        states={
            commands.EMAIL_OSINT: [MessageHandler(filters.TEXT & ~filters.COMMAND, commands.osint_email_process)]
        },
        fallbacks=[CommandHandler("cancel", commands.cancel)],
        persistent=True, name="conv_email_osint"
    )

    conv_phone_osint = ConversationHandler(
        entry_points=[CommandHandler("osint_phone", commands.osint_phone_init)],
        states={
            commands.PHONE_OSINT: [MessageHandler(filters.TEXT & ~filters.COMMAND, commands.osint_phone_process)]
        },
        fallbacks=[CommandHandler("cancel", commands.cancel)],
        persistent=True, name="conv_phone_osint"
    )

    conv_ip_geolocate = ConversationHandler(
        entry_points=[CommandHandler("geolocate_ip", commands.geolocate_ip_init)],
        states={
            commands.IP_GEOLOCATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, commands.geolocate_ip_process)]
        },
        fallbacks=[CommandHandler("cancel", commands.cancel)],
        persistent=True, name="conv_ip_geolocate"
    )
    
    conv_username_osint = ConversationHandler( 
        entry_points=[CommandHandler("osint_username", commands.osint_username_init)],
        states={
            commands.USERNAME_OSINT: [MessageHandler(filters.TEXT & ~filters.COMMAND, commands.osint_username_process)]
        },
        fallbacks=[CommandHandler("cancel", commands.cancel)],
        persistent=True, name="conv_username_osint"
    )

    conv_set_api_key = ConversationHandler(
        entry_points=[CommandHandler("set_api_key", commands.set_api_key_start)],
        states={
            commands.API_KEY_SERVICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, commands.set_api_key_service_received)],
            commands.API_KEY_VALUE: [MessageHandler(filters.TEXT & ~filters.COMMAND, commands.set_api_key_value_received)],
        },
        fallbacks=[CommandHandler("cancel", commands.cancel)],
        persistent=True, name="conv_set_api_key"
    )
    
    conv_clear_api_key = ConversationHandler(
        entry_points=[CommandHandler("clear_api_key", commands.clear_api_key_start)],
        states={
            commands.API_KEY_SERVICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, commands.clear_api_key_service_received)],
        },
        fallbacks=[CommandHandler("cancel", commands.cancel)],
        persistent=True, name="conv_clear_api_key"
    )

    # Añadir todos los handlers a la aplicación
    application.add_handler(conv_url_scan)
    application.add_handler(conv_port_scan)
    application.add_handler(conv_email_osint)
    application.add_handler(conv_phone_osint)
    application.add_handler(conv_ip_geolocate)
    application.add_handler(conv_username_osint)
    application.add_handler(conv_set_api_key)
    application.add_handler(conv_clear_api_key)

    # Opcional: Manejador para comandos desconocidos o texto fuera de una conversación activa.
    # Esto podría responder con un mensaje de ayuda o simplemente ignorar.
    # async def unknown(update: Update, context: ContextTypes.DEFAULT_TYPE):
    #     await update.message.reply_text("Lo siento, no entendí ese comando. Escribe /help para ver las opciones.")
    # application.add_handler(MessageHandler(filters.COMMAND | (filters.TEXT & ~filters.COMMAND & ~filters.UpdateType.EDITED_MESSAGE), unknown))


    # Iniciar el bot
    logging.info("🚀 OSINT Bot Ultimate iniciando y conectando a Telegram...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)
    logging.info("🛑 OSINT Bot Ultimate detenido.")

# Este archivo es importado por main.py, que es el punto de entrada principal.
# La función start_bot() es llamada desde main.py.