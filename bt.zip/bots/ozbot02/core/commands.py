from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import ContextTypes, ConversationHandler, CommandHandler, MessageHandler, filters
from telegram.constants import ParseMode

# Importar las clases de herramientas de utils
from utils.url_analyzer_tool import URLAnalyzerTool
from utils.port_scanner_tool import PortScannerTool
from utils.email_osint_tool import EmailOSINTTool
from utils.phone_osint_tool import PhoneOSINTTool
from utils.ip_analyzer import IPAnalyzer
from utils.username_osint_tool import UsernameOSINTTool # Nueva herramienta
from utils.api_manager import get_api_key, set_api_key_user, clear_api_key_user, get_user_configured_keys
from utils.helpers import (
    validate_url, ensure_http_scheme, validate_ip, 
    validate_domain, validate_email, validate_phone
)

# Estados para ConversationHandler (añadir nuevos)
(
    URL_SCAN, PORT_SCAN_TARGET, EMAIL_OSINT, 
    PHONE_OSINT, IP_GEOLOCATE, USERNAME_OSINT,
    API_KEY_SERVICE, API_KEY_VALUE
) = range(8)


# --- Comandos Principales ---
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Envía un mensaje cuando el comando /start es ejecutado."""
    keyboard = [
        ["/scan_url", "/scan_port"],
        ["/osint_email", "/osint_phone"],
        ["/geolocate_ip", "/osint_username"], # Nuevo
        ["/set_api_key", "/my_api_keys"],    # Nuevo
        ["/help", "/cancel"]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)
    
    welcome_text = (
        "🤖 *¡Bienvenido al OSINT Bot Ultimate!* 🕵️‍♂️\n\n"
        "Soy tu asistente para investigaciones de fuentes abiertas. "
        "Usa los comandos de abajo para empezar.\n\n"
        "⚙️ *Configuración Recomendada:*\n"
        "Algunas funciones avanzadas (como HIBP para emails o IPInfo para IPs) "
        "requieren API keys. Configúralas con `/set_api_key`.\n\n"
        "👇 *Selecciona una opción del menú:*"
    )
    await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Muestra información de ayuda."""
    help_text = (
        "🆘 *Ayuda del OSINT Bot Ultimate*\n\n"
        "Aquí tienes los comandos disponibles:\n\n"
        "🔍 *Escaneos e Investigaciones:*\n"
        "  `/scan_url` - Analiza una URL (WHOIS, DNS, SSL, HTTP Headers, etc.)\n"
        "  `/scan_port` - Escanea puertos comunes de un Host/IP.\n"
        "  `/osint_email` - Investiga una dirección de email (HIBP, Gravatar, MX).\n"
        "  `/osint_phone` - Obtiene información de un número de teléfono.\n"
        "  `/geolocate_ip` - Geolocaliza y analiza una IP (IPinfo, GeoLite2).\n"
        "  `/osint_username` - Busca un nombre de usuario en varias plataformas.\n\n"
        "⚙️ *Configuración de API Keys:*\n"
        "  `/set_api_key` - Configura una API key para un servicio (ej: HIBP, IPinfo).\n"
        "  `/my_api_keys` - Muestra los servicios para los que has configurado claves.\n"
        "  `/clear_api_key` - Elimina una API key configurada.\n\n"
        "✨ *Otros Comandos:*\n"
        "  `/start` - Muestra el mensaje de bienvenida y el teclado principal.\n"
        "  `/help` - Muestra este mensaje de ayuda.\n"
        "  `/cancel` - Cancela la operación actual (dentro de una conversación).\n\n"
        "💡 *Consejo:* Para mejores resultados, configura tus API keys.\n"
        "Algunas herramientas pueden tener resultados limitados o usar APIs públicas (con rate-limiting) si no hay claves configuradas."
    )
    await update.message.reply_text(help_text, parse_mode=ParseMode.MARKDOWN)

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Cancela la conversación actual."""
    await update.message.reply_text(
        "Operación cancelada. Puedes iniciar una nueva acción desde el menú.",
        reply_markup=ReplyKeyboardRemove() # Quita el teclado específico si lo hubiera
    )
    # Llama a start para restaurar el teclado principal
    await start_command(update, context)
    return ConversationHandler.END

# --- Gestión de API Keys ---
async def set_api_key_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Inicia la conversación para configurar una API key."""
    await update.message.reply_text(
        "🔑 Por favor, dime para qué servicio quieres configurar la API key.\n"
        "Ejemplos: `hibp`, `ipinfo`.\n"
        "Escribe `/cancel` para abortar."
    )
    return API_KEY_SERVICE

async def set_api_key_service_received(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Recibe el nombre del servicio para la API key."""
    service_name = update.message.text.lower().strip()
    if not service_name or len(service_name) > 20: # Validación simple
        await update.message.reply_text("Nombre de servicio inválido. Inténtalo de nuevo o /cancel.")
        return API_KEY_SERVICE
        
    context.user_data["current_api_service"] = service_name
    await update.message.reply_text(
        f"Perfecto. Ahora envíame la API key para el servicio `{service_name}`.\n"
        "⚠️ *Importante:* Las API keys son sensibles. Asegúrate de estar en un chat privado.\n"
        "Escribe `/cancel` para abortar."
    )
    return API_KEY_VALUE

async def set_api_key_value_received(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Recibe y guarda la API key."""
    api_key = update.message.text.strip()
    service_name = context.user_data.get("current_api_service")

    if not service_name:
        await update.message.reply_text("Error interno, servicio no especificado. Por favor, /cancel y empieza de nuevo.")
        return ConversationHandler.END
    
    if not api_key or " " in api_key: # Validación muy básica
        await update.message.reply_text("API key inválida (no puede estar vacía o contener espacios). Inténtalo de nuevo o /cancel.")
        return API_KEY_VALUE

    set_api_key_user(context, service_name, api_key)
    del context.user_data["current_api_service"] # Limpiar
    
    await update.message.reply_text(
        f"✅ API key para `{service_name}` guardada correctamente para tu usuario.\n"
        "Puedes ver tus claves con /my_api_keys o eliminarla con /clear_api_key."
    )
    await start_command(update, context) # Mostrar menú principal
    return ConversationHandler.END

async def my_api_keys_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Muestra las API keys configuradas por el usuario."""
    user_keys = get_user_configured_keys(context)
    if not user_keys:
        await update.message.reply_text(
            "No tienes ninguna API key configurada a nivel de usuario.\n"
            "Usa `/set_api_key` para añadir una."
        )
        return

    message = "🔑 *Tus API Keys configuradas (solo nombres de servicio):*\n"
    for service in user_keys:
        message += f"  • `{service}`\n"
    message += "\nPara ver el valor de una clave o modificarla, usa `/set_api_key` de nuevo. Para eliminar, `/clear_api_key`."
    await update.message.reply_text(message, parse_mode=ParseMode.MARKDOWN)

async def clear_api_key_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Inicia la conversación para eliminar una API key."""
    user_keys = get_user_configured_keys(context)
    if not user_keys:
        await update.message.reply_text("No tienes API keys configuradas para eliminar. Usa /set_api_key para añadir una.")
        return ConversationHandler.END
        
    services = "\n".join([f"  • `{s}`" for s in user_keys.keys()])
    await update.message.reply_text(
        "🗑️ ¿Qué API key de servicio deseas eliminar?\n"
        f"Tus servicios configurados son:\n{services}\n\n"
        "Escribe el nombre del servicio o /cancel."
    )
    return API_KEY_SERVICE # Reusamos el estado

async def clear_api_key_service_received(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Recibe el servicio y elimina la API key."""
    service_name = update.message.text.lower().strip()
    
    if clear_api_key_user(context, service_name):
        await update.message.reply_text(f"✅ API key para `{service_name}` eliminada correctamente.")
    else:
        await update.message.reply_text(f"⚠️ No se encontró una API key para `{service_name}` o ya fue eliminada.")
    
    await start_command(update, context) # Mostrar menú principal
    return ConversationHandler.END

# --- Funciones de OSINT (Init y Procesamiento) ---

# URL Scan
async def scan_url_init(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("🌐 Por favor, envíame la URL completa que deseas analizar (ej: https://google.com):")
    return URL_SCAN

async def scan_url_process(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    url = update.message.text.strip()
    url = ensure_http_scheme(url)

    if not validate_url(url):
        await update.message.reply_text("URL inválida. Asegúrate de que sea completa (ej: http://dominio.com) e inténtalo de nuevo, o /cancel.")
        return URL_SCAN # Permite reintentar

    await update.message.reply_text("🔎 Analizando URL... Esto puede tardar un momento.", parse_mode=ParseMode.MARKDOWN)
    analyzer = URLAnalyzerTool(url)
    result = await analyzer.analyze()
    
    # Dividir mensajes largos
    if len(result) > 4096:
        parts = [result[i:i + 4090] for i in range(0, len(result), 4090)] # Dejar un pequeño margen
        for part in parts:
            await update.message.reply_text(part, parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(result, parse_mode=ParseMode.MARKDOWN)
    
    await start_command(update, context) # Mostrar menú principal
    return ConversationHandler.END

# Port Scan
async def scan_port_init(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("🔌 Envíame la IP o dominio para escanear puertos (ej: google.com o 8.8.8.8):")
    return PORT_SCAN_TARGET

async def scan_port_process(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    target = update.message.text.strip()
    if not (validate_ip(target) or validate_domain(target)):
        await update.message.reply_text("Objetivo inválido. Debe ser una IP o un dominio válido. Inténtalo de nuevo, o /cancel.")
        return PORT_SCAN_TARGET

    await update.message.reply_text(f"🛠️ Escaneando puertos comunes en `{target}`... Esto puede tardar.", parse_mode=ParseMode.MARKDOWN)
    scanner = PortScannerTool(target)
    result = await scanner.scan_common_ports()
    await update.message.reply_text(result, parse_mode=ParseMode.MARKDOWN)
    
    await start_command(update, context)
    return ConversationHandler.END

# Email OSINT
async def osint_email_init(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("📧 Envíame la dirección de email a investigar:")
    return EMAIL_OSINT

async def osint_email_process(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    email = update.message.text.strip()
    if not validate_email(email):
        await update.message.reply_text("Email inválido. Por favor, introduce un formato correcto (ej: usuario@dominio.com), o /cancel.")
        return EMAIL_OSINT

    await update.message.reply_text(f"🕵️‍♀️ Investigando email `{email}`... Un momento, por favor.", parse_mode=ParseMode.MARKDOWN)
    # Pasamos 'context' para que la herramienta pueda acceder a las API keys
    investigator = EmailOSINTTool(email, context) 
    result = await investigator.investigate()
    await update.message.reply_text(result, parse_mode=ParseMode.MARKDOWN)
    
    await start_command(update, context)
    return ConversationHandler.END

# Phone OSINT
async def osint_phone_init(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("📱 Envíame el número de teléfono a investigar (incluye código de país, ej: +1234567890):")
    return PHONE_OSINT

async def osint_phone_process(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    phone = update.message.text.strip()
    if not validate_phone(phone): # phonenumbers es bastante robusto
        await update.message.reply_text(
            "Número de teléfono inválido o formato no reconocido. "
            "Asegúrate de incluir el código de país (ej: +1234567890). Inténtalo de nuevo, o /cancel."
        )
        return PHONE_OSINT

    await update.message.reply_text(f"📞 Investigando número `{phone}`... Esto puede ser rápido.", parse_mode=ParseMode.MARKDOWN)
    investigator = PhoneOSINTTool(phone)
    result = await investigator.investigate()
    await update.message.reply_text(result, parse_mode=ParseMode.MARKDOWN)
    
    await start_command(update, context)
    return ConversationHandler.END

# IP Geolocation / Analysis
async def geolocate_ip_init(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("🌍 Envíame la dirección IP a analizar (ej: 8.8.8.8):")
    return IP_GEOLOCATE

async def geolocate_ip_process(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    ip = update.message.text.strip()
    if not validate_ip(ip):
        await update.message.reply_text("Dirección IP inválida. Inténtalo de nuevo, o /cancel.")
        return IP_GEOLOCATE

    await update.message.reply_text(f"🗺️ Analizando IP `{ip}`... Un momento.", parse_mode=ParseMode.MARKDOWN)
    # Pasamos 'context' para que la herramienta pueda acceder a las API keys
    analyzer = IPAnalyzer(ip, context)
    result = await analyzer.analyze()
    await update.message.reply_text(result, parse_mode=ParseMode.MARKDOWN)
    
    await start_command(update, context)
    return ConversationHandler.END

# Username OSINT (Nuevo)
async def osint_username_init(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("👤 Por favor, envíame el nombre de usuario que deseas buscar en plataformas online:")
    return USERNAME_OSINT

async def osint_username_process(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    username = update.message.text.strip()
    if not username or len(username) < 2 or " " in username: # Validación simple
        await update.message.reply_text(
            "Nombre de usuario inválido (demasiado corto o contiene espacios). Inténtalo de nuevo, o /cancel."
        )
        return USERNAME_OSINT

    await update.message.reply_text(f"👥 Buscando `{username}` en plataformas... Esto puede llevar un tiempo.", parse_mode=ParseMode.MARKDOWN)
    tool = UsernameOSINTTool(username)
    result = await tool.search()
    await update.message.reply_text(result, parse_mode=ParseMode.MARKDOWN)
    
    await start_command(update, context)
    return ConversationHandler.END