import os
from dotenv import load_dotenv

# Cargar variables de entorno desde .env si existe
load_dotenv()

# API Keys (pueden ser configuradas por el usuario o desde .env)
# Usaremos context.bot_data para almacenar las claves por chat/usuario si es necesario,
# o context.application.bot_data para claves globales si se configuran vía bot.

DEFAULT_API_KEYS = {
    "hibp": os.getenv("HIBP_API_KEY"),
    "ipinfo": os.getenv("IPINFO_API_KEY"),
    # Añade más servicios aquí
}

def get_api_key(context, service_name: str) -> str | None:
    """
    Obtiene la API key para un servicio.
    Prioriza la clave configurada por el usuario, luego la global, luego .env.
    """
    user_keys = context.user_data.get("api_keys", {})
    bot_global_keys = context.application.bot_data.get("api_keys", {})
    
    key = user_keys.get(service_name)
    if key:
        return key
    
    key = bot_global_keys.get(service_name)
    if key:
        return key
        
    return DEFAULT_API_KEYS.get(service_name)

def set_api_key_user(context, service_name: str, api_key: str):
    """Establece una API key específica para el usuario."""
    if "api_keys" not in context.user_data:
        context.user_data["api_keys"] = {}
    context.user_data["api_keys"][service_name] = api_key

def set_api_key_global(context, service_name: str, api_key: str):
    """Establece una API key global para el bot (usualmente por el admin)."""
    if "api_keys" not in context.application.bot_data:
        context.application.bot_data["api_keys"] = {}
    context.application.bot_data["api_keys"][service_name] = api_key

def clear_api_key_user(context, service_name: str):
    """Limpia una API key específica del usuario."""
    if "api_keys" in context.user_data and service_name in context.user_data["api_keys"]:
        del context.user_data["api_keys"][service_name]
        return True
    return False

def get_user_configured_keys(context) -> dict:
    return context.user_data.get("api_keys", {})