import phonenumbers
from phonenumbers import carrier, geocoder, timezone
import requests
from bs4 import BeautifulSoup
import socket
import geoip2.database
import os
from urllib.parse import quote
import asyncio

class EmailOSINT:
    def __init__(self, email):
        self.email = email
        
    async def investigate(self):
        try:
            # Basic email validation
            if '@' not in self.email:
                return "❌ Formato de email inválido"
                
            username, domain = self.email.split('@')
            
            # Check domain info
            domain_info = {}
            try:
                import whois
                domain_info = whois.whois(domain)
            except:
                pass
                
            # Check if email appears in breaches
            breach_info = await self._check_breaches()
            
            # Find social media profiles
            social_media = await self._find_social_media()
            
            # Format results
            result = f"""
            *📧 OSINT Results for {self.email}*
            
            *📌 Domain Information:*
            ```{domain_info}```
            
            *🛡️ Breach Check:*
            {breach_info}
            
            *📱 Possible Social Media Profiles:*
            {social_media}
            """
            return result
            
        except Exception as e:
            return f"❌ Error investigating email: {str(e)}"
            
    async def _check_breaches(self):
        try:
            # This would typically use the HaveIBeenPwned API, but we'll simulate it
            return "ℹ️ No known breaches found (simulated result)"
        except:
            return "⚠️ Could not check breaches"
            
    async def _find_social_media(self):
        try:
            # Simulate searching social media
            return "ℹ️ Possible profiles found on Facebook, LinkedIn (simulated)"
        except:
            return "⚠️ Could not search social media"

class PhoneOSINT:
    def __init__(self, phone):
        self.phone = phone
        
    async def investigate(self):
        try:
            # Parse phone number
            parsed = phonenumbers.parse(self.phone, None)
            if not phonenumbers.is_valid_number(parsed):
                return "❌ Número telefónico inválido"
                
            # Get carrier info
            carrier_name = carrier.name_for_number(parsed, "en")
            
            # Get geographic info
            region = geocoder.description_for_number(parsed, "en")
            time_zone = timezone.time_zones_for_number(parsed)
            
            # Format results
            result = f"""
            *📱 OSINT Results for {self.phone}*
            
            *📞 Carrier:*
            {carrier_name}
            
            *📍 Region:*
            {region}
            
            *⏰ Time Zone:*
            {time_zone}
            """
            return result
            
        except Exception as e:
            return f"❌ Error investigating phone number: {str(e)}"

class IPGeolocator:
    def __init__(self, ip):
        self.ip = ip
        
    async def locate(self):
        try:
            # Validate IP
            try:
                socket.inet_aton(self.ip)
            except socket.error:
                return "❌ Dirección IP inválida"
                
            # Get geolocation (using free GeoLite2 database)
            # Note: In a real implementation, you'd need to download the GeoLite2 database
            # from MaxMind and place it in the utils folder
            
            # Simulating geolocation
            country = "Simulated Country"
            city = "Simulated City"
            isp = "Simulated ISP"
            org = "Simulated Organization"
            
            # Format results
            result = f"""
            *🌍 Geolocation Results for {self.ip}*
            
            *📍 Country:*
            {country}
            
            *🏙️ City:*
            {city}
            
            *📡 ISP:*
            {isp}
            
            *🏢 Organization:*
            {org}
            """
            return result
            
        except Exception as e:
            return f"❌ Error geolocating IP: {str(e)}"