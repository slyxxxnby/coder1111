import phonenumbers
from phonenumbers import carrier, geocoder, timezone
from .helpers import format_dict_for_markdown
import asyncio

class PhoneOSINTTool:
    def __init__(self, phone_number: str):
        self.phone_number_str = phone_number
        self.parsed_number = None

    async def investigate(self) -> str:
        try:
            # phonenumbers no es async, ejecutar en executor
            loop = asyncio.get_running_loop()
            self.parsed_number = await loop.run_in_executor(None, phonenumbers.parse, self.phone_number_str, None) # None para inferir país si no hay código
            
            if not await loop.run_in_executor(None, phonenumbers.is_valid_number, self.parsed_number):
                return f"❌ Número telefónico '{self.phone_number_str}' inválido o no reconocido."
        except phonenumbers.phonenumberutil.NumberParseException as e:
            return f"❌ Error al parsear el número: {str(e)}. Asegúrate de incluir el código de país (ej: +1234567890)."
        except Exception as e:
            return f"❌ Error inesperado con el número: {str(e)}"

        results = {"numero_original": self.phone_number_str}
        
        # Ejecutar operaciones bloqueantes en executor
        tasks_data = await asyncio.gather(
            loop.run_in_executor(None, self._get_basic_info),
            loop.run_in_executor(None, self._get_carrier_info),
            loop.run_in_executor(None, self._get_geo_info),
            loop.run_in_executor(None, self._get_timezone_info),
            self._search_online_simulation() # Esta es async
        )

        results["informacion_basica"] = tasks_data[0]
        results["operador"] = tasks_data[1]
        results["geografica"] = tasks_data[2]
        results["zona_horaria"] = tasks_data[3]
        results["busqueda_online_simulada"] = tasks_data[4]
        
        return self._format_results(results)

    def _get_basic_info(self):
        return {
            "formato_e164": phonenumbers.format_number(self.parsed_number, phonenumbers.PhoneNumberFormat.E164),
            "formato_internacional": phonenumbers.format_number(self.parsed_number, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
            "formato_nacional": phonenumbers.format_number(self.parsed_number, phonenumbers.PhoneNumberFormat.NATIONAL),
            "tipo_numero": phonenumbers.number_type(self.parsed_number), # Devuelve un int, se podría mapear a string
            "es_posible": phonenumbers.is_possible_number(self.parsed_number),
        }

    def _get_carrier_info(self):
        c = carrier.name_for_number(self.parsed_number, "es") # "es" para español si está disponible
        if not c:
            c = carrier.name_for_number(self.parsed_number, "en") # Fallback a inglés
        return {"nombre_operador": c if c else "Desconocido"}

    def _get_geo_info(self):
        g = geocoder.description_for_number(self.parsed_number, "es")
        if not g:
            g = geocoder.description_for_number(self.parsed_number, "en")
        return {"region_descripcion": g if g else "Desconocida"}

    def _get_timezone_info(self):
        tz = timezone.time_zones_for_number(self.parsed_number)
        return {"zonas_horarias_posibles": tz if tz else ["Desconocida"]}
        
    async def _search_online_simulation(self):
        # Simulación de búsqueda. En la realidad, esto es complejo.
        # Se podrían usar dorks de Google: "numero_telefono"
        # O verificar APIs de Truecaller, etc. (requieren acceso especial)
        numero_e164 = phonenumbers.format_number(self.parsed_number, phonenumbers.PhoneNumberFormat.E164)
        dorks = [
            f"https://www.google.com/search?q=%22{numero_e164}%22",
            f"https://www.google.com/search?q=site%3Alinkedin.com%20%22{self.phone_number_str}%22", # Para números sin formato E164
            # Podríamos añadir más dorks para Facebook, etc.
        ]
        return {
            "mensaje": "Esto es una simulación. Una búsqueda real es más compleja.",
            "sugerencia_google_dorks": dorks,
            "nota": "Ten cuidado al hacer click en enlaces de búsqueda, especialmente para números."
        }

    def _format_results(self, results: dict) -> str:
        output = f"📱 *OSINT Avanzado para Número Telefónico:* `{results['numero_original']}`\n\n"
        
        if "informacion_basica" in results:
            output += f"ℹ️ *Información Básica:*\n```\n{format_dict_for_markdown(results['informacion_basica'])}\n```\n"
        if "operador" in results:
            output += f"📡 *Operador:*\n```\n{format_dict_for_markdown(results['operador'])}\n```\n"
        if "geografica" in results:
            output += f"🌍 *Información Geográfica:*\n```\n{format_dict_for_markdown(results['geografica'])}\n```\n"
        if "zona_horaria" in results:
            output += f"⏰ *Zona Horaria:*\n```\n{format_dict_for_markdown(results['zona_horaria'])}\n```\n"
        if "busqueda_online_simulada" in results:
            output += f"🕵️ *Búsqueda Online (Simulación):*\n"
            output += f"`{results['busqueda_online_simulada'].get('mensaje', '')}`\n"
            output += f"Sugerencia: `{results['busqueda_online_simulada'].get('sugerencia_google_dorks', [])[0]}` (y otros)\n" # Mostrar un dork
            output += f"Nota: `{results['busqueda_online_simulada'].get('nota', '')}`\n"

        output += "\n_La información de operador y geográfica puede no ser 100% precisa, especialmente para números portados o VoIP._"
        return output