# bots/utils/port_scanner_tool.py
import socket
from scapy.all import sr1, IP, TCP, ICMP
import asyncio

class PortScannerTool:
    def __init__(self, target: str):
        self.target = target
        self.ip_address = None

    async def _resolve_target(self) -> bool:
        """Resuelve el objetivo a una IP. Retorna True si es exitoso, False si no."""
        try:
            # Primero, intenta ver si ya es una IP válida
            socket.inet_aton(self.target)
            self.ip_address = self.target
            return True
        except socket.error:
            # Si no es una IP, intenta resolver como hostname
            try:
                loop = asyncio.get_running_loop()
                self.ip_address = await loop.run_in_executor(None, socket.gethostbyname, self.target)
                return True
            except socket.gaierror: # Error de resolución de nombre
                return False
            except Exception: # Otro error inesperado
                return False
        except Exception: # Otro error inesperado en la validación inicial de IP
            return False


    async def _ping_host(self) -> bool:
        """Intenta un ping ICMP para ver si el host está activo."""
        if not self.ip_address:
            return False
        try:
            # print(f"Pinging {self.ip_address}...")
            # Scapy necesita root/admin para enviar paquetes raw en algunos OS.
            ans = await asyncio.to_thread(sr1, IP(dst=self.ip_address)/ICMP(), timeout=1, verbose=0)
            # print(f"Ping response: {ans}")
            return ans is not None
        except Exception as e:
            # print(f"Error en ping a {self.ip_address}: {e}")
            return True # Asumir que está activo si el ping falla (podría estar bloqueado por firewall)

    async def scan_port(self, port: int, timeout: float = 0.7) -> tuple[int, str] | None: # Timeout reducido
        """Escanea un puerto individual usando Scapy."""
        if not self.ip_address:
            return None
        try:
            pkt = IP(dst=self.ip_address)/TCP(dport=port, flags="S") # SYN packet
            # Usar asyncio.to_thread para la operación bloqueante de Scapy
            resp = await asyncio.to_thread(sr1, pkt, timeout=timeout, verbose=0)

            if resp is not None and resp.haslayer(TCP):
                tcp_layer = resp.getlayer(TCP)
                if tcp_layer.flags == 0x12:  # SYN-ACK (Puerto Abierto)
                    # Enviar RST para cerrar la conexión "limpiamente"
                    # Esto es opcional pero buena práctica.
                    rst_pkt = IP(dst=self.ip_address)/TCP(dport=port, sport=tcp_layer.ack, seq=tcp_layer.ack, ack=tcp_layer.seq + 1, flags="R")
                    await asyncio.to_thread(sr1, rst_pkt, timeout=0.2, verbose=0)
                    
                    try:
                        service_name = await asyncio.to_thread(socket.getservbyport, port, "tcp")
                    except OSError:
                        service_name = "Desconocido"
                    return port, service_name
                # Podríamos chequear otros flags como RST (0x14) para cerrado, pero nos enfocamos en abiertos.
        except RuntimeError as e: # Puede ocurrir si Scapy no tiene permisos o loop de eventos
            # print(f"RuntimeError escaneando puerto {port} en {self.ip_address}: {e}")
            pass # Continuar con otros puertos
        except Exception as e: # Captura general para otros errores
            # print(f"Error inesperado escaneando puerto {port} en {self.ip_address}: {e}")
            pass
        return None

    async def scan_common_ports(self) -> str:
        if not await self._resolve_target(): # Primero resolvemos
             return f"❌ Error: No se pudo resolver el objetivo '{self.target}' a una dirección IP."

        # print(f"Escaneando {self.target} (IP: {self.ip_address})")

        # host_is_up = await self._ping_host() # Ping es opcional, puede dar falsos negativos
        # if not host_is_up:
        #     ping_message = f"⚠️ *Advertencia:* El host `{self.ip_address}` no respondió al ping ICMP (podría estar bloqueado).\nSe intentará el escaneo TCP de todas formas.\n\n"
        # else:
        #     ping_message = f"✅ El host `{self.ip_address}` respondió al ping ICMP.\n\n"
        ping_message = "" # Desactivar mensaje de ping por ahora para brevedad


        common_ports = [
            20, 21, 22, 23, 25, 53, 80, 110, 111, 135, 137,138, 139, 143, 161, 162,
            389, 443, 445, 465, 512, 513, 514, 587, 636,
            990, 993, 995, 1080, 1433, 1521, 1723, 2049,
            3306, 3389, 5060, 5432, 5900, 5901, 6000, 6001, 
            6379, 8000, 8008, 8080, 8081, 8443, 9000, 9090, 9200, 9300,
            11211, 27017, 27018, 28017
        ] # Lista más extensa

        results = {"target": self.target, "ip_address": self.ip_address, "open_ports": {}}
        
        # print(f"Iniciando escaneo de {len(common_ports)} puertos comunes para {self.ip_address}...")
        tasks = [self.scan_port(port) for port in common_ports]
        open_port_results = await asyncio.gather(*tasks) # Ejecuta todos los escaneos de puerto en paralelo

        found_open_ports = False
        for res in open_port_results:
            if res:
                port, service = res
                results["open_ports"][port] = service
                found_open_ports = True
        
        # print(f"Escaneo completado. Puertos abiertos: {results['open_ports']}")
        return self._format_results(results, ping_message, found_open_ports)

    def _format_results(self, results: dict, ping_message: str, found_open_ports: bool) -> str:
        output = f"🔌 *Resultados del Escaneo de Puertos para:* `{results['target']}` (IP: `{results['ip_address']}`)\n\n"
        # output += ping_message # Desactivado por ahora

        if found_open_ports:
            output += "🟢 *Puertos Abiertos Detectados:*\n"
            sorted_ports = sorted(results["open_ports"].keys())
            for port in sorted_ports:
                service = results["open_ports"][port]
                output += f"  • `Puerto {str(port).ljust(5)}` ({service})\n"
        else:
            output += "⚫ *No se detectaron puertos abiertos en la lista común escaneada o el host es inaccesible.*\n"
        
        output += "\n_Escaneo realizado con Scapy sobre puertos comunes. Para un análisis exhaustivo, considera herramientas como Nmap._\n"
        output += "_Nota: El éxito del escaneo puede depender de permisos (ej. root/admin para Scapy en algunos SO) y firewalls._"
        return output