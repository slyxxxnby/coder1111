import hashlib
import asyncio
from .helpers import format_dict_for_markdown, make_async_request
from .api_manager import get_api_key
import aiohttp
import dns.resolver # Para MX records

class EmailOSINTTool:
    def __init__(self, email: str, context):
        self.email = email
        self.username, self.domain = email.split('@', 1) if '@' in email else (None, None)
        self.context = context # Para acceder a API keys

    async def investigate(self) -> str:
        if not self.domain:
            return "📧 Email inválido: no contiene '@'."

        results = {"email": self.email}
        hibp_api_key = get_api_key(self.context, "hibp")

        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
            tasks = [
                self._check_hibp(session, hibp_api_key),
                self._check_gravatar(session),
                self._get_mx_records(),
                self._search_social_media_simulation() # Simulación por ahora
            ]
            (hibp_data, gravatar_data, mx_records, 
             social_media_sim) = await asyncio.gather(*tasks, return_exceptions=True)

            results["breach_check (HIBP)"] = hibp_data if not isinstance(hibp_data, Exception) else f"Error: {hibp_data}"
            results["gravatar"] = gravatar_data if not isinstance(gravatar_data, Exception) else f"Error: {gravatar_data}"
            results["mx_records"] = mx_records if not isinstance(mx_records, Exception) else f"Error: {mx_records}"
            results["social_media_simulation"] = social_media_sim if not isinstance(social_media_sim, Exception) else f"Error: {social_media_sim}"
            
        return self._format_results(results)

    async def _check_hibp(self, session: aiohttp.ClientSession, api_key: str | None):
        if not api_key:
            return {"status": "API Key de HIBP no configurada. No se puede verificar."}
        
        headers = {"hibp-api-key": api_key, "user-agent": "OSINTTelegramBot"}
        url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{self.email}?truncateResponse=false"
        
        response_data = await make_async_request(session, "GET", url, headers=headers)

        if response_data is None: # Indica error en la petición o 404
             return {"status": "No encontrado en brechas conocidas (o error de API)."}
        if isinstance(response_data, list) and len(response_data) > 0:
             return {"status": "ENCONTRADO en brechas!", "breaches": [item.get("Name") for item in response_data]}
        
        return {"status": "Error desconocido al verificar HIBP o formato de respuesta inesperado."}


    async def _check_gravatar(self, session: aiohttp.ClientSession):
        email_hash = hashlib.md5(self.email.lower().encode('utf-8')).hexdigest()
        gravatar_url = f"https://www.gravatar.com/avatar/{email_hash}?d=404" # d=404 para que devuelva error si no existe
        profile_url = f"https://www.gravatar.com/{email_hash}"
        try:
            async with session.get(gravatar_url, timeout=5) as response:
                if response.status == 200:
                    return {"status": "Perfil Gravatar encontrado.", "profile_image_url": gravatar_url, "profile_url": profile_url}
                else:
                    return {"status": "Perfil Gravatar no encontrado."}
        except Exception as e:
            return {"error": f"Error verificando Gravatar: {str(e)}"}

    async def _get_mx_records(self):
        try:
            loop = asyncio.get_running_loop()
            answers = await loop.run_in_executor(None, dns.resolver.resolve, self.domain, 'MX')
            return [f"{r.preference} {r.exchange.to_text()}" for r in answers]
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
            return ["No se encontraron registros MX."]
        except Exception as e:
            return [f"Error obteniendo MX: {str(e)}"]
            
    async def _search_social_media_simulation(self):
        # Esta es una simulación. Una búsqueda real requeriría APIs o scraping complejo.
        # Podrías usar Google Dorks aquí:
        # "nombredeusuario" site:twitter.com OR site:facebook.com OR site:linkedin.com/in/
        # O herramientas como Sherlock (pero integrarlas es más complejo)
        possible_sites = ["Twitter", "Facebook", "LinkedIn", "Instagram"]
        found_on = []
        # Simulación simple
        if len(self.username) > 4 : # Usuarios muy cortos son menos probables
            if any(char.isdigit() for char in self.username):
                 found_on.append(possible_sites[0]) # Twitter
                 found_on.append(possible_sites[3]) # Instagram
            else:
                 found_on.append(possible_sites[1]) # Facebook
                 found_on.append(possible_sites[2]) # LinkedIn
        
        if found_on:
            return {"status": "Posiblemente encontrado en (simulación):", "sites": found_on, "suggestion": "Intenta buscar manualmente el username en estas plataformas."}
        return {"status": "Simulación no arrojó coincidencias probables."}


    def _format_results(self, results: dict) -> str:
        output = f"📧 *OSINT Avanzado para Email:* `{results['email']}`\n\n"
        
        if "mx_records" in results:
            output += f"📬 *Registros MX para {self.domain}:*\n`{results['mx_records']}`\n\n"

        if "breach_check (HIBP)" in results:
            hibp = results["breach_check (HIBP)"]
            output += f"🏴‍☠️ *Comprobación de Brechas (HaveIBeenPwned):*\n"
            if isinstance(hibp, dict):
                output += f"  Status: `{hibp.get('status', 'N/A')}`\n"
                if "breaches" in hibp:
                    output += "  Brechas: \n"
                    for breach_name in hibp["breaches"][:5]: # Mostrar hasta 5
                        output += f"    - `{breach_name}`\n"
                    if len(hibp["breaches"]) > 5:
                        output += f"    - ... y {len(hibp['breaches']) - 5} más.\n"
            else:
                output += f"  `{str(hibp)}`\n"
            output += "\n"

        if "gravatar" in results:
            grav = results["gravatar"]
            output += f"👤 *Gravatar:*\n"
            if isinstance(grav, dict):
                output += f"  Status: `{grav.get('status', 'N/A')}`\n"
                if "profile_url" in grav:
                    output += f"  Perfil: {grav['profile_url']}\n" # No en ``` para que sea clickeable
            else:
                output += f"  `{str(grav)}`\n"
            output += "\n"
            
        if "social_media_simulation" in results:
            social = results["social_media_simulation"]
            output += f"📱 *Búsqueda Simulada en Redes Sociales (username: `{self.username}`):*\n"
            if isinstance(social, dict):
                output += f"  Status: `{social.get('status', 'N/A')}`\n"
                if "sites" in social:
                    output += f"  Posibles plataformas: `{', '.join(social['sites'])}`\n"
                if "suggestion" in social:
                    output += f"  Sugerencia: `{social['suggestion']}`\n"
            else:
                output += f"  `{str(social)}`\n"
            output += "\n"
            
        output += "_Recuerda verificar la información manualmente. La precisión de HIBP depende de su API key._"
        return output