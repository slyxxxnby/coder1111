import socket
import asyncio
from .helpers import format_dict_for_markdown, make_async_request
from .api_manager import get_api_key
import aiohttp
import geoip2.database # Para GeoLite2 local
import os

# Ruta a la base de datos GeoLite2. El usuario debe descargarla y colocarla.
# Ejemplo: https://dev.maxmind.com/geoip/geolite2-free-geolocation-data
GEOLITE_DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'GeoLite2-City.mmdb')


class IPAnalyzer:
    def __init__(self, ip_address: str, context):
        self.ip_address = ip_address
        self.context = context

    async def analyze(self) -> str:
        results = {"ip_address": self.ip_address}
        
        # 1. Intenta con API de IPinfo si hay clave
        ipinfo_api_key = get_api_key(self.context, "ipinfo")
        if ipinfo_api_key:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
                ipinfo_data = await self._get_ipinfo_data(session, ipinfo_api_key)
                if ipinfo_data and "error" not in ipinfo_data:
                    results["ipinfo_api"] = ipinfo_data
                    return self._format_results(results) # Si IPinfo funciona, es suficiente
        
        # 2. Fallback a API pública de ip-api.com (sin clave, rate limited)
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
            ip_api_data = await self._get_ip_api_com_data(session)
            if ip_api_data and "status" in ip_api_data and ip_api_data["status"] == "success":
                results["ip_api_com"] = ip_api_data
                # No retornamos aquí para intentar también GeoLite2 si está disponible
            else:
                results["ip_api_com"] = {"error": "No se pudo obtener información de ip-api.com"}

        # 3. Intenta con GeoLite2 local si la base de datos existe
        if os.path.exists(GEOLITE_DB_PATH):
            geolite_data = await self._get_geolite_data()
            if geolite_data and "error" not in geolite_data:
                 results["geolite2_local"] = geolite_data
        else:
            results["geolite2_local"] = {"info": "Base de datos GeoLite2 no encontrada en data/GeoLite2-City.mmdb"}
            
        # 4. Reverse DNS
        reverse_dns_data = await self._get_reverse_dns()
        if reverse_dns_data:
            results["reverse_dns"] = reverse_dns_data
            
        return self._format_results(results)

    async def _get_ipinfo_data(self, session: aiohttp.ClientSession, api_key: str):
        url = f"https://ipinfo.io/{self.ip_address}?token={api_key}"
        data = await make_async_request(session, "GET", url)
        if data and isinstance(data, dict): # Asegurar que es un diccionario
            # Simplificar un poco la salida de IPinfo
            return {
                "ip": data.get("ip"),
                "hostname": data.get("hostname"),
                "city": data.get("city"),
                "region": data.get("region"),
                "country": data.get("country"),
                "loc": data.get("loc"), # Lat/Lon
                "org": data.get("org"), # Organización (ISP)
                "postal": data.get("postal"),
                "timezone": data.get("timezone"),
            }
        return {"error": "No se pudo obtener datos de IPinfo.io o respuesta inesperada."}

    async def _get_ip_api_com_data(self, session: aiohttp.ClientSession):
        # API pública, sin clave, con limitaciones de tasa
        url = f"http://ip-api.com/json/{self.ip_address}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query"
        data = await make_async_request(session, "GET", url)
        if data and isinstance(data, dict): # Asegurar que es un diccionario
            return data
        return {"error": "No se pudo obtener datos de ip-api.com o respuesta inesperada."}
        
    async def _get_geolite_data(self):
        try:
            loop = asyncio.get_running_loop()
            # geoip2 es bloqueante
            def read_db():
                with geoip2.database.Reader(GEOLITE_DB_PATH) as reader:
                    response = reader.city(self.ip_address)
                return {
                    "country_code": response.country.iso_code,
                    "country_name": response.country.name,
                    "city_name": response.city.name,
                    "postal_code": response.postal.code,
                    "latitude": response.location.latitude,
                    "longitude": response.location.longitude,
                    "timezone": response.location.time_zone,
                    "isp": response.traits.isp if response.traits.isp else "N/A",
                    "organization": response.traits.organization if response.traits.organization else "N/A"
                }
            return await loop.run_in_executor(None, read_db)
        except geoip2.errors.AddressNotFoundError:
            return {"error": "IP no encontrada en la base de datos GeoLite2."}
        except Exception as e:
            return {"error": f"Error con GeoLite2: {str(e)}"}

    async def _get_reverse_dns(self):
        try:
            loop = asyncio.get_running_loop()
            # socket.gethostbyaddr es bloqueante
            hostname, _, _ = await loop.run_in_executor(None, socket.gethostbyaddr, self.ip_address)
            return {"hostname": hostname}
        except socket.herror:
            return {"hostname": "No se pudo resolver (o no existe PTR)."}
        except Exception as e:
            return {"error": f"Error en DNS inverso: {str(e)}"}

    def _format_results(self, all_results: dict) -> str:
        output = f"🗺️ *Análisis Avanzado de IP:* `{all_results['ip_address']}`\n\n"

        if "ipinfo_api" in all_results and "error" not in all_results["ipinfo_api"]:
            output += f"🌐 *Información de IPinfo.io (API Key):*\n```\n{format_dict_for_markdown(all_results['ipinfo_api'])}\n```\n"
        elif "ip_api_com" in all_results and "error" not in all_results["ip_api_com"]:
            output += f"🌍 *Información de ip-api.com (Pública):*\n```\n{format_dict_for_markdown(all_results['ip_api_com'])}\n```\n"
        
        if "geolite2_local" in all_results:
            output += f"🏠 *Información de GeoLite2 (Local DB):*\n```\n{format_dict_for_markdown(all_results['geolite2_local'])}\n```\n"

        if "reverse_dns" in all_results:
            output += f" PTR *DNS Reverso:*\n```\n{format_dict_for_markdown(all_results['reverse_dns'])}\n```\n"
            
        if not any(key in all_results for key in ["ipinfo_api", "ip_api_com", "geolite2_local"]):
             output += "❌ No se pudo obtener información de geolocalización para esta IP.\n"

        output += "\n_Para IPinfo.io, configura una API Key para resultados más detallados. Para GeoLite2, descarga la base de datos `GeoLite2-City.mmdb`._"
        return output