# bots/utils/url_analyzer_tool.py
import whois
import dns.resolver
from urllib.parse import urlparse, unquote
import asyncio
import ssl
import socket
from bs4 import BeautifulSoup
from .helpers import format_dict_for_markdown, make_async_request # Importación relativa
import aiohttp
import logging # Para logging de errores si es necesario

logger = logging.getLogger(__name__)

class URLAnalyzerTool:
    def __init__(self, url: str):
        self.url = url
        # Normalizar y parsear la URL
        try:
            self.parsed_url = urlparse(unquote(url)) # unquote para manejar URLs con caracteres especiales
            if not self.parsed_url.scheme: # Si no hay esquema, asumir http
                self.url = f"http://{url}"
                self.parsed_url = urlparse(unquote(self.url))
            self.domain = self.parsed_url.netloc
            if ":" in self.domain: # Quitar puerto del dominio si existe para WHOIS/DNS
                self.domain_for_lookups = self.domain.split(":")[0]
            else:
                self.domain_for_lookups = self.domain
        except Exception as e:
            logger.error(f"Error al parsear la URL '{url}': {e}")
            # Establecer valores por defecto o lanzar un error más específico si se prefiere
            self.parsed_url = urlparse("")
            self.domain = ""
            self.domain_for_lookups = ""
            # Considerar lanzar una excepción aquí si la URL es fundamentalmente inválida


    async def analyze(self) -> str:
        """Realiza un análisis completo de la URL."""
        if not self.domain_for_lookups: # Si el dominio no pudo ser parseado
            return f"❌ Error: La URL '{self.url}' es inválida o no se pudo parsear el dominio."

        results = {"url_original": self.url, "dominio_analizado": self.domain_for_lookups}
        
        # Usar un timeout global para aiohttp.ClientSession
        # y timeouts individuales más cortos para operaciones específicas si es necesario
        client_timeout = aiohttp.ClientTimeout(total=20) # Timeout total para la sesión
        
        async with aiohttp.ClientSession(timeout=client_timeout) as session:
            # Tareas concurrentes
            # Envolver cada tarea en un try-except para que una falla no detenga las demás
            async def safe_task(coro):
                try:
                    return await coro
                except Exception as e:
                    logger.error(f"Error en tarea de análisis de URL ({coro.__name__ if hasattr(coro, '__name__') else 'desconocida'}): {e}", exc_info=True)
                    return {"error": f"Excepción durante la tarea: {type(e).__name__}"}

            tasks = [
                safe_task(self._get_whois_info()),
                safe_task(self._get_dns_records()),
                safe_task(self._get_http_details(session)),
                safe_task(self._get_ssl_info()),
                safe_task(self._check_robots_sitemap(session))
            ]
            
            (whois_info, dns_records, http_details, 
             ssl_info, robots_sitemap) = await asyncio.gather(*tasks) # No se necesita return_exceptions=True si se manejan dentro de safe_task

            results["whois"] = whois_info
            results["dns_records"] = dns_records
            results["http_details"] = http_details
            results["ssl_info"] = ssl_info
            results["robots_sitemap_check"] = robots_sitemap

        return self._format_results(results)

    async def _get_whois_info(self):
        try:
            loop = asyncio.get_running_loop()
            # La librería python-whois no es async, ejecutar en thread pool
            # Usar self.domain_for_lookups que no tiene el puerto
            w = await loop.run_in_executor(None, whois.whois, self.domain_for_lookups)
            if not w: # A veces whois.whois devuelve None si no encuentra nada
                return {"error": "No se encontró información WHOIS o el dominio no es registrable."}

            # Simplificar la salida de WHOIS
            simple_whois = {
                "domain_name": w.domain_name,
                "registrar": w.registrar,
                "creation_date": w.creation_date,
                "expiration_date": w.expiration_date,
                "name_servers": w.name_servers,
                "status": w.status,
                "emails": w.emails,
                "updated_date": w.updated_date,
            }
            # Filtrar fechas que puedan ser listas y tomar el primer elemento
            for key in ["creation_date", "expiration_date", "updated_date"]:
                if isinstance(simple_whois[key], list) and simple_whois[key]:
                    simple_whois[key] = simple_whois[key][0]
                elif isinstance(simple_whois[key], list) and not simple_whois[key]:
                     simple_whois[key] = None # Lista vacía

            return {k: str(v) if v is not None else "N/A" for k, v in simple_whois.items()}
        except whois.parser.PywhoisError as e: # Error específico de parsing de whois
            logger.warning(f"Error de Pywhois para {self.domain_for_lookups}: {e}")
            return {"error": f"No se pudo obtener/parsear WHOIS: {str(e)}"}
        except Exception as e:
            logger.error(f"Excepción en _get_whois_info para {self.domain_for_lookups}: {e}", exc_info=True)
            return {"error": f"Error inesperado obteniendo WHOIS: {str(e)}"}

    async def _get_dns_records(self):
        records = {}
        resolver = dns.resolver.Resolver()
        resolver.timeout = 2.0 # Timeout por query
        resolver.lifetime = 5.0 # Timeout total para la resolución

        loop = asyncio.get_running_loop()
        for record_type in ['A', 'AAAA', 'MX', 'NS', 'TXT', 'SOA', 'CNAME']:
            try:
                # dns.resolver no es async, ejecutar en thread pool
                answers = await loop.run_in_executor(None, resolver.resolve, self.domain_for_lookups, record_type)
                records[record_type] = sorted([str(r.to_text()) for r in answers])
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
                records[record_type] = ["No encontrado"]
            except dns.resolver.Timeout:
                records[record_type] = ["Timeout"]
            except dns.exception.DNSException as e:
                logger.warning(f"DNSException para {self.domain_for_lookups} tipo {record_type}: {e}")
                records[record_type] = [f"Error DNS: {type(e).__name__}"]
            except Exception as e:
                logger.error(f"Excepción en _get_dns_records para {self.domain_for_lookups} tipo {record_type}: {e}", exc_info=True)
                records[record_type] = [f"Error inesperado: {str(e)}"]
        return records

    async def _get_http_details(self, session: aiohttp.ClientSession):
        details = {}
        try:
            # Usar self.url que tiene el esquema y puerto original
            async with session.get(self.url, allow_redirects=True, timeout=10) as response: # Timeout para la petición GET
                details["final_url"] = str(response.url) # URL después de redirecciones
                details["status_code"] = response.status
                details["reason"] = response.reason
                details["headers"] = dict(response.headers)
                
                content_type = response.headers.get("Content-Type", "").lower()
                if "text/html" in content_type:
                    try:
                        content = await response.text(errors='replace') # Leer contenido con manejo de errores de decodificación
                        soup = BeautifulSoup(content, 'html.parser')
                        details["title"] = soup.title.string.strip() if soup.title and soup.title.string else "N/A"
                        
                        meta_tags = {}
                        for tag in soup.find_all('meta', limit=20): # Limitar número de meta tags
                            name = tag.get('name') or tag.get('property')
                            if name:
                                meta_tags[name.lower()] = tag.get('content', '')
                        details["meta_tags"] = meta_tags
                        
                        # Enlaces (ejemplo, primeros 5 internos y 5 externos)
                        internal_links, external_links = [], []
                        for a_tag in soup.find_all('a', href=True, limit=20): # Limitar búsqueda de enlaces
                            href = a_tag.get('href')
                            if href.startswith(('http://', 'https://')) and urlparse(href).netloc != self.parsed_url.netloc:
                                if len(external_links) < 5: external_links.append(href)
                            elif not href.startswith(('mailto:', 'tel:')) : # Ignorar mailto y tel
                                if len(internal_links) < 5: internal_links.append(href)
                        details["sample_internal_links"] = internal_links
                        details["sample_external_links"] = external_links

                        # Extraer comentarios HTML (primeros N caracteres o N comentarios)
                        # comments = soup.find_all(string=lambda text: isinstance(text, Comment))
                        # details["html_comments_sample"] = [c.strip() for c in comments[:3]]

                    except Exception as e_parse:
                        logger.warning(f"Error parseando HTML de {self.url}: {e_parse}")
                        details["html_parsing_error"] = str(e_parse)
                else:
                    details["content_type_note"] = f"Contenido no es HTML ({content_type}), no se extrajo título/meta."

        except aiohttp.ClientError as e: # Errores de conexión, SSL, timeout de aiohttp
            logger.warning(f"ClientError al acceder a URL {self.url}: {e}")
            details["error"] = f"Error de cliente HTTP: {str(e)}"
        except asyncio.TimeoutError: # Timeout de la operación GET
            logger.warning(f"Timeout al acceder a URL {self.url}")
            details["error"] = "Timeout durante la petición HTTP."
        except Exception as e:
            logger.error(f"Excepción en _get_http_details para {self.url}: {e}", exc_info=True)
            details["error"] = f"Error inesperado procesando HTTP: {str(e)}"
        return details

    async def _get_ssl_info(self):
        if self.parsed_url.scheme != "https":
            return {"status": "No es HTTPS, no se verifica SSL."}
        
        # Usar self.domain_for_lookups (sin puerto) para el server_hostname
        # y self.parsed_url.port o 443 para el puerto de conexión
        hostname_ssl = self.domain_for_lookups
        port_ssl = self.parsed_url.port if self.parsed_url.port else 443

        info = {}
        ssl_context = ssl.create_default_context()
        try:
            # La conexión y el handshake SSL son bloqueantes, así que usamos run_in_executor
            loop = asyncio.get_running_loop()
            
            def fetch_cert_sync():
                # Usamos una conexión de socket bloqueante dentro del executor
                conn = ssl_context.wrap_socket(
                    socket.create_connection((hostname_ssl, port_ssl), timeout=5.0), # Timeout conexión
                    server_hostname=hostname_ssl
                )
                conn.settimeout(5.0) # Timeout para operaciones SSL después de conectar
                cert_data = conn.getpeercert()
                conn.close()
                return cert_data

            cert = await loop.run_in_executor(None, fetch_cert_sync)

            if not cert:
                 return {"error": "No se pudo obtener el certificado del peer."}

            info["subject"] = dict(x[0] for x in cert.get("subject", []))
            info["issuer"] = dict(x[0] for x in cert.get("issuer", []))
            info["version"] = cert.get("version")
            info["serial_number"] = cert.get("serialNumber")
            info["not_before"] = cert.get("notBefore")
            info["not_after"] = cert.get("notAfter")
            if 'subjectAltName' in cert:
                info["subject_alt_name"] = [item[1] for item in cert['subjectAltName']]
            # Podríamos añadir más: OCSP, CRL, etc.
            return info
        except socket.timeout:
            logger.warning(f"Timeout obteniendo certificado SSL para {hostname_ssl}:{port_ssl}")
            return {"error": "Timeout obteniendo certificado SSL."}
        except ssl.SSLError as e:
            logger.warning(f"SSLError para {hostname_ssl}:{port_ssl}: {e}")
            return {"error": f"Error SSL: {str(e)} (Comprueba si el certificado es válido y el server_hostname correcto)"}
        except ConnectionRefusedError:
            logger.warning(f"Conexión SSL rechazada para {hostname_ssl}:{port_ssl}")
            return {"error": "Conexión SSL rechazada."}
        except socket.gaierror as e: # Error de resolución de nombre para SSL
            logger.warning(f"Error de resolución de nombre para SSL {hostname_ssl}: {e}")
            return {"error": f"No se pudo resolver el host para SSL: {str(e)}"}
        except Exception as e:
            logger.error(f"Excepción en _get_ssl_info para {hostname_ssl}:{port_ssl}: {e}", exc_info=True)
            return {"error": f"Error inesperado obteniendo SSL: {str(e)}"}


    async def _check_robots_sitemap(self, session: aiohttp.ClientSession):
        checks = {}
        base_url = f"{self.parsed_url.scheme}://{self.parsed_url.netloc}" # Usar netloc que incluye puerto si está en la URL original

        # Robots.txt
        robots_url = f"{base_url}/robots.txt"
        try:
            response_robots_text = await make_async_request(session, "GET", robots_url, timeout=5) # Petición de texto
            if response_robots_text and isinstance(response_robots_text, str):
                checks["robots_txt_status"] = "Encontrado y leído"
                sitemap_links = [
                    line.split(":", 1)[1].strip() for line in response_robots_text.splitlines() 
                    if line.lower().startswith("sitemap:")
                ]
                if sitemap_links:
                    checks["sitemaps_from_robots"] = sitemap_links
                else:
                    checks["sitemaps_from_robots"] = ["No especificado en robots.txt"]
            else: # No encontrado o error en la petición (make_async_request devuelve None en error)
                 checks["robots_txt_status"] = "No encontrado o error al acceder"
        except asyncio.TimeoutError:
            checks["robots_txt_status"] = "Timeout al verificar robots.txt"
        except Exception as e:
            logger.warning(f"Error verificando robots.txt para {robots_url}: {e}")
            checks["robots_txt_status"] = f"Error al verificar: {type(e).__name__}"

        # Sitemap.xml (común, pero puede estar en otro lado o ser nombrado diferente)
        sitemap_url_common = f"{base_url}/sitemap.xml"
        try:
            # Solo necesitamos verificar la existencia, no el contenido para esta prueba simple
            async with session.head(sitemap_url_common, timeout=5, allow_redirects=True) as response_sitemap:
                if response_sitemap.status == 200:
                    checks["sitemap_xml_status_common"] = "Encontrado (sitemap.xml)"
                else:
                    checks["sitemap_xml_status_common"] = f"No encontrado (sitemap.xml - Status: {response_sitemap.status})"
        except asyncio.TimeoutError:
            checks["sitemap_xml_status_common"] = "Timeout al verificar sitemap.xml"
        except aiohttp.ClientError: # Conexión, etc.
            checks["sitemap_xml_status_common"] = "Error de cliente al verificar sitemap.xml"
        except Exception as e:
            logger.warning(f"Error verificando sitemap.xml para {sitemap_url_common}: {e}")
            checks["sitemap_xml_status_common"] = f"Error al verificar: {type(e).__name__}"
        return checks

    def _format_results(self, results: dict) -> str:
        # Truncar strings largos dentro de los diccionarios para evitar mensajes demasiado grandes
        def truncate_value(value, max_len=200):
            s_value = str(value)
            if len(s_value) > max_len:
                return s_value[:max_len-3] + "..."
            return s_value

        def truncate_dict_values(d, max_len=200):
            if isinstance(d, dict):
                return {k: truncate_dict_values(v, max_len) for k, v in d.items()}
            elif isinstance(d, list):
                return [truncate_dict_values(i, max_len) for i in d]
            else:
                return truncate_value(d, max_len)

        output = f"🔎 *Análisis Avanzado de URL para:* `{truncate_value(results.get('url_original', 'N/A'), 100)}`\n"
        output += f"👤 *Dominio Analizado (para WHOIS/DNS):* `{truncate_value(results.get('dominio_analizado', 'N/A'), 100)}`\n\n"

        sections = {
            "whois": ("📜 *Información WHOIS (simplificada):*", results.get("whois")),
            "dns_records": ("📡 *Registros DNS:*", results.get("dns_records")),
            "http_details": ("📄 *Detalles HTTP/HTML:*", results.get("http_details")),
            "ssl_info": ("🛡️ *Información Certificado SSL:*", results.get("ssl_info")),
            "robots_sitemap_check": ("🤖 *Robots.txt y Sitemap.xml:*", results.get("robots_sitemap_check")),
        }

        for key, (title, data) in sections.items():
            if data:
                if isinstance(data, dict) and "error" in data:
                    output += f"{title}\n`Error: {data['error']}`\n\n"
                else:
                    # Truncar valores dentro de la data antes de formatear a Markdown
                    truncated_data = truncate_dict_values(data)
                    formatted_data_md = format_dict_for_markdown(truncated_data)
                    output += f"{title}\n```\n{formatted_data_md}\n```\n\n"
            else:
                output += f"{title}\n`No se obtuvo información o hubo un error.`\n\n"
            
        return output.strip()