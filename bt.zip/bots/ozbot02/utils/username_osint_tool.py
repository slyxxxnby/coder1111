import asyncio
import aiohttp
from .helpers import format_dict_for_markdown, make_async_request

# Lista de sitios (simplificada). Una herramienta como Sherlock tiene cientos.
# { "nombre_bonito": "URL_CON_{USERNAME}_PLACEHOLDER", "error_if_not_found": "texto_o_status_code_error" }
# Para `error_if_not_found`, si es un string, se busca en el contenido. Si es int, es un status code.
# Si no se especifica `error_if_not_found`, se asume que un status 200 significa "encontrado".
SITES_TO_CHECK = {
    "GitHub": {"url": "https://github.com/{username}", "error_type": "status_code", "error_value": 404},
    "Twitter / X": {"url": "https://twitter.com/{username}", "error_type": "status_code", "error_value": 404}, # X puede cambiar esto
    "Instagram": {"url": "https://www.instagram.com/{username}/", "error_type": "status_code", "error_value": 404},
    "Reddit": {"url": "https://www.reddit.com/user/{username}", "error_type": "status_code", "error_value": 404}, # A veces redirige si no existe
    "TikTok": {"url": "https://www.tiktok.com/@{username}", "error_type": "status_code", "error_value": 404},
    "Pastebin (user)": {"url": "https://pastebin.com/u/{username}", "error_type": "text_not_found", "error_value": "Page Not Found"},
    # Añadir más sitios aquí es la clave para hacerlo potente
}

class UsernameOSINTTool:
    def __init__(self, username: str):
        self.username = username.lower() # Muchos sitios no son case-sensitive para usernames

    async def search(self) -> str:
        results = {"username": self.username, "found_on": [], "not_found_on": [], "errors": []}
        
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
            tasks = []
            for site_name, site_data in SITES_TO_CHECK.items():
                url = site_data["url"].format(username=self.username)
                tasks.append(self._check_site(session, site_name, url, site_data))
            
            site_results = await asyncio.gather(*tasks)

            for res in site_results:
                if res["status"] == "found":
                    results["found_on"].append({"site": res["site_name"], "url": res["url"]})
                elif res["status"] == "not_found":
                    results["not_found_on"].append(res["site_name"])
                else: # error
                    results["errors"].append({"site": res["site_name"], "error": res["message"]})
        
        return self._format_results(results)

    async def _check_site(self, session: aiohttp.ClientSession, site_name: str, url: str, site_data: dict):
        try:
            async with session.get(url, allow_redirects=True, timeout=5) as response:
                content = await response.text() # Leer contenido para buscar texto si es necesario
                
                error_type = site_data.get("error_type")
                error_value = site_data.get("error_value")

                if error_type == "status_code":
                    if response.status == error_value:
                        return {"status": "not_found", "site_name": site_name, "url": str(response.url)}
                    elif response.status == 200: # o cualquier otro status que no sea el de error
                        return {"status": "found", "site_name": site_name, "url": str(response.url)}
                    else: # Otro status code inesperado
                        return {"status": "error", "site_name": site_name, "url": str(response.url), "message": f"Status inesperado: {response.status}"}

                elif error_type == "text_not_found": # Si el texto de error está presente, no se encontró
                    if error_value in content:
                        return {"status": "not_found", "site_name": site_name, "url": str(response.url)}
                    else: # Si no está el texto de error, asumir que se encontró (o es otra página)
                        return {"status": "found", "site_name": site_name, "url": str(response.url)}
                
                elif error_type == "text_found": # Si el texto específico DEBE estar para confirmar
                    if error_value in content:
                         return {"status": "found", "site_name": site_name, "url": str(response.url)}
                    else:
                         return {"status": "not_found", "site_name": site_name, "url": str(response.url)}

                # Default: si no hay error_type, 200 es encontrado, otro no.
                else:
                    if response.status == 200:
                        return {"status": "found", "site_name": site_name, "url": str(response.url)}
                    else:
                        return {"status": "not_found", "site_name": site_name, "url": str(response.url)}
                        
        except aiohttp.ClientError as e:
            return {"status": "error", "site_name": site_name, "url": url, "message": f"Error de conexión: {type(e).__name__}"}
        except asyncio.TimeoutError:
            return {"status": "error", "site_name": site_name, "url": url, "message": "Timeout"}
        except Exception as e:
            return {"status": "error", "site_name": site_name, "url": url, "message": f"Error desconocido: {str(e)}"}

    def _format_results(self, results: dict) -> str:
        output = f"👤 *Búsqueda de Nombre de Usuario:* `{results['username']}`\n\n"

        if results["found_on"]:
            output += "🟢 *Encontrado en los siguientes sitios:*\n"
            for item in results["found_on"]:
                output += f"  • *{item['site']}:* {item['url']}\n" # URL clickeable
        else:
            output += "🟡 *No se encontró el usuario en los sitios verificados (o hubo errores).*\n"
        
        # Opcional: mostrar en cuáles no se encontró o hubo errores
        # if results["not_found_on"]:
        #     output += "\n🔴 *No encontrado en:*\n"
        #     output += f"`{', '.join(results['not_found_on'][:10])}`"
        #     if len(results['not_found_on']) > 10: output += " y más..."
        #     output += "\n"

        if results["errors"]:
            output += "\n⚠️ *Errores durante la búsqueda en algunos sitios:*\n"
            for err in results["errors"][:3]: # Mostrar hasta 3 errores
                output += f"  • *{err['site']}:* `{err['message']}`\n"
            if len(results["errors"]) > 3 : output += "  • ... y más errores.\n"

        output += "\n_Esta herramienta verifica una lista predefinida de sitios. La ausencia aquí no significa que el usuario no exista en otros lugares._"
        return output