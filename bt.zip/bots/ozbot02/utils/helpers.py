import re
import phonenumbers
import ipaddress
from urllib.parse import urlparse

# Expresión regular para URLs más robusta
URL_REGEX = re.compile(
    r'^(?:http|ftp)s?://'  # http:// or https://
    r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain...
    r'localhost|'  # localhost...
    r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
    r'(?::\d+)?'  # optional port
    r'(?:/?|[/?]\S+)$', re.IGNORECASE)

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")

def validate_url(url: str) -> bool:
    """Validación de URL mejorada."""
    return re.match(URL_REGEX, url) is not None

def ensure_http_scheme(url: str) -> str:
    """Asegura que la URL tenga un esquema http/https, por defecto http."""
    if not re.match(r'^[a-zA-Z]+://', url):
        return f'http://{url}'
    return url

def validate_ip(ip: str) -> bool:
    """Validación de IP usando el módulo ipaddress."""
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

def validate_domain(domain: str) -> bool:
    """Validación básica de un nombre de dominio."""
    if len(domain) > 255:
        return False
    if domain[-1] == ".":
        domain = domain[:-1] # Quitar punto final si existe
    # Expresión regular para nombres de host (simplificada)
    allowed = re.compile(r"(?!-)[A-Z\d-]{1,63}(?<!-)$", re.IGNORECASE)
    return all(allowed.match(x) for x in domain.split("."))

def validate_email(email: str) -> bool:
    """Validación de email usando regex."""
    return re.match(EMAIL_REGEX, email) is not None

def validate_phone(phone: str) -> bool:
    """Validación de teléfono usando phonenumbers."""
    try:
        parsed_num = phonenumbers.parse(phone, None) # None para inferir el país si no se provee código
        return phonenumbers.is_valid_number(parsed_num)
    except phonenumbers.phonenumberutil.NumberParseException:
        return False

def format_dict_for_markdown(data: dict, indent: int = 0) -> str:
    """Formatea un diccionario para Markdown de forma legible."""
    prefix = "  " * indent
    output = ""
    for key, value in data.items():
        if isinstance(value, dict):
            output += f"{prefix}*{key}:*\n{format_dict_for_markdown(value, indent + 1)}"
        elif isinstance(value, list):
            output += f"{prefix}*{key}:*\n"
            for item in value:
                if isinstance(item, dict):
                    output += f"{prefix}  - {{\n{format_dict_for_markdown(item, indent + 2)}{prefix}  }}\n"
                else:
                    output += f"{prefix}  - {str(item)}\n"
        else:
            output += f"{prefix}*{key}:* `{str(value)}`\n"
    return output.strip()

async def make_async_request(session, method: str, url: str, **kwargs):
    """Helper para realizar peticiones HTTP asíncronas."""
    try:
        async with session.request(method, url, **kwargs) as response:
            response.raise_for_status() # Lanza error para 4xx/5xx
            if "application/json" in response.headers.get("Content-Type", ""):
                return await response.json()
            return await response.text()
    except Exception as e:
        # print(f"Error en request a {url}: {e}") # Para depuración
        return None # O manejar el error de forma más específica