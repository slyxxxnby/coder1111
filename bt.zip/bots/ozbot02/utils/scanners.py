import whois
import socket
import dns.resolver
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup
from scapy.all import sr1, IP, TCP
import asyncio

class URLScanner:
    def __init__(self, url):
        self.url = url
        self.parsed = urlparse(url)
        
    async def scan(self):
        try:
            # WHOIS information
            domain_info = whois.whois(self.parsed.netloc)
            
            # DNS information
            dns_results = {}
            for record_type in ['A', 'AAAA', 'MX', 'NS', 'TXT', 'SOA']:
                try:
                    answers = dns.resolver.resolve(self.parsed.netloc, record_type)
                    dns_results[record_type] = [str(r) for r in answers]
                except:
                    pass
            
            # HTTP headers
            headers = {}
            try:
                response = requests.get(self.url, timeout=10)
                headers = dict(response.headers)
            except:
                pass
            
            # Page metadata
            metadata = {}
            try:
                soup = BeautifulSoup(response.text, 'html.parser')
                metadata['title'] = soup.title.string if soup.title else None
                metadata['meta'] = [str(meta) for meta in soup.find_all('meta')]
            except:
                pass
            
            # Format results
            result = f"""
            *🔗 URL Scan Results for {self.url}*
            
            *🌐 Domain Information:*
            ```{domain_info}```
            
            *📡 DNS Records:*
            ```{dns_results}```
            
            *📋 HTTP Headers:*
            ```{headers}```
            
            *📄 Page Metadata:*
            ```{metadata}```
            """
            return result
            
        except Exception as e:
            return f"❌ Error scanning URL: {str(e)}"

class PortScanner:
    def __init__(self, target):
        self.target = target
        
    async def scan(self):
        try:
            # Resolve hostname to IP if needed
            try:
                ip = socket.gethostbyname(self.target)
            except:
                ip = self.target
                
            # Common ports to scan
            common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 465, 587, 993, 995, 3306, 3389, 8080]
            
            open_ports = []
            services = {}
            
            for port in common_ports:
                try:
                    # Using scapy for TCP scan
                    pkt = IP(dst=ip)/TCP(dport=port, flags="S")
                    resp = sr1(pkt, timeout=2, verbose=0)
                    
                    if resp is not None and resp.haslayer(TCP):
                        if resp.getlayer(TCP).flags == 0x12:  # SYN-ACK
                            open_ports.append(port)
                            try:
                                service = socket.getservbyport(port)
                                services[port] = service
                            except:
                                services[port] = "unknown"
                except:
                    pass
                
            # Format results
            result = f"""
            *🔌 Port Scan Results for {self.target} ({ip})*
            
            *🛡️ Open Ports:*
            ```{open_ports}```
            
            *🛠️ Services:*
            ```{services}```
            """
            return result
            
        except Exception as e:
            return f"❌ Error scanning ports: {str(e)}"