# bots/main.py
import os  # <<<--- AÑADE ESTA LÍNEA
import logging
import asyncio
from core.bot import start_bot # Asegúrate que esta importación sea correcta

def main():
    # Configuración de logging
    logging.basicConfig(
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        level=logging.INFO
    )
    # Para reducir la verbosidad de librerías externas:
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram.ext").setLevel(logging.WARNING)
    logging.getLogger("scapy.runtime").setLevel(logging.ERROR) # Scapy puede ser muy verboso
    logging.getLogger("asyncio").setLevel(logging.WARNING) # A veces asyncio es verboso en debug

    # Para Windows, si se usa asyncio con Scapy, a veces se necesita esta política
    if os.name == 'nt': # Ahora 'os' está definido
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    start_bot()

if __name__ == '__main__':
    main()