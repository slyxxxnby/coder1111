import os
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from url_analyzer import analyze_website

TOKEN = os.getenv('TELEGRAM_BOT_TOKEN') or '7644793001:AAFDLDkM_9o9Xryo-gpOaRXykxZ1YQUQUPw'

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /start is issued."""
    welcome_msg = """
    🛡️ *Web Security Analyzer Bot* 🛡️
    
    I can analyze websites for security vulnerabilities and provide detailed reports.
    
    *Commands:*
    /analyze <url> - Analyze a website (e.g., /analyze example.com)
    /help - Show this help message
    
    Just send me a URL and I'll analyze it for you!
    """
    await update.message.reply_text(welcome_msg, parse_mode='Markdown')

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /help is issued."""
    help_msg = """
    *How to use this bot:*
    
    1. Send me a URL (e.g., example.com)
    2. Or use /analyze <url> command
    
    I'll check:
    - DNS information
    - SSL/TLS configuration
    - Open ports
    - Web technologies
    - Security headers
    - Common vulnerabilities
    - And more!
    """
    await update.message.reply_text(help_msg, parse_mode='Markdown')

async def analyze_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Analyze a website from command argument."""
    if not context.args:
        await update.message.reply_text("Please provide a URL. Example: /analyze example.com")
        return
    
    url = context.args[0]
    await update.message.reply_text(f"🔍 Analyzing {url}... This may take a few moments.")
    
    try:
        report = analyze_website(url)
        await update.message.reply_text(report, parse_mode='Markdown')
    except Exception as e:
        await update.message.reply_text(f"❌ Error analyzing {url}: {str(e)}")

async def handle_url_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle messages containing URLs."""
    text = update.message.text
    if any(proto in text.lower() for proto in ['http://', 'https://', 'www.']):
        await update.message.reply_text(f"🔍 Analyzing {text}... This may take a few moments.")
        try:
            report = analyze_website(text)
            await update.message.reply_text(report, parse_mode='Markdown')
        except Exception as e:
            await update.message.reply_text(f"❌ Error analyzing {text}: {str(e)}")

def setup_bot():
    """Set up the Telegram bot handlers."""
    application = Application.builder().token(TOKEN).build()

    # Command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("analyze", analyze_command))
    
    # Message handler for URLs
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_url_message))
    
    return application