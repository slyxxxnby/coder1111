import socket
import requests
import whois
import dns.resolver
import ssl
import nmap
from urllib.parse import urlparse
from bs4 import BeautifulSoup
from datetime import datetime
import tldextract
import OpenSSL
from sslyze import ServerNetworkLocationViaDirectConnection, Scanner, ServerScanRequest

def analyze_website(url):
    """Comprehensive website analysis function."""
    if not url.startswith(('http://', 'https://')):
        url = f'https://{url}'
    
    parsed_url = urlparse(url)
    domain = parsed_url.netloc or parsed_url.path
    base_url = f"{parsed_url.scheme}://{domain}" if parsed_url.scheme else f"https://{domain}"
    
    # Initialize report
    report = f"# 🛡️ Security Analysis Report for {domain}\n\n"
    
    # 1. Basic Information
    report += "## ℹ️ Basic Information\n"
    report += f"- **URL**: {base_url}\n"
    
    # 2. WHOIS Lookup
    report += "\n## 📋 WHOIS Information\n"
    try:
        whois_info = whois.whois(domain)
        report += f"- **Domain Name**: {whois_info.domain_name}\n"
        report += f"- **Registrar**: {whois_info.registrar}\n"
        report += f"- **Creation Date**: {whois_info.creation_date}\n"
        report += f"- **Expiration Date**: {whois_info.expiration_date}\n"
        report += f"- **Name Servers**: {', '.join(whois_info.name_servers) if whois_info.name_servers else 'N/A'}\n"
    except Exception as e:
        report += f"- ❌ WHOIS lookup failed: {str(e)}\n"
    
    # 3. DNS Information
    report += "\n## 🌐 DNS Information\n"
    try:
        ext = tldextract.extract(domain)
        main_domain = f"{ext.domain}.{ext.suffix}"
        
        resolver = dns.resolver.Resolver()
        resolver.timeout = 5
        resolver.lifetime = 5
        
        # A Records
        try:
            a_records = resolver.resolve(main_domain, 'A')
            report += f"- **A Records**: {', '.join([a.address for a in a_records])}\n"
        except:
            report += "- ❌ Could not resolve A records\n"
        
        # MX Records
        try:
            mx_records = resolver.resolve(main_domain, 'MX')
            report += f"- **MX Records**: {', '.join([str(mx.exchange) for mx in mx_records])}\n"
        except:
            report += "- ❌ Could not resolve MX records\n"
        
        # TXT Records
        try:
            txt_records = resolver.resolve(main_domain, 'TXT')
            report += f"- **TXT Records**: {', '.join([str(txt) for txt in txt_records])}\n"
        except:
            report += "- ❌ Could not resolve TXT records\n"
    except Exception as e:
        report += f"- ❌ DNS resolution failed: {str(e)}\n"
    
    # 4. SSL/TLS Analysis
    report += "\n## 🔒 SSL/TLS Analysis\n"
    try:
        # Basic SSL info
        hostname = domain.split(':')[0]
        port = 443
        
        cert = ssl.get_server_certificate((hostname, port))
        x509 = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, cert)
        
        # Certificate details
        report += f"- **Issuer**: {x509.get_issuer().CN}\n"
        report += f"- **Subject**: {x509.get_subject().CN}\n"
        report += f"- **Valid From**: {x509.get_notBefore().decode('utf-8')}\n"
        report += f"- **Valid Until**: {x509.get_notAfter().decode('utf-8')}\n"
        
        # Check expiration
        expires = datetime.strptime(x509.get_notAfter().decode('utf-8'), '%Y%m%d%H%M%SZ')
        days_left = (expires - datetime.now()).days
        report += f"- **Days Until Expiration**: {days_left}\n"
        if days_left < 30:
            report += "  ⚠️ **Warning**: Certificate expires soon!\n"
        
        # Using SSLyze for deeper analysis
        try:
            server_location = ServerNetworkLocationViaDirectConnection.with_ip_address_lookup(hostname, port)
            scanner = Scanner()
            scan_request = ServerScanRequest(server_location=server_location)
            scanner.queue_scan(scan_request)
            
            for result in scanner.get_results():
                if result.scan_result.ssl_2_0_cipher_suites is not None:
                    report += "- ❌ SSL 2.0 supported (INSECURE!)\n"
                if result.scan_result.ssl_3_0_cipher_suites is not None:
                    report += "- ❌ SSL 3.0 supported (INSECURE!)\n"
                if result.scan_result.tls_1_0_cipher_suites is not None:
                    report += "- ⚠️ TLS 1.0 supported (WEAK!)\n"
                if result.scan_result.tls_1_1_cipher_suites is not None:
                    report += "- ⚠️ TLS 1.1 supported (WEAK!)\n"
                if result.scan_result.tls_1_2_cipher_suites is not None:
                    report += "- ✅ TLS 1.2 supported\n"
                if result.scan_result.tls_1_3_cipher_suites is not None:
                    report += "- ✅ TLS 1.3 supported\n"
        except Exception as e:
            report += f"- ❌ SSLyze analysis failed: {str(e)}\n"
    except Exception as e:
        report += f"- ❌ SSL/TLS analysis failed: {str(e)}\n"
    
    # 5. Port Scanning
    report += "\n## 🔎 Port Scanning (Common Ports)\n"
    try:
        nm = nmap.PortScanner()
        nm.scan(hostname, arguments='-F')  # Fast scan of common ports
        
        if hostname in nm.all_hosts():
            report += "- **Host Status**: Up\n"
            for proto in nm[hostname].all_protocols():
                report += f"- **Protocol**: {proto}\n"
                ports = nm[hostname][proto].keys()
                for port in sorted(ports):
                    port_info = nm[hostname][proto][port]
                    report += f"  - Port {port}: {port_info['state']} ({port_info['name']})\n"
                    if port_info['state'] == 'open' and port in [21, 22, 23, 80, 443, 3306, 3389]:
                        service = port_info['name']
                        report += f"    ⚠️ **Warning**: {service} service exposed on port {port}\n"
        else:
            report += "- ❌ Host appears to be down\n"
    except Exception as e:
        report += f"- ❌ Port scanning failed: {str(e)}\n"
    
    # 6. HTTP Headers Analysis
    report += "\n## 📄 HTTP Headers Analysis\n"
    try:
        response = requests.get(base_url, timeout=10, verify=True)
        headers = response.headers
        
        # Security headers check
        security_headers = {
            'Strict-Transport-Security': '✅ HSTS enabled',
            'Content-Security-Policy': '✅ CSP enabled',
            'X-Frame-Options': '✅ Clickjacking protection',
            'X-Content-Type-Options': '✅ MIME sniffing prevention',
            'X-XSS-Protection': '✅ XSS protection',
            'Referrer-Policy': '✅ Referrer policy set',
            'Feature-Policy': '✅ Feature policy set',
            'Permissions-Policy': '✅ Permissions policy set'
        }
        
        for header, message in security_headers.items():
            if header in headers:
                report += f"- {message}: `{headers[header]}`\n"
            else:
                report += f"- ❌ Missing security header: {header}\n"
        
        # Server info
        if 'Server' in headers:
            report += f"- **Server**: {headers['Server']}\n"
        
        # Cookies analysis
        if 'Set-Cookie' in headers:
            cookies = headers['Set-Cookie'].split(',')
            for cookie in cookies:
                if 'Secure' not in cookie:
                    report += "  ⚠️ **Warning**: Cookie without Secure flag\n"
                if 'HttpOnly' not in cookie:
                    report += "  ⚠️ **Warning**: Cookie without HttpOnly flag\n"
                if 'SameSite' not in cookie:
                    report += "  ⚠️ **Warning**: Cookie without SameSite attribute\n"
    except Exception as e:
        report += f"- ❌ HTTP headers analysis failed: {str(e)}\n"
    
    # 7. Web Technologies
    report += "\n## 🛠️ Web Technologies\n"
    try:
        wappalyzer_url = f"https://api.wappalyzer.com/v2/lookup/?url={base_url}"
        tech_response = requests.get(wappalyzer_url, timeout=10)
        if tech_response.status_code == 200:
            technologies = tech_response.json()
            if technologies:
                report += "- Detected technologies:\n"
                for tech in technologies:
                    report += f"  - {tech['name']} ({tech['version'] if 'version' in tech else 'N/A'})\n"
        else:
            report += "- ❌ Could not detect technologies (API limit reached?)\n"
    except:
        try:
            # Fallback to local detection
            response = requests.get(base_url, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Detect common CMS
            meta_generator = soup.find('meta', attrs={'name': 'generator'})
            if meta_generator:
                report += f"- **CMS**: {meta_generator.get('content')}\n"
            
            # Detect JavaScript frameworks
            scripts = soup.find_all('script')
            for script in scripts:
                src = script.get('src', '')
                if 'jquery' in src.lower():
                    report += "- **JavaScript**: jQuery detected\n"
                elif 'react' in src.lower():
                    report += "- **JavaScript**: React detected\n"
                elif 'vue' in src.lower():
                    report += "- **JavaScript**: Vue.js detected\n"
            
            # Detect common web servers from headers
            if 'Server' in response.headers:
                server = response.headers['Server']
                if 'Apache' in server:
                    report += "- **Web Server**: Apache\n"
                elif 'nginx' in server:
                    report += "- **Web Server**: Nginx\n"
                elif 'IIS' in server:
                    report += "- **Web Server**: Microsoft IIS\n"
        except Exception as e:
            report += f"- ❌ Web technologies detection failed: {str(e)}\n"
    
    # 8. Vulnerability Checks
    report += "\n## 🚨 Common Vulnerability Checks\n"
    try:
        # Check for admin interfaces
        admin_paths = ['/admin', '/wp-admin', '/administrator', '/backoffice']
        for path in admin_paths:
            try:
                admin_url = f"{base_url}{path}"
                admin_response = requests.get(admin_url, timeout=5, allow_redirects=False)
                if admin_response.status_code in [200, 301, 302]:
                    report += f"- ⚠️ **Warning**: Admin interface accessible at {admin_url}\n"
            except:
                pass
        
        # Check for common files
        common_files = ['/robots.txt', '/.git/HEAD', '/.env', '/phpinfo.php']
        for file in common_files:
            try:
                file_url = f"{base_url}{file}"
                file_response = requests.get(file_url, timeout=5)
                if file_response.status_code == 200:
                    report += f"- ⚠️ **Warning**: Sensitive file accessible at {file_url}\n"
            except:
                pass
        
        # Check for SQL injection vulnerability (simple check)
        try:
            test_url = f"{base_url}/?id=1'"
            test_response = requests.get(test_url, timeout=5)
            if any(error in test_response.text.lower() for error in ['sql', 'syntax', 'mysql']):
                report += "- ❌ **Critical**: Possible SQL injection vulnerability detected\n"
        except:
            pass
        
        # Check for XSS vulnerability (simple check)
        try:
            test_url = f"{base_url}/?q=<script>alert('xss')</script>"
            test_response = requests.get(test_url, timeout=5)
            if '<script>alert(' in test_response.text:
                report += "- ❌ **Critical**: Possible XSS vulnerability detected\n"
        except:
            pass
    except Exception as e:
        report += f"- ❌ Vulnerability checks failed: {str(e)}\n"
    
    # 9. Performance and SEO
    report += "\n## ⚡ Performance & SEO\n"
    try:
        response = requests.get(base_url, timeout=10)
        load_time = response.elapsed.total_seconds()
        report += f"- **Load Time**: {load_time:.2f} seconds\n"
        if load_time > 3:
            report += "  ⚠️ **Warning**: Slow page load time\n"
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Check title
        title = soup.title.string if soup.title else None
        if title:
            report += f"- **Title**: {title}\n"
            if len(title) > 60:
                report += "  ⚠️ **Warning**: Title is too long (ideal is under 60 characters)\n"
        
        # Check meta description
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if meta_desc:
            desc = meta_desc.get('content', '')
            report += f"- **Meta Description**: {desc[:100]}...\n"
            if len(desc) > 160:
                report += "  ⚠️ **Warning**: Meta description is too long (ideal is under 160 characters)\n"
        else:
            report += "- ❌ Missing meta description\n"
        
        # Check images without alt text
        images = soup.find_all('img')
        images_without_alt = [img for img in images if not img.get('alt')]
        if images_without_alt:
            report += f"- ⚠️ **Warning**: {len(images_without_alt)} images without alt text\n"
    except Exception as e:
        report += f"- ❌ Performance/SEO analysis failed: {str(e)}\n"
    
    # Summary
    report += "\n## 📊 Summary\n"
    report += "- Basic information collected\n"
    report += "- DNS and WHOIS records analyzed\n"
    report += "- SSL/TLS configuration checked\n"
    report += "- Common ports scanned\n"
    report += "- HTTP headers reviewed\n"
    report += "- Web technologies detected\n"
    report += "- Common vulnerabilities tested\n"
    report += "- Performance metrics measured\n"
    
    report += "\n🔍 *Analysis complete. Review the findings above for security issues.* 🔍\n"
    
    return report