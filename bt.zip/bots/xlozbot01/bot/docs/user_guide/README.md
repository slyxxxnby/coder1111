# OSINT Bot Avanzado - Documentación

## Índice
1. [Introducción](#introducción)
2. [Instalación](#instalación)
3. [Configuración](#configuración)
4. [Funcionalidades](#funcionalidades)
5. [API Keys Opcionales](#api-keys-opcionales)
6. [Arquitectura](#arquitectura)
7. [Extensibilidad](#extensibilidad)
8. [Referencia Técnica](#referencia-técnica)
9. [Solución de Problemas](#solución-de-problemas)

## Introducción

OSINT Bot Avanzado es una herramienta de Telegram para realizar investigaciones OSINT (Open Source Intelligence) de forma rápida y eficiente. El bot permite analizar URLs, escanear puertos, investigar emails y números telefónicos, y geolocalizar direcciones IP.

Esta versión avanzada incluye:
- Arquitectura modular y escalable
- Gestión segura de API Keys opcionales
- Sistema de caché para optimizar rendimiento
- Validación robusta de entradas
- Sistema de plugins para extensibilidad
- Documentación completa

## Instalación

### Requisitos previos
- Python 3.8 o superior
- pip (gestor de paquetes de Python)
- Token de bot de Telegram (obtenido a través de [@BotFather](https://t.me/BotFather))

### Pasos de instalación

1. Clonar el repositorio o descomprimir el archivo:
```bash
git clone https://github.com/usuario/osint_bot.git
cd osint_bot
```

2. Instalar dependencias:
```bash
pip install -r requirements.txt
```

3. Configurar variables de entorno:
   - Crear un archivo `.env` en el directorio raíz con el siguiente contenido:
   ```
   BOT_TOKEN=tu_token_de_telegram
   BOT_NAME=OSINT Bot Avanzado
   BOT_USERNAME=tu_bot_username
   BOT_ADMIN_IDS=123456789,987654321
   ENCRYPTION_KEY=clave_segura_para_encriptar_api_keys
   ```

4. Iniciar el bot:
```bash
python main.py
```

## Configuración

### Variables de Entorno

El bot puede configurarse mediante variables de entorno o un archivo `.env`:

| Variable | Descripción | Valor por defecto |
|----------|-------------|-------------------|
| `BOT_TOKEN` | Token del bot de Telegram | - |
| `BOT_NAME` | Nombre del bot | OSINT Bot Avanzado |
| `BOT_USERNAME` | Nombre de usuario del bot | - |
| `BOT_ADMIN_IDS` | IDs de administradores (separados por comas) | - |
| `LOG_LEVEL` | Nivel de logging (DEBUG, INFO, WARNING, ERROR, CRITICAL) | INFO |
| `LOG_DIR` | Directorio para logs | logs |
| `LOG_FILE` | Nombre del archivo de log | osint_bot.log |
| `CACHE_ENABLED` | Activar sistema de caché | True |
| `CACHE_TTL` | Tiempo de vida de caché en segundos | 3600 |
| `RATE_LIMIT_ENABLED` | Activar límite de tasa | True |
| `RATE_LIMIT_REQUESTS` | Número máximo de solicitudes en la ventana | 5 |
| `RATE_LIMIT_WINDOW` | Ventana de tiempo en segundos | 60 |
| `PLUGINS_ENABLED` | Activar sistema de plugins | True |
| `ENCRYPTION_KEY` | Clave para encriptar API Keys | - |
| `SECURE_MODE` | Activar modo seguro | True |
| `SCAN_TIMEOUT` | Tiempo máximo de escaneo en segundos | 30 |
| `MAX_PORTS_TO_SCAN` | Número máximo de puertos a escanear | 100 |

### Configuración desde el Bot

Algunas opciones pueden configurarse directamente desde el bot usando el comando `/settings`:

- Caché: Activar/desactivar el sistema de caché
- Rate Limit: Activar/desactivar el límite de tasa
- Plugins: Activar/desactivar el sistema de plugins
- Modo Seguro: Activar/desactivar el modo seguro

## Funcionalidades

### Comandos Disponibles

| Comando | Descripción |
|---------|-------------|
| `/start` | Inicia el bot y muestra el menú principal |
| `/help` | Muestra ayuda y comandos disponibles |
| `/scan_url` | Escanea una URL para obtener información detallada |
| `/scan_port` | Escanea puertos de un objetivo |
| `/osint_email` | Realiza OSINT sobre un email |
| `/osint_phone` | Realiza OSINT sobre un número telefónico |
| `/geolocate_ip` | Geolocaliza una dirección IP |
| `/settings` | Configura opciones del bot |
| `/api_keys` | Gestiona API Keys para servicios externos |
| `/cancel` | Cancela la operación actual |

### Escaneo de URL

El comando `/scan_url` permite analizar una URL y obtener información detallada:

- Información WHOIS del dominio
- Registros DNS
- Encabezados HTTP
- Metadatos de la página
- Información de seguridad (si se configura API Key de VirusTotal)

Ejemplo de uso:
1. Envía el comando `/scan_url`
2. El bot te pedirá la URL a analizar
3. Envía la URL (ej. `https://example.com`)
4. El bot analizará la URL y mostrará los resultados

### Escaneo de Puertos

El comando `/scan_port` permite escanear puertos en un objetivo:

- Detecta puertos abiertos
- Identifica servicios asociados
- Información adicional de Shodan (si se configura API Key)

Ejemplo de uso:
1. Envía el comando `/scan_port`
2. El bot te pedirá la IP o dominio a escanear
3. Envía la IP o dominio (ej. `example.com` o `8.8.8.8`)
4. El bot escaneará los puertos y mostrará los resultados

### OSINT de Email

El comando `/osint_email` permite investigar un email:

- Información del dominio
- Verificación de brechas de seguridad (si se configura API Key de Have I Been Pwned)
- Posibles perfiles en redes sociales

Ejemplo de uso:
1. Envía el comando `/osint_email`
2. El bot te pedirá el email a investigar
3. Envía el email (ej. `usuario@example.com`)
4. El bot investigará el email y mostrará los resultados

### OSINT de Teléfono

El comando `/osint_phone` permite investigar un número telefónico:

- Operador telefónico
- Región geográfica
- Zona horaria
- Información adicional (si se configura API Key de Numverify)

Ejemplo de uso:
1. Envía el comando `/osint_phone`
2. El bot te pedirá el número telefónico (con código de país)
3. Envía el número (ej. `+34612345678`)
4. El bot investigará el número y mostrará los resultados

### Geolocalización de IP

El comando `/geolocate_ip` permite geolocalizar una dirección IP:

- País
- Ciudad
- ISP
- Organización
- Información adicional (si se configura API Key de IPinfo)

Ejemplo de uso:
1. Envía el comando `/geolocate_ip`
2. El bot te pedirá la dirección IP a geolocalizar
3. Envía la IP (ej. `8.8.8.8`)
4. El bot geolocalizará la IP y mostrará los resultados

## API Keys Opcionales

El bot puede funcionar sin API Keys, pero para obtener resultados más completos y precisos, se recomienda configurar API Keys para los servicios externos.

### Servicios Soportados

| Servicio | Descripción | URL para obtener API Key |
|----------|-------------|--------------------------|
| Have I Been Pwned | Verificación de brechas de seguridad para emails | [haveibeenpwned.com](https://haveibeenpwned.com/API/Key) |
| Shodan | Búsqueda de dispositivos conectados a Internet | [shodan.io](https://account.shodan.io/) |
| VirusTotal | Análisis de URLs y archivos maliciosos | [virustotal.com](https://www.virustotal.com/gui/join-us) |
| IPinfo | Información detallada sobre direcciones IP | [ipinfo.io](https://ipinfo.io/signup) |
| Numverify | Validación y información de números telefónicos | [numverify.com](https://numverify.com/) |
| WhoisXML API | Información WHOIS detallada | [whoisxmlapi.com](https://www.whoisxmlapi.com/signup.php) |

### Configuración de API Keys

Las API Keys pueden configurarse de dos formas:

1. **Desde el bot**: Usando el comando `/api_keys`
   - Selecciona el servicio para el que quieres configurar la API Key
   - Envía la API Key cuando el bot te la solicite
   - El bot confirmará que la API Key se ha configurado correctamente

2. **Mediante archivo .env**:
   - Añade las API Keys al archivo `.env` con el siguiente formato:
   ```
   HAVEIBEENPWNED_API_KEY=tu_api_key
   SHODAN_API_KEY=tu_api_key
   VIRUSTOTAL_API_KEY=tu_api_key
   IPINFO_API_KEY=tu_api_key
   NUMVERIFY_API_KEY=tu_api_key
   WHOISXML_API_KEY=tu_api_key
   ```

### Seguridad de API Keys

Las API Keys se almacenan de forma segura:
- Encriptadas usando Fernet (criptografía simétrica)
- La clave de encriptación se configura mediante `ENCRYPTION_KEY`
- Las API Keys nunca se muestran en texto plano en los logs

## Arquitectura

El bot está diseñado siguiendo principios de ingeniería de software modernos:

### Estructura del Proyecto

```
osint_bot/
├── config/                # Configuración
│   ├── settings.py        # Configuración general
│   └── api_keys.py        # Gestión de API Keys
├── core/                  # Núcleo del bot
│   ├── bot.py             # Inicialización del bot
│   ├── command_handler.py # Gestor de comandos
│   ├── conversation.py    # Gestión de conversaciones
│   └── middleware.py      # Middleware para procesamiento
├── handlers/              # Manejadores de comandos
├── services/              # Servicios OSINT
│   ├── url_service.py     # Servicio para URLs
│   ├── port_service.py    # Servicio para puertos
│   ├── email_service.py   # Servicio para emails
│   ├── phone_service.py   # Servicio para teléfonos
│   └── ip_service.py      # Servicio para IPs
├── repositories/          # Repositorios de datos
│   ├── api_repository.py  # Repositorio para APIs
│   └── cache_repository.py # Repositorio para caché
├── utils/                 # Utilidades
│   ├── validators.py      # Validadores
│   ├── formatters.py      # Formateadores
│   ├── helpers.py         # Funciones auxiliares
│   └── security.py        # Utilidades de seguridad
├── plugins/               # Sistema de plugins
│   └── plugin_manager.py  # Gestor de plugins
├── tests/                 # Pruebas
├── data/                  # Datos persistentes
│   └── cache/             # Caché persistente
├── logs/                  # Logs del bot
├── .env                   # Variables de entorno
├── main.py                # Punto de entrada
└── requirements.txt       # Dependencias
```

### Patrones de Diseño

El bot implementa varios patrones de diseño:

- **Repository Pattern**: Separa la lógica de acceso a datos del resto de la aplicación
- **Service Pattern**: Encapsula la lógica de negocio en servicios especializados
- **Dependency Injection**: Facilita la inyección de dependencias para pruebas
- **Factory Method**: Para la creación de clientes API según configuración
- **Strategy Pattern**: Para implementar diferentes estrategias de análisis
- **Observer Pattern**: Para notificaciones y eventos del sistema
- **Adapter Pattern**: Para integrar APIs externas con interfaces diferentes
- **Singleton**: Para instancias únicas como configuración y caché
- **Command Pattern**: Para la ejecución de comandos del bot
- **Decorator**: Para añadir funcionalidades a los handlers existentes

### Flujo de Ejecución

1. El usuario envía un comando al bot a través de Telegram
2. El `command_handler.py` recibe el comando y lo dirige al handler correspondiente
3. El handler valida la entrada utilizando `validators.py`
4. El handler solicita al servicio correspondiente que procese la petición
5. El servicio utiliza los repositorios para obtener datos de APIs externas o caché
6. Los repositorios utilizan los clientes API para comunicarse con servicios externos
7. El servicio procesa los datos y devuelve un resultado al handler
8. El handler formatea la respuesta utilizando `formatters.py`
9. El bot envía la respuesta formateada al usuario

## Extensibilidad

### Sistema de Plugins

El bot incluye un sistema de plugins que permite añadir nuevas funcionalidades sin modificar el código base:

1. Crear un nuevo archivo en el directorio `plugins/` con una clase que herede de `Plugin`:

```python
from plugins import Plugin
from telegram import Update
from telegram.ext import CommandHandler, ContextTypes

class MiPlugin(Plugin):
    name = "mi_plugin"
    description = "Mi plugin personalizado"
    
    def register_commands(self, dispatcher):
        dispatcher.add_handler(CommandHandler("mi_comando", self.mi_comando))
    
    async def mi_comando(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text("¡Hola desde mi plugin!")
```

2. El plugin se cargará automáticamente al iniciar el bot si `PLUGINS_ENABLED` está activado

### Añadir Nuevos Servicios OSINT

Para añadir un nuevo servicio OSINT:

1. Crear un nuevo archivo en el directorio `services/` (ej. `domain_service.py`)
2. Implementar la lógica del servicio siguiendo el patrón de los servicios existentes
3. Añadir un nuevo handler en `core/command_handler.py`
4. Registrar el handler en `get_conversation_handlers()`

## Referencia Técnica

### Módulos Principales

#### Config

- **settings.py**: Configuración general del bot
- **api_keys.py**: Gestión de API Keys para servicios externos

#### Core

- **bot.py**: Inicialización y gestión del bot
- **command_handler.py**: Manejo de comandos y conversaciones
- **conversation.py**: Gestión de estados de conversación
- **middleware.py**: Procesamiento previo y posterior de mensajes

#### Services

- **url_service.py**: Análisis de URLs
- **port_service.py**: Escaneo de puertos
- **email_service.py**: Investigación de emails
- **phone_service.py**: Investigación de números telefónicos
- **ip_service.py**: Geolocalización de IPs

#### Repositories

- **api_repository.py**: Acceso a APIs externas
- **cache_repository.py**: Sistema de caché

#### Utils

- **validators.py**: Validación de entradas
- **formatters.py**: Formateo de salidas
- **helpers.py**: Funciones auxiliares
- **security.py**: Utilidades de seguridad

#### Plugins

- **plugin_manager.py**: Gestión de plugins

### Dependencias

El bot utiliza las siguientes dependencias principales:

- **python-telegram-bot**: Framework para bots de Telegram
- **requests**: Para peticiones HTTP
- **beautifulsoup4**: Para scraping web
- **python-whois**: Para consultas WHOIS
- **phonenumbers**: Para análisis de números telefónicos
- **scapy**: Para escaneo de red
- **geoip2**: Para geolocalización de IPs
- **dnspython**: Para consultas DNS
- **cryptography**: Para encriptación de API Keys
- **python-dotenv**: Para cargar variables de entorno

## Solución de Problemas

### Problemas Comunes

#### El bot no responde

- Verifica que el token del bot sea correcto
- Asegúrate de que el bot esté en ejecución
- Comprueba los logs en el directorio `logs/`

#### Error al escanear puertos

- Verifica que tengas permisos para realizar escaneos de red
- Reduce el número de puertos a escanear con `MAX_PORTS_TO_SCAN`
- Aumenta el tiempo de espera con `SCAN_TIMEOUT`

#### Error al usar API Keys

- Verifica que la API Key sea correcta
- Asegúrate de que `ENCRYPTION_KEY` esté configurada
- Comprueba los límites de uso de la API

#### El bot es lento

- Activa el sistema de caché con `CACHE_ENABLED=True`
- Ajusta el tiempo de vida de caché con `CACHE_TTL`
- Reduce el número de puertos a escanear con `MAX_PORTS_TO_SCAN`

### Logs

Los logs se almacenan en el directorio `logs/` y pueden ayudar a diagnosticar problemas:

```bash
tail -f logs/osint_bot.log
```

### Contacto y Soporte

Si tienes problemas o sugerencias, puedes:
- Abrir un issue en el repositorio
- Contactar con el desarrollador a través de Telegram
- Enviar un email a soporte@example.com
