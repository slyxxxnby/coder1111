"""
Módulo para la gestión de API Keys opcionales.
Permite configurar, validar y utilizar API Keys para servicios externos.
"""
import os
import json
import base64
from pathlib import Path
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from . import settings

class APIKeyManager:
    """
    Gestor de API Keys para servicios externos.
    Permite almacenar, recuperar y validar API Keys de forma segura.
    """
    
    def __init__(self, encryption_key=None):
        """
        Inicializa el gestor de API Keys.
        
        Args:
            encryption_key (str, optional): Clave para encriptar las API Keys.
                Si no se proporciona, se utiliza la configurada en settings.
        """
        self.api_keys = {}
        self.api_keys_file = Path(__file__).parent.parent / 'data' / 'api_keys.json'
        
        # Crear directorio si no existe
        self.api_keys_file.parent.mkdir(exist_ok=True)
        
        # Configurar encriptación
        self.encryption_key = encryption_key or settings.ENCRYPTION_KEY
        self.fernet = self._setup_encryption()
        
        # Cargar API Keys existentes
        self.load_api_keys()
    
    def _setup_encryption(self):
        """
        Configura la encriptación para las API Keys.
        
        Returns:
            Fernet: Objeto para encriptar/desencriptar.
        """
        if not self.encryption_key:
            # Si no hay clave de encriptación, generar una temporal
            # Nota: Esto significa que las claves se perderán al reiniciar
            salt = os.urandom(16)
            self.encryption_key = os.urandom(16).hex()
        else:
            # Usar un salt fijo derivado de la clave para consistencia
            salt = self.encryption_key.encode()[:16].ljust(16, b'\0')
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        
        key = base64.urlsafe_b64encode(kdf.derive(self.encryption_key.encode()))
        return Fernet(key)
    
    def load_api_keys(self):
        """
        Carga las API Keys desde el archivo de configuración.
        """
        if not self.api_keys_file.exists():
            self.api_keys = {}
            return
        
        try:
            with open(self.api_keys_file, 'r') as f:
                encrypted_data = f.read()
            
            if encrypted_data:
                decrypted_data = self.fernet.decrypt(encrypted_data.encode()).decode()
                self.api_keys = json.loads(decrypted_data)
            else:
                self.api_keys = {}
        except Exception as e:
            print(f"Error al cargar API Keys: {str(e)}")
            self.api_keys = {}
    
    def save_api_keys(self):
        """
        Guarda las API Keys en el archivo de configuración.
        """
        try:
            encrypted_data = self.fernet.encrypt(json.dumps(self.api_keys).encode()).decode()
            
            with open(self.api_keys_file, 'w') as f:
                f.write(encrypted_data)
                
            return True
        except Exception as e:
            print(f"Error al guardar API Keys: {str(e)}")
            return False
    
    def set_api_key(self, service, key):
        """
        Establece una API Key para un servicio.
        
        Args:
            service (str): Nombre del servicio.
            key (str): API Key.
            
        Returns:
            bool: True si se estableció correctamente, False en caso contrario.
        """
        if not service or not key:
            return False
        
        self.api_keys[service] = key
        return self.save_api_keys()
    
    def get_api_key(self, service):
        """
        Obtiene la API Key para un servicio.
        
        Args:
            service (str): Nombre del servicio.
            
        Returns:
            str: API Key o None si no existe.
        """
        return self.api_keys.get(service)
    
    def delete_api_key(self, service):
        """
        Elimina la API Key para un servicio.
        
        Args:
            service (str): Nombre del servicio.
            
        Returns:
            bool: True si se eliminó correctamente, False en caso contrario.
        """
        if service in self.api_keys:
            del self.api_keys[service]
            return self.save_api_keys()
        return False
    
    def has_api_key(self, service):
        """
        Verifica si existe una API Key para un servicio.
        
        Args:
            service (str): Nombre del servicio.
            
        Returns:
            bool: True si existe, False en caso contrario.
        """
        return service in self.api_keys
    
    def validate_api_key(self, service, validator_func=None):
        """
        Valida la API Key para un servicio.
        
        Args:
            service (str): Nombre del servicio.
            validator_func (callable, optional): Función para validar la API Key.
                Debe aceptar la API Key como parámetro y devolver un booleano.
                
        Returns:
            bool: True si la API Key es válida, False en caso contrario.
        """
        key = self.get_api_key(service)
        
        if not key:
            return False
        
        if validator_func:
            return validator_func(key)
        
        return True
    
    def list_services(self):
        """
        Lista los servicios con API Keys configuradas.
        
        Returns:
            list: Lista de nombres de servicios.
        """
        return list(self.api_keys.keys())

# Instancia global del gestor de API Keys
api_key_manager = APIKeyManager()

# Servicios OSINT disponibles y sus configuraciones
OSINT_SERVICES = {
    'haveibeenpwned': {
        'name': 'Have I Been Pwned',
        'description': 'Verificación de brechas de seguridad para emails',
        'url': 'https://haveibeenpwned.com/API/v3',
        'required': False,
        'fallback': True
    },
    'shodan': {
        'name': 'Shodan',
        'description': 'Búsqueda de dispositivos conectados a Internet',
        'url': 'https://api.shodan.io',
        'required': False,
        'fallback': True
    },
    'virustotal': {
        'name': 'VirusTotal',
        'description': 'Análisis de URLs y archivos maliciosos',
        'url': 'https://www.virustotal.com/api/v3',
        'required': False,
        'fallback': True
    },
    'ipinfo': {
        'name': 'IPinfo',
        'description': 'Información detallada sobre direcciones IP',
        'url': 'https://ipinfo.io/api',
        'required': False,
        'fallback': True
    },
    'numverify': {
        'name': 'Numverify',
        'description': 'Validación y información de números telefónicos',
        'url': 'http://apilayer.net/api/validate',
        'required': False,
        'fallback': True
    },
    'whoisxml': {
        'name': 'WhoisXML API',
        'description': 'Información WHOIS detallada',
        'url': 'https://www.whoisxmlapi.com/whoisserver/WhoisService',
        'required': False,
        'fallback': True
    }
}

def get_service_info(service):
    """
    Obtiene información sobre un servicio OSINT.
    
    Args:
        service (str): Nombre del servicio.
        
    Returns:
        dict: Información del servicio o None si no existe.
    """
    return OSINT_SERVICES.get(service)

def has_api_key(service):
    """
    Verifica si existe una API Key para un servicio.
    
    Args:
        service (str): Nombre del servicio.
        
    Returns:
        bool: True si existe, False en caso contrario.
    """
    return api_key_manager.has_api_key(service)

def get_api_key(service):
    """
    Obtiene la API Key para un servicio.
    
    Args:
        service (str): Nombre del servicio.
        
    Returns:
        str: API Key o None si no existe.
    """
    return api_key_manager.get_api_key(service)

def set_api_key(service, key):
    """
    Establece una API Key para un servicio.
    
    Args:
        service (str): Nombre del servicio.
        key (str): API Key.
        
    Returns:
        bool: True si se estableció correctamente, False en caso contrario.
    """
    return api_key_manager.set_api_key(service, key)

def delete_api_key(service):
    """
    Elimina la API Key para un servicio.
    
    Args:
        service (str): Nombre del servicio.
        
    Returns:
        bool: True si se eliminó correctamente, False en caso contrario.
    """
    return api_key_manager.delete_api_key(service)

def list_services():
    """
    Lista los servicios con API Keys configuradas.
    
    Returns:
        list: Lista de nombres de servicios.
    """
    return api_key_manager.list_services()

def list_available_services():
    """
    Lista todos los servicios OSINT disponibles.
    
    Returns:
        dict: Diccionario con información de los servicios.
    """
    return OSINT_SERVICES
