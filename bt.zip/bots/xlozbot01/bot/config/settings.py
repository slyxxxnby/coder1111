"""
Configuración general para el Bot OSINT Avanzado.
Este módulo contiene la configuración principal del bot, incluyendo opciones
para personalizar el comportamiento y las características del sistema.
"""
import os
import logging
from pathlib import Path
from dotenv import load_dotenv

# Cargar variables de entorno desde archivo .env si existe
env_path = Path(__file__).parent.parent / '.env'
if env_path.exists():
    load_dotenv(dotenv_path=env_path)

# Configuración del Bot
BOT_TOKEN = os.getenv('7644793001:AAFDLDkM_9o9Xryo-gpOaRXykxZ1YQUQUPw', '')
BOT_NAME = os.getenv('BOT_NAME', 'OSINT Bot Avanzado')
BOT_USERNAME = os.getenv('BOT_USERNAME', '')
BOT_ADMIN_IDS = [int(id) for id in os.getenv('BOT_ADMIN_IDS', '').split(',') if id]

# Configuración de Logging
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
LOG_DIR = os.getenv('LOG_DIR', 'logs')
LOG_FILE = os.getenv('LOG_FILE', 'osint_bot.log')
LOG_MAX_SIZE = int(os.getenv('LOG_MAX_SIZE', 10485760))  # 10MB
LOG_BACKUP_COUNT = int(os.getenv('LOG_BACKUP_COUNT', 5))

# Configuración de Caché
CACHE_ENABLED = os.getenv('CACHE_ENABLED', 'True').lower() == 'true'
CACHE_TTL = int(os.getenv('CACHE_TTL', 3600))  # 1 hora por defecto

# Configuración de Rate Limiting
RATE_LIMIT_ENABLED = os.getenv('RATE_LIMIT_ENABLED', 'True').lower() == 'true'
RATE_LIMIT_REQUESTS = int(os.getenv('RATE_LIMIT_REQUESTS', 5))
RATE_LIMIT_WINDOW = int(os.getenv('RATE_LIMIT_WINDOW', 60))  # 60 segundos

# Configuración de Plugins
PLUGINS_ENABLED = os.getenv('PLUGINS_ENABLED', 'True').lower() == 'true'
PLUGINS_DIR = os.getenv('PLUGINS_DIR', 'plugins')

# Configuración de Seguridad
ENCRYPTION_KEY = os.getenv('ENCRYPTION_KEY', '')
SECURE_MODE = os.getenv('SECURE_MODE', 'True').lower() == 'true'

# Configuración de Escaneo
SCAN_TIMEOUT = int(os.getenv('SCAN_TIMEOUT', 30))
MAX_PORTS_TO_SCAN = int(os.getenv('MAX_PORTS_TO_SCAN', 100))
USER_AGENT = os.getenv('USER_AGENT', 'OSINT Bot/1.0')

# Configuración de Funcionalidades
FEATURES = {
    'url_scan': os.getenv('FEATURE_URL_SCAN', 'True').lower() == 'true',
    'port_scan': os.getenv('FEATURE_PORT_SCAN', 'True').lower() == 'true',
    'email_osint': os.getenv('FEATURE_EMAIL_OSINT', 'True').lower() == 'true',
    'phone_osint': os.getenv('FEATURE_PHONE_OSINT', 'True').lower() == 'true',
    'ip_geolocation': os.getenv('FEATURE_IP_GEOLOCATION', 'True').lower() == 'true',
}

# Niveles de logging
LOG_LEVELS = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR,
    'CRITICAL': logging.CRITICAL
}

# Función para obtener el nivel de logging configurado
def get_log_level():
    return LOG_LEVELS.get(LOG_LEVEL.upper(), logging.INFO)
