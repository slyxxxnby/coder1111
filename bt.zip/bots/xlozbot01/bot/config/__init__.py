"""
Módulo de configuración para el Bot OSINT Avanzado.
Gestiona la configuración general y las API Keys opcionales.
"""
