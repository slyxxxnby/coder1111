"""
Módulo para la gestión de conversaciones del Bot OSINT Avanzado.
"""
import logging
from telegram.ext import ConversationHandler

# Configuración del logger
logger = logging.getLogger(__name__)

class ConversationManager:
    """
    Gestor de conversaciones para el Bot OSINT Avanzado.
    Facilita el manejo de estados y transiciones en conversaciones complejas.
    """
    
    def __init__(self):
        """
        Inicializa el gestor de conversaciones.
        """
        self.active_conversations = {}
    
    def start_conversation(self, user_id, conversation_type, initial_data=None):
        """
        Inicia una nueva conversación para un usuario.
        
        Args:
            user_id (int): ID del usuario.
            conversation_type (str): Tipo de conversación.
            initial_data (dict, optional): Datos iniciales para la conversación.
            
        Returns:
            bool: True si se inició correctamente, False si ya existe una conversación activa.
        """
        if user_id in self.active_conversations:
            return False
        
        self.active_conversations[user_id] = {
            'type': conversation_type,
            'state': 'initial',
            'data': initial_data or {}
        }
        
        logger.info(f"Conversación iniciada para usuario {user_id}: {conversation_type}")
        return True
    
    def end_conversation(self, user_id):
        """
        Finaliza la conversación activa de un usuario.
        
        Args:
            user_id (int): ID del usuario.
            
        Returns:
            bool: True si se finalizó correctamente, False si no había conversación activa.
        """
        if user_id not in self.active_conversations:
            return False
        
        conversation = self.active_conversations.pop(user_id)
        logger.info(f"Conversación finalizada para usuario {user_id}: {conversation['type']}")
        return True
    
    def get_conversation(self, user_id):
        """
        Obtiene la conversación activa de un usuario.
        
        Args:
            user_id (int): ID del usuario.
            
        Returns:
            dict: Datos de la conversación o None si no hay conversación activa.
        """
        return self.active_conversations.get(user_id)
    
    def update_conversation_state(self, user_id, state):
        """
        Actualiza el estado de la conversación de un usuario.
        
        Args:
            user_id (int): ID del usuario.
            state (str): Nuevo estado.
            
        Returns:
            bool: True si se actualizó correctamente, False si no había conversación activa.
        """
        if user_id not in self.active_conversations:
            return False
        
        self.active_conversations[user_id]['state'] = state
        return True
    
    def update_conversation_data(self, user_id, data):
        """
        Actualiza los datos de la conversación de un usuario.
        
        Args:
            user_id (int): ID del usuario.
            data (dict): Nuevos datos.
            
        Returns:
            bool: True si se actualizó correctamente, False si no había conversación activa.
        """
        if user_id not in self.active_conversations:
            return False
        
        self.active_conversations[user_id]['data'].update(data)
        return True
    
    def has_active_conversation(self, user_id):
        """
        Verifica si un usuario tiene una conversación activa.
        
        Args:
            user_id (int): ID del usuario.
            
        Returns:
            bool: True si tiene conversación activa, False en caso contrario.
        """
        return user_id in self.active_conversations
    
    def get_conversation_type(self, user_id):
        """
        Obtiene el tipo de conversación activa de un usuario.
        
        Args:
            user_id (int): ID del usuario.
            
        Returns:
            str: Tipo de conversación o None si no hay conversación activa.
        """
        if user_id not in self.active_conversations:
            return None
        
        return self.active_conversations[user_id]['type']
    
    def get_conversation_state(self, user_id):
        """
        Obtiene el estado de la conversación activa de un usuario.
        
        Args:
            user_id (int): ID del usuario.
            
        Returns:
            str: Estado de la conversación o None si no hay conversación activa.
        """
        if user_id not in self.active_conversations:
            return None
        
        return self.active_conversations[user_id]['state']
    
    def get_conversation_data(self, user_id):
        """
        Obtiene los datos de la conversación activa de un usuario.
        
        Args:
            user_id (int): ID del usuario.
            
        Returns:
            dict: Datos de la conversación o None si no hay conversación activa.
        """
        if user_id not in self.active_conversations:
            return None
        
        return self.active_conversations[user_id]['data']

# Instancia global del gestor de conversaciones
conversation_manager = ConversationManager()
