"""
Módulo principal para el core del Bot OSINT Avanzado.
"""
