"""
Módulo de middleware para el Bot OSINT Avanzado.
Proporciona funcionalidades de procesamiento previo y posterior para los mensajes.
"""
import time
import logging
from telegram import Update
from telegram.ext import ContextTypes
from ..config import settings

# Configuración del logger
logger = logging.getLogger(__name__)

class Middleware:
    """
    Clase base para middleware.
    """
    
    async def process_update(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Procesa una actualización antes de ser manejada.
        
        Args:
            update (Update): Actualización de Telegram.
            context (ContextTypes.DEFAULT_TYPE): Contexto de la actualización.
            
        Returns:
            bool: True si la actualización debe continuar, False en caso contrario.
        """
        # Implementar en subclases
        return True

class RateLimitMiddleware(Middleware):
    """
    Middleware para limitar la tasa de solicitudes por usuario.
    """
    
    def __init__(self, limit=5, window=60):
        """
        Inicializa el middleware de rate limiting.
        
        Args:
            limit (int): Número máximo de solicitudes permitidas en la ventana de tiempo.
            window (int): Ventana de tiempo en segundos.
        """
        self.limit = limit
        self.window = window
        self.users = {}
    
    async def process_update(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Procesa una actualización y verifica el límite de tasa.
        
        Args:
            update (Update): Actualización de Telegram.
            context (ContextTypes.DEFAULT_TYPE): Contexto de la actualización.
            
        Returns:
            bool: True si la actualización está dentro del límite, False en caso contrario.
        """
        if not update.effective_user:
            return True
            
        user_id = update.effective_user.id
        current_time = time.time()
        
        if user_id not in self.users:
            self.users[user_id] = []
        
        # Limpiar registros antiguos
        self.users[user_id] = [t for t in self.users[user_id] if current_time - t < self.window]
        
        # Verificar límite
        if len(self.users[user_id]) >= self.limit:
            if update.message:
                await update.message.reply_text(
                    "⚠️ Has excedido el límite de solicitudes. Por favor, inténtalo más tarde."
                )
            return False
        
        self.users[user_id].append(current_time)
        return True

class LoggingMiddleware(Middleware):
    """
    Middleware para registrar información sobre las actualizaciones.
    """
    
    async def process_update(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Registra información sobre la actualización.
        
        Args:
            update (Update): Actualización de Telegram.
            context (ContextTypes.DEFAULT_TYPE): Contexto de la actualización.
            
        Returns:
            bool: Siempre True para permitir que la actualización continúe.
        """
        if update.effective_user:
            user_id = update.effective_user.id
            username = update.effective_user.username or "Sin username"
            
            if update.message and update.message.text:
                logger.info(f"Usuario {user_id} (@{username}) envió: {update.message.text}")
            elif update.callback_query:
                logger.info(f"Usuario {user_id} (@{username}) presionó: {update.callback_query.data}")
        
        return True

class SecurityMiddleware(Middleware):
    """
    Middleware para verificar aspectos de seguridad.
    """
    
    async def process_update(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Verifica aspectos de seguridad de la actualización.
        
        Args:
            update (Update): Actualización de Telegram.
            context (ContextTypes.DEFAULT_TYPE): Contexto de la actualización.
            
        Returns:
            bool: True si la actualización pasa las verificaciones de seguridad, False en caso contrario.
        """
        # Verificar si el modo seguro está activado
        if not settings.SECURE_MODE:
            return True
            
        # Verificar si el usuario está en la lista de administradores para comandos sensibles
        if update.message and update.message.text and update.message.text.startswith(("/api_keys", "/settings")):
            if update.effective_user.id not in settings.BOT_ADMIN_IDS and settings.BOT_ADMIN_IDS:
                await update.message.reply_text(
                    "❌ No tienes permisos para ejecutar este comando."
                )
                return False
        
        return True
