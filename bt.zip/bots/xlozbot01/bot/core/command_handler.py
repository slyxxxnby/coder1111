"""
Módulo para el manejo de comandos del Bot OSINT Avanzado.
"""
import logging
from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler
from ..config import settings, api_keys
from ..services import url_service, port_service, email_service, phone_service, ip_service

# Configuración del logger
logger = logging.getLogger(__name__)

# Estados para los ConversationHandler
(
    URL_SCAN, PORT_SCAN, EMAIL_OSINT, 
    PHONE_OSINT, IP_GEOLOCATION, API_KEY_SERVICE,
    API_KEY_VALUE, SETTINGS_MENU
) = range(8)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /start - Inicia el bot y muestra el menú principal.
    """
    keyboard = [
        ["/scan_url", "/scan_port"],
        ["/osint_email", "/osint_phone"],
        ["/geolocate_ip", "/settings"],
        ["/api_keys", "/help"]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    
    await update.message.reply_text(
        f"🕵️‍♂️ *Bienvenido al {settings.BOT_NAME}* 🕵️‍♀️\n\n"
        "Selecciona una opción del menú para comenzar:\n\n"
        "• /scan_url - Escanear una URL\n"
        "• /scan_port - Escanear puertos\n"
        "• /osint_email - Investigar email\n"
        "• /osint_phone - Investigar teléfono\n"
        "• /geolocate_ip - Geolocalizar IP\n"
        "• /settings - Configurar opciones\n"
        "• /api_keys - Gestionar API Keys\n"
        "• /help - Mostrar ayuda\n",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /help - Muestra la ayuda y comandos disponibles.
    """
    help_text = """
    *📌 Comandos disponibles:*
    
    */scan_url* - Escanea una URL para obtener información detallada
    */scan_port* - Escanea puertos de un objetivo
    */osint_email* - Realiza OSINT sobre un email
    */osint_phone* - Realiza OSINT sobre un número telefónico
    */geolocate_ip* - Geolocaliza una dirección IP
    */settings* - Configura las opciones del bot
    */api_keys* - Gestiona las API Keys para servicios externos
    */help* - Muestra este mensaje
    */cancel* - Cancela la operación actual
    
    _Selecciona una opción del menú o escribe el comando directamente._
    
    *🔑 API Keys Opcionales:*
    Este bot puede funcionar sin API Keys, pero para obtener resultados más completos,
    puedes configurar API Keys para servicios externos usando el comando /api_keys.
    """
    await update.message.reply_text(help_text, parse_mode="Markdown")

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /cancel - Cancela la operación actual.
    """
    await update.message.reply_text("✅ Operación cancelada.")
    return ConversationHandler.END

async def unknown_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Maneja mensajes que no coinciden con ningún comando.
    """
    await update.message.reply_text(
        "No entiendo ese comando. Usa /help para ver los comandos disponibles."
    )

# URL Scanning
async def scan_url_init(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /scan_url - Inicia el escaneo de URL.
    """
    await update.message.reply_text("🔍 Envíame la URL que deseas escanear:")
    return URL_SCAN

async def scan_url(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Procesa la URL enviada y realiza el escaneo.
    """
    url = update.message.text
    
    # Mostrar mensaje de espera
    wait_message = await update.message.reply_text("⏳ Analizando URL, por favor espera...")
    
    # Realizar escaneo
    try:
        result = await url_service.analyze_url(url)
        await wait_message.delete()
        await update.message.reply_text(result, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Error al escanear URL: {str(e)}")
        await wait_message.delete()
        await update.message.reply_text(f"❌ Error al escanear URL: {str(e)}")
    
    return ConversationHandler.END

# Port Scanning
async def scan_port_init(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /scan_port - Inicia el escaneo de puertos.
    """
    await update.message.reply_text("🔌 Envíame la IP o dominio para escanear puertos:")
    return PORT_SCAN

async def scan_port(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Procesa la IP o dominio enviado y realiza el escaneo de puertos.
    """
    target = update.message.text
    
    # Mostrar mensaje de espera
    wait_message = await update.message.reply_text("⏳ Escaneando puertos, por favor espera...")
    
    # Realizar escaneo
    try:
        result = await port_service.scan_ports(target)
        await wait_message.delete()
        await update.message.reply_text(result, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Error al escanear puertos: {str(e)}")
        await wait_message.delete()
        await update.message.reply_text(f"❌ Error al escanear puertos: {str(e)}")
    
    return ConversationHandler.END

# Email OSINT
async def osint_email_init(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /osint_email - Inicia la investigación de email.
    """
    await update.message.reply_text("📧 Envíame el email a investigar:")
    return EMAIL_OSINT

async def osint_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Procesa el email enviado y realiza la investigación OSINT.
    """
    email = update.message.text
    
    # Mostrar mensaje de espera
    wait_message = await update.message.reply_text("⏳ Investigando email, por favor espera...")
    
    # Realizar investigación
    try:
        result = await email_service.investigate_email(email)
        await wait_message.delete()
        await update.message.reply_text(result, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Error al investigar email: {str(e)}")
        await wait_message.delete()
        await update.message.reply_text(f"❌ Error al investigar email: {str(e)}")
    
    return ConversationHandler.END

# Phone OSINT
async def osint_phone_init(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /osint_phone - Inicia la investigación de teléfono.
    """
    await update.message.reply_text("📱 Envíame el número telefónico (con código de país):")
    return PHONE_OSINT

async def osint_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Procesa el número telefónico enviado y realiza la investigación OSINT.
    """
    phone = update.message.text
    
    # Mostrar mensaje de espera
    wait_message = await update.message.reply_text("⏳ Investigando teléfono, por favor espera...")
    
    # Realizar investigación
    try:
        result = await phone_service.investigate_phone(phone)
        await wait_message.delete()
        await update.message.reply_text(result, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Error al investigar teléfono: {str(e)}")
        await wait_message.delete()
        await update.message.reply_text(f"❌ Error al investigar teléfono: {str(e)}")
    
    return ConversationHandler.END

# IP Geolocation
async def geolocate_ip_init(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /geolocate_ip - Inicia la geolocalización de IP.
    """
    await update.message.reply_text("🌍 Envíame la dirección IP a geolocalizar:")
    return IP_GEOLOCATION

async def geolocate_ip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Procesa la dirección IP enviada y realiza la geolocalización.
    """
    ip = update.message.text
    
    # Mostrar mensaje de espera
    wait_message = await update.message.reply_text("⏳ Geolocalizando IP, por favor espera...")
    
    # Realizar geolocalización
    try:
        result = await ip_service.geolocate_ip(ip)
        await wait_message.delete()
        await update.message.reply_text(result, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Error al geolocalizar IP: {str(e)}")
        await wait_message.delete()
        await update.message.reply_text(f"❌ Error al geolocalizar IP: {str(e)}")
    
    return ConversationHandler.END

# Settings
async def settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /settings - Muestra y gestiona las configuraciones del bot.
    """
    keyboard = [
        [InlineKeyboardButton("🔄 Caché", callback_data="settings_cache")],
        [InlineKeyboardButton("⏱️ Rate Limit", callback_data="settings_rate_limit")],
        [InlineKeyboardButton("🔌 Plugins", callback_data="settings_plugins")],
        [InlineKeyboardButton("🔒 Modo Seguro", callback_data="settings_secure_mode")],
        [InlineKeyboardButton("❌ Cerrar", callback_data="settings_close")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "*⚙️ Configuración del Bot*\n\n"
        f"• *Caché:* {'Activada' if settings.CACHE_ENABLED else 'Desactivada'}\n"
        f"• *Rate Limit:* {'Activado' if settings.RATE_LIMIT_ENABLED else 'Desactivado'}\n"
        f"• *Plugins:* {'Activados' if settings.PLUGINS_ENABLED else 'Desactivados'}\n"
        f"• *Modo Seguro:* {'Activado' if settings.SECURE_MODE else 'Desactivado'}\n\n"
        "Selecciona una opción para cambiar su configuración:",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )
    return SETTINGS_MENU

# API Keys
async def api_keys(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Comando /api_keys - Gestiona las API Keys para servicios externos.
    """
    # Verificar si el usuario es administrador
    if update.effective_user.id not in settings.BOT_ADMIN_IDS and settings.BOT_ADMIN_IDS:
        await update.message.reply_text("❌ No tienes permisos para gestionar API Keys.")
        return ConversationHandler.END
    
    # Crear teclado con servicios disponibles
    keyboard = []
    for service_id, service_info in api_keys.OSINT_SERVICES.items():
        status = "✅" if api_keys.has_api_key(service_id) else "❌"
        keyboard.append([
            InlineKeyboardButton(
                f"{status} {service_info['name']}", 
                callback_data=f"apikey_{service_id}"
            )
        ])
    
    keyboard.append([InlineKeyboardButton("❌ Cerrar", callback_data="apikey_close")])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "*🔑 Gestión de API Keys*\n\n"
        "Selecciona un servicio para configurar su API Key:\n\n"
        "✅ = Configurada | ❌ = No configurada",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )
    return API_KEY_SERVICE

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Maneja las callback queries de los botones inline.
    """
    query = update.callback_query
    await query.answer()
    
    # Manejar callbacks de API Keys
    if query.data.startswith("apikey_"):
        service_id = query.data.replace("apikey_", "")
        
        if service_id == "close":
            await query.edit_message_text("✅ Gestión de API Keys cerrada.")
            return ConversationHandler.END
        
        # Guardar el servicio en el contexto
        context.user_data["api_key_service"] = service_id
        service_info = api_keys.get_service_info(service_id)
        
        # Mostrar información del servicio y solicitar API Key
        current_key = api_keys.get_api_key(service_id)
        key_status = "Configurada" if current_key else "No configurada"
        
        keyboard = [
            [InlineKeyboardButton("🗑️ Eliminar API Key", callback_data="apikey_delete")],
            [InlineKeyboardButton("❌ Cancelar", callback_data="apikey_cancel")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            f"*🔑 Configuración de API Key: {service_info['name']}*\n\n"
            f"*Descripción:* {service_info['description']}\n"
            f"*URL:* {service_info['url']}\n"
            f"*Estado actual:* {key_status}\n\n"
            "Envía tu API Key para este servicio o selecciona una opción:",
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )
        return API_KEY_VALUE
    
    # Manejar callbacks de configuración
    elif query.data.startswith("settings_"):
        setting = query.data.replace("settings_", "")
        
        if setting == "close":
            await query.edit_message_text("✅ Configuración cerrada.")
            return ConversationHandler.END
        
        # Implementar cambios de configuración
        # Nota: En una implementación real, estos cambios deberían persistirse
        if setting == "cache":
            # Cambiar estado de caché
            settings.CACHE_ENABLED = not settings.CACHE_ENABLED
        elif setting == "rate_limit":
            # Cambiar estado de rate limit
            settings.RATE_LIMIT_ENABLED = not settings.RATE_LIMIT_ENABLED
        elif setting == "plugins":
            # Cambiar estado de plugins
            settings.PLUGINS_ENABLED = not settings.PLUGINS_ENABLED
        elif setting == "secure_mode":
            # Cambiar estado de modo seguro
            settings.SECURE_MODE = not settings.SECURE_MODE
        
        # Actualizar mensaje con nueva configuración
        keyboard = [
            [InlineKeyboardButton("🔄 Caché", callback_data="settings_cache")],
            [InlineKeyboardButton("⏱️ Rate Limit", callback_data="settings_rate_limit")],
            [InlineKeyboardButton("🔌 Plugins", callback_data="settings_plugins")],
            [InlineKeyboardButton("🔒 Modo Seguro", callback_data="settings_secure_mode")],
            [InlineKeyboardButton("❌ Cerrar", callback_data="settings_close")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(
            "*⚙️ Configuración del Bot*\n\n"
            f"• *Caché:* {'Activada' if settings.CACHE_ENABLED else 'Desactivada'}\n"
            f"• *Rate Limit:* {'Activado' if settings.RATE_LIMIT_ENABLED else 'Desactivado'}\n"
            f"• *Plugins:* {'Activados' if settings.PLUGINS_ENABLED else 'Desactivados'}\n"
            f"• *Modo Seguro:* {'Activado' if settings.SECURE_MODE else 'Desactivado'}\n\n"
            "Selecciona una opción para cambiar su configuración:",
            reply_markup=reply_markup,
            parse_mode="Markdown"
        )
        return SETTINGS_MENU
    
    # Manejar callbacks de eliminación de API Key
    elif query.data == "apikey_delete":
        service_id = context.user_data.get("api_key_service")
        if service_id:
            api_keys.delete_api_key(service_id)
            service_info = api_keys.get_service_info(service_id)
            await query.edit_message_text(
                f"✅ API Key para {service_info['name']} eliminada correctamente."
            )
        else:
            await query.edit_message_text("❌ Error: No se pudo identificar el servicio.")
        
        return ConversationHandler.END
    
    # Manejar cancelación de configuración de API Key
    elif query.data == "apikey_cancel":
        await query.edit_message_text("✅ Configuración de API Key cancelada.")
        return ConversationHandler.END
    
    return SETTINGS_MENU

async def set_api_key(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Procesa la API Key enviada y la configura para el servicio seleccionado.
    """
    service_id = context.user_data.get("api_key_service")
    if not service_id:
        await update.message.reply_text("❌ Error: No se pudo identificar el servicio.")
        return ConversationHandler.END
    
    key = update.message.text
    service_info = api_keys.get_service_info(service_id)
    
    # Configurar API Key
    if api_keys.set_api_key(service_id, key):
        await update.message.reply_text(
            f"✅ API Key para {service_info['name']} configurada correctamente."
        )
    else:
        await update.message.reply_text(
            f"❌ Error al configurar API Key para {service_info['name']}."
        )
    
    return ConversationHandler.END

def get_conversation_handlers():
    """
    Retorna los conversation handlers para las funcionalidades del bot.
    """
    handlers = [
        ConversationHandler(
            entry_points=[CommandHandler("scan_url", scan_url_init)],
            states={
                URL_SCAN: [MessageHandler(filters.TEXT & ~filters.COMMAND, scan_url)]
            },
            fallbacks=[CommandHandler("cancel", cancel)]
        ),
        ConversationHandler(
            entry_points=[CommandHandler("scan_port", scan_port_init)],
            states={
                PORT_SCAN: [MessageHandler(filters.TEXT & ~filters.COMMAND, scan_port)]
            },
            fallbacks=[CommandHandler("cancel", cancel)]
        ),
        ConversationHandler(
            entry_points=[CommandHandler("osint_email", osint_email_init)],
            states={
                EMAIL_OSINT: [MessageHandler(filters.TEXT & ~filters.COMMAND, osint_email)]
            },
            fallbacks=[CommandHandler("cancel", cancel)]
        ),
        ConversationHandler(
            entry_points=[CommandHandler("osint_phone", osint_phone_init)],
            states={
                PHONE_OSINT: [MessageHandler(filters.TEXT & ~filters.COMMAND, osint_phone)]
            },
            fallbacks=[CommandHandler("cancel", cancel)]
        ),
        ConversationHandler(
            entry_points=[CommandHandler("geolocate_ip", geolocate_ip_init)],
            states={
                IP_GEOLOCATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, geolocate_ip)]
            },
            fallbacks=[CommandHandler("cancel", cancel)]
        ),
        ConversationHandler(
            entry_points=[CommandHandler("settings", settings)],
            states={
                SETTINGS_MENU: [CallbackQueryHandler(handle_callback)]
            },
            fallbacks=[CommandHandler("cancel", cancel)]
        ),
        ConversationHandler(
            entry_points=[CommandHandler("api_keys", api_keys)],
            states={
                API_KEY_SERVICE: [CallbackQueryHandler(handle_callback)],
                API_KEY_VALUE: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, set_api_key),
                    CallbackQueryHandler(handle_callback)
                ]
            },
            fallbacks=[CommandHandler("cancel", cancel)]
        )
    ]
    
    return handlers
