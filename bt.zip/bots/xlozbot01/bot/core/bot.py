"""
Módulo principal para la inicialización y gestión del Bot OSINT Avanzado.
"""
import logging
from telegram import Update, ReplyKeyboardMarkup, BotCommand
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
    ConversationHandler,
    CallbackQueryHandler
)
from ..config import settings
from ..core import command_handler, middleware
from ..plugins import plugin_manager

# Configuración del logger
logger = logging.getLogger(__name__)

class OSINTBot:
    """
    Clase principal para la gestión del Bot OSINT Avanzado.
    """
    
    def __init__(self, token=None):
        """
        Inicializa el bot con el token proporcionado o el configurado.
        
        Args:
            token (str, optional): Token del bot de Telegram.
                Si no se proporciona, se utiliza el configurado en settings.
        """
        self.token = token or settings.BOT_TOKEN
        self.application = None
        self.handlers_registered = False
        self.middlewares = []
        
        # Verificar token
        if not self.token:
            logger.error("No se ha configurado un token para el bot")
            raise ValueError("Se requiere un token para inicializar el bot")
    
    async def setup_commands(self):
        """
        Configura los comandos disponibles en el menú del bot.
        """
        commands = [
            BotCommand("start", "Iniciar el bot y mostrar menú principal"),
            BotCommand("help", "Mostrar ayuda y comandos disponibles"),
            BotCommand("scan_url", "Escanear una URL"),
            BotCommand("scan_port", "Escanear puertos"),
            BotCommand("osint_email", "Investigar email"),
            BotCommand("osint_phone", "Investigar teléfono"),
            BotCommand("geolocate_ip", "Geolocalizar IP"),
            BotCommand("settings", "Configurar opciones del bot"),
            BotCommand("api_keys", "Gestionar API Keys"),
            BotCommand("cancel", "Cancelar operación actual")
        ]
        
        await self.application.bot.set_my_commands(commands)
    
    def register_handlers(self):
        """
        Registra los manejadores de comandos y mensajes.
        """
        if self.handlers_registered:
            return
        
        # Manejadores básicos
        self.application.add_handler(CommandHandler("start", command_handler.start))
        self.application.add_handler(CommandHandler("help", command_handler.help_command))
        self.application.add_handler(CommandHandler("settings", command_handler.settings))
        self.application.add_handler(CommandHandler("api_keys", command_handler.api_keys))
        
        # Registrar conversation handlers para cada funcionalidad
        for handler in command_handler.get_conversation_handlers():
            self.application.add_handler(handler)
        
        # Manejador para callback queries
        self.application.add_handler(CallbackQueryHandler(command_handler.handle_callback))
        
        # Manejador para mensajes no reconocidos
        self.application.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND, 
            command_handler.unknown_message
        ))
        
        # Cargar plugins si están habilitados
        if settings.PLUGINS_ENABLED:
            plugin_manager.load_plugins(self.application)
        
        self.handlers_registered = True
    
    def register_middleware(self, middleware_instance):
        """
        Registra un middleware para procesar mensajes.
        
        Args:
            middleware_instance: Instancia de middleware a registrar.
        """
        self.middlewares.append(middleware_instance)
    
    def setup_middleware(self):
        """
        Configura los middlewares predeterminados.
        """
        # Middleware de rate limiting
        if settings.RATE_LIMIT_ENABLED:
            rate_limit_middleware = middleware.RateLimitMiddleware(
                limit=settings.RATE_LIMIT_REQUESTS,
                window=settings.RATE_LIMIT_WINDOW
            )
            self.register_middleware(rate_limit_middleware)
        
        # Middleware de logging
        log_middleware = middleware.LoggingMiddleware()
        self.register_middleware(log_middleware)
        
        # Aplicar middlewares
        for mw in self.middlewares:
            self.application.add_handler(
                MessageHandler(filters.ALL, mw.process_update), group=-1
            )
    
    def start(self):
        """
        Inicia el bot y comienza a escuchar actualizaciones.
        """
        try:
            # Inicializar la aplicación
            self.application = ApplicationBuilder().token(self.token).build()
            
            # Registrar manejadores y middlewares
            self.register_handlers()
            self.setup_middleware()
            
            # Configurar comandos
            self.application.create_task(self.setup_commands())
            
            # Iniciar el polling
            logger.info(f"Iniciando {settings.BOT_NAME}...")
            self.application.run_polling()
            
        except Exception as e:
            logger.error(f"Error al iniciar el bot: {str(e)}")
            raise

def start_bot(token=None):
    """
    Función para iniciar el bot desde el punto de entrada principal.
    
    Args:
        token (str, optional): Token del bot de Telegram.
            Si no se proporciona, se utiliza el configurado en settings.
    """
    # Configurar logging
    setup_logging()
    
    # Iniciar el bot
    bot = OSINTBot(token)
    bot.start()

def setup_logging():
    """
    Configura el sistema de logging.
    """
    import os
    from logging.handlers import RotatingFileHandler
    
    # Crear directorio de logs si no existe
    os.makedirs(settings.LOG_DIR, exist_ok=True)
    
    # Configurar logger principal
    logger = logging.getLogger()
    logger.setLevel(settings.get_log_level())
    
    # Handler para consola
    console_handler = logging.StreamHandler()
    console_handler.setLevel(settings.get_log_level())
    
    # Handler para archivo con rotación
    file_handler = RotatingFileHandler(
        os.path.join(settings.LOG_DIR, settings.LOG_FILE),
        maxBytes=settings.LOG_MAX_SIZE,
        backupCount=settings.LOG_BACKUP_COUNT
    )
    file_handler.setLevel(settings.get_log_level())
    
    # Formato
    formatter = logging.Formatter(settings.LOG_FORMAT)
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)
    
    # Añadir handlers
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
