"""
Módulo de inicialización para los plugins del Bot OSINT Avanzado.
"""
