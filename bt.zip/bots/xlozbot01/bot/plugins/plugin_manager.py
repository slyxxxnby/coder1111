"""
Gestor de plugins para el Bot OSINT Avanzado.
"""
import logging
import importlib
import inspect
import os
from pathlib import Path
from ..config import settings

# Configuración del logger
logger = logging.getLogger(__name__)

class Plugin:
    """
    Clase base para plugins del Bot OSINT Avanzado.
    """
    
    name = "base_plugin"
    description = "Plugin base"
    
    def __init__(self):
        """
        Inicializa el plugin.
        """
        pass
    
    def register_commands(self, dispatcher):
        """
        Registra los comandos del plugin en el dispatcher.
        
        Args:
            dispatcher: Dispatcher de Telegram.
        """
        pass
    
    def initialize(self):
        """
        Inicializa el plugin.
        
        Returns:
            bool: True si se inicializó correctamente.
        """
        return True
    
    def shutdown(self):
        """
        Cierra el plugin.
        
        Returns:
            bool: True si se cerró correctamente.
        """
        return True

class PluginManager:
    """
    Gestor de plugins para el Bot OSINT Avanzado.
    """
    
    def __init__(self):
        """
        Inicializa el gestor de plugins.
        """
        self.plugins = {}
        self.plugins_dir = Path(__file__).parent
    
    def discover_plugins(self):
        """
        Descubre los plugins disponibles.
        
        Returns:
            list: Lista de plugins disponibles.
        """
        plugins = []
        
        # Buscar en el directorio de plugins
        for file in os.listdir(self.plugins_dir):
            if file.endswith(".py") and not file.startswith("__"):
                module_name = file[:-3]
                try:
                    module = importlib.import_module(f"..plugins.{module_name}", package=__package__)
                    
                    # Buscar clases que hereden de Plugin
                    for name, obj in inspect.getmembers(module):
                        if (inspect.isclass(obj) and 
                            issubclass(obj, Plugin) and 
                            obj != Plugin):
                            plugins.append(obj)
                except Exception as e:
                    logger.error(f"Error al cargar plugin {module_name}: {str(e)}")
        
        return plugins
    
    def load_plugins(self, application):
        """
        Carga los plugins disponibles.
        
        Args:
            application: Aplicación de Telegram.
            
        Returns:
            int: Número de plugins cargados.
        """
        if not settings.PLUGINS_ENABLED:
            logger.info("Plugins deshabilitados")
            return 0
        
        count = 0
        discovered_plugins = self.discover_plugins()
        
        for plugin_class in discovered_plugins:
            try:
                plugin = plugin_class()
                if plugin.initialize():
                    plugin.register_commands(application)
                    self.plugins[plugin.name] = plugin
                    logger.info(f"Plugin cargado: {plugin.name} - {plugin.description}")
                    count += 1
                else:
                    logger.warning(f"No se pudo inicializar el plugin: {plugin.name}")
            except Exception as e:
                logger.error(f"Error al cargar plugin {plugin_class.__name__}: {str(e)}")
        
        logger.info(f"Total de plugins cargados: {count}")
        return count
    
    def unload_plugins(self):
        """
        Descarga todos los plugins.
        
        Returns:
            int: Número de plugins descargados.
        """
        count = 0
        for name, plugin in list(self.plugins.items()):
            try:
                if plugin.shutdown():
                    del self.plugins[name]
                    count += 1
                    logger.info(f"Plugin descargado: {name}")
                else:
                    logger.warning(f"No se pudo cerrar el plugin: {name}")
            except Exception as e:
                logger.error(f"Error al descargar plugin {name}: {str(e)}")
        
        logger.info(f"Total de plugins descargados: {count}")
        return count
    
    def get_plugin(self, name):
        """
        Obtiene un plugin por su nombre.
        
        Args:
            name (str): Nombre del plugin.
            
        Returns:
            Plugin: Plugin o None si no existe.
        """
        return self.plugins.get(name)
    
    def get_plugins(self):
        """
        Obtiene todos los plugins cargados.
        
        Returns:
            dict: Diccionario de plugins.
        """
        return self.plugins

# Instancia global del gestor de plugins
plugin_manager = PluginManager()
