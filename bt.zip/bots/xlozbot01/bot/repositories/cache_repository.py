"""
Repositorio para caché en el Bot OSINT Avanzado.
"""
import logging
import json
import time
import os
from pathlib import Path
from ..config import settings
from ..utils import helpers

# Configuración del logger
logger = logging.getLogger(__name__)

class CacheRepository:
    """
    Repositorio para caché de resultados.
    """
    
    def __init__(self):
        """
        Inicializa el repositorio de caché.
        """
        self.cache_dir = Path(__file__).parent.parent / 'data' / 'cache'
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.memory_cache = {}
    
    async def get(self, key):
        """
        Obtiene un valor de la caché.
        
        Args:
            key (str): Clave del valor a obtener.
            
        Returns:
            Any: Valor almacenado o None si no existe o ha expirado.
        """
        if not settings.CACHE_ENABLED:
            return None
        
        try:
            # Intentar obtener de memoria primero
            if key in self.memory_cache:
                item = self.memory_cache[key]
                if item['expires'] > time.time():
                    logger.debug(f"Caché en memoria encontrada para {key}")
                    return item['value']
                else:
                    # Expirado, eliminar de memoria
                    del self.memory_cache[key]
            
            # Intentar obtener de archivo
            cache_file = self.cache_dir / f"{self._sanitize_key(key)}.json"
            if cache_file.exists():
                with open(cache_file, 'r') as f:
                    item = json.load(f)
                
                if item['expires'] > time.time():
                    # Guardar en memoria para acceso más rápido
                    self.memory_cache[key] = item
                    logger.debug(f"Caché en archivo encontrada para {key}")
                    return item['value']
                else:
                    # Expirado, eliminar archivo
                    cache_file.unlink(missing_ok=True)
            
            return None
        except Exception as e:
            logger.error(f"Error al obtener de caché {key}: {str(e)}")
            return None
    
    async def set(self, key, value, ttl=None):
        """
        Almacena un valor en la caché.
        
        Args:
            key (str): Clave para el valor.
            value (Any): Valor a almacenar.
            ttl (int, optional): Tiempo de vida en segundos.
                Si no se proporciona, se utiliza el configurado en settings.
                
        Returns:
            bool: True si se almacenó correctamente.
        """
        if not settings.CACHE_ENABLED:
            return False
        
        try:
            ttl = ttl or settings.CACHE_TTL
            expires = time.time() + ttl
            
            item = {
                'key': key,
                'value': value,
                'expires': expires
            }
            
            # Guardar en memoria
            self.memory_cache[key] = item
            
            # Guardar en archivo
            cache_file = self.cache_dir / f"{self._sanitize_key(key)}.json"
            with open(cache_file, 'w') as f:
                json.dump(item, f)
            
            logger.debug(f"Valor almacenado en caché para {key}")
            return True
        except Exception as e:
            logger.error(f"Error al almacenar en caché {key}: {str(e)}")
            return False
    
    async def delete(self, key):
        """
        Elimina un valor de la caché.
        
        Args:
            key (str): Clave del valor a eliminar.
            
        Returns:
            bool: True si se eliminó correctamente.
        """
        try:
            # Eliminar de memoria
            if key in self.memory_cache:
                del self.memory_cache[key]
            
            # Eliminar de archivo
            cache_file = self.cache_dir / f"{self._sanitize_key(key)}.json"
            if cache_file.exists():
                cache_file.unlink()
            
            logger.debug(f"Valor eliminado de caché para {key}")
            return True
        except Exception as e:
            logger.error(f"Error al eliminar de caché {key}: {str(e)}")
            return False
    
    async def clear(self):
        """
        Limpia toda la caché.
        
        Returns:
            bool: True si se limpió correctamente.
        """
        try:
            # Limpiar memoria
            self.memory_cache = {}
            
            # Limpiar archivos
            for cache_file in self.cache_dir.glob('*.json'):
                cache_file.unlink()
            
            logger.debug("Caché limpiada")
            return True
        except Exception as e:
            logger.error(f"Error al limpiar caché: {str(e)}")
            return False
    
    async def cleanup(self):
        """
        Limpia entradas expiradas de la caché.
        
        Returns:
            int: Número de entradas eliminadas.
        """
        try:
            count = 0
            current_time = time.time()
            
            # Limpiar memoria
            expired_keys = [k for k, v in self.memory_cache.items() if v['expires'] <= current_time]
            for key in expired_keys:
                del self.memory_cache[key]
                count += 1
            
            # Limpiar archivos
            for cache_file in self.cache_dir.glob('*.json'):
                try:
                    with open(cache_file, 'r') as f:
                        item = json.load(f)
                    
                    if item['expires'] <= current_time:
                        cache_file.unlink()
                        count += 1
                except Exception:
                    # Si hay error al leer, eliminar archivo
                    cache_file.unlink(missing_ok=True)
                    count += 1
            
            logger.debug(f"Limpieza de caché completada: {count} entradas eliminadas")
            return count
        except Exception as e:
            logger.error(f"Error al limpiar entradas expiradas: {str(e)}")
            return 0
    
    def _sanitize_key(self, key):
        """
        Sanitiza una clave para usarla como nombre de archivo.
        
        Args:
            key (str): Clave a sanitizar.
            
        Returns:
            str: Clave sanitizada.
        """
        import hashlib
        return hashlib.md5(key.encode()).hexdigest()

# Instancia global del repositorio
cache_repository = CacheRepository()
