"""
Repositorio para acceso a APIs externas en el Bot OSINT Avanzado.
"""
import logging
import aiohttp
import json
from ..config import settings, api_keys
from ..utils import helpers, security

# Configuración del logger
logger = logging.getLogger(__name__)

class APIRepository:
    """
    Repositorio para acceso a APIs externas.
    """
    
    def __init__(self):
        """
        Inicializa el repositorio de APIs.
        """
        pass
    
    async def get_whois_data(self, domain, api_key):
        """
        Obtiene datos WHOIS de un dominio usando WhoisXML API.
        
        Args:
            domain (str): Dominio a consultar.
            api_key (str): API Key para WhoisXML API.
            
        Returns:
            dict: Datos WHOIS o None si no se pudo obtener.
        """
        try:
            url = f"https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey={api_key}&domainName={domain}&outputFormat=JSON"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=settings.SCAN_TIMEOUT) as response:
                    if response.status == 200:
                        data = await response.json()
                        whois_record = data.get('WhoisRecord', {})
                        
                        return {
                            'registrant': whois_record.get('registrant', {}).get('name', "Desconocido"),
                            'org': whois_record.get('registrant', {}).get('organization', "Desconocida"),
                            'creation_date': whois_record.get('createdDate', "Desconocida"),
                            'expiration_date': whois_record.get('expiresDate', "Desconocida"),
                            'registrar': whois_record.get('registrarName', "Desconocido"),
                            'country': whois_record.get('registrant', {}).get('country', "Desconocido")
                        }
            
            return None
        except Exception as e:
            logger.error(f"Error al obtener datos WHOIS para {domain}: {str(e)}")
            return None
    
    async def get_virustotal_data(self, url, api_key):
        """
        Obtiene datos de seguridad de VirusTotal.
        
        Args:
            url (str): URL a consultar.
            api_key (str): API Key para VirusTotal.
            
        Returns:
            dict: Datos de seguridad o None si no se pudo obtener.
        """
        try:
            # Codificar URL para la consulta
            import base64
            url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
            
            headers = {
                "x-apikey": api_key,
                "Accept": "application/json"
            }
            
            api_url = f"https://www.virustotal.com/api/v3/urls/{url_id}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url, headers=headers, timeout=settings.SCAN_TIMEOUT) as response:
                    if response.status == 200:
                        data = await response.json()
                        attributes = data.get('data', {}).get('attributes', {})
                        
                        return {
                            'last_analysis_stats': attributes.get('last_analysis_stats', {}),
                            'reputation': attributes.get('reputation', 0),
                            'total_votes': attributes.get('total_votes', {}),
                            'last_analysis_date': attributes.get('last_analysis_date', 0),
                            'categories': attributes.get('categories', {})
                        }
            
            return None
        except Exception as e:
            logger.error(f"Error al obtener datos de VirusTotal para {url}: {str(e)}")
            return None
    
    async def get_shodan_data(self, ip, api_key):
        """
        Obtiene datos de Shodan para una IP.
        
        Args:
            ip (str): IP a consultar.
            api_key (str): API Key para Shodan.
            
        Returns:
            dict: Datos de Shodan o None si no se pudo obtener.
        """
        try:
            url = f"https://api.shodan.io/shodan/host/{ip}?key={api_key}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=settings.SCAN_TIMEOUT) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        # Extraer puertos y servicios
                        ports = []
                        services = {}
                        
                        for service in data.get('data', []):
                            port = service.get('port')
                            if port and port not in ports:
                                ports.append(port)
                                services[str(port)] = service.get('product', 'desconocido')
                        
                        return {
                            'ip': data.get('ip_str', ip),
                            'hostnames': data.get('hostnames', []),
                            'country': data.get('country_name', "Desconocido"),
                            'city': data.get('city', "Desconocida"),
                            'org': data.get('org', "Desconocida"),
                            'isp': data.get('isp', "Desconocido"),
                            'os': data.get('os', "Desconocido"),
                            'ports': ports,
                            'services': services
                        }
            
            return None
        except Exception as e:
            logger.error(f"Error al obtener datos de Shodan para {ip}: {str(e)}")
            return None
    
    async def check_email_breaches(self, email, api_key):
        """
        Verifica si un email aparece en brechas de seguridad usando Have I Been Pwned.
        
        Args:
            email (str): Email a verificar.
            api_key (str): API Key para Have I Been Pwned.
            
        Returns:
            list: Lista de brechas o None si no se pudo obtener.
        """
        try:
            url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
            
            headers = {
                "hibp-api-key": api_key,
                "User-Agent": settings.USER_AGENT
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=settings.SCAN_TIMEOUT) as response:
                    if response.status == 200:
                        return await response.json()
                    elif response.status == 404:
                        # No se encontraron brechas
                        return []
            
            return None
        except Exception as e:
            logger.error(f"Error al verificar brechas para {email}: {str(e)}")
            return None
    
    async def find_social_profiles(self, username, email, api_key):
        """
        Busca perfiles de redes sociales asociados a un username o email.
        
        Args:
            username (str): Nombre de usuario.
            email (str): Email.
            api_key (str): API Key para el servicio de búsqueda social.
            
        Returns:
            dict: Datos de perfiles sociales o None si no se pudo obtener.
        """
        # Nota: Este es un método simulado ya que no hay una API específica
        # En una implementación real, se usaría una API como Social Searcher o similar
        
        try:
            # Simulación de resultados
            return {
                'profiles': [
                    {'network': 'Facebook', 'url': f'https://www.facebook.com/{username}'},
                    {'network': 'Twitter', 'url': f'https://twitter.com/{username}'},
                    {'network': 'LinkedIn', 'url': f'https://www.linkedin.com/in/{username}'}
                ]
            }
        except Exception as e:
            logger.error(f"Error al buscar perfiles sociales para {username}: {str(e)}")
            return None
    
    async def get_phone_data(self, phone, api_key):
        """
        Obtiene información sobre un número telefónico usando Numverify.
        
        Args:
            phone (str): Número telefónico.
            api_key (str): API Key para Numverify.
            
        Returns:
            dict: Datos del teléfono o None si no se pudo obtener.
        """
        try:
            url = f"http://apilayer.net/api/validate?access_key={api_key}&number={phone}&format=1"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=settings.SCAN_TIMEOUT) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        if data.get('success', False) or data.get('valid', False):
                            return {
                                'valid': data.get('valid', False),
                                'number': data.get('number', phone),
                                'country_code': data.get('country_code'),
                                'country_name': data.get('country_name'),
                                'location': data.get('location'),
                                'carrier': data.get('carrier'),
                                'line_type': data.get('line_type')
                            }
            
            return None
        except Exception as e:
            logger.error(f"Error al obtener datos de teléfono para {phone}: {str(e)}")
            return None
    
    async def get_ip_info(self, ip, api_key):
        """
        Obtiene información sobre una IP usando IPinfo.
        
        Args:
            ip (str): Dirección IP.
            api_key (str): API Key para IPinfo.
            
        Returns:
            dict: Datos de la IP o None si no se pudo obtener.
        """
        try:
            url = f"https://ipinfo.io/{ip}/json?token={api_key}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=settings.SCAN_TIMEOUT) as response:
                    if response.status == 200:
                        return await response.json()
            
            return None
        except Exception as e:
            logger.error(f"Error al obtener información de IP para {ip}: {str(e)}")
            return None

# Instancia global del repositorio
api_repository = APIRepository()
