"""
Módulo de pruebas para validar el funcionamiento del Bot OSINT Avanzado.
"""
import logging
import asyncio
import unittest
from unittest.mock import MagicMock, patch
import sys
import os

# Añadir directorio raíz al path para importaciones
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import settings, api_keys
from services import url_service, port_service, email_service, phone_service, ip_service
from repositories import api_repository, cache_repository
from utils import validators, formatters, helpers, security

# Configuración del logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TestAPIKeys(unittest.TestCase):
    """
    Pruebas para la gestión de API Keys.
    """
    
    def setUp(self):
        """
        Configuración inicial para las pruebas.
        """
        # Crear instancia temporal para pruebas
        self.api_key_manager = api_keys.APIKeyManager(encryption_key="test_key")
    
    def test_set_get_api_key(self):
        """
        Prueba la configuración y obtención de API Keys.
        """
        # Configurar API Key
        result = self.api_key_manager.set_api_key("test_service", "test_key_123")
        self.assertTrue(result)
        
        # Obtener API Key
        key = self.api_key_manager.get_api_key("test_service")
        self.assertEqual(key, "test_key_123")
    
    def test_has_api_key(self):
        """
        Prueba la verificación de existencia de API Keys.
        """
        # Configurar API Key
        self.api_key_manager.set_api_key("test_service", "test_key_123")
        
        # Verificar existencia
        self.assertTrue(self.api_key_manager.has_api_key("test_service"))
        self.assertFalse(self.api_key_manager.has_api_key("nonexistent_service"))
    
    def test_delete_api_key(self):
        """
        Prueba la eliminación de API Keys.
        """
        # Configurar API Key
        self.api_key_manager.set_api_key("test_service", "test_key_123")
        
        # Eliminar API Key
        result = self.api_key_manager.delete_api_key("test_service")
        self.assertTrue(result)
        
        # Verificar que ya no existe
        self.assertFalse(self.api_key_manager.has_api_key("test_service"))

class TestValidators(unittest.TestCase):
    """
    Pruebas para los validadores.
    """
    
    def test_validate_url(self):
        """
        Prueba la validación de URLs.
        """
        # URLs válidas
        self.assertTrue(validators.validate_url("https://example.com"))
        self.assertTrue(validators.validate_url("http://example.com/path"))
        self.assertTrue(validators.validate_url("http://subdomain.example.com"))
        
        # URLs inválidas
        self.assertFalse(validators.validate_url("example.com"))  # Sin protocolo
        self.assertFalse(validators.validate_url("not a url"))
    
    def test_validate_ip(self):
        """
        Prueba la validación de IPs.
        """
        # IPs válidas
        self.assertTrue(validators.validate_ip("192.168.1.1"))
        self.assertTrue(validators.validate_ip("8.8.8.8"))
        
        # IPs inválidas
        self.assertFalse(validators.validate_ip("256.256.256.256"))  # Fuera de rango
        self.assertFalse(validators.validate_ip("192.168.1"))  # Incompleta
        self.assertFalse(validators.validate_ip("not an ip"))
    
    def test_validate_email(self):
        """
        Prueba la validación de emails.
        """
        # Emails válidos
        self.assertTrue(validators.validate_email("user@example.com"))
        self.assertTrue(validators.validate_email("user.name@example.co.uk"))
        
        # Emails inválidos
        self.assertFalse(validators.validate_email("user@"))  # Sin dominio
        self.assertFalse(validators.validate_email("user@domain"))  # Sin TLD
        self.assertFalse(validators.validate_email("not an email"))
    
    def test_validate_phone(self):
        """
        Prueba la validación de teléfonos.
        """
        # Teléfonos válidos
        self.assertTrue(validators.validate_phone("+1234567890"))
        self.assertTrue(validators.validate_phone("+34612345678"))
        
        # Teléfonos inválidos
        self.assertFalse(validators.validate_phone("1234567890"))  # Sin código de país
        self.assertFalse(validators.validate_phone("not a phone"))

class TestSecurity(unittest.TestCase):
    """
    Pruebas para las utilidades de seguridad.
    """
    
    def test_encrypt_decrypt(self):
        """
        Prueba la encriptación y desencriptación de texto.
        """
        text = "texto secreto"
        key = security.SecurityUtils.generate_key("clave_secreta")
        
        # Encriptar
        encrypted = security.SecurityUtils.encrypt_text(text, key)
        self.assertNotEqual(encrypted, text)
        
        # Desencriptar
        decrypted = security.SecurityUtils.decrypt_text(encrypted, key)
        self.assertEqual(decrypted, text)
    
    def test_hash_text(self):
        """
        Prueba la generación de hashes.
        """
        text = "texto a hashear"
        
        # Generar hash
        hash_value = security.SecurityUtils.hash_text(text)
        self.assertNotEqual(hash_value, text)
        
        # Validar hash
        self.assertTrue(security.SecurityUtils.validate_hash(text, hash_value))
        self.assertFalse(security.SecurityUtils.validate_hash("otro texto", hash_value))

class TestCache(unittest.TestCase):
    """
    Pruebas para el sistema de caché.
    """
    
    def setUp(self):
        """
        Configuración inicial para las pruebas.
        """
        self.cache = cache_repository.CacheRepository()
    
    async def test_set_get_cache(self):
        """
        Prueba la configuración y obtención de valores en caché.
        """
        # Configurar valor
        result = await self.cache.set("test_key", "test_value")
        self.assertTrue(result)
        
        # Obtener valor
        value = await self.cache.get("test_key")
        self.assertEqual(value, "test_value")
    
    async def test_delete_cache(self):
        """
        Prueba la eliminación de valores en caché.
        """
        # Configurar valor
        await self.cache.set("test_key", "test_value")
        
        # Eliminar valor
        result = await self.cache.delete("test_key")
        self.assertTrue(result)
        
        # Verificar que ya no existe
        value = await self.cache.get("test_key")
        self.assertIsNone(value)
    
    async def test_cache_expiration(self):
        """
        Prueba la expiración de valores en caché.
        """
        # Configurar valor con TTL corto
        await self.cache.set("test_key", "test_value", ttl=1)
        
        # Verificar que existe
        value = await self.cache.get("test_key")
        self.assertEqual(value, "test_value")
        
        # Esperar a que expire
        await asyncio.sleep(2)
        
        # Verificar que ya no existe
        value = await self.cache.get("test_key")
        self.assertIsNone(value)

class TestURLService(unittest.TestCase):
    """
    Pruebas para el servicio de análisis de URLs.
    """
    
    @patch('services.url_service.api_repository')
    async def test_analyze_url_with_api_key(self, mock_api_repo):
        """
        Prueba el análisis de URL con API Key.
        """
        # Configurar mock
        mock_api_repo.get_whois_data.return_value = {"registrant": "Test"}
        mock_api_repo.get_virustotal_data.return_value = {"reputation": 0}
        
        # Simular API Key disponible
        with patch('services.url_service.api_keys.has_api_key', return_value=True):
            with patch('services.url_service.api_keys.get_api_key', return_value="fake_key"):
                result = await url_service.analyze_url("https://example.com")
                self.assertIn("URL Scan Results", result)
    
    @patch('services.url_service.api_repository')
    async def test_analyze_url_without_api_key(self, mock_api_repo):
        """
        Prueba el análisis de URL sin API Key.
        """
        # Configurar mock
        mock_api_repo.get_whois_data.return_value = None
        mock_api_repo.get_virustotal_data.return_value = None
        
        # Simular API Key no disponible
        with patch('services.url_service.api_keys.has_api_key', return_value=False):
            result = await url_service.analyze_url("https://example.com")
            self.assertIn("URL Scan Results", result)

class TestPortService(unittest.TestCase):
    """
    Pruebas para el servicio de escaneo de puertos.
    """
    
    @patch('services.port_service.api_repository')
    async def test_scan_ports_with_api_key(self, mock_api_repo):
        """
        Prueba el escaneo de puertos con API Key.
        """
        # Configurar mock
        mock_api_repo.get_shodan_data.return_value = {
            "ports": [80, 443],
            "services": {"80": "http", "443": "https"}
        }
        
        # Simular API Key disponible
        with patch('services.port_service.api_keys.has_api_key', return_value=True):
            with patch('services.port_service.api_keys.get_api_key', return_value="fake_key"):
                # Parchear el método _scan_port para evitar escaneos reales
                with patch('services.port_service.PortService._scan_port', 
                          return_value=(80, True, "http")):
                    result = await port_service.scan_ports("example.com")
                    self.assertIn("Port Scan Results", result)
    
    @patch('services.port_service.api_repository')
    async def test_scan_ports_without_api_key(self, mock_api_repo):
        """
        Prueba el escaneo de puertos sin API Key.
        """
        # Configurar mock
        mock_api_repo.get_shodan_data.return_value = None
        
        # Simular API Key no disponible
        with patch('services.port_service.api_keys.has_api_key', return_value=False):
            # Parchear el método _scan_port para evitar escaneos reales
            with patch('services.port_service.PortService._scan_port', 
                      return_value=(80, True, "http")):
                result = await port_service.scan_ports("example.com")
                self.assertIn("Port Scan Results", result)

class TestEmailService(unittest.TestCase):
    """
    Pruebas para el servicio de investigación de emails.
    """
    
    @patch('services.email_service.api_repository')
    async def test_investigate_email_with_api_key(self, mock_api_repo):
        """
        Prueba la investigación de email con API Key.
        """
        # Configurar mock
        mock_api_repo.check_email_breaches.return_value = [
            {"Name": "TestBreach", "BreachDate": "2021-01-01", "Description": "Test breach"}
        ]
        mock_api_repo.find_social_profiles.return_value = {
            "profiles": [
                {"network": "Facebook", "url": "https://facebook.com/test"}
            ]
        }
        
        # Simular API Key disponible
        with patch('services.email_service.api_keys.has_api_key', return_value=True):
            with patch('services.email_service.api_keys.get_api_key', return_value="fake_key"):
                result = await email_service.investigate_email("test@example.com")
                self.assertIn("OSINT Results for Email", result)
    
    @patch('services.email_service.api_repository')
    async def test_investigate_email_without_api_key(self, mock_api_repo):
        """
        Prueba la investigación de email sin API Key.
        """
        # Configurar mock
        mock_api_repo.check_email_breaches.return_value = None
        mock_api_repo.find_social_profiles.return_value = None
        
        # Simular API Key no disponible
        with patch('services.email_service.api_keys.has_api_key', return_value=False):
            result = await email_service.investigate_email("test@example.com")
            self.assertIn("OSINT Results for Email", result)

class TestPhoneService(unittest.TestCase):
    """
    Pruebas para el servicio de investigación de teléfonos.
    """
    
    @patch('services.phone_service.api_repository')
    async def test_investigate_phone_with_api_key(self, mock_api_repo):
        """
        Prueba la investigación de teléfono con API Key.
        """
        # Configurar mock
        mock_api_repo.get_phone_data.return_value = {
            "valid": True,
            "country_code": "ES",
            "country_name": "Spain",
            "carrier": "Test Carrier"
        }
        
        # Simular API Key disponible
        with patch('services.phone_service.api_keys.has_api_key', return_value=True):
            with patch('services.phone_service.api_keys.get_api_key', return_value="fake_key"):
                # Parchear phonenumbers para evitar validaciones reales
                with patch('services.phone_service.phonenumbers.parse'):
                    with patch('services.phone_service.carrier.name_for_number', return_value="Test Carrier"):
                        with patch('services.phone_service.geocoder.description_for_number', return_value="Spain"):
                            with patch('services.phone_service.timezone.time_zones_for_number', return_value=["Europe/Madrid"]):
                                with patch('services.phone_service.validators.validate_phone', return_value=True):
                                    with patch('services.phone_service.validators.normalize_phone', return_value="+34612345678"):
                                        result = await phone_service.investigate_phone("+34612345678")
                                        self.assertIn("OSINT Results for Teléfono", result)
    
    @patch('services.phone_service.api_repository')
    async def test_investigate_phone_without_api_key(self, mock_api_repo):
        """
        Prueba la investigación de teléfono sin API Key.
        """
        # Configurar mock
        mock_api_repo.get_phone_data.return_value = None
        
        # Simular API Key no disponible
        with patch('services.phone_service.api_keys.has_api_key', return_value=False):
            # Parchear phonenumbers para evitar validaciones reales
            with patch('services.phone_service.phonenumbers.parse'):
                with patch('services.phone_service.carrier.name_for_number', return_value="Test Carrier"):
                    with patch('services.phone_service.geocoder.description_for_number', return_value="Spain"):
                        with patch('services.phone_service.timezone.time_zones_for_number', return_value=["Europe/Madrid"]):
                            with patch('services.phone_service.validators.validate_phone', return_value=True):
                                with patch('services.phone_service.validators.normalize_phone', return_value="+34612345678"):
                                    result = await phone_service.investigate_phone("+34612345678")
                                    self.assertIn("OSINT Results for Teléfono", result)

class TestIPService(unittest.TestCase):
    """
    Pruebas para el servicio de geolocalización de IPs.
    """
    
    @patch('services.ip_service.api_repository')
    async def test_geolocate_ip_with_api_key(self, mock_api_repo):
        """
        Prueba la geolocalización de IP con API Key.
        """
        # Configurar mock
        mock_api_repo.get_ip_info.return_value = {
            "country": "Spain",
            "city": "Madrid",
            "org": "Test ISP"
        }
        
        # Simular API Key disponible
        with patch('services.ip_service.api_keys.has_api_key', return_value=True):
            with patch('services.ip_service.api_keys.get_api_key', return_value="fake_key"):
                with patch('services.ip_service.validators.validate_ip', return_value=True):
                    result = await ip_service.geolocate_ip("8.8.8.8")
                    self.assertIn("Geolocation Results for IP", result)
    
    @patch('services.ip_service.api_repository')
    async def test_geolocate_ip_without_api_key(self, mock_api_repo):
        """
        Prueba la geolocalización de IP sin API Key.
        """
        # Configurar mock
        mock_api_repo.get_ip_info.return_value = None
        
        # Simular API Key no disponible
        with patch('services.ip_service.api_keys.has_api_key', return_value=False):
            # Parchear el método _get_free_ip_data para evitar consultas reales
            with patch('services.ip_service.IPService._get_free_ip_data', 
                      return_value={"country": "United States", "city": "Mountain View"}):
                with patch('services.ip_service.validators.validate_ip', return_value=True):
                    result = await ip_service.geolocate_ip("8.8.8.8")
                    self.assertIn("Geolocation Results for IP", result)

def run_tests():
    """
    Ejecuta todas las pruebas.
    """
    # Crear suite de pruebas
    test_suite = unittest.TestSuite()
    
    # Añadir pruebas síncronas
    test_suite.addTest(unittest.makeSuite(TestAPIKeys))
    test_suite.addTest(unittest.makeSuite(TestValidators))
    test_suite.addTest(unittest.makeSuite(TestSecurity))
    
    # Ejecutar pruebas síncronas
    runner = unittest.TextTestRunner()
    runner.run(test_suite)
    
    # Ejecutar pruebas asíncronas
    loop = asyncio.get_event_loop()
    
    # Pruebas de caché
    loop.run_until_complete(TestCache().test_set_get_cache())
    loop.run_until_complete(TestCache().test_delete_cache())
    loop.run_until_complete(TestCache().test_cache_expiration())
    
    # Pruebas de servicios
    loop.run_until_complete(TestURLService().test_analyze_url_with_api_key())
    loop.run_until_complete(TestURLService().test_analyze_url_without_api_key())
    loop.run_until_complete(TestPortService().test_scan_ports_with_api_key())
    loop.run_until_complete(TestPortService().test_scan_ports_without_api_key())
    loop.run_until_complete(TestEmailService().test_investigate_email_with_api_key())
    loop.run_until_complete(TestEmailService().test_investigate_email_without_api_key())
    loop.run_until_complete(TestPhoneService().test_investigate_phone_with_api_key())
    loop.run_until_complete(TestPhoneService().test_investigate_phone_without_api_key())
    loop.run_until_complete(TestIPService().test_geolocate_ip_with_api_key())
    loop.run_until_complete(TestIPService().test_geolocate_ip_without_api_key())
    
    logger.info("Todas las pruebas completadas")

if __name__ == "__main__":
    run_tests()
