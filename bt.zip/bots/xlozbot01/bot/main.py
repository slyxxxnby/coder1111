"""
Módulo principal para iniciar el Bot OSINT Avanzado.
"""
from core.bot import start_bot

def main():
    """
    Función principal para iniciar el bot.
    """
    start_bot()

if __name__ == '__main__':
    main()
