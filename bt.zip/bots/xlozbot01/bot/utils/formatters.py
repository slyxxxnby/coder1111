"""
Módulo de utilidades para formatear salidas en el Bot OSINT Avanzado.
"""
import json
import logging
from datetime import datetime

# Configuración del logger
logger = logging.getLogger(__name__)

def format_url_scan_result(data):
    """
    Formatea los resultados del escaneo de URL.
    
    Args:
        data (dict): Datos del escaneo.
        
    Returns:
        str: Resultado formateado en Markdown.
    """
    try:
        # Extraer información relevante
        url = data.get('url', 'Desconocida')
        domain_info = data.get('domain_info', {})
        dns_records = data.get('dns_records', {})
        headers = data.get('headers', {})
        metadata = data.get('metadata', {})
        
        # Formatear información del dominio
        domain_info_text = ""
        if domain_info:
            domain_info_text += f"Registrante: {domain_info.get('registrant', 'Desconocido')}\n"
            domain_info_text += f"Organización: {domain_info.get('org', 'Desconocida')}\n"
            domain_info_text += f"Fecha de creación: {domain_info.get('creation_date', 'Desconocida')}\n"
            domain_info_text += f"Fecha de expiración: {domain_info.get('expiration_date', 'Desconocida')}\n"
        
        # Formatear registros DNS
        dns_text = ""
        for record_type, records in dns_records.items():
            if records:
                dns_text += f"{record_type}: {', '.join(records)}\n"
        
        # Formatear encabezados HTTP
        headers_text = ""
        for key, value in headers.items():
            headers_text += f"{key}: {value}\n"
        
        # Formatear metadatos
        metadata_text = ""
        if metadata.get('title'):
            metadata_text += f"Título: {metadata['title']}\n"
        
        # Construir resultado final
        result = f"""
*🔗 Resultados del Escaneo de URL: {url}*

*🌐 Información del Dominio:*
```
{domain_info_text}
```

*📡 Registros DNS:*
```
{dns_text}
```

*📋 Encabezados HTTP:*
```
{headers_text}
```

*📄 Metadatos de la Página:*
```
{metadata_text}
```
"""
        return result
    
    except Exception as e:
        logger.error(f"Error al formatear resultados de URL: {str(e)}")
        return f"❌ Error al formatear resultados: {str(e)}"

def format_port_scan_result(data):
    """
    Formatea los resultados del escaneo de puertos.
    
    Args:
        data (dict): Datos del escaneo.
        
    Returns:
        str: Resultado formateado en Markdown.
    """
    try:
        # Extraer información relevante
        target = data.get('target', 'Desconocido')
        ip = data.get('ip', 'Desconocida')
        open_ports = data.get('open_ports', [])
        services = data.get('services', {})
        
        # Formatear puertos abiertos
        ports_text = ""
        if open_ports:
            for port in open_ports:
                service = services.get(str(port), 'desconocido')
                ports_text += f"Puerto {port}: {service}\n"
        else:
            ports_text = "No se encontraron puertos abiertos.\n"
        
        # Construir resultado final
        result = f"""
*🔌 Resultados del Escaneo de Puertos: {target} ({ip})*

*🛡️ Puertos Abiertos y Servicios:*
```
{ports_text}
```
"""
        return result
    
    except Exception as e:
        logger.error(f"Error al formatear resultados de puertos: {str(e)}")
        return f"❌ Error al formatear resultados: {str(e)}"

def format_email_osint_result(data):
    """
    Formatea los resultados de la investigación OSINT de email.
    
    Args:
        data (dict): Datos de la investigación.
        
    Returns:
        str: Resultado formateado en Markdown.
    """
    try:
        # Extraer información relevante
        email = data.get('email', 'Desconocido')
        domain_info = data.get('domain_info', {})
        breach_info = data.get('breach_info', 'No se encontró información sobre brechas.')
        social_media = data.get('social_media', 'No se encontraron perfiles en redes sociales.')
        
        # Formatear información del dominio
        domain_info_text = ""
        if domain_info:
            domain_info_text += f"Registrante: {domain_info.get('registrant', 'Desconocido')}\n"
            domain_info_text += f"Organización: {domain_info.get('org', 'Desconocida')}\n"
            domain_info_text += f"Fecha de creación: {domain_info.get('creation_date', 'Desconocida')}\n"
        
        # Construir resultado final
        result = f"""
*📧 Resultados OSINT para Email: {email}*

*📌 Información del Dominio:*
```
{domain_info_text}
```

*🛡️ Verificación de Brechas:*
{breach_info}

*📱 Posibles Perfiles en Redes Sociales:*
{social_media}
"""
        return result
    
    except Exception as e:
        logger.error(f"Error al formatear resultados de email: {str(e)}")
        return f"❌ Error al formatear resultados: {str(e)}"

def format_phone_osint_result(data):
    """
    Formatea los resultados de la investigación OSINT de teléfono.
    
    Args:
        data (dict): Datos de la investigación.
        
    Returns:
        str: Resultado formateado en Markdown.
    """
    try:
        # Extraer información relevante
        phone = data.get('phone', 'Desconocido')
        carrier = data.get('carrier', 'Desconocido')
        region = data.get('region', 'Desconocida')
        time_zone = data.get('time_zone', 'Desconocida')
        
        # Construir resultado final
        result = f"""
*📱 Resultados OSINT para Teléfono: {phone}*

*📞 Operador:*
{carrier}

*📍 Región:*
{region}

*⏰ Zona Horaria:*
{time_zone}
"""
        return result
    
    except Exception as e:
        logger.error(f"Error al formatear resultados de teléfono: {str(e)}")
        return f"❌ Error al formatear resultados: {str(e)}"

def format_ip_geolocation_result(data):
    """
    Formatea los resultados de la geolocalización de IP.
    
    Args:
        data (dict): Datos de la geolocalización.
        
    Returns:
        str: Resultado formateado en Markdown.
    """
    try:
        # Extraer información relevante
        ip = data.get('ip', 'Desconocida')
        country = data.get('country', 'Desconocido')
        city = data.get('city', 'Desconocida')
        isp = data.get('isp', 'Desconocido')
        org = data.get('org', 'Desconocida')
        
        # Construir resultado final
        result = f"""
*🌍 Resultados de Geolocalización para IP: {ip}*

*📍 País:*
{country}

*🏙️ Ciudad:*
{city}

*📡 ISP:*
{isp}

*🏢 Organización:*
{org}
"""
        return result
    
    except Exception as e:
        logger.error(f"Error al formatear resultados de IP: {str(e)}")
        return f"❌ Error al formatear resultados: {str(e)}"

def format_json(data):
    """
    Formatea un diccionario como JSON legible.
    
    Args:
        data (dict): Datos a formatear.
        
    Returns:
        str: JSON formateado.
    """
    try:
        return json.dumps(data, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Error al formatear JSON: {str(e)}")
        return str(data)

def format_timestamp(timestamp=None):
    """
    Formatea una marca de tiempo.
    
    Args:
        timestamp (float, optional): Marca de tiempo en segundos desde la época.
            Si no se proporciona, se utiliza la hora actual.
            
    Returns:
        str: Marca de tiempo formateada.
    """
    if timestamp is None:
        timestamp = datetime.now().timestamp()
    
    dt = datetime.fromtimestamp(timestamp)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def format_error(error_message):
    """
    Formatea un mensaje de error.
    
    Args:
        error_message (str): Mensaje de error.
        
    Returns:
        str: Mensaje de error formateado.
    """
    return f"❌ Error: {error_message}"

def format_success(success_message):
    """
    Formatea un mensaje de éxito.
    
    Args:
        success_message (str): Mensaje de éxito.
        
    Returns:
        str: Mensaje de éxito formateado.
    """
    return f"✅ {success_message}"

def format_warning(warning_message):
    """
    Formatea un mensaje de advertencia.
    
    Args:
        warning_message (str): Mensaje de advertencia.
        
    Returns:
        str: Mensaje de advertencia formateado.
    """
    return f"⚠️ {warning_message}"

def format_info(info_message):
    """
    Formatea un mensaje informativo.
    
    Args:
        info_message (str): Mensaje informativo.
        
    Returns:
        str: Mensaje informativo formateado.
    """
    return f"ℹ️ {info_message}"
