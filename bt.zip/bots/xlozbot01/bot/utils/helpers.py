"""
Módulo de utilidades auxiliares para el Bot OSINT Avanzado.
"""
import os
import logging
import aiohttp
import asyncio
from urllib.parse import urlparse
from ..config import settings

# Configuración del logger
logger = logging.getLogger(__name__)

async def fetch_url(url, headers=None, timeout=None):
    """
    Realiza una petición HTTP GET a una URL.
    
    Args:
        url (str): URL a la que realizar la petición.
        headers (dict, optional): Cabeceras HTTP.
        timeout (int, optional): Tiempo máximo de espera en segundos.
            
    Returns:
        tuple: (status_code, content, headers)
    """
    timeout = timeout or settings.SCAN_TIMEOUT
    headers = headers or {'User-Agent': settings.USER_AGENT}
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, timeout=timeout) as response:
                content = await response.text()
                return response.status, content, dict(response.headers)
    except Exception as e:
        logger.error(f"Error al realizar petición a {url}: {str(e)}")
        raise

def ensure_dir_exists(directory):
    """
    Asegura que un directorio exista, creándolo si es necesario.
    
    Args:
        directory (str): Ruta del directorio.
            
    Returns:
        bool: True si el directorio existe o se creó correctamente.
    """
    try:
        os.makedirs(directory, exist_ok=True)
        return True
    except Exception as e:
        logger.error(f"Error al crear directorio {directory}: {str(e)}")
        return False

def get_domain_from_url(url):
    """
    Extrae el dominio de una URL.
    
    Args:
        url (str): URL de la que extraer el dominio.
            
    Returns:
        str: Dominio extraído.
    """
    try:
        parsed = urlparse(url)
        return parsed.netloc
    except Exception:
        return url

def get_username_from_email(email):
    """
    Extrae el nombre de usuario de una dirección de email.
    
    Args:
        email (str): Dirección de email.
            
    Returns:
        str: Nombre de usuario extraído.
    """
    try:
        return email.split('@')[0]
    except Exception:
        return email

def get_domain_from_email(email):
    """
    Extrae el dominio de una dirección de email.
    
    Args:
        email (str): Dirección de email.
            
    Returns:
        str: Dominio extraído.
    """
    try:
        return email.split('@')[1]
    except Exception:
        return None

async def run_command(command):
    """
    Ejecuta un comando del sistema de forma asíncrona.
    
    Args:
        command (str): Comando a ejecutar.
            
    Returns:
        tuple: (returncode, stdout, stderr)
    """
    try:
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        
        return process.returncode, stdout.decode(), stderr.decode()
    except Exception as e:
        logger.error(f"Error al ejecutar comando {command}: {str(e)}")
        return -1, "", str(e)

def truncate_text(text, max_length=4000):
    """
    Trunca un texto si excede la longitud máxima.
    
    Args:
        text (str): Texto a truncar.
        max_length (int, optional): Longitud máxima.
            
    Returns:
        str: Texto truncado.
    """
    if len(text) <= max_length:
        return text
    
    return text[:max_length-3] + "..."

def is_admin(user_id):
    """
    Verifica si un usuario es administrador.
    
    Args:
        user_id (int): ID del usuario.
            
    Returns:
        bool: True si el usuario es administrador.
    """
    return user_id in settings.BOT_ADMIN_IDS

def feature_enabled(feature):
    """
    Verifica si una funcionalidad está habilitada.
    
    Args:
        feature (str): Nombre de la funcionalidad.
            
    Returns:
        bool: True si la funcionalidad está habilitada.
    """
    return settings.FEATURES.get(feature, False)

def get_random_user_agent():
    """
    Obtiene un User-Agent aleatorio.
            
    Returns:
        str: User-Agent aleatorio.
    """
    user_agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'
    ]
    
    import random
    return random.choice(user_agents)
