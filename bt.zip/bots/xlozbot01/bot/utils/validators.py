"""
Módulo de utilidades para validación de entradas en el Bot OSINT Avanzado.
"""
import re
import logging
import phonenumbers
from urllib.parse import urlparse

# Configuración del logger
logger = logging.getLogger(__name__)

def validate_url(url):
    """
    Valida una URL.
    
    Args:
        url (str): URL a validar.
        
    Returns:
        bool: True si la URL es válida, False en caso contrario.
    """
    # Asegurar que la URL tenga un esquema
    if not url.startswith(('http://', 'https://')):
        url = f'http://{url}'
    
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except Exception as e:
        logger.error(f"Error validando URL: {str(e)}")
        return False

def validate_ip(ip):
    """
    Valida una dirección IP.
    
    Args:
        ip (str): Dirección IP a validar.
        
    Returns:
        bool: True si la IP es válida, False en caso contrario.
    """
    pattern = r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$'
    match = re.match(pattern, ip)
    
    if not match:
        return False
    
    for i in range(1, 5):
        octet = int(match.group(i))
        if octet < 0 or octet > 255:
            return False
    
    return True

def validate_domain(domain):
    """
    Valida un nombre de dominio.
    
    Args:
        domain (str): Nombre de dominio a validar.
        
    Returns:
        bool: True si el dominio es válido, False en caso contrario.
    """
    pattern = r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
    return bool(re.match(pattern, domain))

def validate_email(email):
    """
    Valida una dirección de email.
    
    Args:
        email (str): Dirección de email a validar.
        
    Returns:
        bool: True si el email es válido, False en caso contrario.
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def validate_phone(phone):
    """
    Valida un número telefónico.
    
    Args:
        phone (str): Número telefónico a validar.
        
    Returns:
        bool: True si el número es válido, False en caso contrario.
    """
    try:
        parsed = phonenumbers.parse(phone, None)
        return phonenumbers.is_valid_number(parsed)
    except Exception as e:
        logger.error(f"Error validando teléfono: {str(e)}")
        return False

def validate_port(port):
    """
    Valida un número de puerto.
    
    Args:
        port (int): Número de puerto a validar.
        
    Returns:
        bool: True si el puerto es válido, False en caso contrario.
    """
    try:
        port_num = int(port)
        return 1 <= port_num <= 65535
    except ValueError:
        return False

def sanitize_input(text):
    """
    Sanitiza una entrada de texto para prevenir inyecciones.
    
    Args:
        text (str): Texto a sanitizar.
        
    Returns:
        str: Texto sanitizado.
    """
    # Eliminar caracteres potencialmente peligrosos
    sanitized = re.sub(r'[;<>&|]', '', text)
    return sanitized.strip()

def normalize_url(url):
    """
    Normaliza una URL añadiendo el esquema si es necesario.
    
    Args:
        url (str): URL a normalizar.
        
    Returns:
        str: URL normalizada.
    """
    if not url.startswith(('http://', 'https://')):
        return f'http://{url}'
    return url

def normalize_ip_or_domain(target):
    """
    Normaliza una IP o dominio.
    
    Args:
        target (str): IP o dominio a normalizar.
        
    Returns:
        str: IP o dominio normalizado.
    """
    # Eliminar espacios y convertir a minúsculas
    target = target.strip().lower()
    
    # Eliminar protocolo si existe
    if target.startswith(('http://', 'https://')):
        parsed = urlparse(target)
        target = parsed.netloc
    
    return target

def normalize_email(email):
    """
    Normaliza una dirección de email.
    
    Args:
        email (str): Email a normalizar.
        
    Returns:
        str: Email normalizado.
    """
    return email.strip().lower()

def normalize_phone(phone):
    """
    Normaliza un número telefónico.
    
    Args:
        phone (str): Número telefónico a normalizar.
        
    Returns:
        str: Número telefónico normalizado o None si no es válido.
    """
    try:
        parsed = phonenumbers.parse(phone, None)
        if phonenumbers.is_valid_number(parsed):
            return phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)
        return None
    except Exception:
        return None
