"""
Módulo de utilidades de seguridad para el Bot OSINT Avanzado.
"""
import os
import base64
import logging
import hashlib
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from ..config import settings

# Configuración del logger
logger = logging.getLogger(__name__)

class SecurityUtils:
    """
    Utilidades de seguridad para el Bot OSINT Avanzado.
    """
    
    @staticmethod
    def generate_key(password, salt=None):
        """
        Genera una clave de encriptación a partir de una contraseña.
        
        Args:
            password (str): Contraseña para generar la clave.
            salt (bytes, optional): Salt para la derivación de clave.
                
        Returns:
            bytes: Clave generada.
        """
        if not salt:
            salt = os.urandom(16)
        elif isinstance(salt, str):
            salt = salt.encode()[:16].ljust(16, b'\0')
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        return key
    
    @staticmethod
    def encrypt_text(text, key=None):
        """
        Encripta un texto.
        
        Args:
            text (str): Texto a encriptar.
            key (bytes, optional): Clave de encriptación.
                Si no se proporciona, se utiliza la configurada en settings.
                
        Returns:
            str: Texto encriptado en formato base64.
        """
        try:
            if not key:
                if not settings.ENCRYPTION_KEY:
                    logger.warning("No se ha configurado una clave de encriptación")
                    return text
                
                key = SecurityUtils.generate_key(
                    settings.ENCRYPTION_KEY,
                    settings.ENCRYPTION_KEY.encode()[:16].ljust(16, b'\0')
                )
            
            f = Fernet(key)
            encrypted = f.encrypt(text.encode())
            return base64.urlsafe_b64encode(encrypted).decode()
        
        except Exception as e:
            logger.error(f"Error al encriptar texto: {str(e)}")
            return text
    
    @staticmethod
    def decrypt_text(encrypted_text, key=None):
        """
        Desencripta un texto.
        
        Args:
            encrypted_text (str): Texto encriptado en formato base64.
            key (bytes, optional): Clave de encriptación.
                Si no se proporciona, se utiliza la configurada en settings.
                
        Returns:
            str: Texto desencriptado.
        """
        try:
            if not key:
                if not settings.ENCRYPTION_KEY:
                    logger.warning("No se ha configurado una clave de encriptación")
                    return encrypted_text
                
                key = SecurityUtils.generate_key(
                    settings.ENCRYPTION_KEY,
                    settings.ENCRYPTION_KEY.encode()[:16].ljust(16, b'\0')
                )
            
            f = Fernet(key)
            decrypted = f.decrypt(base64.urlsafe_b64decode(encrypted_text))
            return decrypted.decode()
        
        except Exception as e:
            logger.error(f"Error al desencriptar texto: {str(e)}")
            return encrypted_text
    
    @staticmethod
    def hash_text(text, algorithm='sha256'):
        """
        Genera un hash de un texto.
        
        Args:
            text (str): Texto a hashear.
            algorithm (str, optional): Algoritmo de hash a utilizar.
                
        Returns:
            str: Hash generado.
        """
        try:
            if algorithm == 'md5':
                return hashlib.md5(text.encode()).hexdigest()
            elif algorithm == 'sha1':
                return hashlib.sha1(text.encode()).hexdigest()
            elif algorithm == 'sha256':
                return hashlib.sha256(text.encode()).hexdigest()
            elif algorithm == 'sha512':
                return hashlib.sha512(text.encode()).hexdigest()
            else:
                return hashlib.sha256(text.encode()).hexdigest()
        
        except Exception as e:
            logger.error(f"Error al generar hash: {str(e)}")
            return ""
    
    @staticmethod
    def validate_hash(text, hash_value, algorithm='sha256'):
        """
        Valida un hash.
        
        Args:
            text (str): Texto a validar.
            hash_value (str): Hash a comparar.
            algorithm (str, optional): Algoritmo de hash utilizado.
                
        Returns:
            bool: True si el hash es válido.
        """
        return SecurityUtils.hash_text(text, algorithm) == hash_value
    
    @staticmethod
    def sanitize_command(command):
        """
        Sanitiza un comando para prevenir inyecciones.
        
        Args:
            command (str): Comando a sanitizar.
                
        Returns:
            str: Comando sanitizado.
        """
        # Eliminar caracteres potencialmente peligrosos
        sanitized = command.replace(';', '').replace('&', '').replace('|', '')
        return sanitized.strip()
    
    @staticmethod
    def is_safe_url(url):
        """
        Verifica si una URL es segura.
        
        Args:
            url (str): URL a verificar.
                
        Returns:
            bool: True si la URL es segura.
        """
        # Lista de dominios permitidos
        allowed_domains = [
            'example.com',
            'api.example.com',
            'github.com',
            'api.github.com',
            'ipinfo.io',
            'api.ipinfo.io',
            'haveibeenpwned.com',
            'api.haveibeenpwned.com',
            'shodan.io',
            'api.shodan.io',
            'virustotal.com',
            'www.virustotal.com',
            'api.virustotal.com',
            'whoisxmlapi.com',
            'www.whoisxmlapi.com',
            'api.whoisxmlapi.com',
            'numverify.com',
            'api.numverify.com',
            'apilayer.net',
            'api.apilayer.net'
        ]
        
        from urllib.parse import urlparse
        parsed = urlparse(url)
        domain = parsed.netloc
        
        # Verificar si el dominio está en la lista de permitidos
        for allowed in allowed_domains:
            if domain == allowed or domain.endswith('.' + allowed):
                return True
        
        return False
