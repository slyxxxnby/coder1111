"""
Servicio para análisis de URLs en el Bot OSINT Avanzado.
"""
import logging
import whois
import dns.resolver
import aiohttp
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from ..config import settings, api_keys
from ..utils import validators, formatters, helpers, security
from ..repositories import api_repository, cache_repository

# Configuración del logger
logger = logging.getLogger(__name__)

class URLService:
    """
    Servicio para análisis de URLs.
    """
    
    def __init__(self):
        """
        Inicializa el servicio de análisis de URLs.
        """
        self.api_repository = api_repository.APIRepository()
        self.cache_repository = cache_repository.CacheRepository()
    
    async def analyze_url(self, url):
        """
        Analiza una URL para obtener información detallada.
        
        Args:
            url (str): URL a analizar.
            
        Returns:
            str: Resultado del análisis formateado.
        """
        try:
            # Validar y normalizar URL
            if not validators.validate_url(url):
                return formatters.format_error("URL inválida")
            
            url = validators.normalize_url(url)
            
            # Verificar caché
            if settings.CACHE_ENABLED:
                cached_result = await self.cache_repository.get(f"url:{url}")
                if cached_result:
                    logger.info(f"Resultado de caché para URL: {url}")
                    return cached_result
            
            # Obtener información
            parsed = urlparse(url)
            domain = parsed.netloc
            
            # Recopilar datos
            data = {
                'url': url,
                'domain_info': await self._get_domain_info(domain),
                'dns_records': await self._get_dns_records(domain),
                'headers': await self._get_http_headers(url),
                'metadata': await self._get_page_metadata(url)
            }
            
            # Enriquecer con datos de API si está disponible
            if api_keys.has_api_key('virustotal'):
                vt_data = await self._get_virustotal_data(url)
                if vt_data:
                    data['security_info'] = vt_data
            
            # Formatear resultado
            result = formatters.format_url_scan_result(data)
            
            # Guardar en caché
            if settings.CACHE_ENABLED:
                await self.cache_repository.set(f"url:{url}", result, settings.CACHE_TTL)
            
            return result
            
        except Exception as e:
            logger.error(f"Error al analizar URL {url}: {str(e)}")
            return formatters.format_error(f"Error al analizar URL: {str(e)}")
    
    async def _get_domain_info(self, domain):
        """
        Obtiene información WHOIS del dominio.
        
        Args:
            domain (str): Dominio a consultar.
            
        Returns:
            dict: Información del dominio.
        """
        try:
            # Intentar usar WhoisXML API si está disponible
            if api_keys.has_api_key('whoisxml'):
                api_key = api_keys.get_api_key('whoisxml')
                whois_data = await self.api_repository.get_whois_data(domain, api_key)
                if whois_data:
                    return whois_data
            
            # Fallback a python-whois
            domain_info = whois.whois(domain)
            return {
                'registrant': domain_info.registrant or "Desconocido",
                'org': domain_info.org or "Desconocida",
                'creation_date': str(domain_info.creation_date),
                'expiration_date': str(domain_info.expiration_date),
                'registrar': domain_info.registrar or "Desconocido",
                'country': domain_info.country or "Desconocido"
            }
        except Exception as e:
            logger.error(f"Error al obtener información WHOIS para {domain}: {str(e)}")
            return {}
    
    async def _get_dns_records(self, domain):
        """
        Obtiene registros DNS del dominio.
        
        Args:
            domain (str): Dominio a consultar.
            
        Returns:
            dict: Registros DNS.
        """
        try:
            dns_results = {}
            for record_type in ['A', 'AAAA', 'MX', 'NS', 'TXT', 'SOA']:
                try:
                    answers = dns.resolver.resolve(domain, record_type)
                    dns_results[record_type] = [str(r) for r in answers]
                except Exception:
                    pass
            
            return dns_results
        except Exception as e:
            logger.error(f"Error al obtener registros DNS para {domain}: {str(e)}")
            return {}
    
    async def _get_http_headers(self, url):
        """
        Obtiene encabezados HTTP de la URL.
        
        Args:
            url (str): URL a consultar.
            
        Returns:
            dict: Encabezados HTTP.
        """
        try:
            headers = {'User-Agent': helpers.get_random_user_agent()}
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=settings.SCAN_TIMEOUT) as response:
                    return dict(response.headers)
        except Exception as e:
            logger.error(f"Error al obtener encabezados HTTP para {url}: {str(e)}")
            return {}
    
    async def _get_page_metadata(self, url):
        """
        Obtiene metadatos de la página.
        
        Args:
            url (str): URL a consultar.
            
        Returns:
            dict: Metadatos de la página.
        """
        try:
            headers = {'User-Agent': helpers.get_random_user_agent()}
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=settings.SCAN_TIMEOUT) as response:
                    html = await response.text()
                    
                    soup = BeautifulSoup(html, 'html.parser')
                    metadata = {
                        'title': soup.title.string if soup.title else None,
                        'description': None,
                        'keywords': None
                    }
                    
                    # Obtener meta description
                    meta_desc = soup.find('meta', attrs={'name': 'description'})
                    if meta_desc:
                        metadata['description'] = meta_desc.get('content')
                    
                    # Obtener meta keywords
                    meta_keywords = soup.find('meta', attrs={'name': 'keywords'})
                    if meta_keywords:
                        metadata['keywords'] = meta_keywords.get('content')
                    
                    return metadata
        except Exception as e:
            logger.error(f"Error al obtener metadatos para {url}: {str(e)}")
            return {}
    
    async def _get_virustotal_data(self, url):
        """
        Obtiene datos de seguridad de VirusTotal.
        
        Args:
            url (str): URL a consultar.
            
        Returns:
            dict: Datos de seguridad.
        """
        try:
            api_key = api_keys.get_api_key('virustotal')
            if not api_key:
                return None
            
            return await self.api_repository.get_virustotal_data(url, api_key)
        except Exception as e:
            logger.error(f"Error al obtener datos de VirusTotal para {url}: {str(e)}")
            return None

# Instancia global del servicio
url_service = URLService()

async def analyze_url(url):
    """
    Función auxiliar para analizar una URL.
    
    Args:
        url (str): URL a analizar.
        
    Returns:
        str: Resultado del análisis formateado.
    """
    return await url_service.analyze_url(url)
