"""
Servicio para geolocalización de IPs en el Bot OSINT Avanzado.
"""
import logging
import socket
import geoip2.database
import aiohttp
from ..config import settings, api_keys
from ..utils import validators, formatters, helpers
from ..repositories import api_repository, cache_repository

# Configuración del logger
logger = logging.getLogger(__name__)

class IPService:
    """
    Servicio para geolocalización de IPs.
    """
    
    def __init__(self):
        """
        Inicializa el servicio de geolocalización de IPs.
        """
        self.api_repository = api_repository.APIRepository()
        self.cache_repository = cache_repository.CacheRepository()
    
    async def geolocate_ip(self, ip):
        """
        Geolocaliza una dirección IP.
        
        Args:
            ip (str): Dirección IP a geolocalizar.
            
        Returns:
            str: Resultado de la geolocalización formateado.
        """
        try:
            # Validar IP
            if not validators.validate_ip(ip):
                return formatters.format_error("Dirección IP inválida")
            
            # Verificar caché
            if settings.CACHE_ENABLED:
                cached_result = await self.cache_repository.get(f"ip:{ip}")
                if cached_result:
                    logger.info(f"Resultado de caché para IP: {ip}")
                    return cached_result
            
            # Recopilar datos
            data = {
                'ip': ip,
                'country': "Desconocido",
                'city': "Desconocida",
                'isp': "Desconocido",
                'org': "Desconocida"
            }
            
            # Intentar usar API si está disponible
            if api_keys.has_api_key('ipinfo'):
                api_key = api_keys.get_api_key('ipinfo')
                ip_data = await self.api_repository.get_ip_info(ip, api_key)
                
                if ip_data:
                    data.update({
                        'country': ip_data.get('country', "Desconocido"),
                        'city': ip_data.get('city', "Desconocida"),
                        'region': ip_data.get('region', "Desconocida"),
                        'loc': ip_data.get('loc', "Desconocida"),
                        'isp': ip_data.get('org', "Desconocido"),
                        'postal': ip_data.get('postal', "Desconocido"),
                        'timezone': ip_data.get('timezone', "Desconocida")
                    })
            else:
                # Fallback a servicio gratuito
                ip_data = await self._get_free_ip_data(ip)
                if ip_data:
                    data.update(ip_data)
            
            # Formatear resultado
            result = formatters.format_ip_geolocation_result(data)
            
            # Guardar en caché
            if settings.CACHE_ENABLED:
                await self.cache_repository.set(f"ip:{ip}", result, settings.CACHE_TTL)
            
            return result
            
        except Exception as e:
            logger.error(f"Error al geolocalizar IP {ip}: {str(e)}")
            return formatters.format_error(f"Error al geolocalizar IP: {str(e)}")
    
    async def _get_free_ip_data(self, ip):
        """
        Obtiene datos de geolocalización de una IP usando un servicio gratuito.
        
        Args:
            ip (str): Dirección IP a geolocalizar.
            
        Returns:
            dict: Datos de geolocalización o None si no se pudo obtener.
        """
        try:
            # Usar servicio gratuito ipapi.co
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://ipapi.co/{ip}/json/") as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'country': data.get('country_name', "Desconocido"),
                            'city': data.get('city', "Desconocida"),
                            'region': data.get('region', "Desconocida"),
                            'isp': data.get('org', "Desconocido"),
                            'org': data.get('org', "Desconocida"),
                            'timezone': data.get('timezone', "Desconocida"),
                            'latitude': data.get('latitude', "Desconocida"),
                            'longitude': data.get('longitude', "Desconocida")
                        }
            
            # Si falla, intentar con otro servicio gratuito
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://ipinfo.io/{ip}/json") as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'country': data.get('country', "Desconocido"),
                            'city': data.get('city', "Desconocida"),
                            'region': data.get('region', "Desconocida"),
                            'isp': data.get('org', "Desconocido"),
                            'org': data.get('org', "Desconocida")
                        }
            
            return None
        except Exception as e:
            logger.error(f"Error al obtener datos gratuitos para IP {ip}: {str(e)}")
            return None

# Instancia global del servicio
ip_service = IPService()

async def geolocate_ip(ip):
    """
    Función auxiliar para geolocalizar una IP.
    
    Args:
        ip (str): Dirección IP a geolocalizar.
        
    Returns:
        str: Resultado de la geolocalización formateado.
    """
    return await ip_service.geolocate_ip(ip)
