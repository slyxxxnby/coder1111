"""
Servicio para investigación OSINT de teléfonos en el Bot OSINT Avanzado.
"""
import logging
import phonenumbers
from phonenumbers import carrier, geocoder, timezone
from ..config import settings, api_keys
from ..utils import validators, formatters, helpers
from ..repositories import api_repository, cache_repository

# Configuración del logger
logger = logging.getLogger(__name__)

class PhoneService:
    """
    Servicio para investigación OSINT de teléfonos.
    """
    
    def __init__(self):
        """
        Inicializa el servicio de investigación OSINT de teléfonos.
        """
        self.api_repository = api_repository.APIRepository()
        self.cache_repository = cache_repository.CacheRepository()
    
    async def investigate_phone(self, phone):
        """
        Investiga un número telefónico para obtener información OSINT.
        
        Args:
            phone (str): Número telefónico a investigar.
            
        Returns:
            str: Resultado de la investigación formateado.
        """
        try:
            # Validar número telefónico
            if not validators.validate_phone(phone):
                return formatters.format_error("Número telefónico inválido")
            
            # Normalizar número
            normalized_phone = validators.normalize_phone(phone)
            if not normalized_phone:
                return formatters.format_error("No se pudo normalizar el número telefónico")
            
            # Verificar caché
            if settings.CACHE_ENABLED:
                cached_result = await self.cache_repository.get(f"phone:{normalized_phone}")
                if cached_result:
                    logger.info(f"Resultado de caché para teléfono: {normalized_phone}")
                    return cached_result
            
            # Analizar número
            parsed = phonenumbers.parse(phone, None)
            
            # Recopilar datos básicos
            data = {
                'phone': normalized_phone,
                'carrier': carrier.name_for_number(parsed, "es") or "Desconocido",
                'region': geocoder.description_for_number(parsed, "es") or "Desconocida",
                'time_zone': ", ".join(timezone.time_zones_for_number(parsed)) or "Desconocida"
            }
            
            # Enriquecer con datos de API si está disponible
            if api_keys.has_api_key('numverify'):
                api_key = api_keys.get_api_key('numverify')
                phone_data = await self.api_repository.get_phone_data(normalized_phone, api_key)
                
                if phone_data:
                    data.update({
                        'valid': phone_data.get('valid', True),
                        'country_code': phone_data.get('country_code'),
                        'country_name': phone_data.get('country_name'),
                        'location': phone_data.get('location'),
                        'carrier': phone_data.get('carrier') or data['carrier'],
                        'line_type': phone_data.get('line_type')
                    })
            
            # Formatear resultado
            result = formatters.format_phone_osint_result(data)
            
            # Guardar en caché
            if settings.CACHE_ENABLED:
                await self.cache_repository.set(f"phone:{normalized_phone}", result, settings.CACHE_TTL)
            
            return result
            
        except Exception as e:
            logger.error(f"Error al investigar teléfono {phone}: {str(e)}")
            return formatters.format_error(f"Error al investigar teléfono: {str(e)}")

# Instancia global del servicio
phone_service = PhoneService()

async def investigate_phone(phone):
    """
    Función auxiliar para investigar un número telefónico.
    
    Args:
        phone (str): Número telefónico a investigar.
        
    Returns:
        str: Resultado de la investigación formateado.
    """
    return await phone_service.investigate_phone(phone)
