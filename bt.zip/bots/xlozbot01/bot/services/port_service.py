"""
Servicio para escaneo de puertos en el Bot OSINT Avanzado.
"""
import logging
import socket
import asyncio
from scapy.all import sr1, IP, TCP
from ..config import settings, api_keys
from ..utils import validators, formatters, helpers
from ..repositories import api_repository, cache_repository

# Configuración del logger
logger = logging.getLogger(__name__)

class PortService:
    """
    Servicio para escaneo de puertos.
    """
    
    def __init__(self):
        """
        Inicializa el servicio de escaneo de puertos.
        """
        self.api_repository = api_repository.APIRepository()
        self.cache_repository = cache_repository.CacheRepository()
    
    async def scan_ports(self, target):
        """
        Escanea puertos en un objetivo.
        
        Args:
            target (str): IP o dominio a escanear.
            
        Returns:
            str: Resultado del escaneo formateado.
        """
        try:
            # Validar y normalizar objetivo
            target = validators.sanitize_input(target)
            target = validators.normalize_ip_or_domain(target)
            
            # Verificar caché
            if settings.CACHE_ENABLED:
                cached_result = await self.cache_repository.get(f"port:{target}")
                if cached_result:
                    logger.info(f"Resultado de caché para escaneo de puertos: {target}")
                    return cached_result
            
            # Resolver hostname a IP si es necesario
            try:
                ip = socket.gethostbyname(target)
            except socket.error:
                ip = target
                if not validators.validate_ip(ip):
                    return formatters.format_error("IP o dominio inválido")
            
            # Determinar puertos a escanear
            ports_to_scan = await self._get_ports_to_scan()
            
            # Escanear puertos
            open_ports, services = await self._scan_ports(ip, ports_to_scan)
            
            # Enriquecer con datos de API si está disponible
            if api_keys.has_api_key('shodan'):
                shodan_data = await self._get_shodan_data(ip)
                if shodan_data and 'ports' in shodan_data:
                    # Añadir puertos adicionales encontrados por Shodan
                    for port in shodan_data['ports']:
                        if port not in open_ports:
                            open_ports.append(port)
                            services[str(port)] = shodan_data.get('services', {}).get(str(port), 'desconocido')
            
            # Recopilar datos
            data = {
                'target': target,
                'ip': ip,
                'open_ports': open_ports,
                'services': services
            }
            
            # Formatear resultado
            result = formatters.format_port_scan_result(data)
            
            # Guardar en caché
            if settings.CACHE_ENABLED:
                await self.cache_repository.set(f"port:{target}", result, settings.CACHE_TTL)
            
            return result
            
        except Exception as e:
            logger.error(f"Error al escanear puertos en {target}: {str(e)}")
            return formatters.format_error(f"Error al escanear puertos: {str(e)}")
    
    async def _get_ports_to_scan(self):
        """
        Determina los puertos a escanear.
        
        Returns:
            list: Lista de puertos a escanear.
        """
        # Puertos comunes
        common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 465, 587, 993, 995, 3306, 3389, 8080]
        
        # Limitar cantidad de puertos según configuración
        max_ports = min(settings.MAX_PORTS_TO_SCAN, 1000)  # Máximo 1000 puertos por seguridad
        
        if max_ports <= len(common_ports):
            return common_ports[:max_ports]
        
        # Añadir puertos adicionales hasta alcanzar el máximo
        additional_ports = list(range(1, 1001))  # Puertos del 1 al 1000
        additional_ports = [p for p in additional_ports if p not in common_ports]
        
        return common_ports + additional_ports[:max_ports - len(common_ports)]
    
    async def _scan_ports(self, ip, ports):
        """
        Escanea puertos en una IP.
        
        Args:
            ip (str): IP a escanear.
            ports (list): Lista de puertos a escanear.
            
        Returns:
            tuple: (open_ports, services)
        """
        open_ports = []
        services = {}
        
        # Crear tareas para escanear puertos en paralelo
        tasks = []
        for port in ports:
            tasks.append(self._scan_port(ip, port))
        
        # Ejecutar tareas en paralelo con límite de concurrencia
        chunk_size = 10  # Escanear 10 puertos a la vez
        for i in range(0, len(tasks), chunk_size):
            chunk = tasks[i:i+chunk_size]
            results = await asyncio.gather(*chunk)
            
            for port, is_open, service in results:
                if is_open:
                    open_ports.append(port)
                    services[str(port)] = service
        
        return open_ports, services
    
    async def _scan_port(self, ip, port):
        """
        Escanea un puerto específico.
        
        Args:
            ip (str): IP a escanear.
            port (int): Puerto a escanear.
            
        Returns:
            tuple: (port, is_open, service)
        """
        try:
            # Crear socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            
            # Intentar conectar
            result = sock.connect_ex((ip, port))
            sock.close()
            
            if result == 0:
                # Puerto abierto, obtener servicio
                try:
                    service = socket.getservbyport(port)
                except:
                    service = "desconocido"
                
                return port, True, service
            
            return port, False, None
            
        except Exception:
            return port, False, None
    
    async def _get_shodan_data(self, ip):
        """
        Obtiene datos de Shodan para una IP.
        
        Args:
            ip (str): IP a consultar.
            
        Returns:
            dict: Datos de Shodan o None si no está disponible.
        """
        try:
            api_key = api_keys.get_api_key('shodan')
            if not api_key:
                return None
            
            return await self.api_repository.get_shodan_data(ip, api_key)
        except Exception as e:
            logger.error(f"Error al obtener datos de Shodan para {ip}: {str(e)}")
            return None

# Instancia global del servicio
port_service = PortService()

async def scan_ports(target):
    """
    Función auxiliar para escanear puertos.
    
    Args:
        target (str): IP o dominio a escanear.
        
    Returns:
        str: Resultado del escaneo formateado.
    """
    return await port_service.scan_ports(target)
