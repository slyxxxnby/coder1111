"""
Servicio para investigación OSINT de emails en el Bot OSINT Avanzado.
"""
import logging
import whois
import aiohttp
from bs4 import BeautifulSoup
from urllib.parse import quote
from ..config import settings, api_keys
from ..utils import validators, formatters, helpers
from ..repositories import api_repository, cache_repository

# Configuración del logger
logger = logging.getLogger(__name__)

class EmailService:
    """
    Servicio para investigación OSINT de emails.
    """
    
    def __init__(self):
        """
        Inicializa el servicio de investigación OSINT de emails.
        """
        self.api_repository = api_repository.APIRepository()
        self.cache_repository = cache_repository.CacheRepository()
    
    async def investigate_email(self, email):
        """
        Investiga un email para obtener información OSINT.
        
        Args:
            email (str): Email a investigar.
            
        Returns:
            str: Resultado de la investigación formateado.
        """
        try:
            # Validar y normalizar email
            if not validators.validate_email(email):
                return formatters.format_error("Email inválido")
            
            email = validators.normalize_email(email)
            
            # Verificar caché
            if settings.CACHE_ENABLED:
                cached_result = await self.cache_repository.get(f"email:{email}")
                if cached_result:
                    logger.info(f"Resultado de caché para email: {email}")
                    return cached_result
            
            # Extraer usuario y dominio
            username, domain = email.split('@')
            
            # Recopilar datos
            data = {
                'email': email,
                'domain_info': await self._get_domain_info(domain),
                'breach_info': await self._check_breaches(email),
                'social_media': await self._find_social_media(username, email)
            }
            
            # Formatear resultado
            result = formatters.format_email_osint_result(data)
            
            # Guardar en caché
            if settings.CACHE_ENABLED:
                await self.cache_repository.set(f"email:{email}", result, settings.CACHE_TTL)
            
            return result
            
        except Exception as e:
            logger.error(f"Error al investigar email {email}: {str(e)}")
            return formatters.format_error(f"Error al investigar email: {str(e)}")
    
    async def _get_domain_info(self, domain):
        """
        Obtiene información del dominio del email.
        
        Args:
            domain (str): Dominio a consultar.
            
        Returns:
            dict: Información del dominio.
        """
        try:
            # Intentar usar WhoisXML API si está disponible
            if api_keys.has_api_key('whoisxml'):
                api_key = api_keys.get_api_key('whoisxml')
                whois_data = await self.api_repository.get_whois_data(domain, api_key)
                if whois_data:
                    return whois_data
            
            # Fallback a python-whois
            domain_info = whois.whois(domain)
            return {
                'registrant': domain_info.registrant or "Desconocido",
                'org': domain_info.org or "Desconocida",
                'creation_date': str(domain_info.creation_date)
            }
        except Exception as e:
            logger.error(f"Error al obtener información del dominio {domain}: {str(e)}")
            return {}
    
    async def _check_breaches(self, email):
        """
        Verifica si el email aparece en brechas de seguridad.
        
        Args:
            email (str): Email a verificar.
            
        Returns:
            str: Información sobre brechas.
        """
        try:
            # Usar Have I Been Pwned API si está disponible
            if api_keys.has_api_key('haveibeenpwned'):
                api_key = api_keys.get_api_key('haveibeenpwned')
                breach_data = await self.api_repository.check_email_breaches(email, api_key)
                
                if breach_data:
                    if isinstance(breach_data, list) and len(breach_data) > 0:
                        breaches = [f"• {b['Name']} ({b['BreachDate']}): {b['Description'][:100]}..." for b in breach_data[:5]]
                        return "🔴 El email aparece en las siguientes brechas de seguridad:\n\n" + "\n\n".join(breaches)
                    else:
                        return "🟢 No se encontraron brechas de seguridad para este email."
            
            # Simulación si no hay API Key
            return "ℹ️ No se pudo verificar brechas de seguridad (API Key no configurada)."
        except Exception as e:
            logger.error(f"Error al verificar brechas para {email}: {str(e)}")
            return "⚠️ Error al verificar brechas de seguridad."
    
    async def _find_social_media(self, username, email):
        """
        Busca perfiles de redes sociales asociados al email o username.
        
        Args:
            username (str): Nombre de usuario extraído del email.
            email (str): Email completo.
            
        Returns:
            str: Información sobre perfiles de redes sociales.
        """
        try:
            # Lista de redes sociales populares para buscar
            social_networks = [
                {'name': 'Facebook', 'url': f'https://www.facebook.com/{username}'},
                {'name': 'Twitter', 'url': f'https://twitter.com/{username}'},
                {'name': 'LinkedIn', 'url': f'https://www.linkedin.com/in/{username}'},
                {'name': 'Instagram', 'url': f'https://www.instagram.com/{username}'},
                {'name': 'GitHub', 'url': f'https://github.com/{username}'}
            ]
            
            # Verificar existencia de perfiles (simulado)
            # En una implementación real, se verificaría la existencia de cada perfil
            
            # Si hay API Key para servicios de OSINT social, usarla
            if api_keys.has_api_key('social'):
                api_key = api_keys.get_api_key('social')
                social_data = await self.api_repository.find_social_profiles(username, email, api_key)
                
                if social_data and 'profiles' in social_data:
                    profiles = [f"• {p['network']}: {p['url']}" for p in social_data['profiles']]
                    if profiles:
                        return "Posibles perfiles encontrados:\n\n" + "\n".join(profiles)
            
            # Simulación si no hay API Key
            profiles = [f"• {network['name']}: {network['url']}" for network in social_networks[:3]]
            return "Posibles perfiles (simulación):\n\n" + "\n".join(profiles) + "\n\n⚠️ Para resultados más precisos, configura una API Key para búsqueda social."
            
        except Exception as e:
            logger.error(f"Error al buscar perfiles sociales para {username}: {str(e)}")
            return "⚠️ Error al buscar perfiles en redes sociales."

# Instancia global del servicio
email_service = EmailService()

async def investigate_email(email):
    """
    Función auxiliar para investigar un email.
    
    Args:
        email (str): Email a investigar.
        
    Returns:
        str: Resultado de la investigación formateado.
    """
    return await email_service.investigate_email(email)
