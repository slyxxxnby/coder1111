"""
Módulo principal del bot GleySxycBot v2.

Este módulo contiene la clase principal del bot que gestiona la conexión con Telegram,
el manejo de comandos, la carga de plugins y la gestión de conversaciones.
"""

import os
import logging
import importlib
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional, Union

from telegram import Update, Bot, BotCommand
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ConversationHandler, filters, ContextTypes, AIORateLimiter
)

# Añadir el directorio raíz al path para importaciones
sys.path.append(str(Path(__file__).parent.parent))

from config.config import (
    TELEGRAM_TOKEN, BOT_NAME, BOT_VERSION, BOT_DESCRIPTION,
    PLUGINS_DIR, RATE_LIMIT, ENABLED_PLUGINS
)

# Configuración de logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class GleySxycBot:
    """Clase principal para gestionar el bot de Telegram."""
    
    def __init__(self, token: str = None):
        """
        Inicializa el bot con el token proporcionado o desde variables de entorno.
        
        Args:
            token (str, opcional): Token de Telegram. Si no se proporciona, se usa el de config.
        """
        self.token = token or TELEGRAM_TOKEN
        if not self.token:
            raise ValueError("No se ha proporcionado un token de Telegram. Configúralo en el archivo .env")
        
        # Inicializar el bot y la aplicación
        self.bot = Bot(token=self.token)
        
        # Configurar limitador de tasa para evitar flood de Telegram
        rate_limiter = AIORateLimiter(
            overall_max_rate=30,  # 30 mensajes por segundo en total
            overall_time_period=1.0,
            group_max_rate=20,    # 20 mensajes por segundo por chat
            group_time_period=60.0,
            max_retries=5
        )
        
        self.application = Application.builder() \
            .token(self.token) \
            .rate_limiter(rate_limiter) \
            .build()
        
        # Almacenar manejadores de comandos y plugins
        self.command_handlers = {}
        self.plugins = {}
        self.conversation_handlers = []
        
        # Estado del bot
        self.is_running = False
        
        logger.info(f"Bot {BOT_NAME} v{BOT_VERSION} inicializado")
    
    async def setup(self):
        """Configura el bot, carga plugins y registra manejadores."""
        logger.info("Configurando bot...")
        
        # Registrar manejadores básicos
        self.register_basic_handlers()
        
        # Cargar plugins habilitados
        await self.load_plugins()
        
        # Configurar comandos para el menú de Telegram
        await self.setup_commands()
        
        logger.info("Bot configurado correctamente")
    
    def register_basic_handlers(self):
        """Registra los manejadores básicos del bot."""
        # Manejador de inicio
        self.application.add_handler(CommandHandler("start", self.start_command))
        
        # Manejador de ayuda
        self.application.add_handler(CommandHandler("help", self.help_command))
        
        # Manejador de versión
        self.application.add_handler(CommandHandler("version", self.version_command))
        
        # Manejador de callbacks de botones
        self.application.add_handler(CallbackQueryHandler(self.button_handler))
        
        # Manejador para mensajes no reconocidos
        self.application.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self.echo)
        )
        
        logger.info("Manejadores básicos registrados")
    
    async def load_plugins(self):
        """Carga los plugins habilitados."""
        logger.info("Cargando plugins...")
        
        # Asegurar que el directorio de plugins existe
        if not os.path.exists(PLUGINS_DIR):
            os.makedirs(PLUGINS_DIR)
            logger.info(f"Directorio de plugins creado: {PLUGINS_DIR}")
        
        # Añadir directorio de plugins al path
        sys.path.append(str(PLUGINS_DIR))
        
        # Cargar plugins habilitados
        for plugin_name in ENABLED_PLUGINS:
            try:
                # Intentar importar el plugin
                plugin_module = importlib.import_module(f"plugins.{plugin_name}")
                
                # Verificar que el plugin tiene la función setup
                if not hasattr(plugin_module, "setup"):
                    logger.warning(f"Plugin {plugin_name} no tiene función setup(). Omitiendo.")
                    continue
                
                # Configurar el plugin
                plugin_handlers = await plugin_module.setup(self)
                
                # Registrar manejadores del plugin
                if plugin_handlers:
                    for handler in plugin_handlers:
                        self.application.add_handler(handler)
                
                # Almacenar referencia al plugin
                self.plugins[plugin_name] = plugin_module
                logger.info(f"Plugin {plugin_name} cargado correctamente")
                
            except Exception as e:
                logger.error(f"Error al cargar plugin {plugin_name}: {e}")
        
        logger.info(f"Plugins cargados: {len(self.plugins)}")
    
    async def setup_commands(self):
        """Configura los comandos disponibles en el menú de Telegram."""
        commands = [
            BotCommand("start", "Inicia el bot y muestra el menú principal"),
            BotCommand("help", "Muestra el mensaje de ayuda con todos los comandos"),
            BotCommand("version", "Muestra la versión actual del bot")
        ]
        
        # Añadir comandos de plugins
        for plugin_name, plugin in self.plugins.items():
            if hasattr(plugin, "get_commands"):
                plugin_commands = plugin.get_commands()
                commands.extend(plugin_commands)
        
        # Configurar comandos en Telegram
        await self.bot.set_my_commands(commands)
        logger.info(f"Comandos configurados: {len(commands)}")
    
    def add_handler(self, handler):
        """
        Añade un manejador al bot.
        
        Args:
            handler: Manejador de telegram.ext a añadir
        """
        self.application.add_handler(handler)
    
    def add_conversation_handler(self, handler):
        """
        Añade un manejador de conversación al bot.
        
        Args:
            handler: ConversationHandler a añadir
        """
        self.application.add_handler(handler)
        self.conversation_handlers.append(handler)
    
    def register_command(self, command, handler_func, description=""):
        """
        Registra un nuevo comando en el bot.
        
        Args:
            command (str): Nombre del comando sin la barra (/)
            handler_func (callable): Función que maneja el comando
            description (str, opcional): Descripción del comando para el menú de ayuda
        """
        self.command_handlers[command] = {
            "handler": handler_func,
            "description": description
        }
        self.application.add_handler(CommandHandler(command, handler_func))
        logger.info(f"Comando /{command} registrado")
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja el comando /start."""
        user = update.effective_user
        await update.message.reply_html(
            f"¡Hola, {user.mention_html()}! 👋\n\n"
            f"Bienvenido a {BOT_NAME} v{BOT_VERSION} - {BOT_DESCRIPTION}\n\n"
            f"Usa /help para ver los comandos disponibles o utiliza el menú principal a continuación."
        )
        
        # Mostrar menú principal
        await self.show_main_menu(update, context)
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja el comando /help."""
        help_text = f"*{BOT_NAME} v{BOT_VERSION}*\n\n"
        help_text += "*Comandos Disponibles:*\n"
        
        # Comandos básicos
        help_text += "• /start - Inicia el bot y muestra el menú principal\n"
        help_text += "• /help - Muestra este mensaje de ayuda\n"
        help_text += "• /version - Muestra la versión actual del bot\n"
        
        # Comandos de plugins
        for command, info in self.command_handlers.items():
            if info["description"]:
                help_text += f"• /{command} - {info['description']}\n"
        
        # Información adicional
        help_text += "\n*Uso del Bot:*\n"
        help_text += "Este bot está diseñado para proporcionar herramientas educativas sobre ciberseguridad. "
        help_text += "Puedes navegar usando los botones del menú o los comandos listados arriba.\n\n"
        
        # Consideraciones éticas
        help_text += "*Consideraciones Éticas:*\n"
        help_text += "Todas las herramientas son para uso educativo. No utilices estas herramientas para actividades maliciosas o ilegales."
        
        await update.message.reply_markdown(help_text)
    
    async def version_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja el comando /version."""
        version_text = f"*{BOT_NAME}*\n"
        version_text += f"Versión: {BOT_VERSION}\n"
        version_text += f"Descripción: {BOT_DESCRIPTION}\n\n"
        
        # Información de plugins
        if self.plugins:
            version_text += "*Plugins Cargados:*\n"
            for plugin_name, plugin in self.plugins.items():
                plugin_version = getattr(plugin, "VERSION", "1.0.0")
                version_text += f"• {plugin_name} v{plugin_version}\n"
        
        await update.message.reply_markdown(version_text)
    
    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Maneja las pulsaciones de botones en línea."""
        query = update.callback_query
        await query.answer()
        
        # Extraer datos del callback
        callback_data = query.data
        
        # Manejar callbacks de plugins
        if ":" in callback_data:
            plugin_name, action = callback_data.split(":", 1)
            if plugin_name in self.plugins and hasattr(self.plugins[plugin_name], "handle_callback"):
                await self.plugins[plugin_name].handle_callback(update, context, action)
                return
        
        # Manejar callbacks básicos
        if callback_data == "main_menu":
            await self.show_main_menu(update, context)
        else:
            await query.message.reply_text(f"Acción no reconocida: {callback_data}")
    
    async def echo(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Responde a mensajes que no son comandos."""
        await update.message.reply_text(
            "No entiendo ese comando. Usa /help para ver las opciones disponibles."
        )
    
    async def show_main_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Muestra el menú principal del bot."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        
        # Crear botones para el menú principal
        keyboard = [
            [
                InlineKeyboardButton("🔍 Análisis de URL", callback_data="url:menu"),
                InlineKeyboardButton("🌐 Geolocalización IP", callback_data="geoip:menu")
            ],
            [
                InlineKeyboardButton("🕵️ Herramientas OSINT", callback_data="osint:menu"),
                InlineKeyboardButton("🔒 Seguridad Web", callback_data="websec:menu")
            ],
            [
                InlineKeyboardButton("🧪 Laboratorio de Malware", callback_data="malware:menu"),
                InlineKeyboardButton("🔐 Criptografía", callback_data="crypto:menu")
            ],
            [
                InlineKeyboardButton("🔍 Análisis Forense", callback_data="forensic:menu"),
                InlineKeyboardButton("🛡️ Seguridad de Dispositivos", callback_data="devsec:menu")
            ],
            [
                InlineKeyboardButton("📚 Centro Educativo", callback_data="edu:menu"),
                InlineKeyboardButton("👥 Comunidad", callback_data="community:menu")
            ],
            [
                InlineKeyboardButton("⚙️ Configuración", callback_data="settings:menu"),
                InlineKeyboardButton("❓ Ayuda", callback_data="help:menu")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Determinar si es un mensaje nuevo o una respuesta a un callback
        if update.callback_query:
            await update.callback_query.message.edit_text(
                f"*{BOT_NAME} v{BOT_VERSION}*\n\n"
                f"Selecciona una opción del menú principal:",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                f"*{BOT_NAME} v{BOT_VERSION}*\n\n"
                f"Selecciona una opción del menú principal:",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
    
    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None):
        """
        Envía un mensaje a un chat específico.
        
        Args:
            chat_id: ID del chat
            text: Texto del mensaje
            parse_mode: Modo de parseo (Markdown, HTML)
            reply_markup: Markup para botones
            
        Returns:
            bool: True si se envió correctamente, False en caso contrario
        """
        try:
            await self.bot.send_message(
                chat_id=chat_id,
                text=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup
            )
            return True
        except Exception as e:
            logger.error(f"Error al enviar mensaje: {e}")
            return False
    
    async def send_photo(self, chat_id, photo, caption=None, parse_mode=None, reply_markup=None):
        """
        Envía una foto a un chat específico.
        
        Args:
            chat_id: ID del chat
            photo: Foto a enviar (file_id, URL o archivo)
            caption: Pie de foto
            parse_mode: Modo de parseo (Markdown, HTML)
            reply_markup: Markup para botones
            
        Returns:
            bool: True si se envió correctamente, False en caso contrario
        """
        try:
            await self.bot.send_photo(
                chat_id=chat_id,
                photo=photo,
                caption=caption,
                parse_mode=parse_mode,
                reply_markup=reply_markup
            )
            return True
        except Exception as e:
            logger.error(f"Error al enviar foto: {e}")
            return False
    
    async def send_document(self, chat_id, document, caption=None, parse_mode=None, reply_markup=None):
        """
        Envía un documento a un chat específico.
        
        Args:
            chat_id: ID del chat
            document: Documento a enviar (file_id, URL o archivo)
            caption: Pie de documento
            parse_mode: Modo de parseo (Markdown, HTML)
            reply_markup: Markup para botones
            
        Returns:
            bool: True si se envió correctamente, False en caso contrario
        """
        try:
            await self.bot.send_document(
                chat_id=chat_id,
                document=document,
                caption=caption,
                parse_mode=parse_mode,
                reply_markup=reply_markup
            )
            return True
        except Exception as e:
            logger.error(f"Error al enviar documento: {e}")
            return False
    
    def run(self):
        """Inicia el bot en modo polling."""
        logger.info("Iniciando el bot...")
        self.is_running = True
        self.application.run_polling()
    
    async def stop(self):
        """Detiene el bot."""
        logger.info("Deteniendo el bot...")
        self.is_running = False
        await self.application.stop()
        logger.info("Bot detenido")


# Función para iniciar el bot
async def setup_and_run():
    """Configura y ejecuta el bot."""
    bot = GleySxycBot()
    await bot.setup()
    bot.run()

# Punto de entrada si se ejecuta como script
if __name__ == "__main__":
    import asyncio
    asyncio.run(setup_and_run())
