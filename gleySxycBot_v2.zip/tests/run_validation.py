"""
Script de validación principal para GleySxycBot v2.

Este script ejecuta pruebas de integración para validar la funcionalidad
completa de todos los módulos del bot y sus integraciones.
"""

import os
import sys
import json
import asyncio
import logging
from datetime import datetime
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('validation.log')
    ]
)

logger = logging.getLogger("validation")

# Importar módulos a validar
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from modules.url_analyzer import URLAnalyzer
    from modules.geolocation_ip import GeolocationIP
    from modules.osint_tools import OSINTTools
    from modules.web_security import WebSecurityTools
    from modules.threat_intelligence import ThreatIntelligence
    from modules.forensic_analysis import ForensicAnalysis
    from modules.cryptography_tools import CryptographyTools
    from modules.malware_lab import MalwareLab
    from modules.controlled_attack_simulator import AttackSimulator
    from modules.security_community import SecurityCommunity
    from modules.security_assistant import SecurityAssistant
    
    logger.info("Módulos importados correctamente")
except ImportError as e:
    logger.error(f"Error al importar módulos: {e}")
    sys.exit(1)

class ValidationResults:
    """Clase para almacenar y reportar resultados de validación."""
    
    def __init__(self):
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "modules": {},
            "overall": {
                "total_tests": 0,
                "passed": 0,
                "failed": 0,
                "errors": 0
            }
        }
    
    def add_module_result(self, module_name, test_name, status, message="", details=None):
        """Añade el resultado de una prueba de módulo."""
        if module_name not in self.results["modules"]:
            self.results["modules"][module_name] = {
                "tests": [],
                "passed": 0,
                "failed": 0,
                "errors": 0
            }
        
        test_result = {
            "test_name": test_name,
            "status": status,
            "message": message
        }
        
        if details:
            test_result["details"] = details
            
        self.results["modules"][module_name]["tests"].append(test_result)
        
        # Actualizar contadores
        self.results["modules"][module_name][status.lower()] += 1
        self.results["overall"]["total_tests"] += 1
        self.results["overall"][status.lower()] += 1
    
    def save_report(self, filename="validation_report.json"):
        """Guarda el reporte de validación en un archivo JSON."""
        with open(filename, "w") as f:
            json.dump(self.results, f, indent=2)
        logger.info(f"Reporte de validación guardado en {filename}")
    
    def print_summary(self):
        """Imprime un resumen de los resultados de validación."""
        print("\n" + "="*50)
        print("RESUMEN DE VALIDACIÓN")
        print("="*50)
        print(f"Total de pruebas: {self.results['overall']['total_tests']}")
        print(f"Pasadas: {self.results['overall']['passed']}")
        print(f"Fallidas: {self.results['overall']['failed']}")
        print(f"Errores: {self.results['overall']['errors']}")
        print("="*50)
        print("RESULTADOS POR MÓDULO:")
        
        for module_name, module_results in self.results["modules"].items():
            total = module_results["passed"] + module_results["failed"] + module_results["errors"]
            print(f"\n{module_name}: {module_results['passed']}/{total} pruebas pasadas")
            
            if module_results["failed"] > 0 or module_results["errors"] > 0:
                print("  Pruebas con problemas:")
                for test in module_results["tests"]:
                    if test["status"] in ["FAILED", "ERROR"]:
                        print(f"  - {test['test_name']}: {test['status']} - {test['message']}")
        
        print("\n" + "="*50)

async def validate_url_analyzer():
    """Valida la funcionalidad del analizador de URL."""
    results = []
    validator = ValidationResults()
    module_name = "URLAnalyzer"
    
    try:
        analyzer = URLAnalyzer()
        
        # Prueba 1: Análisis básico de URL
        try:
            logger.info("Validando análisis básico de URL")
            result = await analyzer.analyze_url("https://www.google.com")
            
            if result["success"] and "domain_info" in result:
                validator.add_module_result(module_name, "Análisis básico de URL", "PASSED", 
                                          "El análisis básico de URL funciona correctamente")
            else:
                validator.add_module_result(module_name, "Análisis básico de URL", "FAILED", 
                                          "El análisis básico de URL no devolvió los datos esperados")
        except Exception as e:
            validator.add_module_result(module_name, "Análisis básico de URL", "ERROR", 
                                      f"Error en análisis básico de URL: {str(e)}")
        
        # Prueba 2: Verificación de reputación
        try:
            logger.info("Validando verificación de reputación de URL")
            result = await analyzer.check_url_reputation("https://www.google.com")
            
            if result["success"]:
                validator.add_module_result(module_name, "Verificación de reputación", "PASSED", 
                                          "La verificación de reputación funciona correctamente")
            else:
                validator.add_module_result(module_name, "Verificación de reputación", "FAILED", 
                                          "La verificación de reputación no devolvió los datos esperados")
        except Exception as e:
            validator.add_module_result(module_name, "Verificación de reputación", "ERROR", 
                                      f"Error en verificación de reputación: {str(e)}")
        
        # Prueba 3: Obtención de recursos educativos
        try:
            logger.info("Validando recursos educativos")
            resources = analyzer.get_educational_resources()
            
            if resources and isinstance(resources, dict) and len(resources) > 0:
                validator.add_module_result(module_name, "Recursos educativos", "PASSED", 
                                          "Los recursos educativos se obtienen correctamente")
            else:
                validator.add_module_result(module_name, "Recursos educativos", "FAILED", 
                                          "Los recursos educativos no se obtienen correctamente")
        except Exception as e:
            validator.add_module_result(module_name, "Recursos educativos", "ERROR", 
                                      f"Error al obtener recursos educativos: {str(e)}")
    
    except Exception as e:
        validator.add_module_result(module_name, "Inicialización", "ERROR", 
                                  f"Error al inicializar el módulo: {str(e)}")
    
    return validator

async def validate_geolocation_ip():
    """Valida la funcionalidad del módulo de geolocalización IP."""
    validator = ValidationResults()
    module_name = "GeolocationIP"
    
    try:
        geo = GeolocationIP()
        
        # Prueba 1: Geolocalización básica
        try:
            logger.info("Validando geolocalización básica")
            result = await geo.geolocate_ip("8.8.8.8")  # IP de Google DNS
            
            if result["success"] and "country" in result:
                validator.add_module_result(module_name, "Geolocalización básica", "PASSED", 
                                          "La geolocalización básica funciona correctamente")
            else:
                validator.add_module_result(module_name, "Geolocalización básica", "FAILED", 
                                          "La geolocalización básica no devolvió los datos esperados")
        except Exception as e:
            validator.add_module_result(module_name, "Geolocalización básica", "ERROR", 
                                      f"Error en geolocalización básica: {str(e)}")
        
        # Prueba 2: Obtención de recursos educativos
        try:
            logger.info("Validando recursos educativos")
            resources = geo.get_educational_resources()
            
            if resources and isinstance(resources, dict) and len(resources) > 0:
                validator.add_module_result(module_name, "Recursos educativos", "PASSED", 
                                          "Los recursos educativos se obtienen correctamente")
            else:
                validator.add_module_result(module_name, "Recursos educativos", "FAILED", 
                                          "Los recursos educativos no se obtienen correctamente")
        except Exception as e:
            validator.add_module_result(module_name, "Recursos educativos", "ERROR", 
                                      f"Error al obtener recursos educativos: {str(e)}")
    
    except Exception as e:
        validator.add_module_result(module_name, "Inicialización", "ERROR", 
                                  f"Error al inicializar el módulo: {str(e)}")
    
    return validator

async def validate_osint_tools():
    """Valida la funcionalidad del módulo de herramientas OSINT."""
    validator = ValidationResults()
    module_name = "OSINTTools"
    
    try:
        osint = OSINTTools()
        
        # Prueba 1: Búsqueda de información de dominio
        try:
            logger.info("Validando búsqueda de información de dominio")
            result = await osint.search_domain_info("google.com")
            
            if result["success"] and "domain_info" in result:
                validator.add_module_result(module_name, "Búsqueda de información de dominio", "PASSED", 
                                          "La búsqueda de información de dominio funciona correctamente")
            else:
                validator.add_module_result(module_name, "Búsqueda de información de dominio", "FAILED", 
                                          "La búsqueda de información de dominio no devolvió los datos esperados")
        except Exception as e:
            validator.add_module_result(module_name, "Búsqueda de información de dominio", "ERROR", 
                                      f"Error en búsqueda de información de dominio: {str(e)}")
        
        # Prueba 2: Obtención de recursos educativos
        try:
            logger.info("Validando recursos educativos")
            resources = osint.get_educational_resources()
            
            if resources and isinstance(resources, dict) and len(resources) > 0:
                validator.add_module_result(module_name, "Recursos educativos", "PASSED", 
                                          "Los recursos educativos se obtienen correctamente")
            else:
                validator.add_module_result(module_name, "Recursos educativos", "FAILED", 
                                          "Los recursos educativos no se obtienen correctamente")
        except Exception as e:
            validator.add_module_result(module_name, "Recursos educativos", "ERROR", 
                                      f"Error al obtener recursos educativos: {str(e)}")
    
    except Exception as e:
        validator.add_module_result(module_name, "Inicialización", "ERROR", 
                                  f"Error al inicializar el módulo: {str(e)}")
    
    return validator

# Implementar funciones similares para los demás módulos
# async def validate_web_security(): ...
# async def validate_threat_intelligence(): ...
# async def validate_forensic_analysis(): ...
# async def validate_cryptography_tools(): ...
# async def validate_malware_lab(): ...
# async def validate_attack_simulator(): ...
# async def validate_security_community(): ...
# async def validate_security_assistant(): ...

async def run_all_validations():
    """Ejecuta todas las validaciones y combina los resultados."""
    logger.info("Iniciando validación completa de todos los módulos")
    
    # Lista de funciones de validación
    validation_functions = [
        validate_url_analyzer,
        validate_geolocation_ip,
        validate_osint_tools,
        # Añadir el resto de funciones de validación aquí
    ]
    
    # Ejecutar todas las validaciones
    validation_results = []
    for validate_func in validation_functions:
        result = await validate_func()
        validation_results.append(result)
    
    # Combinar resultados
    combined_results = ValidationResults()
    for result in validation_results:
        for module_name, module_data in result.results["modules"].items():
            for test in module_data["tests"]:
                combined_results.add_module_result(
                    module_name,
                    test["test_name"],
                    test["status"],
                    test["message"],
                    test.get("details")
                )
    
    # Guardar y mostrar resultados
    combined_results.save_report()
    combined_results.print_summary()
    
    return combined_results

if __name__ == "__main__":
    asyncio.run(run_all_validations())
