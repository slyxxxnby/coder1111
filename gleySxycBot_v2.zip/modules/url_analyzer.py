"""
Módulo para análisis avanzado de URLs con integraciones reales de APIs.

Este módulo proporciona funcionalidades para analizar la seguridad de URLs
utilizando múltiples servicios como VirusTotal, URLScan.io, Google Safe Browsing,
y PhishTank, así como análisis local de características de seguridad.
"""

import re
import logging
import hashlib
import urllib.parse
import ssl
import socket
import requests
import json
import time
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
from bs4 import BeautifulSoup
import validators
import whois
import dns.resolver
import OpenSSL.crypto

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL

# Configuración de logging
logger = logging.getLogger(__name__)

class URLAnalyzer:
    """Clase para analizar la seguridad de URLs utilizando múltiples servicios."""
    
    def __init__(self):
        """Inicializa el analizador de URLs."""
        self.virustotal_api_key = get_api_key('virustotal')
        self.urlscan_api_key = get_api_key('urlscan')
        self.phishtank_api_key = get_api_key('phishtank')
        
        # URLs de APIs
        self.virustotal_url = "https://www.virustotal.com/api/v3/urls"
        self.urlscan_url = "https://urlscan.io/api/v1/scan/"
        self.phishtank_url = "https://checkurl.phishtank.com/checkurl/"
        
        # Headers para APIs
        self.headers = {
            'User-Agent': 'GleySxycBot/2.0.0 (Educational Security Bot)'
        }
    
    def validate_url(self, url: str) -> bool:
        """
        Valida que la URL tenga un formato correcto.
        
        Args:
            url: URL a validar
            
        Returns:
            bool: True si la URL es válida, False en caso contrario
        """
        return validators.url(url)
    
    def normalize_url(self, url: str) -> str:
        """
        Normaliza una URL para análisis consistente.
        
        Args:
            url: URL a normalizar
            
        Returns:
            str: URL normalizada
        """
        # Asegurar que la URL tiene un esquema
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        
        # Parsear y reconstruir para normalizar
        parsed = urllib.parse.urlparse(url)
        
        # Eliminar fragmentos
        normalized = urllib.parse.urlunparse((
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            parsed.params,
            parsed.query,
            ''  # Sin fragmento
        ))
        
        return normalized
    
    def get_url_hash(self, url: str) -> str:
        """
        Genera un hash de la URL para identificación única.
        
        Args:
            url: URL a hashear
            
        Returns:
            str: Hash SHA-256 de la URL
        """
        normalized = self.normalize_url(url)
        return hashlib.sha256(normalized.encode()).hexdigest()
    
    async def analyze_url(self, url: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza una URL utilizando múltiples servicios y técnicas.
        
        Args:
            url: URL a analizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis
        """
        # Validar URL
        if not self.validate_url(url):
            return {
                "success": False,
                "message": "URL inválida",
                "educational_note": "Una URL válida debe incluir el protocolo (http:// o https://) y el dominio."
            }
        
        # Normalizar URL
        normalized_url = self.normalize_url(url)
        url_hash = self.get_url_hash(normalized_url)
        
        # Verificar caché si hay sesión de BD
        if db_session:
            cached_result = get_cached_result(db_session, f"url_analysis:{url_hash}")
            if cached_result:
                logger.info(f"Resultado en caché encontrado para URL: {normalized_url}")
                return cached_result
        
        # Iniciar análisis
        logger.info(f"Analizando URL: {normalized_url}")
        
        # Resultados combinados
        results = {
            "success": True,
            "url": normalized_url,
            "timestamp": datetime.now().isoformat(),
            "analysis": {}
        }
        
        # Análisis básico
        basic_analysis = self.analyze_url_basic(normalized_url)
        results["analysis"]["basic"] = basic_analysis
        
        # Análisis de certificado SSL
        if normalized_url.startswith("https://"):
            ssl_analysis = self.analyze_ssl_certificate(normalized_url)
            results["analysis"]["ssl"] = ssl_analysis
        
        # Análisis con VirusTotal
        if has_api_key('virustotal'):
            try:
                vt_analysis = await self.analyze_url_virustotal(normalized_url)
                results["analysis"]["virustotal"] = vt_analysis
                
                # Registrar uso de API si hay sesión de BD
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "virustotal", "url_analysis", 
                                 success=vt_analysis.get("success", False))
            except Exception as e:
                logger.error(f"Error en análisis VirusTotal: {e}")
                results["analysis"]["virustotal"] = {
                    "success": False,
                    "error": str(e)
                }
        
        # Análisis con URLScan.io
        if has_api_key('urlscan'):
            try:
                urlscan_analysis = await self.analyze_url_urlscan(normalized_url)
                results["analysis"]["urlscan"] = urlscan_analysis
                
                # Registrar uso de API si hay sesión de BD
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "urlscan", "url_scan", 
                                 success=urlscan_analysis.get("success", False))
            except Exception as e:
                logger.error(f"Error en análisis URLScan: {e}")
                results["analysis"]["urlscan"] = {
                    "success": False,
                    "error": str(e)
                }
        
        # Análisis con PhishTank
        if has_api_key('phishtank'):
            try:
                phishtank_analysis = await self.analyze_url_phishtank(normalized_url)
                results["analysis"]["phishtank"] = phishtank_analysis
                
                # Registrar uso de API si hay sesión de BD
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "phishtank", "check_url", 
                                 success=phishtank_analysis.get("success", False))
            except Exception as e:
                logger.error(f"Error en análisis PhishTank: {e}")
                results["analysis"]["phishtank"] = {
                    "success": False,
                    "error": str(e)
                }
        
        # Análisis de dominio
        domain_analysis = self.analyze_domain(normalized_url)
        results["analysis"]["domain"] = domain_analysis
        
        # Calcular puntuación de seguridad
        security_score = self.calculate_security_score(results)
        results["security_score"] = security_score
        
        # Generar recomendaciones
        recommendations = self.generate_recommendations(results)
        results["recommendations"] = recommendations
        
        # Guardar en caché si hay sesión de BD
        if db_session:
            set_cached_result(db_session, f"url_analysis:{url_hash}", results, CACHE_TTL)
            
            # Registrar búsqueda si hay ID de usuario
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "url", normalized_url, 
                          f"Score: {security_score}/100, VirusTotal: {results['analysis'].get('virustotal', {}).get('positives', 0)}")
        
        return results
    
    def analyze_url_basic(self, url: str) -> Dict[str, Any]:
        """
        Realiza un análisis básico de la URL.
        
        Args:
            url: URL a analizar
            
        Returns:
            dict: Resultados del análisis básico
        """
        parsed = urllib.parse.urlparse(url)
        
        # Extraer componentes
        scheme = parsed.scheme
        domain = parsed.netloc
        path = parsed.path
        query = parsed.query
        
        # Verificar características sospechosas
        suspicious_patterns = [
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:\.|%2e)(?:php|html|asp|aspx|jsp|cgi)", "Extensión de archivo sospechosa"),
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:login|signin|account|auth|password|pwd)", "Posible página de login"),
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:bank|paypal|apple|google|microsoft|amazon|facebook|twitter|instagram)", "Posible suplantación de marca"),
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:confirm|verify|secure|update)", "Palabras clave sospechosas"),
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:id=|user=|account=|token=)", "Parámetros sensibles en URL"),
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:redirect|redir|return|goto)", "Posible redirección"),
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:download|setup|install|update|upgrade)", "Posible descarga"),
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:free|prize|winner|lottery|bonus)", "Posible estafa"),
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:bitcoin|crypto|wallet|blockchain)", "Posible estafa de criptomonedas"),
            (r"(?:https?://)[^/]*?(?:[^.]+\.)*?([^.]+\.[^.]+)/.*?(?:adult|xxx|porn|sex)", "Contenido para adultos"),
        ]
        
        suspicious_features = []
        for pattern, description in suspicious_patterns:
            if re.search(pattern, url, re.IGNORECASE):
                suspicious_features.append(description)
        
        # Verificar IP en lugar de dominio
        is_ip_address = re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", domain)
        if is_ip_address:
            suspicious_features.append("Uso de dirección IP en lugar de dominio")
        
        # Verificar caracteres Unicode engañosos
        if any(ord(c) > 127 for c in domain):
            suspicious_features.append("Uso de caracteres Unicode potencialmente engañosos")
        
        # Verificar longitud excesiva
        if len(url) > 100:
            suspicious_features.append("URL excesivamente larga")
        
        # Verificar múltiples subdominios
        subdomain_count = domain.count('.')
        if subdomain_count > 3:
            suspicious_features.append(f"Múltiples subdominios ({subdomain_count})")
        
        # Verificar uso de acortadores conocidos
        shorteners = ['bit.ly', 'tinyurl.com', 'goo.gl', 't.co', 'is.gd', 'cli.gs', 'ow.ly', 
                     'buff.ly', 'adf.ly', 'j.mp', 'cutt.ly', 'shorturl.at', 'tiny.cc']
        for shortener in shorteners:
            if shortener in domain:
                suspicious_features.append(f"Uso de acortador de URL ({shortener})")
                break
        
        return {
            "scheme": scheme,
            "domain": domain,
            "path": path,
            "query": query,
            "suspicious_features": suspicious_features,
            "risk_level": "alto" if len(suspicious_features) > 2 else "medio" if suspicious_features else "bajo"
        }
    
    def analyze_ssl_certificate(self, url: str) -> Dict[str, Any]:
        """
        Analiza el certificado SSL de una URL.
        
        Args:
            url: URL a analizar
            
        Returns:
            dict: Información sobre el certificado SSL
        """
        try:
            # Extraer dominio
            domain = urllib.parse.urlparse(url).netloc
            if ':' in domain:
                domain = domain.split(':')[0]
            
            # Conectar y obtener certificado
            context = ssl.create_default_context()
            with socket.create_connection((domain, 443)) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert_bin = ssock.getpeercert(binary_form=True)
                    cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_ASN1, cert_bin)
            
            # Extraer información
            issuer = dict(cert.get_issuer().get_components())
            issuer = {k.decode(): v.decode() for k, v in issuer.items()}
            
            subject = dict(cert.get_subject().get_components())
            subject = {k.decode(): v.decode() for k, v in subject.items()}
            
            not_before = datetime.strptime(cert.get_notBefore().decode(), "%Y%m%d%H%M%SZ")
            not_after = datetime.strptime(cert.get_notAfter().decode(), "%Y%m%d%H%M%SZ")
            
            # Verificar si está expirado
            now = datetime.now()
            is_expired = now > not_after
            is_not_yet_valid = now < not_before
            
            # Verificar si es autofirmado
            is_self_signed = cert.get_issuer().hash() == cert.get_subject().hash()
            
            # Verificar algoritmo de firma
            signature_algorithm = cert.get_signature_algorithm().decode()
            
            # Verificar si usa SHA-1 (débil)
            uses_sha1 = 'sha1' in signature_algorithm.lower()
            
            return {
                "issuer": issuer,
                "subject": subject,
                "valid_from": not_before.isoformat(),
                "valid_until": not_after.isoformat(),
                "is_expired": is_expired,
                "is_not_yet_valid": is_not_yet_valid,
                "is_self_signed": is_self_signed,
                "signature_algorithm": signature_algorithm,
                "uses_weak_algorithm": uses_sha1,
                "status": "inválido" if (is_expired or is_not_yet_valid or is_self_signed or uses_sha1) else "válido"
            }
        except Exception as e:
            logger.error(f"Error al analizar certificado SSL: {e}")
            return {
                "error": str(e),
                "status": "error"
            }
    
    async def analyze_url_virustotal(self, url: str) -> Dict[str, Any]:
        """
        Analiza una URL utilizando la API de VirusTotal.
        
        Args:
            url: URL a analizar
            
        Returns:
            dict: Resultados del análisis de VirusTotal
        """
        if not self.virustotal_api_key:
            return {
                "success": False,
                "message": "No se ha configurado la clave de API de VirusTotal"
            }
        
        # Calcular identificador de la URL
        url_id = urllib.parse.quote_plus(url)
        
        # Primero, enviar la URL para análisis
        headers = {
            'x-apikey': self.virustotal_api_key,
            **self.headers
        }
        data = {
            'url': url
        }
        
        try:
            # Enviar URL para análisis
            response = requests.post(self.virustotal_url, headers=headers, data=data)
            response.raise_for_status()
            result = response.json()
            
            # Extraer ID de análisis
            analysis_id = result.get('data', {}).get('id')
            if not analysis_id:
                return {
                    "success": False,
                    "message": "No se pudo obtener ID de análisis"
                }
            
            # Esperar un momento para que se complete el análisis
            time.sleep(3)
            
            # Obtener resultados del análisis
            analysis_url = f"{self.virustotal_url}/{url_id}"
            response = requests.get(analysis_url, headers=headers)
            response.raise_for_status()
            analysis = response.json()
            
            # Extraer información relevante
            data = analysis.get('data', {})
            attributes = data.get('attributes', {})
            last_analysis_stats = attributes.get('last_analysis_stats', {})
            last_analysis_results = attributes.get('last_analysis_results', {})
            
            # Contar resultados positivos
            positives = last_analysis_stats.get('malicious', 0) + last_analysis_stats.get('suspicious', 0)
            total = sum(last_analysis_stats.values())
            
            # Extraer categorías
            categories = attributes.get('categories', {})
            category_list = list(categories.values())
            
            # Extraer última fecha de análisis
            last_analysis_date = attributes.get('last_analysis_date')
            if last_analysis_date:
                last_analysis_date = datetime.fromtimestamp(last_analysis_date).isoformat()
            
            # Preparar resultados detallados de motores
            engines = []
            for engine_name, engine_result in last_analysis_results.items():
                engines.append({
                    "name": engine_name,
                    "category": engine_result.get('category', 'unknown'),
                    "result": engine_result.get('result', ''),
                    "method": engine_result.get('method', 'unknown'),
                    "engine_update": engine_result.get('engine_update', '')
                })
            
            return {
                "success": True,
                "scan_id": analysis_id,
                "resource": url,
                "url": url,
                "scan_date": last_analysis_date,
                "permalink": f"https://www.virustotal.com/gui/url/{url_id}/detection",
                "positives": positives,
                "total": total,
                "categories": category_list,
                "engines": engines,
                "reputation": attributes.get('reputation', 0),
                "threat_names": attributes.get('threat_names', []),
                "last_http_response_code": attributes.get('last_http_response_code', 0),
                "last_http_response_content_length": attributes.get('last_http_response_content_length', 0),
                "last_http_response_headers": attributes.get('last_http_response_headers', {}),
                "title": attributes.get('title', ''),
                "risk_score": (positives / total * 100) if total > 0 else 0
            }
        except Exception as e:
            logger.error(f"Error en análisis VirusTotal: {e}")
            return {
                "success": False,
                "message": f"Error al analizar URL con VirusTotal: {str(e)}"
            }
    
    async def analyze_url_urlscan(self, url: str) -> Dict[str, Any]:
        """
        Analiza una URL utilizando la API de URLScan.io.
        
        Args:
            url: URL a analizar
            
        Returns:
            dict: Resultados del análisis de URLScan.io
        """
        if not self.urlscan_api_key:
            return {
                "success": False,
                "message": "No se ha configurado la clave de API de URLScan.io"
            }
        
        headers = {
            'API-Key': self.urlscan_api_key,
            'Content-Type': 'application/json',
            **self.headers
        }
        
        data = {
            'url': url,
            'visibility': 'public'
        }
        
        try:
            # Enviar URL para análisis
            response = requests.post(self.urlscan_url, headers=headers, data=json.dumps(data))
            response.raise_for_status()
            result = response.json()
            
            # Extraer UUID y URL de resultados
            uuid = result.get('uuid')
            result_url = result.get('api')
            
            if not uuid or not result_url:
                return {
                    "success": False,
                    "message": "No se pudo obtener ID de análisis"
                }
            
            # Esperar a que se complete el análisis
            max_retries = 10
            for i in range(max_retries):
                time.sleep(3)  # Esperar 3 segundos entre intentos
                
                try:
                    response = requests.get(result_url, headers=headers)
                    if response.status_code == 200:
                        analysis = response.json()
                        
                        # Verificar si el análisis está completo
                        if analysis.get('task', {}).get('status') == 'completed':
                            break
                except:
                    pass
                
                # Si es el último intento y no se completó, devolver error
                if i == max_retries - 1:
                    return {
                        "success": False,
                        "message": "El análisis no se completó en el tiempo esperado"
                    }
            
            # Extraer información relevante
            page = analysis.get('page', {})
            lists = analysis.get('lists', {})
            verdicts = analysis.get('verdicts', {})
            
            return {
                "success": True,
                "scan_id": uuid,
                "url": url,
                "scan_date": analysis.get('task', {}).get('time'),
                "permalink": f"https://urlscan.io/result/{uuid}/",
                "screenshot": f"https://urlscan.io/screenshots/{uuid}.png",
                "ip": page.get('ip'),
                "country": page.get('country'),
                "server": page.get('server'),
                "domain": page.get('domain'),
                "asnname": page.get('asnname'),
                "asn": page.get('asn'),
                "links": lists.get('urls', [])[:10],  # Limitar a 10 enlaces
                "domains": lists.get('domains', [])[:10],  # Limitar a 10 dominios
                "ips": lists.get('ips', [])[:10],  # Limitar a 10 IPs
                "overall_verdict": verdicts.get('overall', {}).get('malicious'),
                "community_verdict": verdicts.get('community', {}).get('malicious'),
                "engines_verdict": verdicts.get('engines', {}).get('malicious'),
                "malicious": verdicts.get('overall', {}).get('malicious', False),
                "risk_score": verdicts.get('overall', {}).get('score', 0) * 100
            }
        except Exception as e:
            logger.error(f"Error en análisis URLScan: {e}")
            return {
                "success": False,
                "message": f"Error al analizar URL con URLScan.io: {str(e)}"
            }
    
    async def analyze_url_phishtank(self, url: str) -> Dict[str, Any]:
        """
        Analiza una URL utilizando la API de PhishTank.
        
        Args:
            url: URL a analizar
            
        Returns:
            dict: Resultados del análisis de PhishTank
        """
        if not self.phishtank_api_key:
            return {
                "success": False,
                "message": "No se ha configurado la clave de API de PhishTank"
            }
        
        headers = {
            'User-Agent': 'GleySxycBot/2.0.0 (Educational Security Bot)',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        data = {
            'url': url,
            'format': 'json',
            'app_key': self.phishtank_api_key
        }
        
        try:
            response = requests.post(self.phishtank_url, headers=headers, data=data)
            response.raise_for_status()
            result = response.json()
            
            # Extraer información relevante
            meta = result.get('meta', {})
            results = result.get('results', {})
            
            return {
                "success": True,
                "url": url,
                "in_database": results.get('in_database', False),
                "phishing": results.get('phish_detail_page') is not None,
                "verified": results.get('verified', False),
                "verification_time": results.get('verification_time'),
                "phish_detail_page": results.get('phish_detail_page'),
                "target": results.get('target', ''),
                "api_version": meta.get('version'),
                "risk_score": 100 if results.get('verified', False) and results.get('phish_detail_page') else 0
            }
        except Exception as e:
            logger.error(f"Error en análisis PhishTank: {e}")
            return {
                "success": False,
                "message": f"Error al analizar URL con PhishTank: {str(e)}"
            }
    
    def analyze_domain(self, url: str) -> Dict[str, Any]:
        """
        Analiza el dominio de una URL.
        
        Args:
            url: URL a analizar
            
        Returns:
            dict: Información sobre el dominio
        """
        parsed = urllib.parse.urlparse(url)
        domain = parsed.netloc
        
        if ':' in domain:
            domain = domain.split(':')[0]
        
        try:
            # Obtener información WHOIS
            domain_info = whois.whois(domain)
            
            # Obtener registros DNS
            dns_records = {}
            
            # A records
            try:
                a_records = dns.resolver.resolve(domain, 'A')
                dns_records['A'] = [record.to_text() for record in a_records]
            except:
                dns_records['A'] = []
            
            # MX records
            try:
                mx_records = dns.resolver.resolve(domain, 'MX')
                dns_records['MX'] = [record.to_text() for record in mx_records]
            except:
                dns_records['MX'] = []
            
            # TXT records
            try:
                txt_records = dns.resolver.resolve(domain, 'TXT')
                dns_records['TXT'] = [record.to_text() for record in txt_records]
            except:
                dns_records['TXT'] = []
            
            # NS records
            try:
                ns_records = dns.resolver.resolve(domain, 'NS')
                dns_records['NS'] = [record.to_text() for record in ns_records]
            except:
                dns_records['NS'] = []
            
            # Verificar registros SPF y DMARC
            has_spf = any('v=spf1' in record.lower() for record in dns_records['TXT'])
            has_dmarc = False
            try:
                dmarc_records = dns.resolver.resolve(f"_dmarc.{domain}", 'TXT')
                has_dmarc = any('v=dmarc1' in record.to_text().lower() for record in dmarc_records)
            except:
                pass
            
            # Calcular edad del dominio
            creation_date = domain_info.creation_date
            if isinstance(creation_date, list):
                creation_date = creation_date[0]
            
            expiration_date = domain_info.expiration_date
            if isinstance(expiration_date, list):
                expiration_date = expiration_date[0]
            
            now = datetime.now()
            
            domain_age = None
            if creation_date:
                domain_age = (now - creation_date).days
            
            days_to_expiration = None
            if expiration_date:
                days_to_expiration = (expiration_date - now).days
            
            # Verificar si es un dominio reciente (menos de 30 días)
            is_recent = domain_age is not None and domain_age < 30
            
            # Verificar si está por expirar (menos de 30 días)
            is_expiring_soon = days_to_expiration is not None and days_to_expiration < 30
            
            return {
                "domain": domain,
                "registrar": domain_info.registrar,
                "creation_date": creation_date.isoformat() if creation_date else None,
                "expiration_date": expiration_date.isoformat() if expiration_date else None,
                "domain_age_days": domain_age,
                "days_to_expiration": days_to_expiration,
                "is_recent": is_recent,
                "is_expiring_soon": is_expiring_soon,
                "name_servers": domain_info.name_servers if isinstance(domain_info.name_servers, list) else [domain_info.name_servers] if domain_info.name_servers else [],
                "dns_records": dns_records,
                "has_spf": has_spf,
                "has_dmarc": has_dmarc,
                "risk_factors": [
                    "Dominio registrado recientemente" if is_recent else None,
                    "Dominio a punto de expirar" if is_expiring_soon else None,
                    "Sin registro SPF" if not has_spf else None,
                    "Sin registro DMARC" if not has_dmarc else None
                ]
            }
        except Exception as e:
            logger.error(f"Error al analizar dominio: {e}")
            return {
                "domain": domain,
                "error": str(e)
            }
    
    def calculate_security_score(self, results: Dict[str, Any]) -> int:
        """
        Calcula una puntuación de seguridad basada en los resultados del análisis.
        
        Args:
            results: Resultados del análisis
            
        Returns:
            int: Puntuación de seguridad (0-100)
        """
        score = 100  # Comenzar con puntuación máxima
        deductions = []  # Lista para registrar deducciones
        
        # Análisis básico
        basic = results.get("analysis", {}).get("basic", {})
        suspicious_features = basic.get("suspicious_features", [])
        
        # Deducir por características sospechosas
        if suspicious_features:
            deduction = min(len(suspicious_features) * 5, 30)  # Máximo 30 puntos
            score -= deduction
            deductions.append(f"Características sospechosas: -{deduction}")
        
        # Análisis SSL
        ssl = results.get("analysis", {}).get("ssl", {})
        if ssl:
            if ssl.get("is_expired", False):
                score -= 20
                deductions.append("Certificado SSL expirado: -20")
            if ssl.get("is_self_signed", False):
                score -= 15
                deductions.append("Certificado SSL autofirmado: -15")
            if ssl.get("uses_weak_algorithm", False):
                score -= 10
                deductions.append("Algoritmo SSL débil: -10")
        
        # VirusTotal
        vt = results.get("analysis", {}).get("virustotal", {})
        if vt and vt.get("success", False):
            positives = vt.get("positives", 0)
            total = vt.get("total", 0)
            
            if total > 0:
                ratio = positives / total
                if ratio > 0:
                    deduction = min(int(ratio * 100), 50)  # Máximo 50 puntos
                    score -= deduction
                    deductions.append(f"Detecciones VirusTotal ({positives}/{total}): -{deduction}")
        
        # URLScan
        urlscan = results.get("analysis", {}).get("urlscan", {})
        if urlscan and urlscan.get("success", False):
            if urlscan.get("malicious", False):
                score -= 30
                deductions.append("URLScan: URL maliciosa: -30")
        
        # PhishTank
        phishtank = results.get("analysis", {}).get("phishtank", {})
        if phishtank and phishtank.get("success", False):
            if phishtank.get("phishing", False) and phishtank.get("verified", False):
                score -= 50
                deductions.append("PhishTank: Phishing verificado: -50")
        
        # Análisis de dominio
        domain = results.get("analysis", {}).get("domain", {})
        if domain:
            if domain.get("is_recent", False):
                score -= 10
                deductions.append("Dominio registrado recientemente: -10")
            if domain.get("is_expiring_soon", False):
                score -= 5
                deductions.append("Dominio a punto de expirar: -5")
            if not domain.get("has_spf", True):
                score -= 5
                deductions.append("Sin registro SPF: -5")
            if not domain.get("has_dmarc", True):
                score -= 5
                deductions.append("Sin registro DMARC: -5")
        
        # Asegurar que la puntuación esté en el rango 0-100
        score = max(0, min(score, 100))
        
        # Añadir deducciones al resultado
        results["score_deductions"] = deductions
        
        return score
    
    def generate_recommendations(self, results: Dict[str, Any]) -> List[str]:
        """
        Genera recomendaciones basadas en los resultados del análisis.
        
        Args:
            results: Resultados del análisis
            
        Returns:
            list: Lista de recomendaciones
        """
        recommendations = []
        score = results.get("security_score", 0)
        
        # Recomendaciones generales basadas en la puntuación
        if score < 20:
            recommendations.append("Esta URL presenta un riesgo extremadamente alto. Se recomienda evitar completamente su acceso.")
        elif score < 50:
            recommendations.append("Esta URL presenta un riesgo alto. Se recomienda extrema precaución y verificar con fuentes oficiales.")
        elif score < 70:
            recommendations.append("Esta URL presenta un riesgo moderado. Se recomienda precaución al acceder.")
        else:
            recommendations.append("Esta URL parece segura, pero siempre es recomendable mantener precauciones básicas.")
        
        # Recomendaciones específicas basadas en hallazgos
        
        # Análisis básico
        basic = results.get("analysis", {}).get("basic", {})
        suspicious_features = basic.get("suspicious_features", [])
        
        if "Uso de acortador de URL" in str(suspicious_features):
            recommendations.append("Esta URL utiliza un servicio acortador. Considera usar un servicio de expansión de URLs para ver el destino real antes de acceder.")
        
        if "Uso de dirección IP en lugar de dominio" in str(suspicious_features):
            recommendations.append("Esta URL utiliza una dirección IP en lugar de un nombre de dominio, lo que es inusual para sitios legítimos.")
        
        # SSL
        ssl = results.get("analysis", {}).get("ssl", {})
        if ssl:
            if ssl.get("is_expired", False) or ssl.get("is_self_signed", False) or ssl.get("uses_weak_algorithm", False):
                recommendations.append("Esta URL tiene problemas con su certificado SSL. No envíes información sensible a través de este sitio.")
        
        # VirusTotal
        vt = results.get("analysis", {}).get("virustotal", {})
        if vt and vt.get("success", False) and vt.get("positives", 0) > 0:
            recommendations.append(f"Esta URL ha sido detectada como maliciosa por {vt.get('positives')} motores de análisis en VirusTotal.")
        
        # PhishTank
        phishtank = results.get("analysis", {}).get("phishtank", {})
        if phishtank and phishtank.get("success", False) and phishtank.get("phishing", False):
            recommendations.append("Esta URL está registrada como sitio de phishing en PhishTank.")
        
        # Dominio
        domain = results.get("analysis", {}).get("domain", {})
        if domain and domain.get("is_recent", False):
            recommendations.append("Este dominio ha sido registrado recientemente, lo que puede ser sospechoso para sitios que afirman ser establecidos.")
        
        # Añadir recomendaciones educativas
        recommendations.append("Siempre verifica la URL en la barra de direcciones antes de ingresar información sensible.")
        recommendations.append("Busca el candado de HTTPS en la barra de direcciones para confirmar una conexión segura.")
        recommendations.append("Desconfía de URLs que lleguen por correos no solicitados o mensajes de fuentes desconocidas.")
        
        return recommendations
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre análisis de URLs y seguridad web.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "phishing_signs": [
                "URLs que imitan sitios legítimos con pequeñas variaciones",
                "Uso de dominios sospechosos o poco comunes",
                "Presencia de 'http://' en lugar de 'https://'",
                "URLs excesivamente largas con caracteres aleatorios",
                "Redirecciones múltiples",
                "Uso de acortadores de URL para ocultar el destino real",
                "Dominios con caracteres Unicode similares a letras latinas",
                "Uso de subdominios para simular rutas (ejemplo: paypal.secure.domain.com)",
                "Errores gramaticales o de ortografía en la URL",
                "Uso de números en lugar de letras (ejemplo: g00gle en vez de google)"
            ],
            "safety_tips": [
                "Verifica siempre la URL antes de ingresar información sensible",
                "Busca el candado de HTTPS en la barra de direcciones",
                "Desconfía de URLs acortadas de fuentes desconocidas",
                "Utiliza herramientas de análisis como VirusTotal antes de visitar sitios sospechosos",
                "Mantén tu navegador y antivirus actualizados",
                "Activa la autenticación de dos factores en tus cuentas importantes",
                "No hagas clic en enlaces de correos o mensajes no solicitados",
                "Escribe directamente las URLs de sitios sensibles en lugar de seguir enlaces",
                "Utiliza un gestor de contraseñas para evitar ingresar credenciales en sitios falsos",
                "Revisa periódicamente los permisos de aplicaciones conectadas a tus cuentas"
            ],
            "learning_resources": [
                "https://www.virustotal.com/gui/home/url - Análisis gratuito de URLs",
                "https://urlscan.io/ - Escaneo y análisis de sitios web",
                "https://www.phishtank.com/ - Base de datos de sitios de phishing conocidos",
                "https://owasp.org/www-community/attacks/Phishing - Guía OWASP sobre phishing",
                "https://safebrowsing.google.com/ - Google Safe Browsing",
                "https://transparencyreport.google.com/safe-browsing/search - Verificar si un sitio es inseguro",
                "https://www.netcraft.com/apps/browser-extension/ - Extensión anti-phishing",
                "https://www.eff.org/https-everywhere - Extensión para forzar HTTPS",
                "https://www.ssllabs.com/ssltest/ - Prueba de configuración SSL/TLS",
                "https://www.malwaredomainlist.com/ - Lista de dominios maliciosos"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    analyzer = URLAnalyzer()
    import asyncio
    
    async def test():
        result = await analyzer.analyze_url("https://www.google.com")
        print(json.dumps(result, indent=2))
    
    asyncio.run(test())
