"""
Módulo de Seguridad en Redes Sociales.

Este módulo proporciona herramientas para analizar la seguridad y privacidad
en redes sociales, detectar posibles riesgos y ofrecer recomendaciones
para mejorar la protección de la información personal.
"""

import logging
import os
import json
import re
import random
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL

# Configuración de logging
logger = logging.getLogger(__name__)

class SocialMediaSecurity:
    """Clase para herramientas de seguridad en redes sociales."""
    
    def __init__(self):
        """Inicializa la clase de seguridad en redes sociales."""
        self.headers = {
            "User-Agent": "GleySxycBot/2.0.0 (Educational Security Bot)"
        }
        
        # Plataformas de redes sociales soportadas
        self.supported_platforms = [
            "facebook", "twitter", "instagram", "linkedin", 
            "tiktok", "youtube", "reddit", "snapchat"
        ]
        
        # Riesgos comunes por plataforma
        self.common_risks = {
            "facebook": [
                "Configuración de privacidad débil",
                "Compartir ubicación en tiempo real",
                "Aceptar solicitudes de amistad de desconocidos",
                "Publicar información personal sensible",
                "Aplicaciones de terceros con acceso excesivo",
                "Etiquetado automático en fotos",
                "Historial de búsqueda y actividad visible"
            ],
            "twitter": [
                "Tweets públicos con información personal",
                "Geolocalización activada en tweets",
                "Seguir cuentas sospechosas o maliciosas",
                "Compartir opiniones controvertidas que podrían ser utilizadas en su contra",
                "Mensajes directos con contenido sensible",
                "Autenticación débil (sin 2FA)"
            ],
            "instagram": [
                "Cuenta pública con información personal",
                "Geolocalización precisa en publicaciones",
                "Aceptar seguidores desconocidos",
                "Compartir rutinas diarias o ubicaciones frecuentes",
                "Enlaces a otras redes sociales menos seguras",
                "Mensajes directos con contenido sensible"
            ],
            "linkedin": [
                "Información laboral y educativa excesivamente detallada",
                "Conexiones con personas desconocidas",
                "Compartir planes profesionales confidenciales",
                "Información de contacto visible públicamente",
                "Historial de búsqueda visible para otros"
            ],
            "tiktok": [
                "Cuenta pública accesible a cualquiera",
                "Compartir videos grabados en casa/trabajo",
                "Interacciones con desconocidos",
                "Desafíos que podrían comprometer la seguridad",
                "Sincronización con otras redes sociales",
                "Recopilación excesiva de datos personales"
            ],
            "youtube": [
                "Comentarios que revelan información personal",
                "Videos que muestran ubicaciones personales",
                "Historial de visualización público",
                "Listas de reproducción que revelan intereses sensibles",
                "Información de contacto en descripciones de canal"
            ],
            "reddit": [
                "Uso del mismo nombre de usuario en múltiples plataformas",
                "Compartir detalles personales en subreddits",
                "Historial de comentarios que revela patrones o información personal",
                "Participación en comunidades controvertidas",
                "Verificación de correo electrónico sin usar alias"
            ],
            "snapchat": [
                "Compartir ubicación en tiempo real (Snap Map)",
                "Añadir desconocidos como amigos",
                "Compartir contenido sensible incluso en mensajes temporales",
                "Guardar chats o imágenes sensibles",
                "Conectar con contactos del teléfono automáticamente"
            ]
        }
        
        # Recomendaciones de seguridad por plataforma
        self.security_recommendations = {
            "facebook": [
                "Revisa y ajusta tu configuración de privacidad regularmente",
                "Limita quién puede ver tus publicaciones (amigos, amigos de amigos, etc.)",
                "Desactiva la geolocalización en publicaciones",
                "Revisa y elimina aplicaciones de terceros innecesarias",
                "Configura alertas de inicio de sesión",
                "Activa la autenticación de dos factores",
                "Revisa y limpia tu historial de actividad periódicamente",
                "Considera usar listas para compartir contenido específico con grupos concretos",
                "Revisa etiquetas antes de que aparezcan en tu perfil"
            ],
            "twitter": [
                "Considera hacer tu cuenta privada si compartes contenido personal",
                "Desactiva la geolocalización en tweets",
                "Activa la autenticación de dos factores",
                "Revisa las aplicaciones conectadas a tu cuenta",
                "Limita quién puede etiquetarte en fotos",
                "Usa mensajes directos con precaución",
                "Configura filtros de contenido para evitar interacciones no deseadas",
                "Revisa regularmente tus datos y privacidad en la configuración"
            ],
            "instagram": [
                "Configura tu cuenta como privada",
                "Desactiva la opción de compartir ubicación",
                "Revisa solicitudes de seguimiento cuidadosamente",
                "Activa la autenticación de dos factores",
                "Limita las menciones y etiquetas solo a personas que sigues",
                "Revisa las aplicaciones de terceros conectadas",
                "Usa la función 'Mejores amigos' para contenido más personal",
                "Evita compartir historias que revelen tu ubicación en tiempo real"
            ],
            "linkedin": [
                "Ajusta quién puede ver tu perfil y actividad",
                "Limita la información de contacto visible públicamente",
                "Configura quién puede enviarte invitaciones de conexión",
                "Desactiva la visibilidad de tu red para conexiones",
                "Revisa y actualiza la configuración de privacidad regularmente",
                "Activa la verificación en dos pasos",
                "Considera qué información profesional podría ser sensible"
            ],
            "tiktok": [
                "Configura tu cuenta como privada",
                "Desactiva 'Permitir que otros te encuentren'",
                "Limita los comentarios y mensajes directos",
                "Desactiva la sincronización de contactos",
                "Revisa y limita los permisos de la aplicación",
                "Desactiva la función 'Sugerir tu cuenta a otros'",
                "Gestiona cuidadosamente la configuración de 'Datos y privacidad'",
                "Considera usar una cuenta separada para contenido público"
            ],
            "youtube": [
                "Mantén privadas tus listas de reproducción sensibles",
                "Oculta tu historial de visualización",
                "Limita quién puede comentar en tus videos",
                "Revisa la configuración de privacidad del canal",
                "Considera usar un nombre de usuario que no revele tu identidad real",
                "Desactiva la ubicación en los videos subidos",
                "Revisa y limpia tu historial de búsqueda periódicamente"
            ],
            "reddit": [
                "Usa un nombre de usuario que no esté vinculado a tus otras cuentas",
                "Considera tener cuentas separadas para diferentes tipos de actividad",
                "Revisa tu historial de comentarios y publicaciones periódicamente",
                "Desactiva la opción de mostrar tu actividad online",
                "Usa un correo electrónico alternativo para la verificación",
                "Limita la información personal compartida incluso en subreddits de confianza",
                "Activa la autenticación de dos factores"
            ],
            "snapchat": [
                "Configura el modo fantasma en Snap Map",
                "Limita quién puede contactarte",
                "Configura mensajes y snaps para que solo los reciban tus amigos",
                "Activa las notificaciones de captura de pantalla",
                "Revisa y limpia tu lista de amigos regularmente",
                "Activa la autenticación de dos factores",
                "Desactiva la sincronización automática de contactos"
            ]
        }
        
        # Patrones de exposición de información personal
        self.personal_info_patterns = {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "phone": r'\b(\+\d{1,3}[\s.-])?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b',
            "address": r'\b\d{1,5}\s[A-Za-z0-9\s]{1,20}(?:street|st|avenue|ave|road|rd|highway|hwy|square|sq|trail|trl|drive|dr|court|ct|parkway|pkwy|circle|cir|boulevard|blvd)\b',
            "date_of_birth": r'\b(0[1-9]|[12][0-9]|3[01])[/.-](0[1-9]|1[0-2])[/.-](19|20)\d{2}\b',
            "ssn": r'\b\d{3}[-]?\d{2}[-]?\d{4}\b',
            "credit_card": r'\b(?:\d{4}[-\s]?){3}\d{4}\b'
        }
    
    async def analyze_profile_security(self, platform: str, profile_url: str = None, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza la seguridad de un perfil de red social.
        
        Args:
            platform: Plataforma de red social (facebook, twitter, instagram, etc.)
            profile_url: URL del perfil (opcional)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis de seguridad del perfil
        """
        logger.info(f"Analizando seguridad de perfil en {platform}")
        
        # Normalizar plataforma
        platform = platform.lower()
        
        # Verificar si la plataforma es soportada
        if platform not in self.supported_platforms:
            return {
                "success": False,
                "message": f"Plataforma no soportada. Opciones disponibles: {', '.join(self.supported_platforms)}"
            }
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "platform": platform,
            "profile_url": profile_url,
            "security_score": 0,
            "privacy_level": "",
            "risks_detected": [],
            "recommendations": []
        }
        
        try:
            # En una implementación real, aquí se analizaría el perfil real
            # Para esta simulación, generamos un análisis basado en riesgos comunes
            
            # Seleccionar riesgos aleatorios para la plataforma
            platform_risks = self.common_risks.get(platform, [])
            num_risks = random.randint(1, min(5, len(platform_risks)))
            selected_risks = random.sample(platform_risks, num_risks)
            
            # Asignar nivel de severidad a cada riesgo
            risks_with_severity = []
            for risk in selected_risks:
                severity = random.choice(["high", "medium", "low"])
                risks_with_severity.append({
                    "description": risk,
                    "severity": severity
                })
            
            # Ordenar riesgos por severidad
            risks_with_severity.sort(key=lambda x: {"high": 0, "medium": 1, "low": 2}[x["severity"]])
            results["risks_detected"] = risks_with_severity
            
            # Calcular puntuación de seguridad (0-10)
            # Más riesgos y mayor severidad = puntuación más baja
            severity_weights = {"high": 3, "medium": 2, "low": 1}
            risk_impact = sum(severity_weights[risk["severity"]] for risk in risks_with_severity)
            max_impact = sum(severity_weights["high"] for _ in range(len(platform_risks)))
            
            # Normalizar puntuación (invertida: más impacto = menor puntuación)
            if max_impact > 0:
                normalized_score = 10 * (1 - (risk_impact / max_impact))
            else:
                normalized_score = 10
            
            results["security_score"] = round(max(0, min(10, normalized_score)), 1)
            
            # Determinar nivel de privacidad
            if results["security_score"] >= 8:
                results["privacy_level"] = "Alto"
            elif results["security_score"] >= 5:
                results["privacy_level"] = "Medio"
            else:
                results["privacy_level"] = "Bajo"
            
            # Seleccionar recomendaciones basadas en los riesgos detectados
            platform_recommendations = self.security_recommendations.get(platform, [])
            
            # Priorizar recomendaciones para los riesgos detectados
            prioritized_recommendations = []
            for risk in risks_with_severity:
                # Buscar recomendaciones relevantes para este riesgo
                for rec in platform_recommendations:
                    if any(keyword in rec.lower() and keyword in risk["description"].lower() 
                           for keyword in ["privacidad", "ubicación", "geolocalización", "desconocidos", 
                                          "aplicaciones", "etiquetas", "historial", "autenticación"]):
                        prioritized_recommendations.append(rec)
                        platform_recommendations.remove(rec)
                        break
            
            # Añadir recomendaciones generales si no hay suficientes específicas
            if len(prioritized_recommendations) < num_risks + 2:
                additional_needed = min(num_risks + 2 - len(prioritized_recommendations), len(platform_recommendations))
                prioritized_recommendations.extend(random.sample(platform_recommendations, additional_needed))
            
            results["recommendations"] = prioritized_recommendations
            
        except Exception as e:
            logger.error(f"Error al analizar perfil de {platform}: {e}")
            results["success"] = False
            results["message"] = f"Error al analizar perfil: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "social_profile_analysis", f"{platform}:{profile_url or 'N/A'}", 
                      f"Puntuación: {results.get('security_score', 'N/A')}, Nivel: {results.get('privacy_level', 'N/A')}")
            
        return results
    
    async def scan_for_exposed_information(self, content: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Escanea texto en busca de información personal expuesta.
        
        Args:
            content: Texto a analizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis de exposición de información
        """
        logger.info("Escaneando contenido en busca de información personal expuesta")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "content_length": len(content),
            "exposed_information": {},
            "risk_level": "",
            "recommendations": []
        }
        
        try:
            # Buscar patrones de información personal
            exposed_info = {}
            
            for info_type, pattern in self.personal_info_patterns.items():
                matches = re.findall(pattern, content)
                if matches:
                    # Ofuscar la información encontrada para proteger privacidad
                    redacted_matches = []
                    for match in matches:
                        if isinstance(match, tuple):  # Para patrones con grupos
                            match = match[0]
                        
                        if info_type == "email":
                            parts = match.split("@")
                            if len(parts) == 2:
                                redacted = f"{parts[0][0]}{'*' * (len(parts[0])-2)}{parts[0][-1]}@{parts[1]}"
                            else:
                                redacted = f"{'*' * (len(match)-4)}{match[-4:]}"
                        elif info_type in ["phone", "ssn", "credit_card"]:
                            redacted = f"{'*' * (len(match)-4)}{match[-4:]}"
                        else:
                            redacted = f"{'*' * (len(match)-3)}{match[-3:]}"
                        
                        redacted_matches.append(redacted)
                    
                    exposed_info[info_type] = {
                        "count": len(matches),
                        "examples": redacted_matches[:3]  # Limitar a 3 ejemplos
                    }
            
            results["exposed_information"] = exposed_info
            
            # Determinar nivel de riesgo
            total_exposed = sum(info["count"] for info in exposed_info.values())
            
            if total_exposed == 0:
                results["risk_level"] = "Bajo"
            elif total_exposed <= 2:
                results["risk_level"] = "Medio"
            else:
                results["risk_level"] = "Alto"
            
            # Generar recomendaciones
            recommendations = [
                "Evita compartir información personal sensible en redes sociales o foros públicos.",
                "Revisa y elimina publicaciones antiguas que puedan contener información personal."
            ]
            
            if "email" in exposed_info:
                recommendations.append("Considera usar un correo electrónico alternativo para registros públicos.")
            
            if "phone" in exposed_info:
                recommendations.append("Evita publicar tu número de teléfono. Usa mensajería privada para compartirlo cuando sea necesario.")
            
            if "address" in exposed_info:
                recommendations.append("Nunca publiques tu dirección completa. Para entregas, considera usar puntos de recogida o apartados de correos.")
            
            if "date_of_birth" in exposed_info:
                recommendations.append("Limita la visibilidad de tu fecha de nacimiento en perfiles de redes sociales o considera mostrar solo el día y mes.")
            
            if "ssn" in exposed_info or "credit_card" in exposed_info:
                recommendations.append("URGENTE: Elimina inmediatamente cualquier publicación con números de seguridad social o tarjetas de crédito.")
                recommendations.append("Contacta con las plataformas donde se ha publicado esta información para solicitar su eliminación.")
                if "credit_card" in exposed_info:
                    recommendations.append("Contacta con tu banco para informar de la posible exposición de tu tarjeta de crédito.")
            
            results["recommendations"] = recommendations
            
        except Exception as e:
            logger.error(f"Error al escanear contenido: {e}")
            results["success"] = False
            results["message"] = f"Error al escanear contenido: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "exposed_info_scan", "", 
                      f"Nivel de riesgo: {results.get('risk_level', 'N/A')}, Información expuesta: {total_exposed if 'total_exposed' in locals() else 'N/A'}")
            
        return results
    
    async def check_privacy_settings(self, platform: str, settings_data: Dict[str, Any] = None, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Verifica y recomienda configuraciones de privacidad para una plataforma.
        
        Args:
            platform: Plataforma de red social
            settings_data: Datos de configuración actual (opcional)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la verificación (opcional)
            
        Returns:
            dict: Resultados de la verificación de configuración de privacidad
        """
        logger.info(f"Verificando configuración de privacidad para {platform}")
        
        # Normalizar plataforma
        platform = platform.lower()
        
        # Verificar si la plataforma es soportada
        if platform not in self.supported_platforms:
            return {
                "success": False,
                "message": f"Plataforma no soportada. Opciones disponibles: {', '.join(self.supported_platforms)}"
            }
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "platform": platform,
            "privacy_score": 0,
            "settings_review": [],
            "recommended_changes": []
        }
        
        try:
            # En una implementación real, aquí se analizarían las configuraciones reales
            # Para esta simulación, generamos recomendaciones basadas en mejores prácticas
            
            # Configuraciones comunes por plataforma
            platform_settings = {
                "facebook": [
                    {"name": "Visibilidad del perfil", "options": ["Público", "Amigos", "Amigos excepto...", "Solo yo"], "recommended": "Amigos"},
                    {"name": "Quién puede enviar solicitudes de amistad", "options": ["Todos", "Amigos de amigos"], "recommended": "Amigos de amigos"},
                    {"name": "Quién puede ver tus publicaciones futuras", "options": ["Público", "Amigos", "Solo yo"], "recommended": "Amigos"},
                    {"name": "Revisión de etiquetas", "options": ["Activado", "Desactivado"], "recommended": "Activado"},
                    {"name": "Reconocimiento facial", "options": ["Activado", "Desactivado"], "recommended": "Desactivado"},
                    {"name": "Autenticación de dos factores", "options": ["Activado", "Desactivado"], "recommended": "Activado"}
                ],
                "twitter": [
                    {"name": "Privacidad de la cuenta", "options": ["Público", "Protegido"], "recommended": "Protegido"},
                    {"name": "Ubicación en tweets", "options": ["Activado", "Desactivado"], "recommended": "Desactivado"},
                    {"name": "Etiquetado en fotos", "options": ["Permitir a cualquiera", "Solo personas que sigues", "Desactivado"], "recommended": "Solo personas que sigues"},
                    {"name": "Visibilidad de tweets", "options": ["Permitir que todos te encuentren", "Proteger tus tweets"], "recommended": "Proteger tus tweets"},
                    {"name": "Autenticación de dos factores", "options": ["Activado", "Desactivado"], "recommended": "Activado"}
                ],
                "instagram": [
                    {"name": "Privacidad de la cuenta", "options": ["Público", "Privado"], "recommended": "Privado"},
                    {"name": "Actividad de estado", "options": ["Activado", "Desactivado"], "recommended": "Desactivado"},
                    {"name": "Compartir historias", "options": ["Todos", "Seguidores", "Mejores amigos"], "recommended": "Seguidores"},
                    {"name": "Etiquetas", "options": ["Automático", "Manual", "Desactivado"], "recommended": "Manual"},
                    {"name": "Autenticación de dos factores", "options": ["Activado", "Desactivado"], "recommended": "Activado"}
                ]
            }
            
            # Usar configuraciones específicas o predeterminadas para otras plataformas
            current_settings = platform_settings.get(platform, [
                {"name": "Privacidad del perfil", "options": ["Público", "Privado"], "recommended": "Privado"},
                {"name": "Visibilidad de la actividad", "options": ["Todos", "Solo contactos", "Nadie"], "recommended": "Solo contactos"},
                {"name": "Autenticación de dos factores", "options": ["Activado", "Desactivado"], "recommended": "Activado"}
            ])
            
            # Simular configuración actual del usuario
            settings_review = []
            total_score = 0
            max_score = len(current_settings)
            
            for setting in current_settings:
                # Si se proporcionaron datos, usarlos; de lo contrario, generar aleatorios
                if settings_data and setting["name"] in settings_data:
                    current_value = settings_data[setting["name"]]
                else:
                    # 60% de probabilidad de tener configuración no óptima
                    if random.random() < 0.6:
                        non_recommended = [opt for opt in setting["options"] if opt != setting["recommended"]]
                        current_value = random.choice(non_recommended) if non_recommended else setting["recommended"]
                    else:
                        current_value = setting["recommended"]
                
                status = "optimal" if current_value == setting["recommended"] else "suboptimal"
                if status == "optimal":
                    total_score += 1
                
                settings_review.append({
                    "setting": setting["name"],
                    "current_value": current_value,
                    "recommended_value": setting["recommended"],
                    "status": status
                })
            
            # Calcular puntuación de privacidad
            privacy_score = (total_score / max_score) * 10 if max_score > 0 else 0
            results["privacy_score"] = round(privacy_score, 1)
            results["settings_review"] = settings_review
            
            # Generar recomendaciones de cambios
            recommended_changes = []
            for setting in settings_review:
                if setting["status"] == "suboptimal":
                    recommended_changes.append({
                        "setting": setting["setting"],
                        "current": setting["current_value"],
                        "recommended": setting["recommended_value"],
                        "reason": f"Mejorar la privacidad y seguridad de tu cuenta en {platform.capitalize()}"
                    })
            
            results["recommended_changes"] = recommended_changes
            
        except Exception as e:
            logger.error(f"Error al verificar configuración de privacidad: {e}")
            results["success"] = False
            results["message"] = f"Error al verificar configuración de privacidad: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "privacy_settings", platform, 
                      f"Puntuación: {results.get('privacy_score', 'N/A')}, Cambios recomendados: {len(results.get('recommended_changes', []))}")
            
        return results
    
    async def generate_privacy_guide(self, platform: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Genera una guía paso a paso para mejorar la privacidad en una plataforma.
        
        Args:
            platform: Plataforma de red social
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la guía (opcional)
            
        Returns:
            dict: Guía de privacidad para la plataforma
        """
        logger.info(f"Generando guía de privacidad para {platform}")
        
        # Normalizar plataforma
        platform = platform.lower()
        
        # Verificar si la plataforma es soportada
        if platform not in self.supported_platforms:
            return {
                "success": False,
                "message": f"Plataforma no soportada. Opciones disponibles: {', '.join(self.supported_platforms)}"
            }
        
        # Verificar caché
        cache_key = f"privacy_guide:{platform}"
        if db_session:
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Guía en caché encontrada para {platform}")
                return cached_result
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "platform": platform,
            "guide": {
                "title": f"Guía de Privacidad para {platform.capitalize()}",
                "introduction": "",
                "steps": [],
                "additional_tips": []
            }
        }
        
        try:
            # Generar introducción específica para la plataforma
            platform_intros = {
                "facebook": "Facebook recopila una gran cantidad de datos personales. Esta guía te ayudará a proteger tu privacidad ajustando la configuración de tu cuenta.",
                "twitter": "Twitter puede exponer mucha información personal a través de tus tweets y perfil. Sigue estos pasos para mejorar tu privacidad.",
                "instagram": "Instagram comparte por defecto mucha información con otros usuarios. Esta guía te mostrará cómo limitar qué información es visible.",
                "linkedin": "LinkedIn está diseñado para compartir información profesional, pero es importante controlar quién puede ver tus datos. Sigue estos pasos para mejorar tu privacidad.",
                "tiktok": "TikTok recopila muchos datos y tiene configuraciones de privacidad que debes ajustar. Esta guía te ayudará a proteger tu información.",
                "youtube": "YouTube rastrea tu actividad y puede exponer tus intereses. Aprende a mejorar tu privacidad con estos pasos.",
                "reddit": "Reddit puede revelar mucho sobre ti a través de tu historial de publicaciones y comentarios. Esta guía te ayudará a proteger tu anonimato.",
                "snapchat": "Aunque Snapchat se centra en contenido temporal, hay configuraciones importantes de privacidad que debes ajustar. Sigue esta guía para mejorar tu seguridad."
            }
            
            results["guide"]["introduction"] = platform_intros.get(
                platform, 
                f"Las redes sociales pueden exponer mucha información personal. Esta guía te ayudará a mejorar tu privacidad en {platform.capitalize()}."
            )
            
            # Pasos específicos por plataforma
            platform_steps = {
                "facebook": [
                    {
                        "title": "Revisa tu configuración de privacidad",
                        "description": "Ve a Configuración > Privacidad para revisar quién puede ver tus publicaciones, amigos y otra información.",
                        "importance": "high"
                    },
                    {
                        "title": "Limita el público de publicaciones antiguas",
                        "description": "En Configuración > Privacidad, busca 'Limitar el público de las publicaciones antiguas' para cambiar publicaciones públicas a 'Solo amigos'.",
                        "importance": "medium"
                    },
                    {
                        "title": "Configura la revisión de etiquetas",
                        "description": "Ve a Configuración > Perfil y etiquetado para activar la revisión de etiquetas y publicaciones en tu biografía.",
                        "importance": "medium"
                    },
                    {
                        "title": "Desactiva el reconocimiento facial",
                        "description": "Ve a Configuración > Reconocimiento facial y desactiva esta función para evitar ser etiquetado automáticamente.",
                        "importance": "high"
                    },
                    {
                        "title": "Revisa aplicaciones conectadas",
                        "description": "Ve a Configuración > Aplicaciones y sitios web para ver y eliminar aplicaciones de terceros con acceso a tu cuenta.",
                        "importance": "high"
                    },
                    {
                        "title": "Activa alertas de inicio de sesión",
                        "description": "Ve a Configuración > Seguridad e inicio de sesión para activar alertas cuando alguien inicie sesión desde un dispositivo no reconocido.",
                        "importance": "high"
                    },
                    {
                        "title": "Configura la autenticación de dos factores",
                        "description": "En Configuración > Seguridad e inicio de sesión, activa la autenticación de dos factores para mayor seguridad.",
                        "importance": "high"
                    },
                    {
                        "title": "Revisa tu información personal",
                        "description": "Ve a tu perfil y revisa qué información personal es visible. Elimina o limita la visibilidad de información sensible.",
                        "importance": "medium"
                    }
                ],
                "twitter": [
                    {
                        "title": "Protege tus tweets",
                        "description": "Ve a Configuración > Privacidad y seguridad > Audiencia y etiquetado, y marca 'Proteger tus tweets' para que solo tus seguidores puedan verlos.",
                        "importance": "high"
                    },
                    {
                        "title": "Desactiva la ubicación en tweets",
                        "description": "Ve a Configuración > Privacidad y seguridad > Ubicación, y desactiva 'Añadir información de ubicación a tus tweets'.",
                        "importance": "high"
                    },
                    {
                        "title": "Controla el etiquetado en fotos",
                        "description": "Ve a Configuración > Privacidad y seguridad > Audiencia y etiquetado, y configura quién puede etiquetarte en fotos.",
                        "importance": "medium"
                    },
                    {
                        "title": "Limita la visibilidad de tus tweets",
                        "description": "Ve a Configuración > Privacidad y seguridad > Visibilidad y contactos, y ajusta quién puede encontrarte por correo electrónico o teléfono.",
                        "importance": "medium"
                    },
                    {
                        "title": "Revisa aplicaciones conectadas",
                        "description": "Ve a Configuración > Seguridad y acceso a la cuenta > Aplicaciones y sesiones para ver y revocar acceso a aplicaciones de terceros.",
                        "importance": "high"
                    },
                    {
                        "title": "Activa la autenticación de dos factores",
                        "description": "Ve a Configuración > Seguridad y acceso a la cuenta > Seguridad, y activa la autenticación de dos factores.",
                        "importance": "high"
                    }
                ],
                "instagram": [
                    {
                        "title": "Configura tu cuenta como privada",
                        "description": "Ve a Configuración > Privacidad > Privacidad de la cuenta, y activa 'Cuenta privada' para que solo tus seguidores aprobados puedan ver tus publicaciones.",
                        "importance": "high"
                    },
                    {
                        "title": "Controla la actividad de estado",
                        "description": "Ve a Configuración > Privacidad > Actividad de estado, y desactiva esta opción para ocultar cuándo estás activo.",
                        "importance": "medium"
                    },
                    {
                        "title": "Gestiona las etiquetas en fotos",
                        "description": "Ve a Configuración > Privacidad > Menciones/Etiquetas, y configura quién puede etiquetarte y si necesitas aprobar las etiquetas.",
                        "importance": "medium"
                    },
                    {
                        "title": "Controla la visibilidad de historias",
                        "description": "Al publicar una historia, puedes elegir 'Mejores amigos' para compartirla solo con una lista seleccionada de personas.",
                        "importance": "medium"
                    },
                    {
                        "title": "Revisa las conexiones con otras redes sociales",
                        "description": "Ve a Configuración > Cuenta > Cuentas vinculadas, y revisa qué otras plataformas están conectadas a tu cuenta de Instagram.",
                        "importance": "high"
                    },
                    {
                        "title": "Activa la autenticación de dos factores",
                        "description": "Ve a Configuración > Seguridad > Autenticación de dos factores, y activa esta función para mayor seguridad.",
                        "importance": "high"
                    }
                ]
            }
            
            # Usar pasos específicos o genéricos según la plataforma
            steps = platform_steps.get(platform, [
                {
                    "title": "Revisa la configuración de privacidad",
                    "description": f"Accede a la configuración de tu cuenta de {platform.capitalize()} y busca la sección de privacidad para revisar todas las opciones disponibles.",
                    "importance": "high"
                },
                {
                    "title": "Configura tu cuenta como privada",
                    "description": f"Busca la opción para hacer tu cuenta privada o limitar quién puede ver tu contenido en {platform.capitalize()}.",
                    "importance": "high"
                },
                {
                    "title": "Controla quién puede contactarte",
                    "description": f"Ajusta la configuración para limitar quién puede enviarte mensajes o solicitudes en {platform.capitalize()}.",
                    "importance": "medium"
                },
                {
                    "title": "Revisa la información personal visible",
                    "description": "Revisa tu perfil y elimina o limita la visibilidad de información personal sensible.",
                    "importance": "high"
                },
                {
                    "title": "Activa la autenticación de dos factores",
                    "description": "Busca en la configuración de seguridad la opción para activar la autenticación de dos factores.",
                    "importance": "high"
                }
            ])
            
            # Ordenar pasos por importancia
            steps.sort(key=lambda x: {"high": 0, "medium": 1, "low": 2}[x["importance"]])
            results["guide"]["steps"] = steps
            
            # Consejos adicionales
            additional_tips = [
                "Revisa regularmente tu configuración de privacidad, ya que las plataformas suelen actualizarla.",
                "Considera usar un nombre de usuario que no revele tu identidad real.",
                "Piensa dos veces antes de compartir tu ubicación en tiempo real.",
                "Revisa periódicamente las aplicaciones conectadas a tu cuenta y elimina las que ya no uses.",
                "Utiliza contraseñas fuertes y únicas para cada red social."
            ]
            
            # Añadir consejos específicos según la plataforma
            if platform == "facebook":
                additional_tips.append("Utiliza las listas de amigos para compartir contenido específico con grupos concretos.")
                additional_tips.append("Considera eliminar o limitar el acceso a publicaciones antiguas que puedan contener información sensible.")
            elif platform == "twitter":
                additional_tips.append("Considera tener cuentas separadas para diferentes propósitos (personal, profesional, etc.).")
                additional_tips.append("Revisa regularmente tus tweets antiguos y elimina los que puedan contener información sensible.")
            elif platform == "instagram":
                additional_tips.append("Utiliza la función 'Mejores amigos' para compartir contenido más personal solo con personas seleccionadas.")
                additional_tips.append("Evita compartir historias que revelen tu ubicación en tiempo real.")
            
            results["guide"]["additional_tips"] = additional_tips
            
        except Exception as e:
            logger.error(f"Error al generar guía de privacidad: {e}")
            results["success"] = False
            results["message"] = f"Error al generar guía de privacidad: {str(e)}"
        
        # Guardar en caché
        if db_session and results["success"]:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "privacy_guide", platform, 
                      f"Pasos: {len(results['guide']['steps'])}")
            
        return results
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre seguridad en redes sociales.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "social_media_risks": [
                "Sobreexposición de información personal que puede ser utilizada para robo de identidad.",
                "Geolocalización que revela patrones de movimiento y ubicaciones frecuentes.",
                "Ingeniería social basada en información compartida públicamente.",
                "Phishing dirigido utilizando detalles personales para crear mensajes convincentes.",
                "Acoso online facilitado por información personal accesible.",
                "Vigilancia por parte de empleadores potenciales o actuales.",
                "Creación de perfiles de comportamiento basados en publicaciones e interacciones.",
                "Exposición de información de terceros (familiares, amigos) sin su consentimiento.",
                "Permanencia de información incluso después de 'eliminarla' (capturas de pantalla, cachés).",
                "Uso de reconocimiento facial para identificación no autorizada."
            ],
            "privacy_best_practices": [
                "Revisa y ajusta la configuración de privacidad en todas tus redes sociales regularmente.",
                "Limita la información personal en tu perfil público (fecha de nacimiento, dirección, teléfono).",
                "Considera usar un pseudónimo o nombre parcial en lugar de tu nombre completo.",
                "Desactiva la geolocalización en publicaciones y fotos cuando no sea necesaria.",
                "Piensa antes de publicar: ¿estarías cómodo si esta información fuera vista por cualquiera?",
                "Utiliza listas o círculos para compartir contenido específico solo con grupos concretos.",
                "Revisa regularmente las aplicaciones conectadas a tus cuentas de redes sociales.",
                "Activa la autenticación de dos factores en todas tus cuentas.",
                "Evita responder a cuestionarios o juegos que soliciten información personal.",
                "Considera tener cuentas separadas para uso personal y profesional."
            ],
            "recommended_tools": [
                "Privacy Badger - Bloquea rastreadores en sitios web",
                "Jumbo Privacy - Gestiona la privacidad en múltiples redes sociales",
                "Ghostery - Bloquea rastreadores y scripts de seguimiento",
                "DuckDuckGo Privacy Essentials - Protección de privacidad para navegación",
                "Signal - Mensajería privada y segura",
                "ProtonMail - Correo electrónico cifrado",
                "Blur - Protección de identidad y gestión de contraseñas",
                "Disconnect - Bloquea rastreadores de redes sociales",
                "F-Secure TOTAL - Incluye VPN y protección de identidad",
                "DeleteMe - Servicio para eliminar información personal de bases de datos públicas"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    social_security = SocialMediaSecurity()
    import asyncio
    
    async def test():
        # Test profile security analysis
        profile_result = await social_security.analyze_profile_security("facebook")
        print("\n--- Profile Security Analysis ---")
        print(f"Platform: {profile_result['platform']}")
        print(f"Security Score: {profile_result['security_score']}/10 ({profile_result['privacy_level']})")
        print("Risks Detected:")
        for risk in profile_result['risks_detected'][:3]:  # Mostrar solo los primeros 3 riesgos
            print(f"  - {risk['description']} ({risk['severity']})")
        print("Recommendations:")
        for rec in profile_result['recommendations'][:3]:  # Mostrar solo las primeras 3 recomendaciones
            print(f"  - {rec}")
        
        # Test exposed information scan
        content = """
        Hola a todos, mi correo es usuario@ejemplo.com y pueden llamarme al 555-123-4567.
        Vivo en 123 Calle Principal, Madrid. Nací el 01/05/1985.
        """
        exposed_result = await social_security.scan_for_exposed_information(content)
        print("\n--- Exposed Information Scan ---")
        print(f"Risk Level: {exposed_result['risk_level']}")
        print("Exposed Information:")
        for info_type, details in exposed_result['exposed_information'].items():
            print(f"  - {info_type}: {details['count']} occurrences")
            if details['examples']:
                print(f"    Examples: {', '.join(details['examples'])}")
        
        # Test privacy settings check
        settings_result = await social_security.check_privacy_settings("instagram")
        print("\n--- Privacy Settings Check ---")
        print(f"Platform: {settings_result['platform']}")
        print(f"Privacy Score: {settings_result['privacy_score']}/10")
        print("Settings Review:")
        for setting in settings_result['settings_review'][:3]:  # Mostrar solo las primeras 3 configuraciones
            print(f"  - {setting['setting']}: {setting['current_value']} ({setting['status']})")
        
        # Test privacy guide generation
        guide_result = await social_security.generate_privacy_guide("twitter")
        print("\n--- Privacy Guide ---")
        print(f"Title: {guide_result['guide']['title']}")
        print(f"Introduction: {guide_result['guide']['introduction'][:100]}...")
        print("Steps:")
        for i, step in enumerate(guide_result['guide']['steps'][:3], 1):  # Mostrar solo los primeros 3 pasos
            print(f"  {i}. {step['title']} ({step['importance']})")
        
        print("\n--- Educational Resources ---")
        edu_resources = social_security.get_educational_resources()
        print("Social Media Risks:")
        for resource in edu_resources['social_media_risks'][:3]:
            print(f"  - {resource}")
            
    asyncio.run(test())
