"""
Módulo de Asistente de Seguridad Personal.

Este módulo proporciona funcionalidades de asistencia personalizada
para la seguridad del usuario, incluyendo evaluación de riesgos,
recomendaciones personalizadas y monitoreo de seguridad.
"""

import logging
import os
import json
import re
import random
import hashlib
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL

# Configuración de logging
logger = logging.getLogger(__name__)

class SecurityAssistant:
    """Clase para el asistente de seguridad personal."""
    
    def __init__(self):
        """Inicializa la clase del asistente de seguridad."""
        self.headers = {
            "User-Agent": "GleySxycBot/2.0.0 (Educational Security Bot)"
        }
        
        # Categorías de riesgo para evaluación
        self.risk_categories = [
            "passwords", "authentication", "updates", "backups", 
            "encryption", "network", "privacy", "social_engineering"
        ]
        
        # Preguntas para evaluación de riesgo por categoría
        self.risk_assessment_questions = {
            "passwords": [
                {"id": "pwd_1", "question": "¿Utilizas contraseñas únicas para cada servicio?", "weight": 3},
                {"id": "pwd_2", "question": "¿Tus contraseñas tienen al menos 12 caracteres?", "weight": 2},
                {"id": "pwd_3", "question": "¿Utilizas un gestor de contraseñas?", "weight": 3},
                {"id": "pwd_4", "question": "¿Cambias tus contraseñas periódicamente?", "weight": 1},
                {"id": "pwd_5", "question": "¿Tus contraseñas incluyen letras, números y símbolos?", "weight": 2}
            ],
            "authentication": [
                {"id": "auth_1", "question": "¿Utilizas autenticación de dos factores (2FA) cuando está disponible?", "weight": 3},
                {"id": "auth_2", "question": "¿Evitas usar la misma dirección de correo para recuperación de cuentas?", "weight": 2},
                {"id": "auth_3", "question": "¿Utilizas aplicaciones de autenticación en lugar de SMS para 2FA?", "weight": 2},
                {"id": "auth_4", "question": "¿Has configurado métodos de recuperación para tus cuentas principales?", "weight": 2}
            ],
            "updates": [
                {"id": "upd_1", "question": "¿Mantienes tu sistema operativo actualizado?", "weight": 3},
                {"id": "upd_2", "question": "¿Actualizas regularmente tus aplicaciones?", "weight": 2},
                {"id": "upd_3", "question": "¿Tienes activadas las actualizaciones automáticas?", "weight": 2},
                {"id": "upd_4", "question": "¿Revisas las notas de las actualizaciones de seguridad?", "weight": 1}
            ],
            "backups": [
                {"id": "bck_1", "question": "¿Realizas copias de seguridad regularmente?", "weight": 3},
                {"id": "bck_2", "question": "¿Tienes copias de seguridad en ubicaciones físicas diferentes?", "weight": 2},
                {"id": "bck_3", "question": "¿Has probado la restauración de tus copias de seguridad?", "weight": 2},
                {"id": "bck_4", "question": "¿Cifras tus copias de seguridad?", "weight": 2}
            ],
            "encryption": [
                {"id": "enc_1", "question": "¿Tienes cifrado el disco duro de tu dispositivo principal?", "weight": 3},
                {"id": "enc_2", "question": "¿Utilizas conexiones cifradas (HTTPS) al navegar?", "weight": 2},
                {"id": "enc_3", "question": "¿Utilizas aplicaciones de mensajería con cifrado de extremo a extremo?", "weight": 2},
                {"id": "enc_4", "question": "¿Cifras archivos sensibles antes de compartirlos?", "weight": 2}
            ],
            "network": [
                {"id": "net_1", "question": "¿Has cambiado la contraseña predeterminada de tu router?", "weight": 3},
                {"id": "net_2", "question": "¿Utilizas una VPN cuando te conectas a redes públicas?", "weight": 3},
                {"id": "net_3", "question": "¿Has desactivado WPS en tu router?", "weight": 2},
                {"id": "net_4", "question": "¿Tienes un firewall activo en tus dispositivos?", "weight": 2},
                {"id": "net_5", "question": "¿Revisas qué dispositivos están conectados a tu red?", "weight": 1}
            ],
            "privacy": [
                {"id": "prv_1", "question": "¿Revisas los permisos de las aplicaciones que instalas?", "weight": 2},
                {"id": "prv_2", "question": "¿Utilizas navegación privada o bloqueadores de rastreadores?", "weight": 2},
                {"id": "prv_3", "question": "¿Limitas la información personal que compartes en redes sociales?", "weight": 2},
                {"id": "prv_4", "question": "¿Has revisado la configuración de privacidad de tus cuentas?", "weight": 2},
                {"id": "prv_5", "question": "¿Utilizas motores de búsqueda que respetan la privacidad?", "weight": 1}
            ],
            "social_engineering": [
                {"id": "soc_1", "question": "¿Verificas los remitentes de correos antes de abrir adjuntos?", "weight": 3},
                {"id": "soc_2", "question": "¿Evitas hacer clic en enlaces sospechosos?", "weight": 3},
                {"id": "soc_3", "question": "¿Verificas las URL antes de introducir credenciales?", "weight": 3},
                {"id": "soc_4", "question": "¿Desconfías de ofertas demasiado buenas o urgentes?", "weight": 2},
                {"id": "soc_5", "question": "¿Has recibido formación sobre phishing y estafas?", "weight": 2}
            ]
        }
        
        # Recomendaciones por categoría y nivel de riesgo
        self.security_recommendations = {
            "passwords": {
                "high": [
                    "Instala un gestor de contraseñas como Bitwarden, KeePass o 1Password.",
                    "Cambia inmediatamente las contraseñas de tus cuentas más importantes.",
                    "Utiliza contraseñas únicas de al menos 16 caracteres para cada servicio.",
                    "Activa las notificaciones de inicio de sesión en tus cuentas principales."
                ],
                "medium": [
                    "Revisa y actualiza las contraseñas de tus cuentas más importantes.",
                    "Asegúrate de que todas tus contraseñas tengan al menos 12 caracteres y combinen letras, números y símbolos.",
                    "Considera utilizar un gestor de contraseñas si aún no lo haces."
                ],
                "low": [
                    "Continúa con tus buenas prácticas de gestión de contraseñas.",
                    "Considera aumentar la longitud de tus contraseñas a 16+ caracteres.",
                    "Revisa periódicamente si tus cuentas han sido comprometidas en haveibeenpwned.com."
                ]
            },
            "authentication": {
                "high": [
                    "Activa inmediatamente la autenticación de dos factores (2FA) en todas tus cuentas importantes.",
                    "Utiliza aplicaciones de autenticación como Google Authenticator o Authy en lugar de SMS.",
                    "Configura métodos de recuperación alternativos para tus cuentas."
                ],
                "medium": [
                    "Revisa qué cuentas importantes aún no tienen 2FA y actívalo.",
                    "Si utilizas SMS para 2FA, considera cambiar a una aplicación de autenticación.",
                    "Verifica y actualiza tus métodos de recuperación de cuenta."
                ],
                "low": [
                    "Continúa utilizando 2FA en todas tus cuentas.",
                    "Considera utilizar llaves de seguridad físicas (como YubiKey) para una capa adicional de protección.",
                    "Revisa periódicamente los inicios de sesión en tus cuentas principales."
                ]
            },
            "updates": {
                "high": [
                    "Actualiza inmediatamente tu sistema operativo y aplicaciones a la última versión.",
                    "Configura actualizaciones automáticas para el sistema operativo y aplicaciones.",
                    "Considera reemplazar software obsoleto que ya no recibe actualizaciones de seguridad."
                ],
                "medium": [
                    "Verifica qué aplicaciones necesitan actualizaciones y actualízalas.",
                    "Configura recordatorios periódicos para revisar actualizaciones.",
                    "Asegúrate de que tu navegador se actualice automáticamente."
                ],
                "low": [
                    "Continúa con tu rutina de actualizaciones.",
                    "Considera suscribirte a alertas de seguridad para software crítico que utilizas.",
                    "Revisa periódicamente aplicaciones antiguas que podrían representar un riesgo."
                ]
            },
            "backups": {
                "high": [
                    "Implementa inmediatamente una estrategia de copias de seguridad (3-2-1: 3 copias, 2 tipos de almacenamiento, 1 fuera del sitio).",
                    "Realiza una copia de seguridad completa de tus datos importantes ahora mismo.",
                    "Configura copias de seguridad automáticas para tus archivos más importantes."
                ],
                "medium": [
                    "Revisa y mejora tu estrategia actual de copias de seguridad.",
                    "Asegúrate de tener al menos una copia fuera del sitio o en la nube.",
                    "Prueba la restauración de tus copias de seguridad para verificar que funcionan."
                ],
                "low": [
                    "Continúa con tu rutina de copias de seguridad.",
                    "Considera cifrar tus copias de seguridad si contienen información sensible.",
                    "Documenta tu proceso de copias de seguridad y restauración."
                ]
            },
            "encryption": {
                "high": [
                    "Activa el cifrado de disco completo en todos tus dispositivos (BitLocker, FileVault, LUKS).",
                    "Instala una extensión como HTTPS Everywhere para forzar conexiones seguras.",
                    "Cambia a aplicaciones de mensajería con cifrado de extremo a extremo como Signal."
                ],
                "medium": [
                    "Verifica qué dispositivos no tienen cifrado de disco y actívalo.",
                    "Asegúrate de utilizar siempre HTTPS al navegar por sitios web.",
                    "Cifra archivos sensibles antes de almacenarlos en la nube."
                ],
                "low": [
                    "Continúa utilizando cifrado en tus dispositivos y comunicaciones.",
                    "Considera utilizar herramientas como VeraCrypt para crear volúmenes cifrados adicionales.",
                    "Revisa periódicamente las nuevas opciones de cifrado disponibles."
                ]
            },
            "network": {
                "high": [
                    "Cambia inmediatamente la contraseña de tu router y desactiva WPS.",
                    "Actualiza el firmware de tu router a la última versión disponible.",
                    "Instala y configura una VPN para usar en redes públicas.",
                    "Verifica qué dispositivos están conectados a tu red y desconecta los no reconocidos."
                ],
                "medium": [
                    "Revisa la configuración de seguridad de tu router.",
                    "Considera utilizar una VPN cuando te conectes a redes públicas.",
                    "Configura correctamente el firewall en tus dispositivos."
                ],
                "low": [
                    "Continúa con tus buenas prácticas de seguridad de red.",
                    "Considera implementar una red separada para dispositivos IoT.",
                    "Revisa periódicamente los dispositivos conectados a tu red."
                ]
            },
            "privacy": {
                "high": [
                    "Revisa y ajusta la configuración de privacidad en todas tus redes sociales.",
                    "Instala extensiones de privacidad como Privacy Badger y uBlock Origin.",
                    "Cambia a un navegador centrado en la privacidad como Firefox o Brave.",
                    "Utiliza motores de búsqueda que respeten la privacidad como DuckDuckGo."
                ],
                "medium": [
                    "Revisa los permisos de tus aplicaciones y revoca los innecesarios.",
                    "Configura opciones de privacidad en tu navegador actual.",
                    "Limita la información personal que compartes en línea."
                ],
                "low": [
                    "Continúa con tus buenas prácticas de privacidad.",
                    "Considera realizar auditorías periódicas de privacidad de tus cuentas.",
                    "Mantente informado sobre nuevas herramientas y técnicas de privacidad."
                ]
            },
            "social_engineering": {
                "high": [
                    "Aprende a identificar correos de phishing y estafas comunes.",
                    "Nunca proporciones información sensible a menos que hayas verificado al solicitante.",
                    "Verifica siempre las URL antes de introducir credenciales.",
                    "Desconfía de ofertas demasiado buenas para ser verdad o mensajes que generen urgencia."
                ],
                "medium": [
                    "Mejora tus habilidades para detectar intentos de phishing.",
                    "Verifica siempre la identidad de quien te contacta antes de compartir información.",
                    "Mantente informado sobre las últimas técnicas de ingeniería social."
                ],
                "low": [
                    "Continúa con tu cautela frente a posibles estafas.",
                    "Considera compartir tu conocimiento con amigos y familiares.",
                    "Mantente actualizado sobre nuevas técnicas de ingeniería social."
                ]
            }
        }
        
        # Servicios de monitoreo de brechas de seguridad
        self.breach_monitoring_services = [
            {"name": "Have I Been Pwned", "url": "https://haveibeenpwned.com/", "api_available": True},
            {"name": "Firefox Monitor", "url": "https://monitor.firefox.com/", "api_available": False},
            {"name": "Google Password Checkup", "url": "https://passwords.google.com/checkup", "api_available": False}
        ]
    
    async def perform_risk_assessment(self, answers: Dict[str, bool], db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Realiza una evaluación de riesgo de seguridad basada en las respuestas del usuario.
        
        Args:
            answers: Diccionario con IDs de preguntas como claves y respuestas (True/False) como valores
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la evaluación (opcional)
            
        Returns:
            dict: Resultados de la evaluación de riesgo
        """
        logger.info("Realizando evaluación de riesgo de seguridad")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "overall_score": 0,
            "overall_risk_level": "",
            "categories": {},
            "recommendations": []
        }
        
        try:
            # Validar respuestas
            if not answers:
                results["success"] = False
                results["message"] = "No se proporcionaron respuestas para la evaluación"
                return results
            
            # Calcular puntuación por categoría
            total_weight = 0
            total_score = 0
            
            for category, questions in self.risk_assessment_questions.items():
                category_weight = sum(q["weight"] for q in questions)
                category_max_score = category_weight * 10  # Máxima puntuación posible
                category_score = 0
                
                for question in questions:
                    question_id = question["id"]
                    if question_id in answers:
                        # Si la respuesta es positiva (True), suma puntos
                        if answers[question_id]:
                            category_score += question["weight"] * 10
                
                # Normalizar puntuación de categoría a escala 0-10
                normalized_score = category_score / category_max_score * 10 if category_max_score > 0 else 0
                
                # Determinar nivel de riesgo para la categoría
                risk_level = self._get_risk_level(normalized_score)
                
                # Añadir recomendaciones específicas según nivel de riesgo
                category_recommendations = self.security_recommendations[category][risk_level]
                
                results["categories"][category] = {
                    "score": round(normalized_score, 1),
                    "risk_level": risk_level,
                    "recommendations": category_recommendations
                }
                
                # Acumular para puntuación general
                total_weight += category_weight
                total_score += category_score
            
            # Calcular puntuación general normalizada
            overall_normalized_score = total_score / (total_weight * 10) * 10 if total_weight > 0 else 0
            results["overall_score"] = round(overall_normalized_score, 1)
            results["overall_risk_level"] = self._get_risk_level(overall_normalized_score)
            
            # Recopilar todas las recomendaciones de categorías de alto riesgo primero
            high_risk_recommendations = []
            medium_risk_recommendations = []
            low_risk_recommendations = []
            
            for category, data in results["categories"].items():
                if data["risk_level"] == "high":
                    high_risk_recommendations.extend(data["recommendations"])
                elif data["risk_level"] == "medium":
                    medium_risk_recommendations.extend(data["recommendations"])
                else:
                    low_risk_recommendations.extend(data["recommendations"])
            
            # Combinar recomendaciones priorizando las de mayor riesgo
            results["recommendations"] = high_risk_recommendations + medium_risk_recommendations[:3] + low_risk_recommendations[:2]
            
        except Exception as e:
            logger.error(f"Error al realizar evaluación de riesgo: {e}")
            results["success"] = False
            results["message"] = f"Error al realizar evaluación de riesgo: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "risk_assessment", "", 
                      f"Puntuación: {results.get('overall_score', 'N/A')}, Nivel: {results.get('overall_risk_level', 'N/A')}")
            
        return results
    
    async def check_email_breaches(self, email: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Verifica si un correo electrónico ha sido comprometido en brechas de seguridad conocidas.
        Utiliza la API de Have I Been Pwned si está disponible, o proporciona enlaces a servicios.
        
        Args:
            email: Dirección de correo electrónico a verificar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la verificación (opcional)
            
        Returns:
            dict: Resultados de la verificación de brechas
        """
        logger.info(f"Verificando brechas para correo: {email}")
        
        # Verificar caché
        cache_key = f"email_breach:{email}"
        if db_session:
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultado en caché encontrado para {email}")
                return cached_result
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "email": email,
            "found_in_breaches": False,
            "breach_count": 0,
            "breaches": [],
            "manual_check_links": []
        }
        
        try:
            # Verificar si tenemos API key para HIBP
            hibp_api_key = get_api_key("hibp")
            
            if hibp_api_key:
                # Usar la API de Have I Been Pwned
                hibp_url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
                headers = {
                    "hibp-api-key": hibp_api_key,
                    "User-Agent": "GleySxycBot/2.0.0"
                }
                
                try:
                    response = requests.get(hibp_url, headers=headers, timeout=10)
                    
                    if response.status_code == 200:
                        # Se encontraron brechas
                        breaches = response.json()
                        results["found_in_breaches"] = True
                        results["breach_count"] = len(breaches)
                        
                        # Procesar información de brechas
                        for breach in breaches:
                            results["breaches"].append({
                                "name": breach.get("Name", "Unknown"),
                                "domain": breach.get("Domain", ""),
                                "breach_date": breach.get("BreachDate", ""),
                                "pwn_count": breach.get("PwnCount", 0),
                                "data_classes": breach.get("DataClasses", []),
                                "description": breach.get("Description", "")
                            })
                        
                    elif response.status_code == 404:
                        # No se encontraron brechas
                        results["found_in_breaches"] = False
                        results["breach_count"] = 0
                        
                    else:
                        # Error en la API
                        logger.warning(f"Error en API HIBP: {response.status_code}")
                        results["api_error"] = f"Error en la API: {response.status_code}"
                        
                except requests.exceptions.RequestException as e:
                    logger.error(f"Error al conectar con HIBP: {e}")
                    results["api_error"] = f"Error de conexión: {str(e)}"
            
            # Siempre proporcionar enlaces para verificación manual
            for service in self.breach_monitoring_services:
                results["manual_check_links"].append({
                    "name": service["name"],
                    "url": service["url"]
                })
            
        except Exception as e:
            logger.error(f"Error al verificar brechas: {e}")
            results["success"] = False
            results["message"] = f"Error al verificar brechas: {str(e)}"
        
        # Guardar en caché
        if db_session and results["success"]:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "email_breach", email, 
                      f"Brechas encontradas: {results.get('breach_count', 0)}")
            
        return results
    
    async def check_password_security(self, password: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Verifica la seguridad de una contraseña y si ha sido comprometida.
        Utiliza el método k-anonimity de HIBP para verificar de forma segura.
        
        Args:
            password: Contraseña a verificar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la verificación (opcional)
            
        Returns:
            dict: Resultados de la verificación de seguridad de la contraseña
        """
        logger.info("Verificando seguridad de contraseña")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "password_strength": {
                "score": 0,
                "level": "",
                "estimated_crack_time": "",
                "feedback": []
            },
            "compromised": {
                "is_compromised": False,
                "times_seen": 0
            }
        }
        
        try:
            # Evaluar fortaleza de la contraseña
            length = len(password)
            has_lowercase = any(c.islower() for c in password)
            has_uppercase = any(c.isupper() for c in password)
            has_digit = any(c.isdigit() for c in password)
            has_special = any(not c.isalnum() for c in password)
            
            # Calcular puntuación básica
            score = 0
            if length >= 12: score += 3
            elif length >= 8: score += 2
            else: score += 1
            
            if has_lowercase: score += 1
            if has_uppercase: score += 1
            if has_digit: score += 1
            if has_special: score += 1
            
            # Penalizar patrones comunes
            common_patterns = [
                r"12345", r"qwerty", r"password", r"admin", r"welcome",
                r"abc123", r"letmein", r"monkey", r"111111", r"sunshine"
            ]
            
            for pattern in common_patterns:
                if re.search(pattern, password.lower()):
                    score -= 2
                    results["password_strength"]["feedback"].append(f"Contiene patrón común: {pattern}")
            
            # Penalizar repeticiones
            if re.search(r"(.)\1{2,}", password):  # Tres o más caracteres iguales seguidos
                score -= 1
                results["password_strength"]["feedback"].append("Contiene caracteres repetidos")
            
            # Normalizar puntuación
            score = max(1, min(10, score))
            results["password_strength"]["score"] = score
            
            # Determinar nivel
            if score >= 8:
                level = "Fuerte"
                crack_time = "Años a décadas"
            elif score >= 6:
                level = "Moderada"
                crack_time = "Semanas a meses"
            elif score >= 4:
                level = "Débil"
                crack_time = "Horas a días"
            else:
                level = "Muy débil"
                crack_time = "Segundos a minutos"
            
            results["password_strength"]["level"] = level
            results["password_strength"]["estimated_crack_time"] = crack_time
            
            # Añadir recomendaciones según puntuación
            if score < 8:
                if length < 12:
                    results["password_strength"]["feedback"].append("Aumenta la longitud a al menos 12 caracteres")
                if not has_lowercase:
                    results["password_strength"]["feedback"].append("Incluye letras minúsculas")
                if not has_uppercase:
                    results["password_strength"]["feedback"].append("Incluye letras mayúsculas")
                if not has_digit:
                    results["password_strength"]["feedback"].append("Incluye números")
                if not has_special:
                    results["password_strength"]["feedback"].append("Incluye símbolos especiales")
            
            # Verificar si la contraseña ha sido comprometida (método k-anonymity de HIBP)
            # Solo enviamos los primeros 5 caracteres del hash para preservar privacidad
            password_hash = hashlib.sha1(password.encode()).hexdigest().upper()
            prefix = password_hash[:5]
            suffix = password_hash[5:]
            
            try:
                hibp_url = f"https://api.pwnedpasswords.com/range/{prefix}"
                response = requests.get(hibp_url, timeout=10)
                
                if response.status_code == 200:
                    hashes = response.text.splitlines()
                    for h in hashes:
                        parts = h.split(":")
                        if len(parts) == 2 and parts[0] == suffix:
                            results["compromised"]["is_compromised"] = True
                            results["compromised"]["times_seen"] = int(parts[1])
                            break
                else:
                    logger.warning(f"Error al verificar contraseña comprometida: {response.status_code}")
                    
            except requests.exceptions.RequestException as e:
                logger.error(f"Error al conectar con API de contraseñas comprometidas: {e}")
                results["api_error"] = f"Error de conexión: {str(e)}"
            
        except Exception as e:
            logger.error(f"Error al verificar seguridad de contraseña: {e}")
            results["success"] = False
            results["message"] = f"Error al verificar seguridad de contraseña: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "password_check", "", 
                      f"Fortaleza: {results['password_strength']['level']}, Comprometida: {results['compromised']['is_compromised']}")
            
        return results
    
    async def generate_security_plan(self, risk_assessment_results: Dict[str, Any], db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Genera un plan de seguridad personalizado basado en los resultados de la evaluación de riesgo.
        
        Args:
            risk_assessment_results: Resultados de la evaluación de riesgo
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el plan (opcional)
            
        Returns:
            dict: Plan de seguridad personalizado
        """
        logger.info("Generando plan de seguridad personalizado")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "plan": {
                "title": "Plan de Seguridad Personalizado",
                "summary": "",
                "risk_level": "",
                "immediate_actions": [],
                "short_term_actions": [],
                "long_term_actions": [],
                "resources": []
            }
        }
        
        try:
            # Verificar que tenemos resultados de evaluación válidos
            if not risk_assessment_results or not risk_assessment_results.get("success", False):
                results["success"] = False
                results["message"] = "Se requieren resultados válidos de evaluación de riesgo"
                return results
            
            # Obtener nivel de riesgo general
            overall_risk = risk_assessment_results.get("overall_risk_level", "medium")
            results["plan"]["risk_level"] = overall_risk
            
            # Generar resumen según nivel de riesgo
            if overall_risk == "high":
                results["plan"]["summary"] = "Tu nivel de riesgo es alto. Es necesario tomar medidas inmediatas para mejorar tu seguridad en varias áreas críticas."
            elif overall_risk == "medium":
                results["plan"]["summary"] = "Tu nivel de riesgo es medio. Hay áreas específicas que requieren atención para mejorar tu postura de seguridad."
            else:
                results["plan"]["summary"] = "Tu nivel de riesgo es bajo. Estás siguiendo buenas prácticas de seguridad, pero siempre hay espacio para mejoras."
            
            # Recopilar acciones por categoría y prioridad
            immediate_actions = []
            short_term_actions = []
            long_term_actions = []
            
            # Procesar categorías por nivel de riesgo
            categories = risk_assessment_results.get("categories", {})
            
            # Primero procesar categorías de alto riesgo
            for category, data in categories.items():
                if data["risk_level"] == "high":
                    recommendations = data.get("recommendations", [])
                    if recommendations:
                        immediate_actions.extend(recommendations[:2])  # Las 2 primeras son inmediatas
                        if len(recommendations) > 2:
                            short_term_actions.extend(recommendations[2:])  # El resto son a corto plazo
            
            # Luego procesar categorías de riesgo medio
            for category, data in categories.items():
                if data["risk_level"] == "medium":
                    recommendations = data.get("recommendations", [])
                    if recommendations:
                        short_term_actions.extend(recommendations[:2])  # Las 2 primeras son a corto plazo
                        if len(recommendations) > 2:
                            long_term_actions.extend(recommendations[2:])  # El resto son a largo plazo
            
            # Finalmente procesar categorías de bajo riesgo
            for category, data in categories.items():
                if data["risk_level"] == "low":
                    recommendations = data.get("recommendations", [])
                    if recommendations:
                        long_term_actions.extend(recommendations[:2])  # Máximo 2 recomendaciones
            
            # Eliminar duplicados y limitar cantidad
            results["plan"]["immediate_actions"] = list(dict.fromkeys(immediate_actions))[:5]
            results["plan"]["short_term_actions"] = list(dict.fromkeys(short_term_actions))[:5]
            results["plan"]["long_term_actions"] = list(dict.fromkeys(long_term_actions))[:5]
            
            # Añadir recursos relevantes según las categorías de mayor riesgo
            high_risk_categories = [category for category, data in categories.items() if data["risk_level"] == "high"]
            
            resources = []
            if "passwords" in high_risk_categories:
                resources.append({"name": "Have I Been Pwned", "url": "https://haveibeenpwned.com/", "description": "Verifica si tus cuentas han sido comprometidas"})
                resources.append({"name": "Bitwarden", "url": "https://bitwarden.com/", "description": "Gestor de contraseñas gratuito y de código abierto"})
            
            if "authentication" in high_risk_categories:
                resources.append({"name": "Authy", "url": "https://authy.com/", "description": "Aplicación de autenticación de dos factores"})
                resources.append({"name": "Guía de 2FA", "url": "https://www.securemessagingapps.com/how-to-set-up-2fa/", "description": "Cómo configurar 2FA en servicios populares"})
            
            if "network" in high_risk_categories:
                resources.append({"name": "ProtonVPN", "url": "https://protonvpn.com/", "description": "VPN con plan gratuito"})
                resources.append({"name": "Router Security", "url": "https://routersecurity.org/", "description": "Guía de seguridad para routers"})
            
            if "privacy" in high_risk_categories:
                resources.append({"name": "Privacy Tools", "url": "https://www.privacytools.io/", "description": "Herramientas y servicios que respetan la privacidad"})
                resources.append({"name": "uBlock Origin", "url": "https://github.com/gorhill/uBlock", "description": "Bloqueador de anuncios y rastreadores"})
            
            if "social_engineering" in high_risk_categories:
                resources.append({"name": "Phishing Quiz", "url": "https://phishingquiz.withgoogle.com/", "description": "Test de Google para identificar phishing"})
                resources.append({"name": "FTC Scam Alerts", "url": "https://www.consumer.ftc.gov/features/scam-alerts", "description": "Alertas de estafas actuales"})
            
            # Añadir recursos generales si no hay suficientes específicos
            general_resources = [
                {"name": "CISA Security Tips", "url": "https://www.cisa.gov/tips", "description": "Consejos de seguridad de la Agencia de Ciberseguridad de EE.UU."},
                {"name": "EFF Surveillance Self-Defense", "url": "https://ssd.eff.org/", "description": "Guías para proteger tu privacidad digital"},
                {"name": "OWASP Personal Security", "url": "https://owasp.org/www-project-personal-security-checklist/", "description": "Lista de verificación de seguridad personal"}
            ]
            
            # Combinar y limitar recursos
            all_resources = resources + general_resources
            results["plan"]["resources"] = all_resources[:8]  # Limitar a 8 recursos
            
        except Exception as e:
            logger.error(f"Error al generar plan de seguridad: {e}")
            results["success"] = False
            results["message"] = f"Error al generar plan de seguridad: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "security_plan", "", 
                      f"Nivel de riesgo: {results['plan']['risk_level']}")
            
        return results
    
    def _get_risk_level(self, score: float) -> str:
        """Determina el nivel de riesgo basado en la puntuación."""
        if score < 4:
            return "high"
        elif score < 7:
            return "medium"
        else:
            return "low"
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre seguridad personal.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "security_basics": [
                "La seguridad personal digital es un proceso continuo, no un estado final.",
                "El eslabón más débil en la seguridad suele ser el factor humano, no la tecnología.",
                "La autenticación de dos factores (2FA) es una de las medidas más efectivas para proteger tus cuentas.",
                "Las contraseñas largas y únicas son fundamentales; considera usar un gestor de contraseñas.",
                "Mantener el software actualizado es crucial para protegerse contra vulnerabilidades conocidas.",
                "Las copias de seguridad regulares son tu mejor defensa contra el ransomware y la pérdida de datos.",
                "El cifrado protege tus datos en caso de pérdida o robo de dispositivos.",
                "La ingeniería social es una de las técnicas de ataque más efectivas; aprende a reconocerla.",
                "La privacidad y la seguridad están interrelacionadas; proteger una ayuda a proteger la otra.",
                "Un plan de seguridad por capas proporciona múltiples líneas de defensa."
            ],
            "daily_habits": [
                "Verifica el remitente y los enlaces antes de hacer clic en correos electrónicos.",
                "Utiliza redes privadas virtuales (VPN) cuando te conectes a redes Wi-Fi públicas.",
                "Bloquea tus dispositivos cuando no los estés utilizando.",
                "Revisa regularmente la actividad de inicio de sesión en tus cuentas importantes.",
                "Actualiza tu software cuando se publiquen parches de seguridad.",
                "Utiliza diferentes contraseñas para diferentes servicios.",
                "Realiza copias de seguridad de tus datos importantes regularmente.",
                "Revisa los permisos de las aplicaciones que instalas.",
                "Utiliza navegación privada o borra tu historial y cookies periódicamente.",
                "Desconfía de ofertas demasiado buenas para ser verdad o mensajes que generen urgencia."
            ],
            "recommended_tools": [
                "Gestores de contraseñas: Bitwarden, KeePass, 1Password",
                "Autenticación de dos factores: Authy, Google Authenticator, YubiKey",
                "VPN: ProtonVPN, Mullvad, Wireguard",
                "Navegadores seguros: Firefox con configuración de privacidad, Brave, Tor Browser",
                "Extensiones de navegador: uBlock Origin, Privacy Badger, HTTPS Everywhere",
                "Cifrado de disco: BitLocker (Windows), FileVault (Mac), LUKS (Linux)",
                "Cifrado de archivos: VeraCrypt, Cryptomator",
                "Mensajería segura: Signal, Wire, Element (Matrix)",
                "Correo electrónico privado: ProtonMail, Tutanota",
                "Motores de búsqueda: DuckDuckGo, Startpage, Searx"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    assistant = SecurityAssistant()
    import asyncio
    
    async def test():
        # Test risk assessment
        sample_answers = {
            "pwd_1": True,   # Usa contraseñas únicas
            "pwd_2": False,  # No usa contraseñas largas
            "pwd_3": False,  # No usa gestor de contraseñas
            "auth_1": True,  # Usa 2FA
            "upd_1": True,   # Mantiene SO actualizado
            "bck_1": False,  # No hace copias de seguridad
            "net_1": True,   # Ha cambiado contraseña del router
            "prv_1": True,   # Revisa permisos de apps
            "soc_1": True    # Verifica remitentes de correos
        }
        
        assessment_result = await assistant.perform_risk_assessment(sample_answers)
        print("\n--- Risk Assessment ---")
        print(f"Overall Score: {assessment_result['overall_score']}")
        print(f"Risk Level: {assessment_result['overall_risk_level']}")
        print("Categories:")
        for category, data in assessment_result["categories"].items():
            print(f"  - {category}: {data['score']} ({data['risk_level']})")
        print("Top Recommendations:")
        for rec in assessment_result["recommendations"][:3]:
            print(f"  - {rec}")
        
        # Test password security check
        password_result = await assistant.check_password_security("password123")
        print("\n--- Password Security Check ---")
        print(f"Strength: {password_result['password_strength']['level']} ({password_result['password_strength']['score']}/10)")
        print(f"Compromised: {password_result['compromised']['is_compromised']} (Seen {password_result['compromised']['times_seen']} times)")
        if password_result['password_strength']['feedback']:
            print("Feedback:")
            for feedback in password_result['password_strength']['feedback']:
                print(f"  - {feedback}")
        
        # Test security plan generation
        plan_result = await assistant.generate_security_plan(assessment_result)
        print("\n--- Security Plan ---")
        print(f"Summary: {plan_result['plan']['summary']}")
        print("Immediate Actions:")
        for action in plan_result['plan']['immediate_actions'][:2]:
            print(f"  - {action}")
        
        print("\n--- Educational Resources ---")
        edu_resources = assistant.get_educational_resources()
        print("Security Basics:")
        for resource in edu_resources['security_basics'][:3]:
            print(f"  - {resource}")
            
    asyncio.run(test())
