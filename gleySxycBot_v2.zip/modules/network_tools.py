"""
Módulo de Herramientas de Red Avanzadas.

Este módulo proporciona funcionalidades avanzadas para análisis de redes,
monitoreo de tráfico, escaneo de puertos y diagnóstico de conectividad.
"""

import logging
import os
import json
import re
import random
import socket
import struct
import asyncio
import ipaddress
import subprocess
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL, ETHICAL_WARNING

# Configuración de logging
logger = logging.getLogger(__name__)

class NetworkTools:
    """Clase para herramientas de red avanzadas."""
    
    def __init__(self):
        """Inicializa la clase de herramientas de red."""
        self.headers = {
            "User-Agent": "GleySxycBot/2.0.0 (Educational Security Bot)"
        }
        
        # Puertos comunes para escaneo
        self.common_ports = {
            21: "FTP",
            22: "SSH",
            23: "Telnet",
            25: "SMTP",
            53: "DNS",
            80: "HTTP",
            110: "POP3",
            143: "IMAP",
            443: "HTTPS",
            445: "SMB",
            3306: "MySQL",
            3389: "RDP",
            5432: "PostgreSQL",
            8080: "HTTP-Proxy"
        }
        
        # Rangos de IP privadas
        self.private_ranges = [
            ipaddress.ip_network("10.0.0.0/8"),
            ipaddress.ip_network("172.16.0.0/12"),
            ipaddress.ip_network("192.168.0.0/16"),
            ipaddress.ip_network("127.0.0.0/8")
        ]
    
    async def analyze_network_traffic(self, interface: str = None, duration: int = 10, packet_count: int = 100, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza el tráfico de red en una interfaz específica.
        
        Args:
            interface: Interfaz de red a analizar (opcional, se detecta automáticamente)
            duration: Duración del análisis en segundos
            packet_count: Número máximo de paquetes a capturar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis de tráfico
        """
        logger.info(f"Analizando tráfico de red en interfaz: {interface or 'auto'}")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "interface": interface,
            "duration": duration,
            "packet_count": packet_count,
            "traffic_summary": {
                "total_packets": 0,
                "total_bytes": 0,
                "protocols": {},
                "top_sources": [],
                "top_destinations": []
            },
            "packets": []
        }
        
        try:
            # Verificar si tenemos tcpdump o tshark instalado
            has_tcpdump = self._check_command_exists("tcpdump")
            has_tshark = self._check_command_exists("tshark")
            
            if not has_tcpdump and not has_tshark:
                results["success"] = False
                results["message"] = "No se encontraron herramientas de captura de paquetes (tcpdump o tshark)"
                return results
            
            # Detectar interfaz si no se especifica
            if not interface:
                interface = await self._detect_default_interface()
                results["interface"] = interface
            
            # Generar datos simulados para evitar captura real de paquetes
            # En una implementación real, se usaría tcpdump o tshark para capturar tráfico
            
            # Simular captura de paquetes
            packet_count = min(packet_count, 100)  # Limitar a 100 paquetes máximo
            total_bytes = 0
            protocols = {"TCP": 0, "UDP": 0, "ICMP": 0, "HTTP": 0, "HTTPS": 0, "DNS": 0, "Other": 0}
            sources = {}
            destinations = {}
            
            for i in range(packet_count):
                # Generar IPs aleatorias (preferentemente privadas para la simulación)
                src_ip = self._generate_random_ip()
                dst_ip = self._generate_random_ip()
                
                # Incrementar contadores de IPs
                sources[src_ip] = sources.get(src_ip, 0) + 1
                destinations[dst_ip] = destinations.get(dst_ip, 0) + 1
                
                # Seleccionar protocolo aleatorio con pesos
                protocol = random.choices(
                    ["TCP", "UDP", "ICMP", "HTTP", "HTTPS", "DNS", "Other"],
                    weights=[50, 30, 5, 30, 40, 20, 5],
                    k=1
                )[0]
                protocols[protocol] += 1
                
                # Generar tamaño de paquete aleatorio
                packet_size = random.randint(64, 1500)
                total_bytes += packet_size
                
                # Generar puertos para TCP/UDP
                src_port = random.randint(1024, 65535)
                dst_port = random.choice(list(self.common_ports.keys())) if protocol in ["TCP", "UDP"] else None
                service = self.common_ports.get(dst_port, "Unknown") if dst_port else None
                
                # Añadir paquete a la lista
                packet = {
                    "timestamp": (datetime.now().timestamp() + i * 0.01),
                    "src_ip": src_ip,
                    "dst_ip": dst_ip,
                    "protocol": protocol,
                    "length": packet_size
                }
                
                if src_port:
                    packet["src_port"] = src_port
                if dst_port:
                    packet["dst_port"] = dst_port
                if service:
                    packet["service"] = service
                
                results["packets"].append(packet)
            
            # Preparar resumen de tráfico
            results["traffic_summary"]["total_packets"] = packet_count
            results["traffic_summary"]["total_bytes"] = total_bytes
            results["traffic_summary"]["protocols"] = protocols
            
            # Top 5 IPs fuente y destino
            results["traffic_summary"]["top_sources"] = [
                {"ip": ip, "count": count}
                for ip, count in sorted(sources.items(), key=lambda x: x[1], reverse=True)[:5]
            ]
            
            results["traffic_summary"]["top_destinations"] = [
                {"ip": ip, "count": count}
                for ip, count in sorted(destinations.items(), key=lambda x: x[1], reverse=True)[:5]
            ]
            
        except Exception as e:
            logger.error(f"Error al analizar tráfico de red: {e}")
            results["success"] = False
            results["message"] = f"Error al analizar tráfico de red: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "network_traffic", interface or "auto", 
                      f"Paquetes: {results['traffic_summary']['total_packets']}, Bytes: {results['traffic_summary']['total_bytes']}")
            
        return results
    
    async def scan_network(self, target: str, port_range: str = "common", db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Escanea una red o host para detectar hosts activos y puertos abiertos.
        
        Args:
            target: IP, rango de IP o nombre de host a escanear
            port_range: Rango de puertos a escanear ("common", "all", "1-1024", etc.)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el escaneo (opcional)
            
        Returns:
            dict: Resultados del escaneo de red
        """
        logger.warning(f"Escaneando red: {target} (puertos: {port_range}). {ETHICAL_WARNING}")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "target": target,
            "port_range": port_range,
            "hosts": []
        }
        
        try:
            # Validar target
            try:
                # Verificar si es una IP individual
                ipaddress.ip_address(target)
                targets = [target]
            except ValueError:
                try:
                    # Verificar si es un rango de IPs
                    network = ipaddress.ip_network(target, strict=False)
                    # Limitar a /24 para evitar escaneos masivos
                    if network.num_addresses > 256:
                        results["success"] = False
                        results["message"] = "El rango de IPs es demasiado grande. Limítese a rangos /24 o menores."
                        return results
                    targets = [str(ip) for ip in network.hosts()]
                except ValueError:
                    # Asumir que es un nombre de host
                    try:
                        ip = socket.gethostbyname(target)
                        targets = [ip]
                        results["resolved_ip"] = ip
                    except socket.gaierror:
                        results["success"] = False
                        results["message"] = f"No se pudo resolver el nombre de host: {target}"
                        return results
            
            # Determinar puertos a escanear
            ports_to_scan = []
            if port_range == "common":
                ports_to_scan = list(self.common_ports.keys())
            elif port_range == "all":
                ports_to_scan = list(range(1, 1025))  # Limitar a los primeros 1024 puertos
            else:
                try:
                    # Parsear rango personalizado (ej: "80,443,8080" o "1-100")
                    parts = port_range.split(",")
                    for part in parts:
                        if "-" in part:
                            start, end = map(int, part.split("-"))
                            ports_to_scan.extend(range(start, end + 1))
                        else:
                            ports_to_scan.append(int(part))
                except ValueError:
                    results["success"] = False
                    results["message"] = f"Formato de rango de puertos inválido: {port_range}"
                    return results
            
            # Limitar número de puertos para evitar escaneos masivos
            if len(ports_to_scan) > 100:
                ports_to_scan = ports_to_scan[:100]
                results["message"] = "Se ha limitado el escaneo a los primeros 100 puertos."
            
            # Escanear hosts
            for target_ip in targets:
                host_result = {
                    "ip": target_ip,
                    "status": "unknown",
                    "hostname": None,
                    "open_ports": []
                }
                
                # Verificar si el host está activo
                is_active = await self._ping_host(target_ip)
                host_result["status"] = "active" if is_active else "inactive"
                
                # Intentar resolver nombre de host
                try:
                    hostname = socket.gethostbyaddr(target_ip)[0]
                    host_result["hostname"] = hostname
                except (socket.herror, socket.gaierror):
                    pass
                
                # Si el host está activo, escanear puertos
                if is_active:
                    open_ports = []
                    port_tasks = []
                    
                    for port in ports_to_scan:
                        port_tasks.append(self._check_port(target_ip, port))
                    
                    port_results = await asyncio.gather(*port_tasks)
                    
                    for port, is_open in port_results:
                        if is_open:
                            service = self.common_ports.get(port, "Unknown")
                            open_ports.append({
                                "port": port,
                                "service": service
                            })
                    
                    host_result["open_ports"] = open_ports
                
                results["hosts"].append(host_result)
            
        except Exception as e:
            logger.error(f"Error al escanear red: {e}")
            results["success"] = False
            results["message"] = f"Error al escanear red: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "network_scan", target, 
                      f"Hosts: {len(results['hosts'])}, Puertos: {port_range}")
            
        return results
    
    async def trace_route(self, target: str, max_hops: int = 30, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Realiza un traceroute a un host objetivo.
        
        Args:
            target: IP o nombre de host objetivo
            max_hops: Número máximo de saltos
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el traceroute (opcional)
            
        Returns:
            dict: Resultados del traceroute
        """
        logger.info(f"Realizando traceroute a {target}")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "target": target,
            "max_hops": max_hops,
            "hops": []
        }
        
        try:
            # Resolver IP si es un nombre de host
            try:
                ip = socket.gethostbyname(target)
                results["resolved_ip"] = ip
            except socket.gaierror:
                results["success"] = False
                results["message"] = f"No se pudo resolver el nombre de host: {target}"
                return results
            
            # En una implementación real, se usaría subprocess para ejecutar traceroute/tracert
            # Para esta simulación, generamos datos realistas
            
            # Generar número aleatorio de saltos (entre 5 y max_hops)
            num_hops = random.randint(5, min(15, max_hops))
            
            # Generar saltos simulados
            current_ttl = 1
            for i in range(num_hops):
                hop = {
                    "hop": current_ttl,
                    "ip": self._generate_random_ip(private=(i < num_hops - 1)),  # Último salto es la IP destino
                    "hostname": None,
                    "rtt": []
                }
                
                # El último salto es el destino
                if i == num_hops - 1:
                    hop["ip"] = ip
                
                # Generar RTT (Round Trip Time) para 3 intentos
                for _ in range(3):
                    # Simular pérdida de paquetes ocasionalmente
                    if random.random() < 0.1:  # 10% de probabilidad de pérdida
                        hop["rtt"].append(None)
                    else:
                        # RTT entre 5ms y 300ms, aumentando con cada salto
                        rtt = random.uniform(5 + i * 10, 20 + i * 20)
                        hop["rtt"].append(round(rtt, 2))
                
                # Intentar resolver nombre de host (simulado)
                if random.random() < 0.7:  # 70% de probabilidad de resolver
                    if i == num_hops - 1:
                        hop["hostname"] = target if "." in target else None
                    else:
                        hop["hostname"] = f"router-{i+1}.isp-{random.randint(1,5)}.net"
                
                results["hops"].append(hop)
                current_ttl += 1
            
        except Exception as e:
            logger.error(f"Error al realizar traceroute: {e}")
            results["success"] = False
            results["message"] = f"Error al realizar traceroute: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "traceroute", target, 
                      f"Hops: {len(results['hops'])}")
            
        return results
    
    async def analyze_dns(self, domain: str, record_types: List[str] = None, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza registros DNS para un dominio.
        
        Args:
            domain: Nombre de dominio a analizar
            record_types: Lista de tipos de registros a consultar (A, AAAA, MX, NS, TXT, etc.)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis DNS
        """
        logger.info(f"Analizando DNS para dominio: {domain}")
        
        # Verificar caché
        cache_key = f"dns_analysis:{domain}"
        if db_session:
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultados en caché encontrados para {domain}")
                return cached_result
        
        # Tipos de registro predeterminados si no se especifican
        if not record_types:
            record_types = ["A", "AAAA", "MX", "NS", "TXT", "SOA", "CNAME"]
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "domain": domain,
            "records": {}
        }
        
        try:
            # En una implementación real, se usaría dnspython o subprocess para ejecutar dig/nslookup
            # Para esta simulación, generamos datos realistas
            
            # Validar dominio
            if not self._is_valid_domain(domain):
                results["success"] = False
                results["message"] = f"Dominio inválido: {domain}"
                return results
            
            # Consultar registros DNS
            for record_type in record_types:
                record_results = []
                
                if record_type == "A":
                    # Simular registros A (IPv4)
                    num_records = random.randint(1, 3)
                    for _ in range(num_records):
                        record_results.append({
                            "value": self._generate_random_ip(private=False),
                            "ttl": random.randint(300, 86400)
                        })
                
                elif record_type == "AAAA":
                    # Simular registros AAAA (IPv6)
                    if random.random() < 0.7:  # 70% de probabilidad de tener IPv6
                        num_records = random.randint(1, 2)
                        for _ in range(num_records):
                            record_results.append({
                                "value": self._generate_random_ipv6(),
                                "ttl": random.randint(300, 86400)
                            })
                
                elif record_type == "MX":
                    # Simular registros MX
                    num_records = random.randint(1, 3)
                    for i in range(num_records):
                        record_results.append({
                            "preference": i * 10,
                            "value": f"mail{i+1}.{domain}" if i > 0 else f"mail.{domain}",
                            "ttl": random.randint(300, 86400)
                        })
                
                elif record_type == "NS":
                    # Simular registros NS
                    num_records = random.randint(2, 4)
                    for i in range(num_records):
                        record_results.append({
                            "value": f"ns{i+1}.{random.choice(['registrar.com', 'dns-provider.net', domain])}",
                            "ttl": random.randint(3600, 86400)
                        })
                
                elif record_type == "TXT":
                    # Simular registros TXT
                    txt_records = [
                        f"v=spf1 ip4:{self._generate_random_ip(private=False)} include:_spf.{domain} ~all",
                        f"google-site-verification={self._generate_random_string(16)}",
                        f"MS={self._generate_random_string(32)}"
                    ]
                    num_records = random.randint(1, len(txt_records))
                    for i in range(num_records):
                        record_results.append({
                            "value": txt_records[i],
                            "ttl": random.randint(300, 86400)
                        })
                
                elif record_type == "SOA":
                    # Simular registro SOA
                    record_results.append({
                        "primary": f"ns1.{random.choice(['registrar.com', 'dns-provider.net', domain])}",
                        "email": f"hostmaster@{domain}",
                        "serial": int(datetime.now().strftime("%Y%m%d%H")),
                        "refresh": 7200,
                        "retry": 3600,
                        "expire": 1209600,
                        "minimum": 86400,
                        "ttl": 3600
                    })
                
                elif record_type == "CNAME":
                    # Simular registros CNAME
                    cname_subdomains = ["www", "blog", "shop", "mail"]
                    num_records = random.randint(1, len(cname_subdomains))
                    for i in range(num_records):
                        subdomain = cname_subdomains[i]
                        record_results.append({
                            "name": f"{subdomain}.{domain}",
                            "value": domain if subdomain != "mail" else f"mail-server.{domain}",
                            "ttl": random.randint(300, 86400)
                        })
                
                # Añadir resultados al diccionario principal
                if record_results:
                    results["records"][record_type] = record_results
            
        except Exception as e:
            logger.error(f"Error al analizar DNS: {e}")
            results["success"] = False
            results["message"] = f"Error al analizar DNS: {str(e)}"
        
        # Guardar en caché
        if db_session and results["success"]:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "dns_analysis", domain, 
                      f"Tipos de registro: {','.join(record_types)}")
            
        return results
    
    async def analyze_ssl_certificate(self, domain: str, port: int = 443, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza el certificado SSL/TLS de un dominio.
        
        Args:
            domain: Nombre de dominio a analizar
            port: Puerto SSL/TLS (por defecto 443)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis del certificado
        """
        logger.info(f"Analizando certificado SSL para {domain}:{port}")
        
        # Verificar caché
        cache_key = f"ssl_cert:{domain}:{port}"
        if db_session:
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultados en caché encontrados para {domain}:{port}")
                return cached_result
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "domain": domain,
            "port": port,
            "certificate": None,
            "chain": [],
            "protocols": [],
            "cipher_suites": [],
            "vulnerabilities": []
        }
        
        try:
            # En una implementación real, se usaría OpenSSL o bibliotecas como ssl, cryptography, etc.
            # Para esta simulación, generamos datos realistas
            
            # Validar dominio
            if not self._is_valid_domain(domain):
                results["success"] = False
                results["message"] = f"Dominio inválido: {domain}"
                return results
            
            # Simular certificado
            current_date = datetime.now()
            not_before = current_date.replace(year=current_date.year - 1)
            not_after = current_date.replace(year=current_date.year + 1)
            
            # Probabilidad de certificado caducado o próximo a caducar
            cert_status = random.choices(
                ["valid", "expiring_soon", "expired"],
                weights=[80, 15, 5],
                k=1
            )[0]
            
            if cert_status == "expiring_soon":
                not_after = current_date.replace(day=current_date.day + random.randint(5, 30))
            elif cert_status == "expired":
                not_after = current_date.replace(day=current_date.day - random.randint(1, 30))
            
            # Generar información del certificado
            results["certificate"] = {
                "subject": {
                    "common_name": domain if random.random() < 0.7 else f"*.{'.'.join(domain.split('.')[1:])}"
                },
                "issuer": {
                    "organization": random.choice([
                        "Let's Encrypt", "DigiCert Inc", "Comodo CA Limited", 
                        "GlobalSign", "GoDaddy.com, Inc.", "Sectigo Limited"
                    ]),
                    "common_name": random.choice([
                        "Let's Encrypt Authority X3", "DigiCert SHA2 Secure Server CA", 
                        "Comodo RSA Domain Validation Secure Server CA", "GlobalSign GCC R3",
                        "Go Daddy Secure Certificate Authority - G2", "Sectigo RSA Domain Validation Secure Server CA"
                    ])
                },
                "version": 3,
                "serial_number": self._generate_random_string(16, hex_only=True),
                "not_before": not_before.isoformat(),
                "not_after": not_after.isoformat(),
                "status": cert_status,
                "signature_algorithm": random.choice(["sha256WithRSAEncryption", "sha384WithRSAEncryption"]),
                "public_key": {
                    "algorithm": "RSA",
                    "key_size": random.choice([2048, 4096])
                },
                "extensions": {
                    "subject_alt_names": [domain] if "www." not in domain else [domain, domain.replace("www.", "")]
                }
            }
            
            # Generar cadena de certificados
            chain_length = random.randint(1, 3)
            for i in range(chain_length):
                chain_cert = {
                    "subject": {
                        "organization": results["certificate"]["issuer"]["organization"],
                        "common_name": results["certificate"]["issuer"]["common_name"] if i == 0 else f"Intermediate CA {i}"
                    },
                    "issuer": {
                        "organization": results["certificate"]["issuer"]["organization"] if i < chain_length - 1 else "Root CA",
                        "common_name": f"Root CA {i+1}" if i == chain_length - 1 else f"Intermediate CA {i+1}"
                    },
                    "not_before": (not_before.replace(year=not_before.year - 1)).isoformat(),
                    "not_after": (not_after.replace(year=not_after.year + 5)).isoformat()
                }
                results["chain"].append(chain_cert)
            
            # Protocolos soportados
            protocols = ["TLSv1.2", "TLSv1.3"]
            if random.random() < 0.3:  # 30% de probabilidad de soportar protocolos obsoletos
                protocols.extend(["TLSv1.0", "TLSv1.1"])
            if random.random() < 0.1:  # 10% de probabilidad de soportar SSL3
                protocols.append("SSLv3")
            results["protocols"] = protocols
            
            # Cipher suites
            modern_ciphers = [
                "TLS_AES_256_GCM_SHA384",
                "TLS_AES_128_GCM_SHA256",
                "TLS_CHACHA20_POLY1305_SHA256",
                "ECDHE-RSA-AES256-GCM-SHA384",
                "ECDHE-RSA-AES128-GCM-SHA256",
                "ECDHE-ECDSA-AES256-GCM-SHA384"
            ]
            
            weak_ciphers = [
                "ECDHE-RSA-AES256-SHA",
                "AES256-SHA",
                "DES-CBC3-SHA",
                "RC4-SHA"
            ]
            
            results["cipher_suites"] = modern_ciphers
            if "TLSv1.0" in protocols or "TLSv1.1" in protocols or "SSLv3" in protocols:
                results["cipher_suites"].extend(random.sample(weak_ciphers, k=random.randint(1, len(weak_ciphers))))
            
            # Vulnerabilidades
            vulnerabilities = []
            
            if "SSLv3" in protocols:
                vulnerabilities.append({
                    "name": "POODLE",
                    "severity": "High",
                    "description": "POODLE (Padding Oracle On Downgraded Legacy Encryption) afecta a SSLv3 y permite a atacantes obtener datos en texto plano."
                })
            
            if "RC4-SHA" in results["cipher_suites"]:
                vulnerabilities.append({
                    "name": "RC4 Vulnerable",
                    "severity": "Medium",
                    "description": "El cifrado RC4 es considerado criptográficamente débil y no debe ser utilizado."
                })
            
            if cert_status == "expired":
                vulnerabilities.append({
                    "name": "Certificado Caducado",
                    "severity": "High",
                    "description": "El certificado SSL ha caducado y debe ser renovado inmediatamente."
                })
            elif cert_status == "expiring_soon":
                vulnerabilities.append({
                    "name": "Certificado Próximo a Caducar",
                    "severity": "Medium",
                    "description": "El certificado SSL caducará pronto y debe ser renovado."
                })
            
            if domain not in results["certificate"]["extensions"]["subject_alt_names"]:
                vulnerabilities.append({
                    "name": "Nombre de Dominio No Coincidente",
                    "severity": "High",
                    "description": "El nombre de dominio no coincide con el certificado."
                })
            
            results["vulnerabilities"] = vulnerabilities
            
        except Exception as e:
            logger.error(f"Error al analizar certificado SSL: {e}")
            results["success"] = False
            results["message"] = f"Error al analizar certificado SSL: {str(e)}"
        
        # Guardar en caché
        if db_session and results["success"]:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "ssl_analysis", f"{domain}:{port}", 
                      f"Estado: {results['certificate']['status'] if results.get('certificate') else 'N/A'}")
            
        return results
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre herramientas de red.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "network_analysis_basics": [
                "El análisis de tráfico de red permite identificar patrones, anomalías y posibles amenazas.",
                "Los analizadores de paquetes (sniffers) como Wireshark son herramientas fundamentales para inspeccionar el tráfico.",
                "El escaneo de puertos ayuda a identificar servicios expuestos y posibles vulnerabilidades.",
                "El sistema DNS (Domain Name System) traduce nombres de dominio a direcciones IP y viceversa.",
                "Los certificados SSL/TLS proporcionan autenticidad, integridad y confidencialidad en las comunicaciones web.",
                "El traceroute muestra la ruta que siguen los paquetes hasta llegar a su destino.",
                "Las herramientas de monitoreo de red ayudan a detectar problemas de rendimiento y seguridad.",
                "El análisis de protocolos permite entender cómo funcionan las comunicaciones entre sistemas.",
                "Las redes privadas virtuales (VPN) cifran el tráfico para proteger la privacidad y seguridad.",
                "El conocimiento de la topología de red es esencial para identificar puntos de fallo y optimizar el rendimiento."
            ],
            "network_security_tips": [
                "Mantén un inventario actualizado de todos los dispositivos conectados a tu red.",
                "Segmenta tu red para limitar el acceso entre diferentes partes de la infraestructura.",
                "Implementa firewalls y sistemas de detección/prevención de intrusiones (IDS/IPS).",
                "Utiliza cifrado para proteger datos sensibles en tránsito y en reposo.",
                "Configura correctamente los controles de acceso a la red (NAC).",
                "Monitoriza el tráfico de red para detectar comportamientos anómalos.",
                "Actualiza regularmente el firmware de routers, switches y otros dispositivos de red.",
                "Implementa autenticación fuerte para el acceso a recursos de red.",
                "Realiza auditorías de seguridad periódicas en tu infraestructura de red.",
                "Desarrolla y prueba planes de respuesta a incidentes para problemas de red."
            ],
            "recommended_tools": [
                "Wireshark - Analizador de protocolos de red",
                "Nmap - Escáner de puertos y herramienta de descubrimiento de red",
                "tcpdump - Herramienta de línea de comandos para captura y análisis de paquetes",
                "Netcat - Utilidad de red para leer y escribir datos a través de conexiones de red",
                "Zenmap - Interfaz gráfica para Nmap",
                "Angry IP Scanner - Escáner de red rápido y fácil de usar",
                "Nagios - Sistema de monitoreo de red",
                "Zabbix - Plataforma de monitoreo de redes y aplicaciones",
                "OpenVAS - Framework de escaneo de vulnerabilidades",
                "Snort - Sistema de detección de intrusiones de red"
            ]
        }
    
    async def _detect_default_interface(self) -> str:
        """Detecta la interfaz de red predeterminada."""
        # En una implementación real, se usaría código específico del sistema operativo
        # Para esta simulación, devolvemos un valor predeterminado
        return "eth0"
    
    def _check_command_exists(self, command: str) -> bool:
        """Verifica si un comando existe en el sistema."""
        try:
            subprocess.run(["which", command], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            return True
        except subprocess.CalledProcessError:
            return False
    
    def _generate_random_ip(self, private: bool = True) -> str:
        """Genera una dirección IP aleatoria."""
        if private:
            # Generar IP privada
            private_range = random.choice(self.private_ranges)
            ip_int = random.randint(int(private_range.network_address), int(private_range.broadcast_address))
            return str(ipaddress.ip_address(ip_int))
        else:
            # Generar IP pública (evitando rangos privados y especiales)
            while True:
                ip_int = random.randint(1, 0xffffffff)
                ip = ipaddress.ip_address(ip_int)
                
                # Verificar que no sea privada ni especial
                if not ip.is_private and not ip.is_multicast and not ip.is_reserved and not ip.is_loopback:
                    return str(ip)
    
    def _generate_random_ipv6(self) -> str:
        """Genera una dirección IPv6 aleatoria."""
        parts = []
        for _ in range(8):
            parts.append(f"{random.randint(0, 0xffff):x}")
        return ":".join(parts)
    
    def _generate_random_string(self, length: int, hex_only: bool = False) -> str:
        """Genera una cadena aleatoria."""
        if hex_only:
            chars = "0123456789ABCDEF"
        else:
            chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        return "".join(random.choice(chars) for _ in range(length))
    
    def _is_valid_domain(self, domain: str) -> bool:
        """Verifica si un dominio es válido."""
        pattern = r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
        return bool(re.match(pattern, domain))
    
    async def _ping_host(self, host: str) -> bool:
        """Verifica si un host está activo mediante ping."""
        # En una implementación real, se usaría subprocess para ejecutar ping
        # Para esta simulación, devolvemos un valor aleatorio con alta probabilidad de éxito
        return random.random() < 0.9  # 90% de probabilidad de que el host esté activo
    
    async def _check_port(self, host: str, port: int) -> Tuple[int, bool]:
        """Verifica si un puerto está abierto."""
        # En una implementación real, se intentaría establecer una conexión TCP
        # Para esta simulación, devolvemos un valor aleatorio con probabilidad variable según el puerto
        
        # Puertos comunes tienen mayor probabilidad de estar abiertos
        if port in self.common_ports:
            probability = 0.7  # 70% para puertos comunes
        else:
            probability = 0.1  # 10% para otros puertos
        
        is_open = random.random() < probability
        return port, is_open

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    network_tools = NetworkTools()
    import asyncio
    
    async def test():
        # Test network traffic analysis
        traffic_result = await network_tools.analyze_network_traffic()
        print("\n--- Network Traffic Analysis ---")
        print(f"Interface: {traffic_result['interface']}")
        print(f"Total packets: {traffic_result['traffic_summary']['total_packets']}")
        print(f"Total bytes: {traffic_result['traffic_summary']['total_bytes']}")
        print("Protocols:")
        for protocol, count in traffic_result['traffic_summary']['protocols'].items():
            print(f"  - {protocol}: {count}")
        
        # Test network scan
        scan_result = await network_tools.scan_network("192.168.1.0/24", "common")
        print("\n--- Network Scan ---")
        print(f"Target: {scan_result['target']}")
        print(f"Hosts found: {len(scan_result['hosts'])}")
        for host in scan_result['hosts'][:2]:  # Mostrar solo los primeros 2 hosts
            print(f"  - {host['ip']} ({host['status']})")
            if host['open_ports']:
                print(f"    Open ports: {len(host['open_ports'])}")
                for port in host['open_ports'][:3]:  # Mostrar solo los primeros 3 puertos
                    print(f"      - {port['port']}/{port['service']}")
        
        # Test traceroute
        trace_result = await network_tools.trace_route("google.com")
        print("\n--- Traceroute ---")
        print(f"Target: {trace_result['target']} ({trace_result.get('resolved_ip', 'N/A')})")
        print(f"Hops: {len(trace_result['hops'])}")
        for hop in trace_result['hops'][:5]:  # Mostrar solo los primeros 5 saltos
            hostname = hop['hostname'] or 'Unknown'
            rtt_avg = sum([r for r in hop['rtt'] if r is not None]) / len([r for r in hop['rtt'] if r is not None]) if any(r is not None for r in hop['rtt']) else 'N/A'
            print(f"  {hop['hop']}. {hop['ip']} ({hostname}) - RTT: {rtt_avg if rtt_avg != 'N/A' else 'N/A'}ms")
        
        # Test DNS analysis
        dns_result = await network_tools.analyze_dns("example.com")
        print("\n--- DNS Analysis ---")
        print(f"Domain: {dns_result['domain']}")
        print(f"Record types: {', '.join(dns_result['records'].keys())}")
        for record_type, records in list(dns_result['records'].items())[:3]:  # Mostrar solo los primeros 3 tipos
            print(f"  {record_type} records:")
            for record in records[:2]:  # Mostrar solo los primeros 2 registros
                if record_type == "SOA":
                    print(f"    - Primary: {record['primary']}, Email: {record['email']}")
                else:
                    print(f"    - {record.get('value', 'N/A')}")
        
        # Test SSL certificate analysis
        ssl_result = await network_tools.analyze_ssl_certificate("example.com")
        print("\n--- SSL Certificate Analysis ---")
        if ssl_result['certificate']:
            print(f"Domain: {ssl_result['domain']}")
            print(f"Issuer: {ssl_result['certificate']['issuer']['organization']}")
            print(f"Valid until: {ssl_result['certificate']['not_after']}")
            print(f"Status: {ssl_result['certificate']['status']}")
            print(f"Protocols: {', '.join(ssl_result['protocols'])}")
            if ssl_result['vulnerabilities']:
                print("Vulnerabilities:")
                for vuln in ssl_result['vulnerabilities']:
                    print(f"  - {vuln['name']} ({vuln['severity']})")
        
        print("\n--- Educational Resources ---")
        edu_resources = network_tools.get_educational_resources()
        print("Network Analysis Basics:")
        for resource in edu_resources['network_analysis_basics'][:3]:
            print(f"  - {resource}")
            
    asyncio.run(test())
