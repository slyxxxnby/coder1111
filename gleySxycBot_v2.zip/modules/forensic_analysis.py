"""
Módulo para análisis forense digital.

Este módulo proporciona herramientas para análisis forense básico de archivos,
extracción de metadatos, análisis de memoria y recuperación de datos.
"""

import logging
import os
import hashlib
import magic
import exifread
import re
import json
import io
import struct
import binascii
import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
from pathlib import Path

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL

# Configuración de logging
logger = logging.getLogger(__name__)

class ForensicAnalysis:
    """Clase para análisis forense digital."""
    
    def __init__(self):
        """Inicializa la clase de análisis forense."""
        self.headers = {
            "User-Agent": "GleySxycBot/2.0.0 (Educational Security Bot)"
        }
    
    async def analyze_file(self, file_content: bytes, filename: str = None, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Realiza un análisis forense básico de un archivo.
        
        Args:
            file_content: Contenido del archivo en bytes
            filename: Nombre del archivo (opcional)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis forense
        """
        logger.info(f"Analizando archivo: {filename or 'archivo sin nombre'}")
        
        results = {
            "success": True,
            "filename": filename,
            "timestamp": datetime.datetime.now().isoformat(),
            "file_info": {},
            "hashes": {},
            "metadata": {},
            "strings": [],
            "hex_dump": "",
            "file_structure": {},
            "potential_indicators": []
        }
        
        try:
            # Información básica del archivo
            file_size = len(file_content)
            file_type = magic.from_buffer(file_content, mime=True)
            file_description = magic.from_buffer(file_content)
            
            results["file_info"] = {
                "size": file_size,
                "size_human": self._format_size(file_size),
                "mime_type": file_type,
                "description": file_description
            }
            
            # Calcular hashes
            results["hashes"] = self._calculate_hashes(file_content)
            
            # Extraer metadatos según el tipo de archivo
            results["metadata"] = self._extract_metadata(file_content, file_type, filename)
            
            # Extraer strings ASCII/Unicode
            results["strings"] = self._extract_strings(file_content)[:100]  # Limitar a 100 strings
            
            # Generar hex dump (primeros 512 bytes)
            results["hex_dump"] = self._generate_hex_dump(file_content[:512])
            
            # Analizar estructura del archivo según su tipo
            results["file_structure"] = self._analyze_file_structure(file_content, file_type)
            
            # Buscar indicadores potenciales
            results["potential_indicators"] = self._find_potential_indicators(file_content, file_type, results["strings"])
            
        except Exception as e:
            logger.error(f"Error al analizar archivo: {e}")
            results["success"] = False
            results["message"] = f"Error al analizar archivo: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "forensic", filename or "archivo", 
                      f"Tipo: {results['file_info'].get('mime_type', 'desconocido')}, Tamaño: {results['file_info'].get('size_human', '0')}")
            
        return results
    
    def _calculate_hashes(self, data: bytes) -> Dict[str, str]:
        """
        Calcula múltiples hashes para los datos proporcionados.
        
        Args:
            data: Datos en bytes
            
        Returns:
            dict: Diferentes hashes calculados
        """
        md5 = hashlib.md5(data).hexdigest()
        sha1 = hashlib.sha1(data).hexdigest()
        sha256 = hashlib.sha256(data).hexdigest()
        sha512 = hashlib.sha512(data).hexdigest()
        
        return {
            "md5": md5,
            "sha1": sha1,
            "sha256": sha256,
            "sha512": sha512
        }
    
    def _extract_metadata(self, data: bytes, mime_type: str, filename: str = None) -> Dict[str, Any]:
        """
        Extrae metadatos específicos según el tipo de archivo.
        
        Args:
            data: Datos en bytes
            mime_type: Tipo MIME del archivo
            filename: Nombre del archivo (opcional)
            
        Returns:
            dict: Metadatos extraídos
        """
        metadata = {}
        
        # Imágenes (JPEG, PNG, etc.)
        if mime_type.startswith("image/"):
            try:
                file_stream = io.BytesIO(data)
                tags = exifread.process_file(file_stream)
                
                exif_data = {}
                for tag, value in tags.items():
                    if tag not in ("JPEGThumbnail", "TIFFThumbnail", "Filename", "EXIF MakerNote"):
                        exif_data[tag] = str(value)
                
                metadata["exif"] = exif_data
                
                # Extraer información de geolocalización si está disponible
                if "GPS GPSLatitude" in tags and "GPS GPSLongitude" in tags:
                    try:
                        lat = self._convert_to_degrees(tags["GPS GPSLatitude"].values)
                        lon = self._convert_to_degrees(tags["GPS GPSLongitude"].values)
                        
                        # Ajustar según referencia N/S y E/W
                        if "GPS GPSLatitudeRef" in tags and tags["GPS GPSLatitudeRef"].values == "S":
                            lat = -lat
                        if "GPS GPSLongitudeRef" in tags and tags["GPS GPSLongitudeRef"].values == "W":
                            lon = -lon
                            
                        metadata["gps"] = {
                            "latitude": lat,
                            "longitude": lon,
                            "map_url": f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}&zoom=14"
                        }
                    except Exception as e:
                        logger.warning(f"Error al extraer coordenadas GPS: {e}")
            except Exception as e:
                logger.warning(f"Error al extraer metadatos EXIF: {e}")
        
        # Documentos PDF
        elif mime_type == "application/pdf":
            try:
                # Extraer información básica del PDF
                pdf_info = {}
                
                # Buscar metadatos en el encabezado
                pdf_header_match = re.search(rb"%PDF-(\d+\.\d+)", data[:1024])
                if pdf_header_match:
                    pdf_info["version"] = pdf_header_match.group(1).decode()
                
                # Buscar información del autor, título, etc.
                author_match = re.search(rb"/Author\s*\(([^)]+)\)", data)
                if author_match:
                    pdf_info["author"] = author_match.group(1).decode("utf-8", errors="replace")
                
                title_match = re.search(rb"/Title\s*\(([^)]+)\)", data)
                if title_match:
                    pdf_info["title"] = title_match.group(1).decode("utf-8", errors="replace")
                
                creator_match = re.search(rb"/Creator\s*\(([^)]+)\)", data)
                if creator_match:
                    pdf_info["creator"] = creator_match.group(1).decode("utf-8", errors="replace")
                
                producer_match = re.search(rb"/Producer\s*\(([^)]+)\)", data)
                if producer_match:
                    pdf_info["producer"] = producer_match.group(1).decode("utf-8", errors="replace")
                
                creation_date_match = re.search(rb"/CreationDate\s*\(([^)]+)\)", data)
                if creation_date_match:
                    pdf_info["creation_date"] = creation_date_match.group(1).decode("utf-8", errors="replace")
                
                mod_date_match = re.search(rb"/ModDate\s*\(([^)]+)\)", data)
                if mod_date_match:
                    pdf_info["modification_date"] = mod_date_match.group(1).decode("utf-8", errors="replace")
                
                metadata["pdf"] = pdf_info
            except Exception as e:
                logger.warning(f"Error al extraer metadatos PDF: {e}")
        
        # Documentos Office
        elif mime_type in ["application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                          "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                          "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation"]:
            try:
                # Extraer información básica de documentos Office
                office_info = {}
                
                # Buscar metadatos comunes
                creator_match = re.search(rb"<dc:creator>([^<]+)</dc:creator>", data)
                if creator_match:
                    office_info["creator"] = creator_match.group(1).decode("utf-8", errors="replace")
                
                title_match = re.search(rb"<dc:title>([^<]+)</dc:title>", data)
                if title_match:
                    office_info["title"] = title_match.group(1).decode("utf-8", errors="replace")
                
                subject_match = re.search(rb"<dc:subject>([^<]+)</dc:subject>", data)
                if subject_match:
                    office_info["subject"] = subject_match.group(1).decode("utf-8", errors="replace")
                
                description_match = re.search(rb"<dc:description>([^<]+)</dc:description>", data)
                if description_match:
                    office_info["description"] = description_match.group(1).decode("utf-8", errors="replace")
                
                last_modified_by_match = re.search(rb"<cp:lastModifiedBy>([^<]+)</cp:lastModifiedBy>", data)
                if last_modified_by_match:
                    office_info["last_modified_by"] = last_modified_by_match.group(1).decode("utf-8", errors="replace")
                
                revision_match = re.search(rb"<cp:revision>([^<]+)</cp:revision>", data)
                if revision_match:
                    office_info["revision"] = revision_match.group(1).decode("utf-8", errors="replace")
                
                metadata["office"] = office_info
            except Exception as e:
                logger.warning(f"Error al extraer metadatos Office: {e}")
        
        # Archivos ejecutables
        elif mime_type in ["application/x-dosexec", "application/x-executable", "application/x-mach-binary"]:
            try:
                # Extraer información básica de ejecutables
                exe_info = {}
                
                # Verificar si es un PE (Windows)
                if data[:2] == b"MZ":
                    exe_info["format"] = "PE (Windows Executable)"
                    
                    # Obtener offset del PE header
                    pe_offset = struct.unpack("<I", data[0x3C:0x40])[0]
                    
                    # Verificar firma PE
                    if data[pe_offset:pe_offset+4] == b"PE\0\0":
                        # Obtener timestamp de compilación
                        timestamp = struct.unpack("<I", data[pe_offset+8:pe_offset+12])[0]
                        exe_info["compilation_timestamp"] = timestamp
                        exe_info["compilation_date"] = datetime.datetime.fromtimestamp(timestamp).isoformat()
                        
                        # Obtener arquitectura
                        machine_type = struct.unpack("<H", data[pe_offset+4:pe_offset+6])[0]
                        machine_types = {
                            0x014c: "x86 (32-bit)",
                            0x0200: "IA64 (Itanium)",
                            0x8664: "x64 (AMD64)"
                        }
                        exe_info["architecture"] = machine_types.get(machine_type, f"Unknown ({hex(machine_type)})")
                        
                        # Características
                        characteristics = struct.unpack("<H", data[pe_offset+22:pe_offset+24])[0]
                        exe_info["is_dll"] = bool(characteristics & 0x2000)
                        exe_info["is_system"] = bool(characteristics & 0x1000)
                        
                # Verificar si es ELF (Linux)
                elif data[:4] == b"\x7FELF":
                    exe_info["format"] = "ELF (Linux/Unix Executable)"
                    
                    # Obtener arquitectura
                    elf_class = data[4]
                    exe_info["architecture"] = "64-bit" if elf_class == 2 else "32-bit"
                    
                    # Obtener tipo
                    e_type = struct.unpack("<H", data[16:18])[0]
                    types = {
                        1: "Relocatable",
                        2: "Executable",
                        3: "Shared object",
                        4: "Core file"
                    }
                    exe_info["type"] = types.get(e_type, f"Unknown ({e_type})")
                
                # Verificar si es Mach-O (macOS)
                elif data[:4] in [b"\xFE\xED\xFA\xCE", b"\xCE\xFA\xED\xFE", b"\xFE\xED\xFA\xCF", b"\xCF\xFA\xED\xFE"]:
                    exe_info["format"] = "Mach-O (macOS Executable)"
                    
                    # Determinar endianness y arquitectura
                    if data[:4] in [b"\xFE\xED\xFA\xCE", b"\xFE\xED\xFA\xCF"]:
                        endian = "big"
                        exe_info["endianness"] = "Big Endian"
                    else:
                        endian = "little"
                        exe_info["endianness"] = "Little Endian"
                    
                    if data[:4] in [b"\xFE\xED\xFA\xCE", b"\xCE\xFA\xED\xFE"]:
                        exe_info["architecture"] = "32-bit"
                    else:
                        exe_info["architecture"] = "64-bit"
                    
                    # Obtener tipo
                    if endian == "big":
                        filetype = struct.unpack(">I", data[12:16])[0]
                    else:
                        filetype = struct.unpack("<I", data[12:16])[0]
                    
                    types = {
                        1: "Object",
                        2: "Executable",
                        3: "Fixed VM Shared Library",
                        4: "Core",
                        5: "Preloaded Executable",
                        6: "Dynamically Bound Shared Library",
                        7: "Dynamic Link Editor",
                        8: "Bundle",
                        9: "Shared Library Stub",
                        10: "Debug Companion File",
                        11: "Kernel Extension Bundle"
                    }
                    exe_info["type"] = types.get(filetype, f"Unknown ({filetype})")
                
                metadata["executable"] = exe_info
            except Exception as e:
                logger.warning(f"Error al extraer metadatos de ejecutable: {e}")
        
        return metadata
    
    def _extract_strings(self, data: bytes, min_length: int = 4) -> List[str]:
        """
        Extrae strings ASCII y Unicode de los datos binarios.
        
        Args:
            data: Datos en bytes
            min_length: Longitud mínima de strings a extraer
            
        Returns:
            list: Strings extraídos
        """
        # Extraer strings ASCII
        ascii_strings = re.findall(b"[\x20-\x7E]{" + str(min_length).encode() + b",}", data)
        ascii_strings = [s.decode("ascii") for s in ascii_strings]
        
        # Extraer strings Unicode (UTF-16LE)
        unicode_pattern = re.compile(b"(?:[\x20-\x7E]\x00){" + str(min_length).encode() + b",}")
        unicode_strings = []
        for match in unicode_pattern.finditer(data):
            try:
                unicode_str = match.group().decode("utf-16le")
                unicode_strings.append(unicode_str)
            except UnicodeDecodeError:
                pass
        
        # Combinar y eliminar duplicados
        all_strings = ascii_strings + unicode_strings
        return list(set(all_strings))
    
    def _generate_hex_dump(self, data: bytes, bytes_per_line: int = 16) -> str:
        """
        Genera un hex dump de los datos.
        
        Args:
            data: Datos en bytes
            bytes_per_line: Número de bytes por línea
            
        Returns:
            str: Hex dump formateado
        """
        result = []
        for i in range(0, len(data), bytes_per_line):
            chunk = data[i:i+bytes_per_line]
            hex_values = " ".join(f"{b:02x}" for b in chunk)
            ascii_values = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
            result.append(f"{i:08x}:  {hex_values:<{bytes_per_line*3}}  {ascii_values}")
        
        return "\n".join(result)
    
    def _analyze_file_structure(self, data: bytes, mime_type: str) -> Dict[str, Any]:
        """
        Analiza la estructura del archivo según su tipo.
        
        Args:
            data: Datos en bytes
            mime_type: Tipo MIME del archivo
            
        Returns:
            dict: Información sobre la estructura del archivo
        """
        structure = {}
        
        # Imágenes JPEG
        if mime_type == "image/jpeg":
            try:
                structure["format"] = "JPEG"
                
                # Buscar marcadores JPEG
                markers = []
                i = 0
                while i < len(data) - 1:
                    if data[i] == 0xFF and data[i+1] in [0xD8, 0xE0, 0xE1, 0xDB, 0xC0, 0xC4, 0xDA, 0xD9]:
                        marker_types = {
                            0xD8: "SOI (Start of Image)",
                            0xE0: "APP0 (JFIF)",
                            0xE1: "APP1 (EXIF)",
                            0xDB: "DQT (Define Quantization Table)",
                            0xC0: "SOF0 (Start of Frame)",
                            0xC4: "DHT (Define Huffman Table)",
                            0xDA: "SOS (Start of Scan)",
                            0xD9: "EOI (End of Image)"
                        }
                        markers.append({
                            "offset": i,
                            "marker": f"FF {data[i+1]:02X}",
                            "type": marker_types.get(data[i+1], f"Unknown (FF {data[i+1]:02X})")
                        })
                    i += 1
                
                structure["markers"] = markers[:10]  # Limitar a 10 marcadores
            except Exception as e:
                logger.warning(f"Error al analizar estructura JPEG: {e}")
        
        # Imágenes PNG
        elif mime_type == "image/png":
            try:
                structure["format"] = "PNG"
                
                # Verificar firma PNG
                if data[:8] == b"\x89PNG\r\n\x1a\n":
                    structure["signature"] = "Valid PNG signature"
                
                # Buscar chunks PNG
                chunks = []
                i = 8  # Saltar la firma
                while i < len(data) - 12:  # Necesitamos al menos 12 bytes para un chunk
                    try:
                        length = struct.unpack(">I", data[i:i+4])[0]
                        chunk_type = data[i+4:i+8].decode("ascii")
                        chunks.append({
                            "offset": i,
                            "length": length,
                            "type": chunk_type,
                            "description": self._get_png_chunk_description(chunk_type)
                        })
                        i += length + 12  # 4 (length) + 4 (type) + length + 4 (CRC)
                    except Exception:
                        i += 1
                
                structure["chunks"] = chunks
            except Exception as e:
                logger.warning(f"Error al analizar estructura PNG: {e}")
        
        # Archivos PDF
        elif mime_type == "application/pdf":
            try:
                structure["format"] = "PDF"
                
                # Verificar firma PDF
                if data[:5] == b"%PDF-":
                    structure["signature"] = f"PDF {data[5:8].decode('ascii')}"
                
                # Buscar objetos PDF
                obj_pattern = re.compile(rb"\d+\s+\d+\s+obj[\r\n]")
                objects = [{"offset": m.start(), "object": m.group().decode("ascii").strip()} for m in obj_pattern.finditer(data)]
                
                structure["objects"] = objects[:20]  # Limitar a 20 objetos
                structure["object_count"] = len(objects)
                
                # Buscar xref table
                xref_match = re.search(rb"xref[\r\n]", data)
                if xref_match:
                    structure["xref_offset"] = xref_match.start()
                
                # Buscar trailer
                trailer_match = re.search(rb"trailer[\r\n]", data)
                if trailer_match:
                    structure["trailer_offset"] = trailer_match.start()
                
                # Buscar startxref
                startxref_match = re.search(rb"startxref[\r\n]", data)
                if startxref_match:
                    structure["startxref_offset"] = startxref_match.start()
            except Exception as e:
                logger.warning(f"Error al analizar estructura PDF: {e}")
        
        # Archivos ZIP (incluyendo Office modernos)
        elif mime_type in ["application/zip", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                          "application/vnd.openxmlformats-officedocument.presentationml.presentation"]:
            try:
                structure["format"] = "ZIP"
                
                # Verificar firma ZIP
                if data[:4] == b"PK\x03\x04":
                    structure["signature"] = "Valid ZIP signature"
                
                # Buscar archivos dentro del ZIP
                files = []
                i = 0
                while i < len(data) - 30:  # Necesitamos al menos 30 bytes para un header local
                    if data[i:i+4] == b"PK\x03\x04":  # Local file header
                        try:
                            version = struct.unpack("<H", data[i+4:i+6])[0]
                            flags = struct.unpack("<H", data[i+6:i+8])[0]
                            compression = struct.unpack("<H", data[i+8:i+10])[0]
                            file_time = struct.unpack("<H", data[i+10:i+12])[0]
                            file_date = struct.unpack("<H", data[i+12:i+14])[0]
                            crc = struct.unpack("<I", data[i+14:i+18])[0]
                            compressed_size = struct.unpack("<I", data[i+18:i+22])[0]
                            uncompressed_size = struct.unpack("<I", data[i+22:i+26])[0]
                            name_length = struct.unpack("<H", data[i+26:i+28])[0]
                            extra_length = struct.unpack("<H", data[i+28:i+30])[0]
                            
                            if i + 30 + name_length <= len(data):
                                filename = data[i+30:i+30+name_length].decode("utf-8", errors="replace")
                                files.append({
                                    "offset": i,
                                    "filename": filename,
                                    "compressed_size": compressed_size,
                                    "uncompressed_size": uncompressed_size,
                                    "compression_method": compression
                                })
                            
                            i += 30 + name_length + extra_length + compressed_size
                        except Exception:
                            i += 1
                    else:
                        i += 1
                
                structure["files"] = files[:20]  # Limitar a 20 archivos
                structure["file_count"] = len(files)
            except Exception as e:
                logger.warning(f"Error al analizar estructura ZIP: {e}")
        
        # Ejecutables PE (Windows)
        elif mime_type == "application/x-dosexec":
            try:
                if data[:2] == b"MZ":
                    structure["format"] = "PE (Windows Executable)"
                    
                    # Obtener offset del PE header
                    pe_offset = struct.unpack("<I", data[0x3C:0x40])[0]
                    
                    # Verificar firma PE
                    if data[pe_offset:pe_offset+4] == b"PE\0\0":
                        structure["pe_header_offset"] = pe_offset
                        
                        # Obtener número de secciones
                        num_sections = struct.unpack("<H", data[pe_offset+6:pe_offset+8])[0]
                        structure["section_count"] = num_sections
                        
                        # Obtener información de secciones
                        sections = []
                        section_table_offset = pe_offset + 0x18 + struct.unpack("<H", data[pe_offset+20:pe_offset+22])[0]
                        
                        for i in range(num_sections):
                            section_offset = section_table_offset + i * 40
                            if section_offset + 40 <= len(data):
                                name = data[section_offset:section_offset+8].rstrip(b"\0").decode("ascii", errors="replace")
                                virtual_size = struct.unpack("<I", data[section_offset+8:section_offset+12])[0]
                                virtual_address = struct.unpack("<I", data[section_offset+12:section_offset+16])[0]
                                raw_size = struct.unpack("<I", data[section_offset+16:section_offset+20])[0]
                                raw_address = struct.unpack("<I", data[section_offset+20:section_offset+24])[0]
                                characteristics = struct.unpack("<I", data[section_offset+36:section_offset+40])[0]
                                
                                sections.append({
                                    "name": name,
                                    "virtual_address": virtual_address,
                                    "virtual_size": virtual_size,
                                    "raw_address": raw_address,
                                    "raw_size": raw_size,
                                    "is_code": bool(characteristics & 0x20),
                                    "is_initialized_data": bool(characteristics & 0x40),
                                    "is_uninitialized_data": bool(characteristics & 0x80),
                                    "is_executable": bool(characteristics & 0x20000000),
                                    "is_readable": bool(characteristics & 0x40000000),
                                    "is_writable": bool(characteristics & 0x80000000)
                                })
                        
                        structure["sections"] = sections
                        
                        # Obtener información de directorios
                        optional_header_offset = pe_offset + 0x18
                        data_directory_offset = optional_header_offset + 96 if data[optional_header_offset] == 0x0B else optional_header_offset + 112
                        
                        directories = []
                        directory_names = [
                            "Export Table", "Import Table", "Resource Table", "Exception Table",
                            "Certificate Table", "Base Relocation Table", "Debug", "Architecture",
                            "Global Ptr", "TLS Table", "Load Config Table", "Bound Import",
                            "IAT", "Delay Import Descriptor", "CLR Runtime Header", "Reserved"
                        ]
                        
                        for i in range(min(16, (len(data) - data_directory_offset) // 8)):
                            dir_offset = data_directory_offset + i * 8
                            rva = struct.unpack("<I", data[dir_offset:dir_offset+4])[0]
                            size = struct.unpack("<I", data[dir_offset+4:dir_offset+8])[0]
                            
                            if rva != 0 and size != 0:
                                directories.append({
                                    "name": directory_names[i],
                                    "rva": rva,
                                    "size": size
                                })
                        
                        structure["directories"] = directories
            except Exception as e:
                logger.warning(f"Error al analizar estructura PE: {e}")
        
        return structure
    
    def _find_potential_indicators(self, data: bytes, mime_type: str, strings: List[str]) -> List[Dict[str, Any]]:
        """
        Busca indicadores potenciales de interés forense.
        
        Args:
            data: Datos en bytes
            mime_type: Tipo MIME del archivo
            strings: Strings extraídos del archivo
            
        Returns:
            list: Indicadores potenciales encontrados
        """
        indicators = []
        
        # Buscar URLs
        url_pattern = re.compile(r"https?://[^\s/$.?#].[^\s]*", re.IGNORECASE)
        urls = []
        for string in strings:
            for url in url_pattern.findall(string):
                if url not in urls:
                    urls.append(url)
        
        if urls:
            indicators.append({
                "type": "URLs",
                "description": "URLs encontradas en el archivo",
                "items": urls[:10]  # Limitar a 10 URLs
            })
        
        # Buscar direcciones IP
        ip_pattern = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        ips = []
        for string in strings:
            for ip in ip_pattern.findall(string):
                # Validar que sea una IP válida
                if all(0 <= int(octet) <= 255 for octet in ip.split(".")):
                    if ip not in ips:
                        ips.append(ip)
        
        if ips:
            indicators.append({
                "type": "Direcciones IP",
                "description": "Direcciones IP encontradas en el archivo",
                "items": ips[:10]  # Limitar a 10 IPs
            })
        
        # Buscar direcciones de correo electrónico
        email_pattern = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
        emails = []
        for string in strings:
            for email in email_pattern.findall(string):
                if email not in emails:
                    emails.append(email)
        
        if emails:
            indicators.append({
                "type": "Correos electrónicos",
                "description": "Direcciones de correo electrónico encontradas en el archivo",
                "items": emails[:10]  # Limitar a 10 correos
            })
        
        # Buscar comandos de sistema
        command_patterns = [
            r"\bpowershell\s+-[^;]+", r"\bcmd\.exe\s+/[^;]+", r"\bbash\s+-[^;]+",
            r"\bsh\s+-[^;]+", r"\bwget\s+[^;]+", r"\bcurl\s+[^;]+",
            r"\bnetsh\s+[^;]+", r"\bnetcat\s+[^;]+", r"\bnc\s+[^;]+"
        ]
        
        commands = []
        for pattern in command_patterns:
            for string in strings:
                matches = re.findall(pattern, string, re.IGNORECASE)
                for match in matches:
                    if match not in commands:
                        commands.append(match)
        
        if commands:
            indicators.append({
                "type": "Comandos de sistema",
                "description": "Posibles comandos de sistema encontrados en el archivo",
                "items": commands[:10]  # Limitar a 10 comandos
            })
        
        # Buscar patrones de ofuscación
        obfuscation_patterns = [
            r"chr\(\d+\)\s*\+", r"String\.fromCharCode", r"\\x[0-9a-fA-F]{2}",
            r"\\u[0-9a-fA-F]{4}", r"base64", r"eval\(", r"document\.write\("
        ]
        
        obfuscation = []
        for pattern in obfuscation_patterns:
            for string in strings:
                if re.search(pattern, string, re.IGNORECASE):
                    if string not in obfuscation:
                        obfuscation.append(string)
        
        if obfuscation:
            indicators.append({
                "type": "Posible ofuscación",
                "description": "Patrones que podrían indicar código ofuscado",
                "items": obfuscation[:10]  # Limitar a 10 items
            })
        
        # Buscar patrones específicos según el tipo de archivo
        if mime_type == "application/x-dosexec":
            # Buscar nombres de APIs comunes en malware
            suspicious_apis = [
                "CreateProcess", "VirtualAlloc", "WriteProcessMemory", "CreateRemoteThread",
                "RegCreateKey", "HttpSendRequest", "InternetOpen", "ShellExecute",
                "WinExec", "CreateService", "socket", "connect", "WSAStartup"
            ]
            
            found_apis = []
            for api in suspicious_apis:
                for string in strings:
                    if api in string and api not in found_apis:
                        found_apis.append(api)
            
            if found_apis:
                indicators.append({
                    "type": "APIs potencialmente sospechosas",
                    "description": "APIs comúnmente utilizadas en malware",
                    "items": found_apis
                })
        
        return indicators
    
    def _convert_to_degrees(self, value) -> float:
        """
        Convierte valores de coordenadas EXIF a grados decimales.
        
        Args:
            value: Valor de coordenada EXIF
            
        Returns:
            float: Coordenada en grados decimales
        """
        d = float(value[0].num) / float(value[0].den)
        m = float(value[1].num) / float(value[1].den)
        s = float(value[2].num) / float(value[2].den)
        
        return d + (m / 60.0) + (s / 3600.0)
    
    def _format_size(self, size_bytes: int) -> str:
        """
        Formatea un tamaño en bytes a una representación legible.
        
        Args:
            size_bytes: Tamaño en bytes
            
        Returns:
            str: Tamaño formateado
        """
        if size_bytes < 1024:
            return f"{size_bytes} bytes"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.2f} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes / (1024 * 1024):.2f} MB"
        else:
            return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"
    
    def _get_png_chunk_description(self, chunk_type: str) -> str:
        """
        Obtiene la descripción de un tipo de chunk PNG.
        
        Args:
            chunk_type: Tipo de chunk PNG
            
        Returns:
            str: Descripción del chunk
        """
        chunk_descriptions = {
            "IHDR": "Header (imagen)",
            "PLTE": "Paleta de colores",
            "IDAT": "Datos de imagen",
            "IEND": "Fin de imagen",
            "tRNS": "Transparencia",
            "cHRM": "Cromaticidad primaria",
            "gAMA": "Gamma",
            "iCCP": "Perfil ICC de color",
            "sBIT": "Bits significativos",
            "sRGB": "Espacio de color RGB estándar",
            "tEXt": "Texto",
            "zTXt": "Texto comprimido",
            "iTXt": "Texto internacional",
            "bKGD": "Color de fondo",
            "hIST": "Histograma",
            "pHYs": "Dimensiones físicas",
            "sPLT": "Paleta sugerida",
            "tIME": "Tiempo de última modificación"
        }
        
        return chunk_descriptions.get(chunk_type, "Chunk desconocido")
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre análisis forense digital.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "forensic_basics": [
                "El análisis forense digital es la aplicación de técnicas científicas para identificar, preservar, analizar y presentar evidencia digital.",
                "Los principios básicos incluyen: minimizar la alteración de datos, documentar todo el proceso y mantener la cadena de custodia.",
                "Las fases típicas son: identificación, preservación, análisis, documentación y presentación.",
                "Los metadatos de archivos pueden revelar información valiosa como fechas de creación, modificación y acceso.",
                "Los hashes criptográficos (MD5, SHA-1, SHA-256) se utilizan para verificar la integridad de los datos.",
                "El análisis de memoria volátil puede revelar procesos en ejecución, conexiones de red y datos no guardados.",
                "La recuperación de datos eliminados es posible porque la eliminación generalmente solo marca el espacio como disponible.",
                "El análisis de registros del sistema puede revelar actividades de usuarios, programas ejecutados y configuraciones.",
                "Las herramientas forenses especializadas permiten examinar sistemas de archivos, recuperar datos y analizar artefactos.",
                "La esteganografía es la técnica de ocultar información dentro de archivos aparentemente inocuos."
            ],
            "file_analysis_tips": [
                "Siempre trabaja con copias de los archivos originales para preservar la evidencia.",
                "Utiliza múltiples herramientas para verificar los resultados, ya que cada una puede detectar diferentes aspectos.",
                "Presta atención a las discrepancias entre la extensión del archivo y su tipo real (magic bytes).",
                "Los metadatos pueden ser manipulados, verifica su coherencia con otras fuentes de información.",
                "Busca patrones inusuales como código ofuscado o datos ocultos en áreas no utilizadas del archivo.",
                "Analiza las cadenas de texto para encontrar URLs, direcciones IP, correos electrónicos y comandos.",
                "Compara los hashes con bases de datos de malware conocido.",
                "Examina la estructura del archivo para detectar anomalías o datos ocultos.",
                "Utiliza sandboxes para analizar el comportamiento de archivos potencialmente maliciosos.",
                "Documenta todos los hallazgos de manera clara y precisa, incluyendo metodología y herramientas utilizadas."
            ],
            "learning_resources": [
                "https://www.sans.org/digital-forensics-incident-response/ - Recursos de SANS sobre forense digital",
                "https://forensicswiki.xyz/ - Wiki colaborativa sobre herramientas y técnicas forenses",
                "https://www.sleuthkit.org/ - The Sleuth Kit, conjunto de herramientas forenses de código abierto",
                "https://www.autopsy.com/ - Autopsy, plataforma forense digital de código abierto",
                "https://www.volatilityfoundation.org/ - Volatility Framework para análisis de memoria",
                "https://www.osforensics.com/ - OSForensics, herramienta para investigaciones forenses",
                "https://www.x-ways.net/forensics/ - X-Ways Forensics, herramienta profesional de análisis forense",
                "https://www.magnetforensics.com/ - Magnet Forensics, soluciones para análisis forense digital",
                "https://www.dfrws.org/ - Digital Forensics Research Workshop, conferencias y recursos",
                "https://www.nist.gov/itl/ssd/digital-forensics - Estándares y guías de NIST sobre forense digital"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    forensic = ForensicAnalysis()
    
    # Ejemplo de uso
    try:
        with open("test_file.jpg", "rb") as f:
            file_content = f.read()
        
        import asyncio
        
        async def test():
            result = await forensic.analyze_file(file_content, "test_file.jpg")
            print(json.dumps(result, indent=2))
        
        asyncio.run(test())
    except FileNotFoundError:
        print("Archivo de prueba no encontrado")
