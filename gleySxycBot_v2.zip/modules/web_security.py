"""
Módulo para herramientas de seguridad web avanzadas.

Este módulo proporciona funcionalidades para análisis de seguridad web,
incluyendo escaneo de puertos, detección de tecnologías, análisis de cabeceras,
verificación de configuraciones SSL/TLS y detección de vulnerabilidades comunes.
"""

import logging
import requests
import json
import socket
import ssl
import re
import urllib.parse
import concurrent.futures
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
from bs4 import BeautifulSoup
import OpenSSL.crypto

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL

# Configuración de logging
logger = logging.getLogger(__name__)

class WebSecurity:
    """Clase para proporcionar herramientas de seguridad web avanzadas."""
    
    def __init__(self):
        """Inicializa la clase de herramientas de seguridad web."""
        self.shodan_api_key = get_api_key("shodan")
        self.securityheaders_api_key = get_api_key("securityheaders")
        
        # URLs de APIs
        self.securityheaders_url = "https://securityheaders.com/api/v1/"
        
        # Headers para APIs
        self.headers = {
            "User-Agent": "GleySxycBot/2.0.0 (Educational Security Bot)"
        }
        
        # Puertos comunes para escanear
        self.common_ports = {
            21: "FTP",
            22: "SSH",
            23: "Telnet",
            25: "SMTP",
            53: "DNS",
            80: "HTTP",
            110: "POP3",
            143: "IMAP",
            443: "HTTPS",
            465: "SMTPS",
            587: "SMTP (Submission)",
            993: "IMAPS",
            995: "POP3S",
            1433: "MSSQL",
            1521: "Oracle",
            3306: "MySQL",
            3389: "RDP",
            5432: "PostgreSQL",
            5900: "VNC",
            6379: "Redis",
            8080: "HTTP-Proxy",
            8443: "HTTPS-Alt",
            27017: "MongoDB"
        }
        
        # Firmas de tecnologías web
        self.tech_signatures = {
            "WordPress": [
                {"type": "html", "pattern": r"wp-content|wp-includes"},
                {"type": "header", "name": "X-Powered-By", "pattern": r"WordPress"},
                {"type": "meta", "name": "generator", "pattern": r"WordPress"}
            ],
            "Joomla": [
                {"type": "html", "pattern": r"joomla!|\/media\/jui\/"},
                {"type": "meta", "name": "generator", "pattern": r"Joomla"}
            ],
            "Drupal": [
                {"type": "html", "pattern": r"Drupal|drupal.org"},
                {"type": "meta", "name": "generator", "pattern": r"Drupal"}
            ],
            "Bootstrap": [
                {"type": "html", "pattern": r"bootstrap.min.css|bootstrap.min.js"}
            ],
            "jQuery": [
                {"type": "html", "pattern": r"jquery.min.js|jquery-\d+.\d+.\d+.min.js"}
            ],
            "React": [
                {"type": "html", "pattern": r"react.js|react.min.js|react-dom"}
            ],
            "Angular": [
                {"type": "html", "pattern": r"angular.js|angular.min.js|ng-app"}
            ],
            "Vue.js": [
                {"type": "html", "pattern": r"vue.js|vue.min.js|v-app|v-bind"}
            ],
            "PHP": [
                {"type": "header", "name": "X-Powered-By", "pattern": r"PHP"}
            ],
            "ASP.NET": [
                {"type": "header", "name": "X-Powered-By", "pattern": r"ASP.NET"},
                {"type": "header", "name": "X-AspNet-Version", "pattern": r".+"}
            ],
            "Laravel": [
                {"type": "header", "name": "Set-Cookie", "pattern": r"laravel_session"}
            ],
            "Django": [
                {"type": "header", "name": "X-Framework", "pattern": r"Django"}
            ],
            "Express.js": [
                {"type": "header", "name": "X-Powered-By", "pattern": r"Express"}
            ],
            "Nginx": [
                {"type": "header", "name": "Server", "pattern": r"nginx"}
            ],
            "Apache": [
                {"type": "header", "name": "Server", "pattern": r"Apache"}
            ],
            "IIS": [
                {"type": "header", "name": "Server", "pattern": r"Microsoft-IIS"}
            ],
            "Cloudflare": [
                {"type": "header", "name": "Server", "pattern": r"cloudflare"},
                {"type": "header", "name": "CF-Ray", "pattern": r".+"}
            ],
            "Akamai": [
                {"type": "header", "name": "Server", "pattern": r"AkamaiGHost"}
            ],
            "Fastly": [
                {"type": "header", "name": "Fastly-Debug-Digest", "pattern": r".+"}
            ]
        }
    
    async def scan_ports(self, target: str, ports: List[int] = None, timeout: float = 1.0, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Realiza un escaneo de puertos en un host objetivo.
        
        Args:
            target: Dirección IP o nombre de dominio a escanear
            ports: Lista de puertos a escanear (opcional, por defecto se usan los puertos comunes)
            timeout: Tiempo de espera para cada conexión en segundos
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del escaneo de puertos
        """
        # Validar target
        try:
            # Intentar resolver el nombre de dominio si es necesario
            ip = socket.gethostbyname(target)
        except socket.gaierror:
            return {
                "success": False,
                "message": f"No se pudo resolver el host: {target}"
            }
        
        # Verificar caché
        if db_session:
            cache_key = f"websec_portscan:{target}"
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultado en caché encontrado para escaneo de puertos: {target}")
                return cached_result
        
        logger.info(f"Escaneando puertos en: {target}")
        
        # Usar puertos comunes si no se especifican
        if ports is None:
            ports = list(self.common_ports.keys())
        
        results = {
            "success": True,
            "target": target,
            "ip": ip,
            "timestamp": datetime.now().isoformat(),
            "open_ports": [],
            "scan_time": 0
        }
        
        start_time = datetime.now()
        
        # Función para escanear un puerto
        def scan_port(port):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                result = sock.connect_ex((ip, port))
                sock.close()
                if result == 0:
                    service = self.common_ports.get(port, "Desconocido")
                    return {"port": port, "state": "open", "service": service}
                return None
            except Exception as e:
                logger.warning(f"Error al escanear puerto {port}: {e}")
                return None
        
        # Escanear puertos en paralelo
        open_ports = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
            future_to_port = {executor.submit(scan_port, port): port for port in ports}
            for future in concurrent.futures.as_completed(future_to_port):
                result = future.result()
                if result:
                    open_ports.append(result)
        
        # Ordenar por número de puerto
        open_ports.sort(key=lambda x: x["port"])
        
        end_time = datetime.now()
        scan_time = (end_time - start_time).total_seconds()
        
        results["open_ports"] = open_ports
        results["scan_time"] = scan_time
        
        # Guardar en caché
        if db_session:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "portscan", target, 
                          f"Puertos abiertos: {len(open_ports)}")
        
        return results
    
    async def analyze_headers(self, url: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza las cabeceras de seguridad de una URL.
        
        Args:
            url: URL a analizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis de cabeceras
        """
        # Validar URL
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        # Verificar caché
        if db_session:
            cache_key = f"websec_headers:{url}"
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultado en caché encontrado para análisis de cabeceras: {url}")
                return cached_result
        
        logger.info(f"Analizando cabeceras de: {url}")
        
        results = {
            "success": True,
            "url": url,
            "timestamp": datetime.now().isoformat(),
            "headers": {},
            "security_headers": {},
            "missing_headers": [],
            "score": 0
        }
        
        try:
            # Realizar solicitud
            response = requests.get(url, headers=self.headers, timeout=10, allow_redirects=True)
            response.raise_for_status()
            
            # Obtener cabeceras
            headers = dict(response.headers)
            results["headers"] = headers
            
            # Analizar cabeceras de seguridad
            security_headers = {
                "Strict-Transport-Security": {
                    "present": "Strict-Transport-Security" in headers,
                    "value": headers.get("Strict-Transport-Security", ""),
                    "description": "Fuerza conexiones HTTPS (HSTS)",
                    "recommendation": "max-age=31536000; includeSubDomains; preload"
                },
                "Content-Security-Policy": {
                    "present": "Content-Security-Policy" in headers,
                    "value": headers.get("Content-Security-Policy", ""),
                    "description": "Previene XSS y otras inyecciones",
                    "recommendation": "default-src 'self'; script-src 'self'; object-src 'none'"
                },
                "X-Content-Type-Options": {
                    "present": "X-Content-Type-Options" in headers,
                    "value": headers.get("X-Content-Type-Options", ""),
                    "description": "Previene MIME sniffing",
                    "recommendation": "nosniff"
                },
                "X-Frame-Options": {
                    "present": "X-Frame-Options" in headers,
                    "value": headers.get("X-Frame-Options", ""),
                    "description": "Previene clickjacking",
                    "recommendation": "DENY o SAMEORIGIN"
                },
                "X-XSS-Protection": {
                    "present": "X-XSS-Protection" in headers,
                    "value": headers.get("X-XSS-Protection", ""),
                    "description": "Filtro XSS en navegadores antiguos",
                    "recommendation": "1; mode=block"
                },
                "Referrer-Policy": {
                    "present": "Referrer-Policy" in headers,
                    "value": headers.get("Referrer-Policy", ""),
                    "description": "Controla información del referrer",
                    "recommendation": "strict-origin-when-cross-origin"
                },
                "Feature-Policy": {
                    "present": "Feature-Policy" in headers or "Permissions-Policy" in headers,
                    "value": headers.get("Feature-Policy", headers.get("Permissions-Policy", "")),
                    "description": "Controla características del navegador",
                    "recommendation": "camera 'none'; microphone 'none'; geolocation 'self'"
                },
                "Expect-CT": {
                    "present": "Expect-CT" in headers,
                    "value": headers.get("Expect-CT", ""),
                    "description": "Certificate Transparency",
                    "recommendation": "max-age=86400, enforce"
                }
            }
            
            results["security_headers"] = security_headers
            
            # Identificar cabeceras faltantes
            missing_headers = [header for header, info in security_headers.items() if not info["present"]]
            results["missing_headers"] = missing_headers
            
            # Calcular puntuación
            total_headers = len(security_headers)
            present_headers = total_headers - len(missing_headers)
            score = int((present_headers / total_headers) * 100)
            results["score"] = score
            
            # Verificar si hay cabeceras que revelan información sensible
            sensitive_headers = ["Server", "X-Powered-By", "X-AspNet-Version", "X-Runtime"]
            results["sensitive_headers"] = [header for header in sensitive_headers if header in headers]
            
            # Verificar si hay cookies inseguras
            cookies = response.cookies
            insecure_cookies = []
            for cookie in cookies:
                if not cookie.secure or not cookie.has_nonstandard_attr("HttpOnly"):
                    insecure_cookies.append({
                        "name": cookie.name,
                        "secure": cookie.secure,
                        "httponly": cookie.has_nonstandard_attr("HttpOnly"),
                        "samesite": cookie.get_nonstandard_attr("SameSite", "None")
                    })
            results["insecure_cookies"] = insecure_cookies
            
            # Usar SecurityHeaders.com API si está disponible
            if has_api_key("securityheaders"):
                try:
                    api_url = f"{self.securityheaders_url}?q={urllib.parse.quote_plus(url)}&hide=on"
                    api_headers = {
                        "X-Api-Key": self.securityheaders_api_key,
                        **self.headers
                    }
                    api_response = requests.get(api_url, headers=api_headers, timeout=10)
                    api_response.raise_for_status()
                    api_data = api_response.json()
                    
                    results["securityheaders_grade"] = api_data.get("grade", "?")
                    results["securityheaders_score"] = api_data.get("score", 0)
                    
                    if db_session and user_id:
                        log_api_usage(db_session, user_id, "securityheaders", "scan", success=True)
                except Exception as e:
                    logger.warning(f"Error al usar SecurityHeaders API: {e}")
                    if db_session and user_id:
                        log_api_usage(db_session, user_id, "securityheaders", "scan", success=False, error_message=str(e))
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error al analizar cabeceras: {e}")
            return {
                "success": False,
                "message": f"Error al conectar con la URL: {str(e)}"
            }
        
        # Guardar en caché
        if db_session:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "headers", url, 
                          f"Score: {results['score']}/100, Faltantes: {len(missing_headers)}")
        
        return results
    
    async def analyze_ssl_tls(self, domain: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza la configuración SSL/TLS de un dominio.
        
        Args:
            domain: Dominio a analizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis SSL/TLS
        """
        # Eliminar protocolo si está presente
        domain = re.sub(r'^https?://', '', domain)
        # Eliminar ruta si está presente
        domain = domain.split('/')[0]
        
        # Verificar caché
        if db_session:
            cache_key = f"websec_ssl:{domain}"
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultado en caché encontrado para análisis SSL/TLS: {domain}")
                return cached_result
        
        logger.info(f"Analizando SSL/TLS de: {domain}")
        
        results = {
            "success": True,
            "domain": domain,
            "timestamp": datetime.now().isoformat(),
            "certificate": {},
            "protocols": {},
            "cipher_suites": [],
            "vulnerabilities": [],
            "score": 0
        }
        
        try:
            # Conectar al servidor
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            with socket.create_connection((domain, 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    # Obtener versión de protocolo
                    protocol_version = ssock.version()
                    
                    # Obtener certificado
                    cert_bin = ssock.getpeercert(binary_form=True)
                    cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_ASN1, cert_bin)
                    
                    # Obtener información del certificado
                    issuer = dict(cert.get_issuer().get_components())
                    issuer = {k.decode(): v.decode() for k, v in issuer.items()}
                    
                    subject = dict(cert.get_subject().get_components())
                    subject = {k.decode(): v.decode() for k, v in subject.items()}
                    
                    not_before = datetime.strptime(cert.get_notBefore().decode(), "%Y%m%d%H%M%SZ")
                    not_after = datetime.strptime(cert.get_notAfter().decode(), "%Y%m%d%H%M%SZ")
                    
                    # Verificar si está expirado
                    now = datetime.now()
                    is_expired = now > not_after
                    is_not_yet_valid = now < not_before
                    
                    # Verificar si es autofirmado
                    is_self_signed = cert.get_issuer().hash() == cert.get_subject().hash()
                    
                    # Verificar algoritmo de firma
                    signature_algorithm = cert.get_signature_algorithm().decode()
                    
                    # Verificar si usa SHA-1 (débil)
                    uses_sha1 = 'sha1' in signature_algorithm.lower()
                    
                    # Verificar nombres alternativos del sujeto (SAN)
                    san = []
                    for i in range(cert.get_extension_count()):
                        ext = cert.get_extension(i)
                        if ext.get_short_name().decode() == 'subjectAltName':
                            san_text = ext.__str__()
                            san = [name.strip() for name in san_text.split(',')]
                    
                    # Almacenar información del certificado
                    results["certificate"] = {
                        "issuer": issuer,
                        "subject": subject,
                        "valid_from": not_before.isoformat(),
                        "valid_until": not_after.isoformat(),
                        "is_expired": is_expired,
                        "is_not_yet_valid": is_not_yet_valid,
                        "is_self_signed": is_self_signed,
                        "signature_algorithm": signature_algorithm,
                        "uses_weak_algorithm": uses_sha1,
                        "subject_alternative_names": san,
                        "serial_number": hex(cert.get_serial_number()),
                        "version": cert.get_version()
                    }
                    
                    # Almacenar información del protocolo
                    results["protocols"] = {
                        "name": protocol_version,
                        "supported": True
                    }
                    
                    # Obtener suite de cifrado
                    cipher = ssock.cipher()
                    if cipher:
                        results["cipher_suites"].append({
                            "name": cipher[0],
                            "version": cipher[1],
                            "bits": cipher[2]
                        })
            
            # Verificar vulnerabilidades conocidas
            vulnerabilities = []
            
            # Verificar si el certificado es válido
            if is_expired:
                vulnerabilities.append({
                    "name": "Certificado expirado",
                    "severity": "Alta",
                    "description": "El certificado SSL ha expirado y ya no es válido."
                })
            
            if is_not_yet_valid:
                vulnerabilities.append({
                    "name": "Certificado aún no válido",
                    "severity": "Alta",
                    "description": "El certificado SSL aún no es válido (fecha futura)."
                })
            
            if is_self_signed:
                vulnerabilities.append({
                    "name": "Certificado autofirmado",
                    "severity": "Alta",
                    "description": "El certificado está autofirmado y no es de confianza."
                })
            
            if uses_sha1:
                vulnerabilities.append({
                    "name": "Algoritmo de firma débil",
                    "severity": "Media",
                    "description": "El certificado utiliza SHA-1, que se considera inseguro."
                })
            
            # Verificar protocolo
            if protocol_version == "TLSv1" or protocol_version == "TLSv1.1":
                vulnerabilities.append({
                    "name": f"Protocolo obsoleto: {protocol_version}",
                    "severity": "Media",
                    "description": f"El servidor utiliza {protocol_version}, que se considera obsoleto."
                })
            elif protocol_version == "SSLv3" or protocol_version == "SSLv2":
                vulnerabilities.append({
                    "name": f"Protocolo inseguro: {protocol_version}",
                    "severity": "Alta",
                    "description": f"El servidor utiliza {protocol_version}, que se considera inseguro."
                })
            
            # Verificar cipher suite
            for cipher in results["cipher_suites"]:
                if "NULL" in cipher["name"] or "anon" in cipher["name"] or "RC4" in cipher["name"] or "DES" in cipher["name"]:
                    vulnerabilities.append({
                        "name": f"Cipher suite débil: {cipher['name']}",
                        "severity": "Alta",
                        "description": f"El servidor utiliza una cipher suite débil: {cipher['name']}"
                    })
                elif "CBC" in cipher["name"]:
                    vulnerabilities.append({
                        "name": f"Cipher suite potencialmente vulnerable: {cipher['name']}",
                        "severity": "Media",
                        "description": f"El servidor utiliza una cipher suite que podría ser vulnerable a ataques BEAST: {cipher['name']}"
                    })
            
            results["vulnerabilities"] = vulnerabilities
            
            # Calcular puntuación
            score = 100
            
            # Restar por vulnerabilidades
            for vuln in vulnerabilities:
                if vuln["severity"] == "Alta":
                    score -= 25
                elif vuln["severity"] == "Media":
                    score -= 15
                else:
                    score -= 5
            
            # Asegurar que la puntuación esté en el rango 0-100
            results["score"] = max(0, min(score, 100))
            
        except (socket.gaierror, socket.timeout) as e:
            logger.error(f"Error al conectar con el dominio: {e}")
            return {
                "success": False,
                "message": f"Error al conectar con el dominio: {str(e)}"
            }
        except ssl.SSLError as e:
            logger.error(f"Error SSL: {e}")
            return {
                "success": False,
                "message": f"Error SSL: {str(e)}"
            }
        except Exception as e:
            logger.error(f"Error al analizar SSL/TLS: {e}")
            return {
                "success": False,
                "message": f"Error al analizar SSL/TLS: {str(e)}"
            }
        
        # Guardar en caché
        if db_session:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "ssl", domain, 
                          f"Score: {results['score']}/100, Vulnerabilidades: {len(vulnerabilities)}")
        
        return results
    
    async def detect_technologies(self, url: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Detecta tecnologías utilizadas en un sitio web.
        
        Args:
            url: URL a analizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Tecnologías detectadas
        """
        # Validar URL
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        # Verificar caché
        if db_session:
            cache_key = f"websec_tech:{url}"
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultado en caché encontrado para detección de tecnologías: {url}")
                return cached_result
        
        logger.info(f"Detectando tecnologías en: {url}")
        
        results = {
            "success": True,
            "url": url,
            "timestamp": datetime.now().isoformat(),
            "technologies": [],
            "server": None,
            "frameworks": [],
            "cms": None,
            "javascript_libraries": []
        }
        
        try:
            # Realizar solicitud
            response = requests.get(url, headers=self.headers, timeout=10)
            response.raise_for_status()
            
            # Obtener cabeceras
            headers = dict(response.headers)
            
            # Obtener contenido HTML
            html_content = response.text
            
            # Parsear HTML
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Detectar tecnologías
            detected_tech = []
            
            for tech_name, signatures in self.tech_signatures.items():
                for signature in signatures:
                    if signature["type"] == "html":
                        if re.search(signature["pattern"], html_content, re.IGNORECASE):
                            detected_tech.append(tech_name)
                            break
                    elif signature["type"] == "header":
                        header_name = signature["name"]
                        if header_name in headers and re.search(signature["pattern"], headers[header_name], re.IGNORECASE):
                            detected_tech.append(tech_name)
                            break
                    elif signature["type"] == "meta":
                        meta_name = signature["name"]
                        meta_tag = soup.find("meta", attrs={"name": meta_name})
                        if meta_tag and "content" in meta_tag.attrs and re.search(signature["pattern"], meta_tag["content"], re.IGNORECASE):
                            detected_tech.append(tech_name)
                            break
            
            # Eliminar duplicados
            detected_tech = list(set(detected_tech))
            
            # Clasificar tecnologías
            server = None
            frameworks = []
            cms = None
            js_libraries = []
            
            for tech in detected_tech:
                if tech in ["Nginx", "Apache", "IIS"]:
                    server = tech
                elif tech in ["Laravel", "Django", "Express.js", "ASP.NET"]:
                    frameworks.append(tech)
                elif tech in ["WordPress", "Joomla", "Drupal"]:
                    cms = tech
                elif tech in ["jQuery", "React", "Angular", "Vue.js"]:
                    js_libraries.append(tech)
            
            # Almacenar resultados
            results["technologies"] = detected_tech
            results["server"] = server
            results["frameworks"] = frameworks
            results["cms"] = cms
            results["javascript_libraries"] = js_libraries
            
            # Detectar versiones (simplificado)
            versions = {}
            
            # WordPress
            if "WordPress" in detected_tech:
                wp_version_meta = soup.find("meta", attrs={"name": "generator"})
                if wp_version_meta and "content" in wp_version_meta.attrs and "WordPress" in wp_version_meta["content"]:
                    wp_version_match = re.search(r"WordPress\s+([\d.]+)", wp_version_meta["content"])
                    if wp_version_match:
                        versions["WordPress"] = wp_version_match.group(1)
            
            # jQuery
            if "jQuery" in detected_tech:
                jquery_scripts = soup.find_all("script", src=re.compile(r"jquery[-.](\d+\.\d+\.\d+)(\.min)?\.js"))
                for script in jquery_scripts:
                    jquery_version_match = re.search(r"jquery[-.](\d+\.\d+\.\d+)(\.min)?\.js", script["src"])
                    if jquery_version_match:
                        versions["jQuery"] = jquery_version_match.group(1)
                        break
            
            results["versions"] = versions
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error al detectar tecnologías: {e}")
            return {
                "success": False,
                "message": f"Error al conectar con la URL: {str(e)}"
            }
        
        # Guardar en caché
        if db_session:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "tech", url, 
                          f"Tecnologías: {len(detected_tech)}")
        
        return results
    
    async def check_common_vulnerabilities(self, url: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Verifica vulnerabilidades comunes en un sitio web.
        
        Args:
            url: URL a analizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados de la verificación de vulnerabilidades
        """
        # Validar URL
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        # Verificar caché
        if db_session:
            cache_key = f"websec_vulns:{url}"
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultado en caché encontrado para verificación de vulnerabilidades: {url}")
                return cached_result
        
        logger.info(f"Verificando vulnerabilidades comunes en: {url}")
        
        results = {
            "success": True,
            "url": url,
            "timestamp": datetime.now().isoformat(),
            "vulnerabilities": [],
            "warnings": [],
            "info": []
        }
        
        try:
            # Realizar solicitud principal
            response = requests.get(url, headers=self.headers, timeout=10)
            response.raise_for_status()
            
            # Obtener cabeceras
            headers = dict(response.headers)
            
            # Obtener contenido HTML
            html_content = response.text
            
            # Parsear HTML
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Verificar formularios sin CSRF protection
            forms = soup.find_all("form")
            for form in forms:
                csrf_token = form.find("input", attrs={"name": re.compile(r"csrf|token", re.IGNORECASE)})
                if not csrf_token and form.get("method", "").lower() == "post":
                    results["warnings"].append({
                        "type": "CSRF",
                        "description": "Formulario POST sin token CSRF visible",
                        "location": str(form)[:100] + "..." if len(str(form)) > 100 else str(form)
                    })
            
            # Verificar inputs vulnerables a XSS
            inputs = soup.find_all("input")
            for input_tag in inputs:
                if input_tag.get("type") in ["text", "search", "url", "tel", "email", None]:
                    results["info"].append({
                        "type": "Posible XSS",
                        "description": "Input que podría ser vulnerable a XSS si no se sanitiza correctamente",
                        "location": str(input_tag)[:100] + "..." if len(str(input_tag)) > 100 else str(input_tag)
                    })
            
            # Verificar cabeceras de seguridad faltantes
            security_headers = [
                "Content-Security-Policy",
                "X-Content-Type-Options",
                "X-Frame-Options",
                "X-XSS-Protection",
                "Strict-Transport-Security"
            ]
            
            for header in security_headers:
                if header not in headers:
                    results["warnings"].append({
                        "type": "Cabecera faltante",
                        "description": f"La cabecera de seguridad {header} no está presente",
                        "recommendation": f"Añadir la cabecera {header}"
                    })
            
            # Verificar si hay información sensible en el HTML
            sensitive_patterns = [
                (r"apikey\s*[=:]\s*['\"]([\w\-]+)['\"]", "API Key"),
                (r"password\s*[=:]\s*['\"]([\w\-]+)['\"]", "Contraseña"),
                (r"secret\s*[=:]\s*['\"]([\w\-]+)['\"]", "Secreto"),
                (r"token\s*[=:]\s*['\"]([\w\-]+)['\"]", "Token"),
                (r"database\s*[=:]\s*['\"]([\w\-]+)['\"]", "Base de datos"),
                (r"<!--.*?-->", "Comentario HTML")
            ]
            
            for pattern, desc in sensitive_patterns:
                matches = re.findall(pattern, html_content, re.IGNORECASE)
                if matches:
                    results["warnings"].append({
                        "type": "Información sensible",
                        "description": f"Posible {desc} encontrado en el código fuente",
                        "count": len(matches)
                    })
            
            # Verificar archivos sensibles
            sensitive_files = [
                "/robots.txt",
                "/.git/HEAD",
                "/.env",
                "/config.php",
                "/wp-config.php",
                "/phpinfo.php",
                "/.htaccess",
                "/server-status",
                "/admin",
                "/backup"
            ]
            
            base_url = urllib.parse.urlparse(url)
            base_url = f"{base_url.scheme}://{base_url.netloc}"
            
            for file_path in sensitive_files[:3]:  # Limitar a 3 para evitar muchas solicitudes
                try:
                    file_url = base_url + file_path
                    file_response = requests.head(file_url, headers=self.headers, timeout=5)
                    
                    if file_response.status_code == 200:
                        results["warnings"].append({
                            "type": "Archivo sensible",
                            "description": f"El archivo {file_path} es accesible",
                            "url": file_url
                        })
                except Exception:
                    pass
            
            # Verificar si es WordPress y tiene vulnerabilidades comunes
            if "WordPress" in html_content:
                # Verificar si expone la versión
                wp_version_meta = soup.find("meta", attrs={"name": "generator"})
                if wp_version_meta and "content" in wp_version_meta.attrs and "WordPress" in wp_version_meta["content"]:
                    results["warnings"].append({
                        "type": "Exposición de versión",
                        "description": f"La versión de WordPress está expuesta: {wp_version_meta['content']}",
                        "recommendation": "Ocultar la versión de WordPress"
                    })
                
                # Verificar si el directorio wp-content es navegable
                try:
                    wp_content_url = base_url + "/wp-content/"
                    wp_content_response = requests.head(wp_content_url, headers=self.headers, timeout=5)
                    
                    if wp_content_response.status_code == 200:
                        results["warnings"].append({
                            "type": "Directorio navegable",
                            "description": "El directorio wp-content es navegable",
                            "url": wp_content_url,
                            "recommendation": "Deshabilitar la navegación de directorios"
                        })
                except Exception:
                    pass
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error al verificar vulnerabilidades: {e}")
            return {
                "success": False,
                "message": f"Error al conectar con la URL: {str(e)}"
            }
        
        # Guardar en caché
        if db_session:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "vulns", url, 
                          f"Advertencias: {len(results['warnings'])}, Info: {len(results['info'])}")
        
        return results
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre seguridad web.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "web_security_basics": [
                "La seguridad web es un conjunto de prácticas para proteger sitios y aplicaciones web.",
                "Las vulnerabilidades más comunes incluyen XSS, CSRF, inyección SQL y configuraciones incorrectas.",
                "El proyecto OWASP Top 10 identifica las vulnerabilidades web más críticas.",
                "Las cabeceras HTTP de seguridad ayudan a mitigar varios tipos de ataques.",
                "El cifrado SSL/TLS es esencial para proteger la comunicación entre cliente y servidor.",
                "La autenticación y autorización adecuadas son fundamentales para la seguridad web.",
                "La validación de entrada y sanitización de salida previenen muchos ataques de inyección.",
                "Las actualizaciones regulares de software son cruciales para corregir vulnerabilidades conocidas.",
                "El principio de menor privilegio debe aplicarse a todos los componentes web.",
                "El monitoreo y logging son importantes para detectar y responder a incidentes."
            ],
            "security_tips": [
                "Implementa HTTPS en todo tu sitio web utilizando certificados válidos.",
                "Configura correctamente las cabeceras de seguridad HTTP.",
                "Utiliza tokens CSRF en todos los formularios POST.",
                "Sanitiza todas las entradas de usuario para prevenir XSS e inyecciones.",
                "Implementa una política de contraseñas fuerte y considera la autenticación de dos factores.",
                "Mantén actualizado todo el software, incluyendo CMS, plugins y bibliotecas.",
                "Configura correctamente los permisos de archivos y directorios.",
                "Utiliza WAF (Web Application Firewall) para protección adicional.",
                "Realiza auditorías y pruebas de penetración regularmente.",
                "Implementa el principio de defensa en profundidad con múltiples capas de seguridad."
            ],
            "learning_resources": [
                "https://owasp.org/www-project-top-ten/ - OWASP Top 10",
                "https://developer.mozilla.org/es/docs/Web/HTTP/Headers/Content-Security-Policy - Guía de CSP",
                "https://securityheaders.com/ - Análisis de cabeceras de seguridad",
                "https://www.ssllabs.com/ssltest/ - Prueba de configuración SSL/TLS",
                "https://portswigger.net/web-security - Academia de seguridad web",
                "https://cheatsheetseries.owasp.org/ - Hojas de referencia de OWASP",
                "https://www.hacksplaining.com/ - Lecciones interactivas sobre vulnerabilidades",
                "https://www.zaproxy.org/ - Herramienta de pruebas de seguridad",
                "https://observatory.mozilla.org/ - Observatorio de seguridad web de Mozilla",
                "https://www.troyhunt.com/ - Blog de seguridad de Troy Hunt"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    web_security = WebSecurity()
    import asyncio
    
    async def test():
        # Test port scanning
        scan_result = await web_security.scan_ports("example.com", [80, 443, 8080])
        print("\n--- Port Scan Results ---")
        print(json.dumps(scan_result, indent=2))
        
        # Test header analysis
        headers_result = await web_security.analyze_headers("https://example.com")
        print("\n--- Header Analysis Results ---")
        print(json.dumps(headers_result, indent=2))
        
        # Test SSL/TLS analysis
        ssl_result = await web_security.analyze_ssl_tls("example.com")
        print("\n--- SSL/TLS Analysis Results ---")
        print(json.dumps(ssl_result, indent=2))
        
        # Test technology detection
        tech_result = await web_security.detect_technologies("https://example.com")
        print("\n--- Technology Detection Results ---")
        print(json.dumps(tech_result, indent=2))
        
        # Test vulnerability check
        vuln_result = await web_security.check_common_vulnerabilities("https://example.com")
        print("\n--- Vulnerability Check Results ---")
        print(json.dumps(vuln_result, indent=2))
    
    asyncio.run(test())
