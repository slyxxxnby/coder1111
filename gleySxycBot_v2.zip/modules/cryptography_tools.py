"""
Módulo para criptografía práctica.

Este módulo proporciona herramientas para cifrado/descifrado, hashing,
generación de claves, firma digital y análisis de algoritmos criptográficos.
"""

import logging
import os
import hashlib
import base64
import binascii
import secrets
import string
import re
import json
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union

# Importar bibliotecas criptográficas
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes, padding
from cryptography.hazmat.primitives.asymmetric import rsa, padding as asymmetric_padding
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.serialization import load_pem_private_key, load_pem_public_key
from cryptography.hazmat.primitives.serialization import Encoding, PrivateFormat, PublicFormat, NoEncryption
from cryptography.exceptions import InvalidSignature

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import CACHE_TTL

# Configuración de logging
logger = logging.getLogger(__name__)

class CryptographyTools:
    """Clase para herramientas de criptografía práctica."""
    
    def __init__(self):
        """Inicializa la clase de herramientas criptográficas."""
        self.supported_hash_algorithms = {
            "md5": hashlib.md5,
            "sha1": hashlib.sha1,
            "sha224": hashlib.sha224,
            "sha256": hashlib.sha256,
            "sha384": hashlib.sha384,
            "sha512": hashlib.sha512,
            "sha3_224": hashlib.sha3_224,
            "sha3_256": hashlib.sha3_256,
            "sha3_384": hashlib.sha3_384,
            "sha3_512": hashlib.sha3_512,
            "blake2b": hashlib.blake2b,
            "blake2s": hashlib.blake2s
        }
        
        self.supported_symmetric_algorithms = {
            "aes-128-cbc": {"algorithm": algorithms.AES, "key_size": 16, "mode": modes.CBC},
            "aes-192-cbc": {"algorithm": algorithms.AES, "key_size": 24, "mode": modes.CBC},
            "aes-256-cbc": {"algorithm": algorithms.AES, "key_size": 32, "mode": modes.CBC},
            "aes-128-ctr": {"algorithm": algorithms.AES, "key_size": 16, "mode": modes.CTR},
            "aes-192-ctr": {"algorithm": algorithms.AES, "key_size": 24, "mode": modes.CTR},
            "aes-256-ctr": {"algorithm": algorithms.AES, "key_size": 32, "mode": modes.CTR},
            "chacha20": {"algorithm": algorithms.ChaCha20, "key_size": 32, "nonce_size": 16}
        }
    
    async def calculate_hash(self, data: str, algorithm: str = "sha256", db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Calcula el hash de una cadena de texto utilizando el algoritmo especificado.
        
        Args:
            data: Texto a hashear
            algorithm: Algoritmo de hash a utilizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el cálculo (opcional)
            
        Returns:
            dict: Resultado del cálculo de hash
        """
        if algorithm not in self.supported_hash_algorithms:
            return {
                "success": False,
                "message": f"Algoritmo no soportado. Algoritmos disponibles: {', '.join(self.supported_hash_algorithms.keys())}"
            }
        
        logger.info(f"Calculando hash {algorithm} para texto")
        
        results = {
            "success": True,
            "algorithm": algorithm,
            "timestamp": datetime.now().isoformat(),
            "hash": None
        }
        
        try:
            # Calcular hash
            hash_func = self.supported_hash_algorithms[algorithm]
            hash_result = hash_func(data.encode('utf-8')).hexdigest()
            results["hash"] = hash_result
            
        except Exception as e:
            logger.error(f"Error al calcular hash: {e}")
            results["success"] = False
            results["message"] = f"Error al calcular hash: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "hash", algorithm, 
                      f"Texto: {data[:20]}{'...' if len(data) > 20 else ''}")
            
        return results
    
    async def generate_key_pair(self, key_size: int = 2048, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Genera un par de claves RSA.
        
        Args:
            key_size: Tamaño de la clave en bits
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la generación (opcional)
            
        Returns:
            dict: Par de claves generado
        """
        if key_size not in [1024, 2048, 3072, 4096]:
            return {
                "success": False,
                "message": "Tamaño de clave no válido. Valores permitidos: 1024, 2048, 3072, 4096"
            }
        
        logger.info(f"Generando par de claves RSA de {key_size} bits")
        
        results = {
            "success": True,
            "key_size": key_size,
            "timestamp": datetime.now().isoformat(),
            "private_key": None,
            "public_key": None
        }
        
        try:
            # Generar par de claves
            private_key = rsa.generate_private_key(
                public_exponent=65537,
                key_size=key_size
            )
            public_key = private_key.public_key()
            
            # Serializar claves a formato PEM
            private_pem = private_key.private_bytes(
                encoding=Encoding.PEM,
                format=PrivateFormat.PKCS8,
                encryption_algorithm=NoEncryption()
            ).decode('utf-8')
            
            public_pem = public_key.public_bytes(
                encoding=Encoding.PEM,
                format=PublicFormat.SubjectPublicKeyInfo
            ).decode('utf-8')
            
            results["private_key"] = private_pem
            results["public_key"] = public_pem
            
        except Exception as e:
            logger.error(f"Error al generar par de claves: {e}")
            results["success"] = False
            results["message"] = f"Error al generar par de claves: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "keypair", f"RSA-{key_size}", 
                      "Par de claves RSA generado")
            
        return results
    
    async def encrypt_symmetric(self, plaintext: str, password: str, algorithm: str = "aes-256-cbc", db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Cifra un texto utilizando un algoritmo simétrico.
        
        Args:
            plaintext: Texto a cifrar
            password: Contraseña para derivar la clave
            algorithm: Algoritmo de cifrado a utilizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el cifrado (opcional)
            
        Returns:
            dict: Resultado del cifrado
        """
        if algorithm not in self.supported_symmetric_algorithms:
            return {
                "success": False,
                "message": f"Algoritmo no soportado. Algoritmos disponibles: {', '.join(self.supported_symmetric_algorithms.keys())}"
            }
        
        logger.info(f"Cifrando texto con {algorithm}")
        
        results = {
            "success": True,
            "algorithm": algorithm,
            "timestamp": datetime.now().isoformat(),
            "ciphertext": None,
            "iv": None,
            "salt": None,
            "nonce": None
        }
        
        try:
            # Generar salt para derivación de clave
            salt = os.urandom(16)
            
            # Derivar clave a partir de la contraseña
            algo_info = self.supported_symmetric_algorithms[algorithm]
            key_size = algo_info["key_size"]
            
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=key_size,
                salt=salt,
                iterations=100000
            )
            key = kdf.derive(password.encode('utf-8'))
            
            # Cifrar según el algoritmo
            if "chacha20" in algorithm:
                # ChaCha20 requiere un nonce
                nonce = os.urandom(16)
                cipher = Cipher(algo_info["algorithm"](key, nonce), mode=None)
                encryptor = cipher.encryptor()
                ciphertext = encryptor.update(plaintext.encode('utf-8')) + encryptor.finalize()
                
                results["ciphertext"] = base64.b64encode(ciphertext).decode('utf-8')
                results["nonce"] = base64.b64encode(nonce).decode('utf-8')
                results["salt"] = base64.b64encode(salt).decode('utf-8')
                
            else:
                # Algoritmos que requieren IV (como AES-CBC)
                iv = os.urandom(16)
                
                # Crear modo según el algoritmo
                if "cbc" in algorithm:
                    mode = algo_info["mode"](iv)
                    # Aplicar padding para CBC
                    padder = padding.PKCS7(128).padder()
                    padded_data = padder.update(plaintext.encode('utf-8')) + padder.finalize()
                    
                    cipher = Cipher(algo_info["algorithm"](key), mode)
                    encryptor = cipher.encryptor()
                    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
                    
                elif "ctr" in algorithm:
                    mode = algo_info["mode"](iv)
                    cipher = Cipher(algo_info["algorithm"](key), mode)
                    encryptor = cipher.encryptor()
                    ciphertext = encryptor.update(plaintext.encode('utf-8')) + encryptor.finalize()
                
                results["ciphertext"] = base64.b64encode(ciphertext).decode('utf-8')
                results["iv"] = base64.b64encode(iv).decode('utf-8')
                results["salt"] = base64.b64encode(salt).decode('utf-8')
            
        except Exception as e:
            logger.error(f"Error al cifrar texto: {e}")
            results["success"] = False
            results["message"] = f"Error al cifrar texto: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "encrypt", algorithm, 
                      f"Texto cifrado: {len(plaintext)} caracteres")
            
        return results
    
    async def decrypt_symmetric(self, ciphertext: str, password: str, algorithm: str = "aes-256-cbc", 
                               iv: str = None, salt: str = None, nonce: str = None, 
                               db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Descifra un texto utilizando un algoritmo simétrico.
        
        Args:
            ciphertext: Texto cifrado en base64
            password: Contraseña para derivar la clave
            algorithm: Algoritmo de cifrado utilizado
            iv: Vector de inicialización en base64 (para CBC/CTR)
            salt: Salt en base64 utilizado para derivar la clave
            nonce: Nonce en base64 (para ChaCha20)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el descifrado (opcional)
            
        Returns:
            dict: Resultado del descifrado
        """
        if algorithm not in self.supported_symmetric_algorithms:
            return {
                "success": False,
                "message": f"Algoritmo no soportado. Algoritmos disponibles: {', '.join(self.supported_symmetric_algorithms.keys())}"
            }
        
        # Verificar parámetros necesarios según algoritmo
        if "chacha20" in algorithm and not nonce:
            return {
                "success": False,
                "message": "Se requiere un nonce para descifrar con ChaCha20"
            }
        
        if "chacha20" not in algorithm and not iv:
            return {
                "success": False,
                "message": f"Se requiere un IV para descifrar con {algorithm}"
            }
        
        if not salt:
            return {
                "success": False,
                "message": "Se requiere un salt para derivar la clave"
            }
        
        logger.info(f"Descifrando texto con {algorithm}")
        
        results = {
            "success": True,
            "algorithm": algorithm,
            "timestamp": datetime.now().isoformat(),
            "plaintext": None
        }
        
        try:
            # Decodificar datos de base64
            ciphertext_bytes = base64.b64decode(ciphertext)
            salt_bytes = base64.b64decode(salt)
            
            # Derivar clave a partir de la contraseña
            algo_info = self.supported_symmetric_algorithms[algorithm]
            key_size = algo_info["key_size"]
            
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=key_size,
                salt=salt_bytes,
                iterations=100000
            )
            key = kdf.derive(password.encode('utf-8'))
            
            # Descifrar según el algoritmo
            if "chacha20" in algorithm:
                # ChaCha20 requiere un nonce
                nonce_bytes = base64.b64decode(nonce)
                cipher = Cipher(algo_info["algorithm"](key, nonce_bytes), mode=None)
                decryptor = cipher.decryptor()
                plaintext = decryptor.update(ciphertext_bytes) + decryptor.finalize()
                
            else:
                # Algoritmos que requieren IV (como AES-CBC)
                iv_bytes = base64.b64decode(iv)
                
                # Crear modo según el algoritmo
                if "cbc" in algorithm:
                    mode = algo_info["mode"](iv_bytes)
                    cipher = Cipher(algo_info["algorithm"](key), mode)
                    decryptor = cipher.decryptor()
                    padded_plaintext = decryptor.update(ciphertext_bytes) + decryptor.finalize()
                    
                    # Quitar padding
                    unpadder = padding.PKCS7(128).unpadder()
                    plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()
                    
                elif "ctr" in algorithm:
                    mode = algo_info["mode"](iv_bytes)
                    cipher = Cipher(algo_info["algorithm"](key), mode)
                    decryptor = cipher.decryptor()
                    plaintext = decryptor.update(ciphertext_bytes) + decryptor.finalize()
            
            # Decodificar texto plano
            results["plaintext"] = plaintext.decode('utf-8')
            
        except Exception as e:
            logger.error(f"Error al descifrar texto: {e}")
            results["success"] = False
            results["message"] = f"Error al descifrar texto: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "decrypt", algorithm, 
                      "Texto descifrado")
            
        return results
    
    async def sign_data(self, data: str, private_key_pem: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Firma datos utilizando una clave privada RSA.
        
        Args:
            data: Datos a firmar
            private_key_pem: Clave privada en formato PEM
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la firma (opcional)
            
        Returns:
            dict: Resultado de la firma
        """
        logger.info("Firmando datos con clave privada RSA")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "signature": None
        }
        
        try:
            # Cargar clave privada
            private_key = load_pem_private_key(
                private_key_pem.encode('utf-8'),
                password=None
            )
            
            # Firmar datos
            signature = private_key.sign(
                data.encode('utf-8'),
                asymmetric_padding.PSS(
                    mgf=asymmetric_padding.MGF1(hashes.SHA256()),
                    salt_length=asymmetric_padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            
            results["signature"] = base64.b64encode(signature).decode('utf-8')
            
        except Exception as e:
            logger.error(f"Error al firmar datos: {e}")
            results["success"] = False
            results["message"] = f"Error al firmar datos: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "sign", "RSA-PSS-SHA256", 
                      f"Datos firmados: {len(data)} caracteres")
            
        return results
    
    async def verify_signature(self, data: str, signature: str, public_key_pem: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Verifica una firma utilizando una clave pública RSA.
        
        Args:
            data: Datos originales
            signature: Firma en base64
            public_key_pem: Clave pública en formato PEM
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la verificación (opcional)
            
        Returns:
            dict: Resultado de la verificación
        """
        logger.info("Verificando firma con clave pública RSA")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "is_valid": False
        }
        
        try:
            # Cargar clave pública
            public_key = load_pem_public_key(
                public_key_pem.encode('utf-8')
            )
            
            # Decodificar firma
            signature_bytes = base64.b64decode(signature)
            
            # Verificar firma
            try:
                public_key.verify(
                    signature_bytes,
                    data.encode('utf-8'),
                    asymmetric_padding.PSS(
                        mgf=asymmetric_padding.MGF1(hashes.SHA256()),
                        salt_length=asymmetric_padding.PSS.MAX_LENGTH
                    ),
                    hashes.SHA256()
                )
                results["is_valid"] = True
            except InvalidSignature:
                results["is_valid"] = False
            
        except Exception as e:
            logger.error(f"Error al verificar firma: {e}")
            results["success"] = False
            results["message"] = f"Error al verificar firma: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "verify", "RSA-PSS-SHA256", 
                      f"Verificación: {'Válida' if results.get('is_valid') else 'Inválida'}")
            
        return results
    
    async def generate_password(self, length: int = 16, include_uppercase: bool = True, 
                              include_lowercase: bool = True, include_digits: bool = True, 
                              include_symbols: bool = True, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Genera una contraseña aleatoria segura.
        
        Args:
            length: Longitud de la contraseña
            include_uppercase: Incluir letras mayúsculas
            include_lowercase: Incluir letras minúsculas
            include_digits: Incluir dígitos
            include_symbols: Incluir símbolos
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la generación (opcional)
            
        Returns:
            dict: Contraseña generada y su evaluación
        """
        if length < 8 or length > 128:
            return {
                "success": False,
                "message": "La longitud debe estar entre 8 y 128 caracteres"
            }
        
        if not any([include_uppercase, include_lowercase, include_digits, include_symbols]):
            return {
                "success": False,
                "message": "Debe incluir al menos un tipo de caracteres"
            }
        
        logger.info(f"Generando contraseña de {length} caracteres")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "password": None,
            "strength": None,
            "entropy_bits": None
        }
        
        try:
            # Definir conjuntos de caracteres
            charset = ""
            if include_uppercase:
                charset += string.ascii_uppercase
            if include_lowercase:
                charset += string.ascii_lowercase
            if include_digits:
                charset += string.digits
            if include_symbols:
                charset += string.punctuation
            
            # Generar contraseña
            password = ''.join(secrets.choice(charset) for _ in range(length))
            
            # Asegurar que la contraseña incluye al menos un carácter de cada tipo solicitado
            has_uppercase = any(c in string.ascii_uppercase for c in password) if include_uppercase else True
            has_lowercase = any(c in string.ascii_lowercase for c in password) if include_lowercase else True
            has_digits = any(c in string.digits for c in password) if include_digits else True
            has_symbols = any(c in string.punctuation for c in password) if include_symbols else True
            
            # Regenerar si no cumple los requisitos
            while not all([has_uppercase, has_lowercase, has_digits, has_symbols]):
                password = ''.join(secrets.choice(charset) for _ in range(length))
                has_uppercase = any(c in string.ascii_uppercase for c in password) if include_uppercase else True
                has_lowercase = any(c in string.ascii_lowercase for c in password) if include_lowercase else True
                has_digits = any(c in string.digits for c in password) if include_digits else True
                has_symbols = any(c in string.punctuation for c in password) if include_symbols else True
            
            # Calcular entropía
            charset_size = len(charset)
            entropy_bits = length * (charset_size.bit_length() - 1)  # Aproximación
            
            # Evaluar fortaleza
            if entropy_bits < 40:
                strength = "Muy débil"
            elif entropy_bits < 60:
                strength = "Débil"
            elif entropy_bits < 80:
                strength = "Moderada"
            elif entropy_bits < 100:
                strength = "Fuerte"
            else:
                strength = "Muy fuerte"
            
            results["password"] = password
            results["strength"] = strength
            results["entropy_bits"] = entropy_bits
            
        except Exception as e:
            logger.error(f"Error al generar contraseña: {e}")
            results["success"] = False
            results["message"] = f"Error al generar contraseña: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "password", f"len={length}", 
                      f"Fortaleza: {results.get('strength', 'N/A')}")
            
        return results
    
    async def analyze_password_strength(self, password: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza la fortaleza de una contraseña.
        
        Args:
            password: Contraseña a analizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Análisis de la contraseña
        """
        logger.info("Analizando fortaleza de contraseña")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "length": len(password),
            "has_uppercase": any(c.isupper() for c in password),
            "has_lowercase": any(c.islower() for c in password),
            "has_digits": any(c.isdigit() for c in password),
            "has_symbols": any(not c.isalnum() for c in password),
            "strength": None,
            "entropy_bits": None,
            "estimated_crack_time": None,
            "suggestions": []
        }
        
        try:
            # Calcular entropía aproximada
            charset_size = 0
            if results["has_uppercase"]:
                charset_size += 26
            if results["has_lowercase"]:
                charset_size += 26
            if results["has_digits"]:
                charset_size += 10
            if results["has_symbols"]:
                charset_size += 33  # Aproximado
            
            if charset_size == 0:
                charset_size = 26  # Mínimo
            
            entropy_bits = results["length"] * (charset_size.bit_length() - 1)  # Aproximación
            results["entropy_bits"] = entropy_bits
            
            # Evaluar fortaleza
            if entropy_bits < 40:
                strength = "Muy débil"
                crack_time = "Segundos a minutos"
            elif entropy_bits < 60:
                strength = "Débil"
                crack_time = "Horas a días"
            elif entropy_bits < 80:
                strength = "Moderada"
                crack_time = "Semanas a meses"
            elif entropy_bits < 100:
                strength = "Fuerte"
                crack_time = "Años a décadas"
            else:
                strength = "Muy fuerte"
                crack_time = "Siglos o más"
            
            results["strength"] = strength
            results["estimated_crack_time"] = crack_time
            
            # Buscar patrones comunes
            patterns = [
                (r"^[a-zA-Z]+$", "Solo letras"),
                (r"^[0-9]+$", "Solo números"),
                (r"^[a-z]+$", "Solo minúsculas"),
                (r"^[A-Z]+$", "Solo mayúsculas"),
                (r"12345|qwerty|asdfg|zxcvb", "Secuencia de teclado"),
                (r"password|contraseña|admin|root", "Palabra común"),
                (r"(.)\1{2,}", "Caracteres repetidos")
            ]
            
            for pattern, description in patterns:
                if re.search(pattern, password):
                    results["suggestions"].append(f"Evitar {description.lower()}")
            
            # Sugerencias basadas en características
            if results["length"] < 12:
                results["suggestions"].append("Aumentar la longitud a al menos 12 caracteres")
            if not results["has_uppercase"]:
                results["suggestions"].append("Incluir letras mayúsculas")
            if not results["has_lowercase"]:
                results["suggestions"].append("Incluir letras minúsculas")
            if not results["has_digits"]:
                results["suggestions"].append("Incluir números")
            if not results["has_symbols"]:
                results["suggestions"].append("Incluir símbolos")
            
        except Exception as e:
            logger.error(f"Error al analizar contraseña: {e}")
            results["success"] = False
            results["message"] = f"Error al analizar contraseña: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "password_analysis", "", 
                      f"Fortaleza: {results.get('strength', 'N/A')}")
            
        return results
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre criptografía.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "crypto_basics": [
                "La criptografía es la ciencia de proteger la información mediante técnicas matemáticas.",
                "El cifrado simétrico utiliza la misma clave para cifrar y descifrar (AES, ChaCha20).",
                "El cifrado asimétrico utiliza un par de claves: pública para cifrar y privada para descifrar (RSA, ECC).",
                "Las funciones hash generan una huella digital única de los datos (SHA-256, Blake2).",
                "La firma digital permite verificar la autenticidad e integridad de un mensaje.",
                "La criptografía de curva elíptica (ECC) ofrece seguridad similar a RSA con claves más pequeñas.",
                "El cifrado de extremo a extremo protege los datos durante todo su recorrido.",
                "La entropía mide la aleatoriedad y es crucial para la seguridad criptográfica.",
                "Los ataques de fuerza bruta intentan todas las combinaciones posibles de claves.",
                "La criptografía cuántica utiliza principios de la física cuántica para comunicaciones seguras."
            ],
            "security_tips": [
                "Utiliza algoritmos criptográficos modernos y estándares (AES-256, RSA-2048+, SHA-256+).",
                "Nunca implementes tus propios algoritmos criptográficos (usa bibliotecas probadas).",
                "Genera contraseñas fuertes con al menos 12 caracteres y diferentes tipos de caracteres.",
                "Utiliza un gestor de contraseñas para almacenar credenciales de forma segura.",
                "Implementa autenticación de dos factores (2FA) siempre que sea posible.",
                "Mantén las claves privadas en lugares seguros y nunca las compartas.",
                "Rota las claves periódicamente para minimizar el impacto de posibles filtraciones.",
                "Verifica la integridad de los archivos descargados mediante hashes.",
                "Utiliza protocolos seguros como HTTPS, SSH y TLS para las comunicaciones.",
                "Mantente informado sobre vulnerabilidades y actualizaciones de seguridad."
            ],
            "learning_resources": [
                "https://www.cryptool.org/ - Herramientas educativas de criptografía",
                "https://cryptohack.org/ - Plataforma de aprendizaje de criptografía",
                "https://www.coursera.org/learn/crypto - Curso de criptografía de Stanford",
                "https://www.khanacademy.org/computing/computer-science/cryptography - Lecciones de criptografía",
                "https://www.crypto101.io/ - Introducción a la criptografía",
                "https://www.schneier.com/books/applied-cryptography/ - Libro 'Applied Cryptography'",
                "https://crackstation.net/ - Base de datos de hashes y herramientas",
                "https://www.keylength.com/ - Recomendaciones de longitud de claves",
                "https://www.eff.org/dice - Generación de contraseñas con dados",
                "https://haveibeenpwned.com/ - Verificación de filtraciones de contraseñas"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    crypto_tools = CryptographyTools()
    import asyncio
    
    async def test():
        # Test hash calculation
        hash_result = await crypto_tools.calculate_hash("Hello, World!", "sha256")
        print("\n--- Hash Calculation ---")
        print(json.dumps(hash_result, indent=2))
        
        # Test key pair generation
        keypair_result = await crypto_tools.generate_key_pair(2048)
        print("\n--- Key Pair Generation ---")
        print("Private Key:")
        print(keypair_result["private_key"][:100] + "...")
        print("Public Key:")
        print(keypair_result["public_key"][:100] + "...")
        
        # Test symmetric encryption/decryption
        encrypt_result = await crypto_tools.encrypt_symmetric("Secret message", "password123", "aes-256-cbc")
        print("\n--- Symmetric Encryption ---")
        print(json.dumps(encrypt_result, indent=2))
        
        decrypt_result = await crypto_tools.decrypt_symmetric(
            encrypt_result["ciphertext"], 
            "password123", 
            "aes-256-cbc",
            encrypt_result["iv"],
            encrypt_result["salt"]
        )
        print("\n--- Symmetric Decryption ---")
        print(json.dumps(decrypt_result, indent=2))
        
        # Test password generation
        password_result = await crypto_tools.generate_password(16, True, True, True, True)
        print("\n--- Password Generation ---")
        print(json.dumps(password_result, indent=2))
        
        # Test password strength analysis
        strength_result = await crypto_tools.analyze_password_strength(password_result["password"])
        print("\n--- Password Strength Analysis ---")
        print(json.dumps(strength_result, indent=2))
        
    asyncio.run(test())
