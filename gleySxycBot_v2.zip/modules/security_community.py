"""
Módulo de Comunidad de Seguridad.

Este módulo proporciona funcionalidades para conectar con la comunidad
de seguridad, compartir información, acceder a recursos comunitarios
y participar en desafíos educativos.
"""

import logging
import os
import json
import requests
import re
import random
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL

# Configuración de logging
logger = logging.getLogger(__name__)

class SecurityCommunity:
    """Clase para interactuar con la comunidad de seguridad."""
    
    def __init__(self):
        """Inicializa la clase de comunidad de seguridad."""
        self.headers = {
            "User-Agent": "GleySxycBot/2.0.0 (Educational Security Bot)"
        }
        
        # Fuentes de noticias y blogs de seguridad
        self.security_news_sources = [
            {"name": "The Hacker News", "url": "https://thehackernews.com/", "rss": "https://feeds.feedburner.com/TheHackersNews"},
            {"name": "Krebs on Security", "url": "https://krebsonsecurity.com/", "rss": "https://krebsonsecurity.com/feed/"},
            {"name": "Schneier on Security", "url": "https://www.schneier.com/", "rss": "https://www.schneier.com/feed/atom/"},
            {"name": "Threatpost", "url": "https://threatpost.com/", "rss": "https://threatpost.com/feed/"},
            {"name": "Dark Reading", "url": "https://www.darkreading.com/", "rss": "https://www.darkreading.com/rss.xml"},
            {"name": "Bleeping Computer", "url": "https://www.bleepingcomputer.com/", "rss": "https://www.bleepingcomputer.com/feed/"},
            {"name": "Security Week", "url": "https://www.securityweek.com/", "rss": "https://feeds.feedburner.com/securityweek"},
            {"name": "CISA", "url": "https://www.cisa.gov/", "rss": "https://www.cisa.gov/cisa/xml/rss.xml"}
        ]
        
        # Comunidades y foros de seguridad
        self.security_communities = [
            {"name": "Reddit r/netsec", "url": "https://www.reddit.com/r/netsec/", "description": "Comunidad de Reddit sobre seguridad de redes y hacking ético"},
            {"name": "Reddit r/cybersecurity", "url": "https://www.reddit.com/r/cybersecurity/", "description": "Comunidad de Reddit sobre ciberseguridad"},
            {"name": "HackTheBox Forum", "url": "https://forum.hackthebox.eu/", "description": "Foro oficial de HackTheBox para discusiones sobre retos y seguridad"},
            {"name": "TryHackMe Discord", "url": "https://discord.gg/tryhackme", "description": "Comunidad de Discord de TryHackMe"},
            {"name": "OWASP Community", "url": "https://owasp.org/www-community/", "description": "Comunidad de OWASP para seguridad en aplicaciones web"},
            {"name": "Stack Exchange Information Security", "url": "https://security.stackexchange.com/", "description": "Preguntas y respuestas sobre seguridad informática"},
            {"name": "Hack Forums", "url": "https://hackforums.net/", "description": "Foro sobre hacking, seguridad y programación"},
            {"name": "0x00sec", "url": "https://0x00sec.org/", "description": "Comunidad de hackers, programadores y entusiastas de la seguridad"}
        ]
        
        # Plataformas de CTF y desafíos
        self.ctf_platforms = [
            {"name": "HackTheBox", "url": "https://www.hackthebox.eu/", "description": "Plataforma de pentesting con máquinas y desafíos"},
            {"name": "TryHackMe", "url": "https://tryhackme.com/", "description": "Plataforma de aprendizaje de ciberseguridad con labs interactivos"},
            {"name": "VulnHub", "url": "https://www.vulnhub.com/", "description": "Máquinas virtuales vulnerables para practicar pentesting"},
            {"name": "CTFtime", "url": "https://ctftime.org/", "description": "Calendario y rankings de competiciones CTF"},
            {"name": "PicoCTF", "url": "https://picoctf.org/", "description": "CTF educativo para estudiantes"},
            {"name": "Root Me", "url": "https://www.root-me.org/", "description": "Plataforma con desafíos de hacking"},
            {"name": "Hack The Box Academy", "url": "https://academy.hackthebox.eu/", "description": "Cursos estructurados de ciberseguridad"},
            {"name": "OverTheWire", "url": "https://overthewire.org/wargames/", "description": "Wargames para aprender seguridad y conceptos de Linux"}
        ]
        
        # Recursos educativos gratuitos
        self.educational_resources = [
            {"name": "SANS Cyber Aces", "url": "https://www.cyberaces.org/", "description": "Cursos gratuitos de fundamentos de ciberseguridad"},
            {"name": "Cybrary", "url": "https://www.cybrary.it/", "description": "Plataforma de aprendizaje con cursos gratuitos y de pago"},
            {"name": "edX Cybersecurity", "url": "https://www.edx.org/learn/cybersecurity", "description": "Cursos universitarios gratuitos de ciberseguridad"},
            {"name": "Coursera Cybersecurity", "url": "https://www.coursera.org/browse/computer-science/computer-security-and-networks", "description": "Cursos universitarios de ciberseguridad"},
            {"name": "Hack.me", "url": "https://hack.me/", "description": "Comunidad con entornos vulnerables para practicar"},
            {"name": "OWASP WebGoat", "url": "https://owasp.org/www-project-webgoat/", "description": "Aplicación web deliberadamente insegura para aprender"},
            {"name": "Hacksplaining", "url": "https://www.hacksplaining.com/", "description": "Lecciones interactivas sobre vulnerabilidades"},
            {"name": "Portswigger Web Security Academy", "url": "https://portswigger.net/web-security", "description": "Academia gratuita de seguridad web"}
        ]
        
        # Desafíos de ejemplo para la comunidad
        self.sample_challenges = [
            {
                "id": "chall-001",
                "title": "Descifra el mensaje",
                "category": "Criptografía",
                "difficulty": "Fácil",
                "description": "Descifra el siguiente mensaje codificado en base64: 'R2xlWVN4eWNCb3QgZXMgdW4gYm90IGVkdWNhdGl2byBkZSBjaWJlcnNlZ3VyaWRhZA=='",
                "hint": "Utiliza herramientas de decodificación de base64",
                "solution": "GleYSxycBot es un bot educativo de ciberseguridad"
            },
            {
                "id": "chall-002",
                "title": "Encuentra la vulnerabilidad",
                "category": "Web",
                "difficulty": "Media",
                "description": "Analiza el siguiente código PHP y encuentra la vulnerabilidad: `$query = \"SELECT * FROM users WHERE username='\" . $_GET['user'] . \"' AND password='\" . $_GET['pass'] . \"'\";`",
                "hint": "Piensa en inyección SQL",
                "solution": "Inyección SQL: se pueden manipular los parámetros 'user' y 'pass' para alterar la consulta SQL"
            },
            {
                "id": "chall-003",
                "title": "Análisis de tráfico",
                "category": "Forense",
                "difficulty": "Media",
                "description": "En una captura de tráfico, has visto peticiones HTTP con el User-Agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.59 C2/1.0'. ¿Qué es sospechoso?",
                "hint": "Examina cuidadosamente el final del User-Agent",
                "solution": "El 'C2/1.0' al final sugiere que es tráfico de Command & Control (C2) de malware"
            }
        ]
    
    async def get_security_news(self, count: int = 5, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Obtiene noticias recientes de seguridad de fuentes confiables.
        
        Args:
            count: Número de noticias a obtener
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita las noticias (opcional)
            
        Returns:
            dict: Noticias de seguridad recientes
        """
        logger.info(f"Obteniendo {count} noticias de seguridad recientes")
        
        # Verificar caché
        cache_key = f"security_news:{count}"
        if db_session:
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info("Noticias de seguridad encontradas en caché")
                return cached_result
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "count": count,
            "news": []
        }
        
        try:
            # En una implementación real, aquí se haría scraping de RSS o uso de APIs
            # Para esta simulación, generamos noticias de ejemplo basadas en temas reales
            
            # Temas recientes de seguridad (actualizados periódicamente)
            recent_topics = [
                "Vulnerabilidad crítica en OpenSSL permite ejecución remota de código",
                "Nueva campaña de ransomware dirigida al sector sanitario",
                "Investigadores descubren backdoor en popular librería de npm",
                "CISA advierte sobre vulnerabilidades zero-day en routers empresariales",
                "Filtración masiva de datos afecta a millones de usuarios",
                "Nuevo malware elude detección utilizando técnicas de ofuscación avanzadas",
                "Vulnerabilidad en Android permite acceso no autorizado a datos sensibles",
                "Ataque de phishing sofisticado dirigido a empleados de tecnología",
                "Parche de emergencia para Windows corrige falla de elevación de privilegios",
                "Descubierta red botnet que utiliza dispositivos IoT comprometidos"
            ]
            
            # Generar noticias simuladas con fechas recientes
            for i in range(min(count, len(recent_topics))):
                days_ago = random.randint(0, 7)  # Noticias de la última semana
                news_date = datetime.now() - timedelta(days=days_ago, hours=random.randint(0, 23))
                
                source = random.choice(self.security_news_sources)
                
                results["news"].append({
                    "title": recent_topics[i],
                    "source": source["name"],
                    "url": source["url"] + "article" + str(random.randint(1000, 9999)),  # URL simulada
                    "date": news_date.isoformat(),
                    "summary": f"Información detallada sobre {recent_topics[i].lower()}. Los expertos recomiendan actualizar sistemas y aplicar parches de seguridad."
                })
            
            # Ordenar por fecha (más reciente primero)
            results["news"].sort(key=lambda x: x["date"], reverse=True)
            
        except Exception as e:
            logger.error(f"Error al obtener noticias de seguridad: {e}")
            results["success"] = False
            results["message"] = f"Error al obtener noticias de seguridad: {str(e)}"
        
        # Guardar en caché
        if db_session and results["success"]:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "security_news", f"count={count}", 
                      f"Noticias obtenidas: {len(results['news'])}")
            
        return results
    
    async def get_community_resources(self, category: str = "all", db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Obtiene recursos de la comunidad de seguridad según la categoría.
        
        Args:
            category: Categoría de recursos ('communities', 'ctf', 'education', 'all')
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita los recursos (opcional)
            
        Returns:
            dict: Recursos de la comunidad
        """
        logger.info(f"Obteniendo recursos de comunidad para categoría: {category}")
        
        valid_categories = ["communities", "ctf", "education", "all"]
        if category not in valid_categories:
            return {
                "success": False,
                "message": f"Categoría no válida. Opciones: {', '.join(valid_categories)}"
            }
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "category": category,
            "resources": []
        }
        
        try:
            if category == "communities" or category == "all":
                results["resources"].extend([
                    {"type": "community", **community}
                    for community in self.security_communities
                ])
            
            if category == "ctf" or category == "all":
                results["resources"].extend([
                    {"type": "ctf", **platform}
                    for platform in self.ctf_platforms
                ])
            
            if category == "education" or category == "all":
                results["resources"].extend([
                    {"type": "education", **resource}
                    for resource in self.educational_resources
                ])
            
        except Exception as e:
            logger.error(f"Error al obtener recursos de comunidad: {e}")
            results["success"] = False
            results["message"] = f"Error al obtener recursos de comunidad: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "community_resources", category, 
                      f"Recursos obtenidos: {len(results['resources'])}")
            
        return results
    
    async def get_security_challenge(self, difficulty: str = "random", category: str = "random", db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Obtiene un desafío de seguridad para practicar habilidades.
        
        Args:
            difficulty: Dificultad del desafío ('easy', 'medium', 'hard', 'random')
            category: Categoría del desafío ('crypto', 'web', 'forensic', 'random')
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el desafío (opcional)
            
        Returns:
            dict: Desafío de seguridad
        """
        logger.info(f"Obteniendo desafío de seguridad: dificultad={difficulty}, categoría={category}")
        
        # Normalizar parámetros
        difficulty = difficulty.lower()
        category = category.lower()
        
        # Mapear dificultades
        difficulty_map = {
            "easy": "Fácil",
            "medium": "Media",
            "hard": "Difícil",
            "random": "random"
        }
        
        # Mapear categorías
        category_map = {
            "crypto": "Criptografía",
            "web": "Web",
            "forensic": "Forense",
            "random": "random"
        }
        
        # Validar parámetros
        if difficulty not in difficulty_map:
            return {
                "success": False,
                "message": f"Dificultad no válida. Opciones: {', '.join(difficulty_map.keys())}"
            }
        
        if category not in category_map:
            return {
                "success": False,
                "message": f"Categoría no válida. Opciones: {', '.join(category_map.keys())}"
            }
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "challenge": None
        }
        
        try:
            # Filtrar desafíos según parámetros
            filtered_challenges = self.sample_challenges
            
            if difficulty != "random":
                filtered_challenges = [c for c in filtered_challenges if c["difficulty"] == difficulty_map[difficulty]]
            
            if category != "random":
                filtered_challenges = [c for c in filtered_challenges if c["category"] == category_map[category]]
            
            if not filtered_challenges:
                # Si no hay desafíos que coincidan, usar cualquiera
                challenge = random.choice(self.sample_challenges)
            else:
                challenge = random.choice(filtered_challenges)
            
            # No incluir la solución en la respuesta inicial
            challenge_without_solution = {k: v for k, v in challenge.items() if k != "solution"}
            results["challenge"] = challenge_without_solution
            
        except Exception as e:
            logger.error(f"Error al obtener desafío de seguridad: {e}")
            results["success"] = False
            results["message"] = f"Error al obtener desafío de seguridad: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "security_challenge", f"{difficulty}_{category}", 
                      f"Desafío: {results['challenge']['id'] if results.get('challenge') else 'ninguno'}")
            
        return results
    
    async def check_challenge_solution(self, challenge_id: str, proposed_solution: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Verifica la solución propuesta para un desafío.
        
        Args:
            challenge_id: ID del desafío
            proposed_solution: Solución propuesta por el usuario
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que propone la solución (opcional)
            
        Returns:
            dict: Resultado de la verificación
        """
        logger.info(f"Verificando solución para desafío {challenge_id}")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "is_correct": False,
            "challenge_id": challenge_id,
            "feedback": ""
        }
        
        try:
            # Buscar el desafío por ID
            challenge = next((c for c in self.sample_challenges if c["id"] == challenge_id), None)
            
            if not challenge:
                results["success"] = False
                results["message"] = f"Desafío con ID {challenge_id} no encontrado"
                return results
            
            # Comparar soluciones (en una implementación real, esto sería más sofisticado)
            correct_solution = challenge["solution"].lower()
            user_solution = proposed_solution.lower()
            
            # Verificar si la solución es correcta (permitiendo cierta flexibilidad)
            if user_solution == correct_solution or user_solution in correct_solution:
                results["is_correct"] = True
                results["feedback"] = "¡Correcto! Has resuelto el desafío correctamente."
            else:
                # Calcular similitud para dar pistas
                similarity = self._calculate_similarity(user_solution, correct_solution)
                
                if similarity > 0.7:
                    results["feedback"] = "¡Casi! Estás muy cerca de la solución correcta."
                elif similarity > 0.4:
                    results["feedback"] = "Vas por buen camino, pero aún no es la solución correcta."
                else:
                    results["feedback"] = "Solución incorrecta. Intenta un enfoque diferente."
            
            # Si el usuario ha resuelto correctamente, proporcionar la solución completa
            if results["is_correct"]:
                results["solution"] = challenge["solution"]
                results["explanation"] = f"Desafío resuelto: {challenge['title']} ({challenge['category']}, {challenge['difficulty']})"
            
        except Exception as e:
            logger.error(f"Error al verificar solución: {e}")
            results["success"] = False
            results["message"] = f"Error al verificar solución: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "challenge_solution", challenge_id, 
                      f"Resultado: {'Correcto' if results.get('is_correct') else 'Incorrecto'}")
            
        return results
    
    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """
        Calcula la similitud entre dos cadenas (implementación simple).
        
        Args:
            str1: Primera cadena
            str2: Segunda cadena
            
        Returns:
            float: Valor de similitud entre 0 y 1
        """
        # Implementación simple basada en conjuntos de palabras
        words1 = set(str1.lower().split())
        words2 = set(str2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        
        return len(intersection) / len(union)
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre comunidades de seguridad.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "community_importance": [
                "Las comunidades de seguridad son fundamentales para compartir conocimientos y mantenerse actualizado.",
                "Participar en comunidades ayuda a aprender de expertos y conocer las últimas tendencias en ciberseguridad.",
                "El intercambio de información sobre amenazas mejora la capacidad de respuesta colectiva.",
                "Las comunidades fomentan la colaboración y el networking entre profesionales de seguridad.",
                "Los CTF (Capture The Flag) son competiciones que ayudan a desarrollar habilidades prácticas.",
                "Compartir investigaciones y hallazgos beneficia a toda la comunidad de seguridad.",
                "Las comunidades ofrecen recursos educativos gratuitos y de calidad.",
                "La diversidad de perspectivas en las comunidades enriquece el análisis de problemas de seguridad.",
                "El aprendizaje continuo es esencial en ciberseguridad debido a la evolución constante de las amenazas.",
                "La ética hacker positiva promueve la seguridad y la responsabilidad en la comunidad."
            ],
            "participation_tips": [
                "Comienza como observador para entender la dinámica de la comunidad antes de participar activamente.",
                "Haz preguntas específicas y bien formuladas cuando necesites ayuda.",
                "Comparte tus conocimientos y hallazgos, por pequeños que parezcan.",
                "Respeta las reglas y la ética de cada comunidad.",
                "Participa en CTFs y desafíos para mejorar tus habilidades prácticas.",
                "Mantén una actitud de aprendizaje continuo y humildad.",
                "Establece conexiones con otros miembros de la comunidad.",
                "Contribuye a proyectos de código abierto relacionados con seguridad.",
                "Asiste a conferencias y eventos virtuales de la comunidad.",
                "Mantén un equilibrio entre aprender y compartir conocimientos."
            ],
            "recommended_communities": [
                "OWASP (Open Web Application Security Project) - Comunidad enfocada en seguridad de aplicaciones web",
                "Reddit r/netsec - Comunidad con noticias y discusiones sobre seguridad de redes",
                "HackTheBox - Plataforma con máquinas y desafíos para practicar hacking ético",
                "TryHackMe - Plataforma educativa con laboratorios interactivos de ciberseguridad",
                "DEF CON - Una de las conferencias de hacking más grandes del mundo con comunidad activa",
                "Stack Exchange Information Security - Plataforma de preguntas y respuestas sobre seguridad",
                "GitHub Security Lab - Comunidad enfocada en seguridad de código y software",
                "Discord de seguridad - Varios servidores como The Many Hats Club, InfoSec Community, etc."
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    community = SecurityCommunity()
    import asyncio
    
    async def test():
        # Test get security news
        news_result = await community.get_security_news(3)
        print("\n--- Security News ---")
        print(json.dumps(news_result, indent=2))
        
        # Test get community resources
        resources_result = await community.get_community_resources("ctf")
        print("\n--- Community Resources (CTF) ---")
        print(json.dumps(resources_result, indent=2))
        
        # Test get security challenge
        challenge_result = await community.get_security_challenge("medium", "crypto")
        print("\n--- Security Challenge ---")
        print(json.dumps(challenge_result, indent=2))
        
        # Test check challenge solution
        if challenge_result["success"] and challenge_result["challenge"]:
            solution_result = await community.check_challenge_solution(
                challenge_result["challenge"]["id"],
                "Esta es una solución de prueba"
            )
            print("\n--- Challenge Solution Check ---")
            print(json.dumps(solution_result, indent=2))
        
        print("\n--- Educational Resources ---")
        edu_resources = community.get_educational_resources()
        print(json.dumps(edu_resources, indent=2))
            
    asyncio.run(test())
