"""
Módulo para herramientas OSINT (Open Source Intelligence) avanzadas.

Este módulo proporciona funcionalidades para realizar búsquedas OSINT en diversas
fuentes, incluyendo nombres de usuario, correos electrónicos, dominios, números
de teléfono y análisis de metadatos, utilizando APIs reales y técnicas de scraping.
"""

import logging
import requests
import json
import re
import dns.resolver
import whois
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
from bs4 import BeautifulSoup
import phonenumbers
from phonenumbers import geocoder, carrier
import exifread
import io

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL

# Configuración de logging
logger = logging.getLogger(__name__)

class OSINTTools:
    """Clase para proporcionar herramientas OSINT avanzadas."""
    
    def __init__(self):
        """Inicializa la clase de herramientas OSINT."""
        self.hibp_api_key = get_api_key("hibp")
        self.securitytrails_api_key = get_api_key("securitytrails")
        
        # URLs de APIs
        self.hibp_url = "https://haveibeenpwned.com/api/v3/breachedaccount/"
        self.securitytrails_domain_url = "https://api.securitytrails.com/v1/domain/"
        self.securitytrails_subdomain_url = "https://api.securitytrails.com/v1/domain/{}/subdomains"
        
        # Headers para APIs
        self.headers = {
            "User-Agent": "GleySxycBot/2.0.0 (Educational Security Bot)"
        }
        
        # Sitios para búsqueda de nombres de usuario (ejemplo)
        self.username_sites = {
            "Instagram": "https://www.instagram.com/{}/",
            "Twitter": "https://twitter.com/{}",
            "GitHub": "https://github.com/{}",
            "Reddit": "https://www.reddit.com/user/{}",
            "TikTok": "https://www.tiktok.com/@{}",
            "Pinterest": "https://www.pinterest.com/{}/",
            "LinkedIn": "https://www.linkedin.com/in/{}/", # Requiere login
            "Facebook": "https://www.facebook.com/{}/" # Requiere login
        }
    
    async def search_username(self, username: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Busca un nombre de usuario en múltiples plataformas.
        
        Args:
            username: Nombre de usuario a buscar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados de la búsqueda
        """
        if not username or not re.match(r"^[a-zA-Z0-9_.-]{3,30}$", username):
            return {
                "success": False,
                "message": "Nombre de usuario inválido. Debe tener entre 3 y 30 caracteres alfanuméricos, guiones bajos, puntos o guiones."
            }
        
        # Verificar caché
        if db_session:
            cached_result = get_cached_result(db_session, f"osint_username:{username}")
            if cached_result:
                logger.info(f"Resultado en caché encontrado para username: {username}")
                return cached_result
        
        logger.info(f"Buscando nombre de usuario: {username}")
        
        results = {
            "success": True,
            "username": username,
            "timestamp": datetime.now().isoformat(),
            "found_on": [],
            "potential_on": [],
            "checked_sites": len(self.username_sites)
        }
        
        # Realizar búsquedas (simplificado, idealmente usaría APIs o scraping más robusto)
        for site, url_format in self.username_sites.items():
            url = url_format.format(username)
            try:
                # Simulación de verificación (una implementación real requeriría requests o APIs)
                # Aquí se podría usar aiohttp para hacer las peticiones asíncronas
                # Por simplicidad, asumimos que algunos sitios requieren login y no se pueden verificar fácilmente
                if site in ["LinkedIn", "Facebook"]:
                    results["potential_on"].append({"site": site, "url": url})
                else:
                    # Simulación de éxito para algunos sitios
                    if site in ["GitHub", "Twitter", "Reddit"]:
                         results["found_on"].append({"site": site, "url": url})
                    # En una implementación real, se verificaría el código de estado o contenido
                    # response = await aiohttp.ClientSession().get(url, headers=self.headers)
                    # if response.status == 200:
                    #    results["found_on"].append({"site": site, "url": url})
                    
            except Exception as e:
                logger.warning(f"Error al verificar {site} para {username}: {e}")
        
        # Guardar en caché
        if db_session:
            set_cached_result(db_session, f"osint_username:{username}", results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "username", username, 
                          f"Encontrado en {len(results["found_on"])} sitios")
        
        return results
    
    async def check_email_breaches(self, email: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Verifica si un correo electrónico ha sido comprometido en filtraciones de datos (Have I Been Pwned).
        
        Args:
            email: Correo electrónico a verificar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados de la verificación
        """
        if not validators.email(email):
            return {
                "success": False,
                "message": "Correo electrónico inválido"
            }
        
        if not has_api_key("hibp"):
            return {
                "success": False,
                "message": "No se ha configurado la clave de API de Have I Been Pwned (HIBP)"
            }
        
        # Verificar caché
        if db_session:
            cached_result = get_cached_result(db_session, f"osint_email:{email}")
            if cached_result:
                logger.info(f"Resultado en caché encontrado para email: {email}")
                return cached_result
        
        logger.info(f"Verificando email en HIBP: {email}")
        
        url = f"{self.hibp_url}{urllib.parse.quote(email)}?truncateResponse=false"
        headers = {
            "hibp-api-key": self.hibp_api_key,
            **self.headers
        }
        
        results = {
            "success": True,
            "email": email,
            "timestamp": datetime.now().isoformat(),
            "breaches": [],
            "is_pwned": False
        }
        
        try:
            response = requests.get(url, headers=headers)
            
            if response.status_code == 404:
                # No encontrado en filtraciones
                results["is_pwned"] = False
            elif response.status_code == 200:
                # Encontrado en filtraciones
                results["is_pwned"] = True
                breaches_data = response.json()
                results["breaches"] = breaches_data
            else:
                response.raise_for_status() # Lanzar excepción para otros errores
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Error al verificar email con HIBP: {e}")
            return {
                "success": False,
                "message": f"Error al conectar con HIBP: {str(e)}"
            }
        
        # Guardar en caché
        if db_session:
            set_cached_result(db_session, f"osint_email:{email}", results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "email", email, 
                          f"Pwned: {results["is_pwned"]}, Breaches: {len(results["breaches"])}")
                log_api_usage(db_session, user_id, "hibp", "breachedaccount", success=True)
        
        return results
    
    async def analyze_domain_osint(self, domain: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Realiza un análisis OSINT de un dominio.
        
        Args:
            domain: Dominio a analizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis OSINT del dominio
        """
        if not validators.domain(domain):
            return {
                "success": False,
                "message": "Nombre de dominio inválido"
            }
        
        # Verificar caché
        if db_session:
            cached_result = get_cached_result(db_session, f"osint_domain:{domain}")
            if cached_result:
                logger.info(f"Resultado en caché encontrado para dominio: {domain}")
                return cached_result
        
        logger.info(f"Analizando dominio OSINT: {domain}")
        
        results = {
            "success": True,
            "domain": domain,
            "timestamp": datetime.now().isoformat(),
            "whois": {},
            "dns_records": {},
            "subdomains": {},
            "historical_data": {}
        }
        
        # Análisis WHOIS
        try:
            whois_info = whois.whois(domain)
            # Convertir fechas a string si existen
            for key in ["creation_date", "expiration_date", "updated_date"]:
                if hasattr(whois_info, key):
                    date_val = getattr(whois_info, key)
                    if isinstance(date_val, list):
                        setattr(whois_info, key, [d.isoformat() if isinstance(d, datetime) else d for d in date_val])
                    elif isinstance(date_val, datetime):
                        setattr(whois_info, key, date_val.isoformat())
            results["whois"] = whois_info
        except Exception as e:
            logger.warning(f"Error al obtener WHOIS para {domain}: {e}")
            results["whois"] = {"error": str(e)}
        
        # Análisis DNS
        record_types = ["A", "AAAA", "MX", "TXT", "NS", "CNAME", "SOA"]
        dns_data = {}
        for record_type in record_types:
            try:
                answers = dns.resolver.resolve(domain, record_type)
                dns_data[record_type] = [r.to_text() for r in answers]
            except dns.resolver.NoAnswer:
                dns_data[record_type] = []
            except dns.resolver.NXDOMAIN:
                dns_data[record_type] = []
                logger.warning(f"Dominio {domain} no encontrado (NXDOMAIN)")
                # Si no existe el dominio, no continuar con otros tipos
                if record_type == 'A': break 
            except Exception as e:
                logger.warning(f"Error al obtener registro {record_type} para {domain}: {e}")
                dns_data[record_type] = [f"Error: {str(e)}"]
        results["dns_records"] = dns_data
        
        # Búsqueda de subdominios con SecurityTrails
        if has_api_key("securitytrails"):
            try:
                url = self.securitytrails_subdomain_url.format(domain)
                headers = {
                    "APIKEY": self.securitytrails_api_key,
                    **self.headers
                }
                response = requests.get(url, headers=headers)
                response.raise_for_status()
                subdomain_data = response.json()
                results["subdomains"] = {
                    "count": subdomain_data.get("subdomain_count"),
                    "list": subdomain_data.get("subdomains", [])[:20] # Limitar a 20
                }
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "securitytrails", "subdomains", success=True)
            except Exception as e:
                logger.warning(f"Error al obtener subdominios de SecurityTrails para {domain}: {e}")
                results["subdomains"] = {"error": str(e)}
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "securitytrails", "subdomains", success=False)
        else:
            results["subdomains"] = {"message": "API Key de SecurityTrails no configurada"}
            
        # Datos históricos con SecurityTrails
        if has_api_key("securitytrails"):
            try:
                url = f"{self.securitytrails_domain_url}{domain}/history/dns/a"
                headers = {
                    "APIKEY": self.securitytrails_api_key,
                    **self.headers
                }
                response = requests.get(url, headers=headers)
                response.raise_for_status()
                history_data = response.json()
                results["historical_data"]["dns_a"] = history_data.get("records", [])[:10] # Limitar a 10
                
                url_ns = f"{self.securitytrails_domain_url}{domain}/history/dns/ns"
                response_ns = requests.get(url_ns, headers=headers)
                response_ns.raise_for_status()
                history_data_ns = response_ns.json()
                results["historical_data"]["dns_ns"] = history_data_ns.get("records", [])[:10] # Limitar a 10
                
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "securitytrails", "history", success=True)
            except Exception as e:
                logger.warning(f"Error al obtener historial de SecurityTrails para {domain}: {e}")
                results["historical_data"] = {"error": str(e)}
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "securitytrails", "history", success=False)
        else:
            results["historical_data"] = {"message": "API Key de SecurityTrails no configurada"}
        
        # Guardar en caché
        if db_session:
            set_cached_result(db_session, f"osint_domain:{domain}", results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "domain", domain, 
                          f"Subdominios: {results["subdomains"].get("count", 0)}")
        
        return results
    
    async def analyze_phone_number(self, phone_number: str, country_code: str = None, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza un número de teléfono para obtener información básica.
        
        Args:
            phone_number: Número de teléfono a analizar
            country_code: Código de país (ej. 'US', 'ES') para ayudar al parseo
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis del número de teléfono
        """
        try:
            parsed_number = phonenumbers.parse(phone_number, country_code)
            
            if not phonenumbers.is_valid_number(parsed_number):
                return {
                    "success": False,
                    "message": "Número de teléfono inválido o imposible"
                }
            
            # Verificar caché
            cache_key = f"osint_phone:{parsed_number.country_code}{parsed_number.national_number}"
            if db_session:
                cached_result = get_cached_result(db_session, cache_key)
                if cached_result:
                    logger.info(f"Resultado en caché encontrado para teléfono: {phone_number}")
                    return cached_result
            
            logger.info(f"Analizando número de teléfono: {phone_number}")
            
            results = {
                "success": True,
                "phone_number": phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.E164),
                "timestamp": datetime.now().isoformat(),
                "is_valid": True,
                "country_code": parsed_number.country_code,
                "national_number": parsed_number.national_number,
                "location": geocoder.description_for_number(parsed_number, "es"),
                "carrier": carrier.name_for_number(parsed_number, "es"),
                "timezone": geocoder.time_zones_for_number(parsed_number),
                "type": phonenumbers.number_type(parsed_number)
            }
            
            # Mapear tipo de número a texto
            number_types = {
                phonenumbers.PhoneNumberType.FIXED_LINE: "Fijo",
                phonenumbers.PhoneNumberType.MOBILE: "Móvil",
                phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE: "Fijo o Móvil",
                phonenumbers.PhoneNumberType.TOLL_FREE: "Gratuito",
                phonenumbers.PhoneNumberType.PREMIUM_RATE: "Tarifa Premium",
                phonenumbers.PhoneNumberType.SHARED_COST: "Costo Compartido",
                phonenumbers.PhoneNumberType.VOIP: "VoIP",
                phonenumbers.PhoneNumberType.PERSONAL_NUMBER: "Número Personal",
                phonenumbers.PhoneNumberType.PAGER: "Buscapersonas",
                phonenumbers.PhoneNumberType.UAN: "Acceso Universal",
                phonenumbers.PhoneNumberType.VOICEMAIL: "Buzón de Voz",
                phonenumbers.PhoneNumberType.UNKNOWN: "Desconocido"
            }
            results["type_description"] = number_types.get(results["type"], "Desconocido")
            
            # Guardar en caché
            if db_session:
                set_cached_result(db_session, cache_key, results, CACHE_TTL)
                
                # Registrar búsqueda
                if user_id:
                    from utils.db_utils import log_search
                    log_search(db_session, user_id, "phone", results["phone_number"], 
                              f"País: {results["country_code"]}, Tipo: {results["type_description"]}")
            
            return results
            
        except phonenumbers.phonenumberutil.NumberParseException as e:
            return {
                "success": False,
                "message": f"Error al parsear el número: {str(e)}"
            }
        except Exception as e:
            logger.error(f"Error inesperado al analizar número de teléfono: {e}")
            return {
                "success": False,
                "message": f"Error inesperado: {str(e)}"
            }
    
    async def analyze_file_metadata(self, file_content: bytes, filename: str = None, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza los metadatos de un archivo (principalmente imágenes).
        
        Args:
            file_content: Contenido del archivo en bytes
            filename: Nombre del archivo (opcional)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Metadatos extraídos del archivo
        """
        logger.info(f"Analizando metadatos de archivo: {filename or 'archivo sin nombre'}")
        
        results = {
            "success": True,
            "filename": filename,
            "timestamp": datetime.now().isoformat(),
            "metadata": {},
            "potential_sensitive_info": []
        }
        
        try:
            # Usar exifread para extraer metadatos EXIF
            file_stream = io.BytesIO(file_content)
            tags = exifread.process_file(file_stream)
            
            if not tags:
                results["success"] = False
                results["message"] = "No se encontraron metadatos EXIF en el archivo."
                return results
            
            metadata_dict = {}
            sensitive_keys = ["GPS", "Make", "Model", "DateTime", "Software", "Artist", "Copyright"]
            
            for tag, value in tags.items():
                if tag not in (
                    "JPEGThumbnail", "TIFFThumbnail", "Filename", "EXIF MakerNote"
                ): # Ignorar miniaturas y datos binarios grandes
                    try:
                        # Intentar decodificar si es bytes
                        if isinstance(value.values, bytes):
                            try:
                                metadata_dict[str(tag)] = value.values.decode("utf-8", errors="replace")
                            except:
                                metadata_dict[str(tag)] = str(value.values)
                        else:
                            metadata_dict[str(tag)] = str(value.values)
                            
                        # Verificar si es información potencialmente sensible
                        for sensitive_key in sensitive_keys:
                            if sensitive_key.lower() in str(tag).lower():
                                results["potential_sensitive_info"].append(f"{tag}: {metadata_dict[str(tag)]}")
                                break
                                
                    except Exception as e:
                        logger.warning(f"Error procesando tag {tag}: {e}")
                        metadata_dict[str(tag)] = str(value)
            
            results["metadata"] = metadata_dict
            
            # (Opcional) Se podrían añadir otras librerías para analizar otros tipos de metadatos
            
        except Exception as e:
            logger.error(f"Error al analizar metadatos: {e}")
            results["success"] = False
            results["message"] = f"Error al procesar el archivo: {str(e)}"
        
        # No se cachea el análisis de archivos por defecto
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "metadata", filename or "archivo", 
                      f"Tags: {len(results['metadata'])}, Sensible: {len(results['potential_sensitive_info'])}")
            
        return results
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre OSINT.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "osint_basics": [
                "OSINT (Open Source Intelligence) es la recopilación y análisis de información de fuentes públicas.",
                "Se utiliza en ciberseguridad, periodismo de investigación, inteligencia competitiva y más.",
                "Las fuentes incluyen sitios web, redes sociales, registros públicos, noticias, etc.",
                "Es crucial utilizar OSINT de manera ética y legal, respetando la privacidad.",
                "Las herramientas OSINT automatizan la recopilación de información, pero requieren análisis humano.",
                "Verificar la información de múltiples fuentes es fundamental para la precisión.",
                "La huella digital es la información que dejamos en línea, accesible a través de OSINT.",
                "Proteger tu propia información es tan importante como saber buscar la de otros.",
                "OSINT puede revelar conexiones entre personas, organizaciones y eventos.",
                "El marco OSINT (OSINT Framework) es un buen punto de partida para encontrar herramientas."
            ],
            "privacy_tips": [
                "Revisa y ajusta la configuración de privacidad en todas tus redes sociales.",
                "Evita compartir información personal sensible como dirección, teléfono o documentos.",
                "Desactiva la geolocalización en fotos y publicaciones.",
                "Considera usar pseudónimos en lugar de tu nombre real en plataformas públicas.",
                "Revisa periódicamente qué información tuya es accesible públicamente (egosurfing).",
                "Utiliza contraseñas fuertes y únicas para cada servicio.",
                "Ten cuidado con la información que compartes en foros y comentarios públicos.",
                "Utiliza correos electrónicos desechables para registros no importantes.",
                "Sé consciente de los metadatos en los archivos que compartes (fotos, documentos).",
                "Considera usar servicios de eliminación de datos personales si te preocupa tu exposición."
            ],
            "learning_resources": [
                "https://osintframework.com/ - Colección de herramientas OSINT",
                "https://github.com/jivoi/awesome-osint - Lista curada de recursos OSINT",
                "https://www.bellingcat.com/ - Grupo de investigación que utiliza OSINT",
                "https://osintcurio.us/ - Proyecto educativo sobre OSINT",
                "https://haveibeenpwned.com/ - Verifica si tus datos han sido filtrados",
                "https://intelx.io/ - Motor de búsqueda OSINT",
                "https://www.social-searcher.com/ - Búsqueda en redes sociales",
                "https://web.archive.org/ - Archivo histórico de páginas web",
                "https://www.exploit-db.com/google-hacking-database - Google Dorks para búsquedas avanzadas",
                "https://start.me/p/q6mw4Q/osint - Colección de enlaces OSINT"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    osint_tool = OSINTTools()
    import asyncio
    
    async def test():
        # Test username search
        # username_result = await osint_tool.search_username("testuser123")
        # print("\n--- Username Search ---")
        # print(json.dumps(username_result, indent=2))
        
        # Test email breach check (requires HIBP API key)
        # email_result = await osint_tool.check_email_breaches("test@example.com")
        # print("\n--- Email Breach Check ---")
        # print(json.dumps(email_result, indent=2))
        
        # Test domain analysis
        domain_result = await osint_tool.analyze_domain_osint("google.com")
        print("\n--- Domain OSINT Analysis ---")
        print(json.dumps(domain_result, indent=2, default=str))
        
        # Test phone number analysis
        phone_result = await osint_tool.analyze_phone_number("+16502530000", "US")
        print("\n--- Phone Number Analysis ---")
        print(json.dumps(phone_result, indent=2))
        
        # Test metadata analysis (requires a file)
        # try:
        #     with open("test_image.jpg", "rb") as f:
        #         file_content = f.read()
        #     metadata_result = await osint_tool.analyze_file_metadata(file_content, "test_image.jpg")
        #     print("\n--- Metadata Analysis ---")
        #     print(json.dumps(metadata_result, indent=2))
        # except FileNotFoundError:
        #     print("\n--- Metadata Analysis Skipped (test_image.jpg not found) ---")
            
    asyncio.run(test())
