"""
Módulo para geolocalización avanzada de IPs con integraciones reales de APIs.

Este módulo proporciona funcionalidades para obtener información detallada sobre direcciones IP
utilizando múltiples servicios como IPinfo.io, MaxMind GeoIP, IP-API y IPGeolocation.io,
así como análisis de reputación y detección de VPN/proxy.
"""

import logging
import ipaddress
import requests
import json
import time
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
import geoip2.database
import geoip2.errors
from pathlib import Path

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL, DATA_DIR

# Configuración de logging
logger = logging.getLogger(__name__)

class GeoLocationIP:
    """Clase para obtener información geográfica y de red sobre direcciones IP utilizando múltiples servicios."""
    
    def __init__(self):
        """Inicializa el geolocalizador de IPs."""
        self.ipinfo_api_key = get_api_key('ipinfo')
        self.abuseipdb_api_key = get_api_key('abuseipdb')
        self.shodan_api_key = get_api_key('shodan')
        
        # URLs de APIs
        self.ipinfo_url = "https://ipinfo.io/"
        self.ip_api_url = "http://ip-api.com/json/"
        self.abuseipdb_url = "https://api.abuseipdb.com/api/v2/check"
        
        # Headers para APIs
        self.headers = {
            'User-Agent': 'GleySxycBot/2.0.0 (Educational Security Bot)'
        }
        
        # Rutas de bases de datos locales
        self.geoip_city_db = DATA_DIR / "geoip" / "GeoLite2-City.mmdb"
        self.geoip_asn_db = DATA_DIR / "geoip" / "GeoLite2-ASN.mmdb"
        
        # Crear directorio para bases de datos si no existe
        (DATA_DIR / "geoip").mkdir(exist_ok=True, parents=True)
        
        # Verificar si existen las bases de datos locales
        self.has_local_geoip = self.geoip_city_db.exists() and self.geoip_asn_db.exists()
        
        # Cargar bases de datos si existen
        if self.has_local_geoip:
            try:
                self.geoip_city_reader = geoip2.database.Reader(str(self.geoip_city_db))
                self.geoip_asn_reader = geoip2.database.Reader(str(self.geoip_asn_db))
                logger.info("Bases de datos GeoIP cargadas correctamente")
            except Exception as e:
                logger.error(f"Error al cargar bases de datos GeoIP: {e}")
                self.has_local_geoip = False
    
    def validate_ip(self, ip_str: str) -> bool:
        """
        Valida que la cadena sea una dirección IP válida (IPv4 o IPv6).
        
        Args:
            ip_str: Dirección IP a validar
            
        Returns:
            bool: True si la IP es válida, False en caso contrario
        """
        try:
            ip_obj = ipaddress.ip_address(ip_str)
            return True
        except ValueError:
            return False
    
    def is_private_ip(self, ip_str: str) -> bool:
        """
        Verifica si una IP es privada o reservada.
        
        Args:
            ip_str: Dirección IP a verificar
            
        Returns:
            bool: True si la IP es privada, False en caso contrario
        """
        try:
            ip_obj = ipaddress.ip_address(ip_str)
            return ip_obj.is_private or ip_obj.is_reserved or ip_obj.is_loopback
        except ValueError:
            return False
    
    async def get_ip_info(self, ip_str: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Obtiene información sobre una dirección IP utilizando múltiples servicios.
        
        Args:
            ip_str: Dirección IP a analizar
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Información sobre la IP
        """
        # Validar IP
        if not self.validate_ip(ip_str):
            return {
                "success": False,
                "message": "Dirección IP inválida",
                "educational_note": "Una dirección IPv4 válida tiene el formato xxx.xxx.xxx.xxx, donde cada xxx es un número entre 0 y 255."
            }
        
        # Verificar si es una IP privada
        if self.is_private_ip(ip_str):
            return {
                "success": False,
                "message": "Dirección IP privada o reservada",
                "educational_note": "Las direcciones IP privadas (como 192.168.x.x, 10.x.x.x, 172.16-31.x.x) no son accesibles desde Internet y no pueden ser geolocalizadas."
            }
        
        # Verificar caché si hay sesión de BD
        if db_session:
            cached_result = get_cached_result(db_session, f"ip_info:{ip_str}")
            if cached_result:
                logger.info(f"Resultado en caché encontrado para IP: {ip_str}")
                return cached_result
        
        # Iniciar análisis
        logger.info(f"Analizando IP: {ip_str}")
        
        # Resultados combinados
        results = {
            "success": True,
            "ip": ip_str,
            "timestamp": datetime.now().isoformat(),
            "analysis": {}
        }
        
        # Análisis con GeoIP local
        if self.has_local_geoip:
            try:
                geoip_analysis = self.analyze_ip_geoip_local(ip_str)
                results["analysis"]["geoip_local"] = geoip_analysis
            except Exception as e:
                logger.error(f"Error en análisis GeoIP local: {e}")
                results["analysis"]["geoip_local"] = {
                    "success": False,
                    "error": str(e)
                }
        
        # Análisis con IPinfo
        if has_api_key('ipinfo'):
            try:
                ipinfo_analysis = await self.analyze_ip_ipinfo(ip_str)
                results["analysis"]["ipinfo"] = ipinfo_analysis
                
                # Registrar uso de API si hay sesión de BD
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "ipinfo", "ip_info", 
                                 success=ipinfo_analysis.get("success", False))
            except Exception as e:
                logger.error(f"Error en análisis IPinfo: {e}")
                results["analysis"]["ipinfo"] = {
                    "success": False,
                    "error": str(e)
                }
        
        # Análisis con IP-API (gratuito)
        try:
            ip_api_analysis = await self.analyze_ip_api(ip_str)
            results["analysis"]["ip_api"] = ip_api_analysis
        except Exception as e:
            logger.error(f"Error en análisis IP-API: {e}")
            results["analysis"]["ip_api"] = {
                "success": False,
                "error": str(e)
            }
        
        # Análisis con AbuseIPDB
        if has_api_key('abuseipdb'):
            try:
                abuseipdb_analysis = await self.analyze_ip_abuseipdb(ip_str)
                results["analysis"]["abuseipdb"] = abuseipdb_analysis
                
                # Registrar uso de API si hay sesión de BD
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "abuseipdb", "check_ip", 
                                 success=abuseipdb_analysis.get("success", False))
            except Exception as e:
                logger.error(f"Error en análisis AbuseIPDB: {e}")
                results["analysis"]["abuseipdb"] = {
                    "success": False,
                    "error": str(e)
                }
        
        # Análisis con Shodan
        if has_api_key('shodan'):
            try:
                shodan_analysis = await self.analyze_ip_shodan(ip_str)
                results["analysis"]["shodan"] = shodan_analysis
                
                # Registrar uso de API si hay sesión de BD
                if db_session and user_id:
                    log_api_usage(db_session, user_id, "shodan", "host", 
                                 success=shodan_analysis.get("success", False))
            except Exception as e:
                logger.error(f"Error en análisis Shodan: {e}")
                results["analysis"]["shodan"] = {
                    "success": False,
                    "error": str(e)
                }
        
        # Detección de VPN/Proxy
        vpn_proxy_detection = self.detect_vpn_proxy(results)
        results["vpn_proxy"] = vpn_proxy_detection
        
        # Consolidar información geográfica
        geo_info = self.consolidate_geo_info(results)
        results["geo_info"] = geo_info
        
        # Calcular puntuación de riesgo
        risk_score = self.calculate_risk_score(results)
        results["risk_score"] = risk_score
        
        # Generar recomendaciones
        recommendations = self.generate_recommendations(results)
        results["recommendations"] = recommendations
        
        # Guardar en caché si hay sesión de BD
        if db_session:
            set_cached_result(db_session, f"ip_info:{ip_str}", results, CACHE_TTL)
            
            # Registrar búsqueda si hay ID de usuario
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "ip", ip_str, 
                          f"País: {geo_info.get('country', 'Desconocido')}, Riesgo: {risk_score}/100")
        
        return results
    
    def analyze_ip_geoip_local(self, ip_str: str) -> Dict[str, Any]:
        """
        Analiza una IP utilizando las bases de datos locales de GeoIP.
        
        Args:
            ip_str: Dirección IP a analizar
            
        Returns:
            dict: Resultados del análisis local
        """
        if not self.has_local_geoip:
            return {
                "success": False,
                "message": "Bases de datos GeoIP no disponibles"
            }
        
        try:
            # Obtener información de ciudad
            city_response = self.geoip_city_reader.city(ip_str)
            
            # Obtener información de ASN
            asn_response = self.geoip_asn_reader.asn(ip_str)
            
            return {
                "success": True,
                "ip": ip_str,
                "city": city_response.city.name,
                "region": city_response.subdivisions.most_specific.name if city_response.subdivisions else None,
                "country": city_response.country.name,
                "country_code": city_response.country.iso_code,
                "continent": city_response.continent.name,
                "postal": city_response.postal.code,
                "latitude": city_response.location.latitude,
                "longitude": city_response.location.longitude,
                "timezone": city_response.location.time_zone,
                "asn": asn_response.autonomous_system_number,
                "org": asn_response.autonomous_system_organization,
                "accuracy_radius": city_response.location.accuracy_radius
            }
        except geoip2.errors.AddressNotFoundError:
            return {
                "success": False,
                "message": "IP no encontrada en la base de datos"
            }
        except Exception as e:
            logger.error(f"Error en análisis GeoIP local: {e}")
            return {
                "success": False,
                "message": f"Error al analizar IP: {str(e)}"
            }
    
    async def analyze_ip_ipinfo(self, ip_str: str) -> Dict[str, Any]:
        """
        Analiza una IP utilizando la API de IPinfo.io.
        
        Args:
            ip_str: Dirección IP a analizar
            
        Returns:
            dict: Resultados del análisis de IPinfo
        """
        if not self.ipinfo_api_key:
            return {
                "success": False,
                "message": "No se ha configurado la clave de API de IPinfo.io"
            }
        
        url = f"{self.ipinfo_url}{ip_str}"
        headers = {
            'Authorization': f'Bearer {self.ipinfo_api_key}',
            **self.headers
        }
        
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            
            # Extraer coordenadas si están disponibles
            loc = data.get('loc', '').split(',')
            latitude = float(loc[0]) if len(loc) > 0 and loc[0] else None
            longitude = float(loc[1]) if len(loc) > 1 and loc[1] else None
            
            return {
                "success": True,
                "ip": data.get('ip'),
                "hostname": data.get('hostname'),
                "city": data.get('city'),
                "region": data.get('region'),
                "country": data.get('country'),
                "country_name": self.get_country_name(data.get('country')),
                "loc": data.get('loc'),
                "latitude": latitude,
                "longitude": longitude,
                "org": data.get('org'),
                "postal": data.get('postal'),
                "timezone": data.get('timezone'),
                "asn": data.get('asn'),
                "company": data.get('company'),
                "privacy": data.get('privacy'),
                "abuse": data.get('abuse')
            }
        except Exception as e:
            logger.error(f"Error en análisis IPinfo: {e}")
            return {
                "success": False,
                "message": f"Error al analizar IP con IPinfo: {str(e)}"
            }
    
    async def analyze_ip_api(self, ip_str: str) -> Dict[str, Any]:
        """
        Analiza una IP utilizando la API gratuita de IP-API.com.
        
        Args:
            ip_str: Dirección IP a analizar
            
        Returns:
            dict: Resultados del análisis de IP-API
        """
        url = f"{self.ip_api_url}{ip_str}"
        
        try:
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            data = response.json()
            
            if data.get('status') != 'success':
                return {
                    "success": False,
                    "message": data.get('message', 'Error desconocido')
                }
            
            return {
                "success": True,
                "ip": data.get('query'),
                "city": data.get('city'),
                "region": data.get('regionName'),
                "region_code": data.get('region'),
                "country": data.get('country'),
                "country_code": data.get('countryCode'),
                "continent": data.get('continent'),
                "continent_code": data.get('continentCode'),
                "latitude": data.get('lat'),
                "longitude": data.get('lon'),
                "timezone": data.get('timezone'),
                "isp": data.get('isp'),
                "org": data.get('org'),
                "as": data.get('as'),
                "asn": data.get('as').split(' ')[0].replace('AS', '') if data.get('as') else None,
                "mobile": data.get('mobile'),
                "proxy": data.get('proxy'),
                "hosting": data.get('hosting')
            }
        except Exception as e:
            logger.error(f"Error en análisis IP-API: {e}")
            return {
                "success": False,
                "message": f"Error al analizar IP con IP-API: {str(e)}"
            }
    
    async def analyze_ip_abuseipdb(self, ip_str: str) -> Dict[str, Any]:
        """
        Analiza una IP utilizando la API de AbuseIPDB.
        
        Args:
            ip_str: Dirección IP a analizar
            
        Returns:
            dict: Resultados del análisis de AbuseIPDB
        """
        if not self.abuseipdb_api_key:
            return {
                "success": False,
                "message": "No se ha configurado la clave de API de AbuseIPDB"
            }
        
        headers = {
            'Key': self.abuseipdb_api_key,
            'Accept': 'application/json',
            **self.headers
        }
        
        params = {
            'ipAddress': ip_str,
            'maxAgeInDays': 90,
            'verbose': True
        }
        
        try:
            response = requests.get(self.abuseipdb_url, headers=headers, params=params)
            response.raise_for_status()
            data = response.json()
            
            if 'data' not in data:
                return {
                    "success": False,
                    "message": "Respuesta inválida de AbuseIPDB"
                }
            
            result = data['data']
            
            return {
                "success": True,
                "ip": result.get('ipAddress'),
                "is_public": result.get('isPublic'),
                "ip_version": result.get('ipVersion'),
                "is_whitelisted": result.get('isWhitelisted'),
                "abuse_confidence_score": result.get('abuseConfidenceScore'),
                "country_code": result.get('countryCode'),
                "country_name": result.get('countryName'),
                "usage_type": result.get('usageType'),
                "isp": result.get('isp'),
                "domain": result.get('domain'),
                "total_reports": result.get('totalReports'),
                "num_distinct_users": result.get('numDistinctUsers'),
                "last_reported_at": result.get('lastReportedAt'),
                "reports": result.get('reports', [])[:5]  # Limitar a 5 reportes
            }
        except Exception as e:
            logger.error(f"Error en análisis AbuseIPDB: {e}")
            return {
                "success": False,
                "message": f"Error al analizar IP con AbuseIPDB: {str(e)}"
            }
    
    async def analyze_ip_shodan(self, ip_str: str) -> Dict[str, Any]:
        """
        Analiza una IP utilizando la API de Shodan.
        
        Args:
            ip_str: Dirección IP a analizar
            
        Returns:
            dict: Resultados del análisis de Shodan
        """
        if not self.shodan_api_key:
            return {
                "success": False,
                "message": "No se ha configurado la clave de API de Shodan"
            }
        
        try:
            # Importar Shodan solo si se necesita
            import shodan
            
            api = shodan.Shodan(self.shodan_api_key)
            result = api.host(ip_str)
            
            # Extraer puertos abiertos
            ports = result.get('ports', [])
            
            # Extraer servicios (limitados a 10)
            services = []
            for port in ports[:10]:
                service_data = next((s for s in result.get('data', []) if s.get('port') == port), None)
                if service_data:
                    services.append({
                        "port": port,
                        "transport": service_data.get('transport', 'unknown'),
                        "product": service_data.get('product', ''),
                        "version": service_data.get('version', ''),
                        "cpe": service_data.get('cpe', []),
                        "banner": service_data.get('data', '')[:100]  # Limitar longitud del banner
                    })
            
            # Extraer vulnerabilidades (CVEs)
            vulnerabilities = result.get('vulns', {})
            cves = list(vulnerabilities.keys()) if vulnerabilities else []
            
            return {
                "success": True,
                "ip": ip_str,
                "hostnames": result.get('hostnames', []),
                "domains": result.get('domains', []),
                "country_code": result.get('country_code'),
                "country_name": result.get('country_name'),
                "city": result.get('city'),
                "org": result.get('org'),
                "isp": result.get('isp'),
                "asn": result.get('asn'),
                "os": result.get('os'),
                "ports": ports,
                "services": services,
                "vulnerabilities": cves,
                "tags": result.get('tags', []),
                "last_update": result.get('last_update')
            }
        except Exception as e:
            logger.error(f"Error en análisis Shodan: {e}")
            return {
                "success": False,
                "message": f"Error al analizar IP con Shodan: {str(e)}"
            }
    
    def detect_vpn_proxy(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Detecta si una IP probablemente pertenece a un servicio VPN o proxy.
        
        Args:
            results: Resultados del análisis de IP
            
        Returns:
            dict: Información sobre detección de VPN/proxy
        """
        indicators = []
        confidence = 0
        
        # Verificar resultados de IP-API
        ip_api = results.get("analysis", {}).get("ip_api", {})
        if ip_api.get("success", False):
            if ip_api.get("proxy", False):
                indicators.append("Detectado como proxy por IP-API")
                confidence += 40
            if ip_api.get("hosting", False):
                indicators.append("Detectado como hosting por IP-API")
                confidence += 20
        
        # Verificar resultados de AbuseIPDB
        abuseipdb = results.get("analysis", {}).get("abuseipdb", {})
        if abuseipdb.get("success", False):
            if abuseipdb.get("usage_type") in ["VPN", "Proxy", "TOR", "Relay"]:
                indicators.append(f"Tipo de uso: {abuseipdb.get('usage_type')} según AbuseIPDB")
                confidence += 40
            
            # Verificar reportes de abuso
            abuse_score = abuseipdb.get("abuse_confidence_score", 0)
            if abuse_score > 50:
                indicators.append(f"Alto puntaje de abuso: {abuse_score}% según AbuseIPDB")
                confidence += 20
        
        # Verificar resultados de IPinfo
        ipinfo = results.get("analysis", {}).get("ipinfo", {})
        if ipinfo.get("success", False):
            privacy = ipinfo.get("privacy", {})
            if privacy:
                if privacy.get("vpn", False):
                    indicators.append("Detectado como VPN por IPinfo")
                    confidence += 40
                if privacy.get("proxy", False):
                    indicators.append("Detectado como proxy por IPinfo")
                    confidence += 40
                if privacy.get("tor", False):
                    indicators.append("Detectado como nodo Tor por IPinfo")
                    confidence += 50
                if privacy.get("hosting", False):
                    indicators.append("Detectado como hosting por IPinfo")
                    confidence += 20
        
        # Verificar resultados de Shodan
        shodan = results.get("analysis", {}).get("shodan", {})
        if shodan.get("success", False):
            if "vpn" in str(shodan.get("tags", [])).lower():
                indicators.append("Etiquetado como VPN por Shodan")
                confidence += 30
            
            # Verificar puertos comunes de VPN
            vpn_ports = [1194, 1723, 500, 4500, 1701, 51820]
            open_ports = shodan.get("ports", [])
            common_ports = set(vpn_ports).intersection(set(open_ports))
            if common_ports:
                indicators.append(f"Puertos comunes de VPN abiertos: {', '.join(map(str, common_ports))}")
                confidence += 10 * len(common_ports)
        
        # Limitar confianza a 100%
        confidence = min(confidence, 100)
        
        # Determinar resultado final
        is_vpn_proxy = confidence >= 40
        
        return {
            "is_vpn_proxy": is_vpn_proxy,
            "confidence": confidence,
            "indicators": indicators,
            "level": "alto" if confidence >= 70 else "medio" if confidence >= 40 else "bajo"
        }
    
    def consolidate_geo_info(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Consolida la información geográfica de múltiples fuentes.
        
        Args:
            results: Resultados del análisis de IP
            
        Returns:
            dict: Información geográfica consolidada
        """
        # Prioridad de fuentes: IPinfo > IP-API > GeoIP local
        geo_info = {}
        
        # Intentar obtener de IPinfo
        ipinfo = results.get("analysis", {}).get("ipinfo", {})
        if ipinfo.get("success", False):
            geo_info = {
                "ip": ipinfo.get("ip"),
                "hostname": ipinfo.get("hostname"),
                "city": ipinfo.get("city"),
                "region": ipinfo.get("region"),
                "country": ipinfo.get("country_name") or self.get_country_name(ipinfo.get("country")),
                "country_code": ipinfo.get("country"),
                "latitude": ipinfo.get("latitude"),
                "longitude": ipinfo.get("longitude"),
                "postal": ipinfo.get("postal"),
                "timezone": ipinfo.get("timezone"),
                "org": ipinfo.get("org"),
                "asn": ipinfo.get("asn"),
                "source": "ipinfo"
            }
        
        # Si faltan datos, complementar con IP-API
        ip_api = results.get("analysis", {}).get("ip_api", {})
        if ip_api.get("success", False):
            if not geo_info:
                geo_info = {
                    "ip": ip_api.get("ip"),
                    "city": ip_api.get("city"),
                    "region": ip_api.get("region"),
                    "country": ip_api.get("country"),
                    "country_code": ip_api.get("country_code"),
                    "continent": ip_api.get("continent"),
                    "latitude": ip_api.get("latitude"),
                    "longitude": ip_api.get("longitude"),
                    "timezone": ip_api.get("timezone"),
                    "isp": ip_api.get("isp"),
                    "org": ip_api.get("org"),
                    "asn": ip_api.get("asn"),
                    "source": "ip-api"
                }
            else:
                # Complementar datos faltantes
                for key in ["city", "region", "country", "latitude", "longitude", "timezone", "org", "asn"]:
                    if not geo_info.get(key) and ip_api.get(key):
                        geo_info[key] = ip_api.get(key)
                
                # Datos adicionales de IP-API
                if ip_api.get("continent") and not geo_info.get("continent"):
                    geo_info["continent"] = ip_api.get("continent")
                if ip_api.get("isp") and not geo_info.get("isp"):
                    geo_info["isp"] = ip_api.get("isp")
        
        # Si aún faltan datos, complementar con GeoIP local
        geoip = results.get("analysis", {}).get("geoip_local", {})
        if geoip.get("success", False):
            if not geo_info:
                geo_info = {
                    "ip": geoip.get("ip"),
                    "city": geoip.get("city"),
                    "region": geoip.get("region"),
                    "country": geoip.get("country"),
                    "country_code": geoip.get("country_code"),
                    "continent": geoip.get("continent"),
                    "postal": geoip.get("postal"),
                    "latitude": geoip.get("latitude"),
                    "longitude": geoip.get("longitude"),
                    "timezone": geoip.get("timezone"),
                    "asn": geoip.get("asn"),
                    "org": geoip.get("org"),
                    "source": "geoip-local"
                }
            else:
                # Complementar datos faltantes
                for key in ["city", "region", "country", "country_code", "postal", "latitude", "longitude", "timezone", "asn", "org"]:
                    if not geo_info.get(key) and geoip.get(key):
                        geo_info[key] = geoip.get(key)
                
                # Datos adicionales de GeoIP
                if geoip.get("continent") and not geo_info.get("continent"):
                    geo_info["continent"] = geoip.get("continent")
        
        # Añadir datos de Shodan si están disponibles
        shodan = results.get("analysis", {}).get("shodan", {})
        if shodan.get("success", False):
            if not geo_info.get("hostnames") and shodan.get("hostnames"):
                geo_info["hostnames"] = shodan.get("hostnames")
            if not geo_info.get("domains") and shodan.get("domains"):
                geo_info["domains"] = shodan.get("domains")
            if not geo_info.get("os") and shodan.get("os"):
                geo_info["os"] = shodan.get("os")
        
        # Añadir mapa si hay coordenadas
        if geo_info.get("latitude") and geo_info.get("longitude"):
            geo_info["map_url"] = f"https://www.openstreetmap.org/?mlat={geo_info['latitude']}&mlon={geo_info['longitude']}&zoom=14"
        
        return geo_info
    
    def calculate_risk_score(self, results: Dict[str, Any]) -> int:
        """
        Calcula una puntuación de riesgo basada en los resultados del análisis.
        
        Args:
            results: Resultados del análisis
            
        Returns:
            int: Puntuación de riesgo (0-100)
        """
        score = 0
        factors = []
        
        # Verificar AbuseIPDB
        abuseipdb = results.get("analysis", {}).get("abuseipdb", {})
        if abuseipdb.get("success", False):
            abuse_score = abuseipdb.get("abuse_confidence_score", 0)
            score += abuse_score * 0.5  # Máximo 50 puntos
            
            if abuse_score > 0:
                factors.append(f"Puntaje de abuso: {abuse_score}%")
            
            # Verificar reportes
            total_reports = abuseipdb.get("total_reports", 0)
            if total_reports > 0:
                report_score = min(total_reports * 2, 30)  # Máximo 30 puntos
                score += report_score
                factors.append(f"Reportes de abuso: {total_reports}")
        
        # Verificar VPN/Proxy
        vpn_proxy = results.get("vpn_proxy", {})
        if vpn_proxy.get("is_vpn_proxy", False):
            vpn_score = vpn_proxy.get("confidence", 0) * 0.2  # Máximo 20 puntos
            score += vpn_score
            factors.append(f"VPN/Proxy detectado ({vpn_proxy.get('confidence')}% confianza)")
        
        # Verificar Shodan
        shodan = results.get("analysis", {}).get("shodan", {})
        if shodan.get("success", False):
            # Verificar vulnerabilidades
            vulns = shodan.get("vulnerabilities", [])
            if vulns:
                vuln_score = min(len(vulns) * 5, 30)  # Máximo 30 puntos
                score += vuln_score
                factors.append(f"Vulnerabilidades conocidas: {len(vulns)}")
            
            # Verificar puertos abiertos
            ports = shodan.get("ports", [])
            risky_ports = [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 993, 995, 1433, 1723, 3306, 3389, 5432, 5900, 8080]
            open_risky_ports = [p for p in ports if p in risky_ports]
            if open_risky_ports:
                port_score = min(len(open_risky_ports) * 2, 20)  # Máximo 20 puntos
                score += port_score
                factors.append(f"Puertos de riesgo abiertos: {len(open_risky_ports)}")
        
        # Limitar puntuación a 100
        score = min(int(score), 100)
        
        # Añadir factores al resultado
        results["risk_factors"] = factors
        
        return score
    
    def generate_recommendations(self, results: Dict[str, Any]) -> List[str]:
        """
        Genera recomendaciones basadas en los resultados del análisis.
        
        Args:
            results: Resultados del análisis
            
        Returns:
            list: Lista de recomendaciones
        """
        recommendations = []
        risk_score = results.get("risk_score", 0)
        vpn_proxy = results.get("vpn_proxy", {})
        
        # Recomendaciones generales basadas en la puntuación de riesgo
        if risk_score >= 80:
            recommendations.append("Esta IP presenta un riesgo extremadamente alto. Se recomienda bloquear cualquier conexión desde esta dirección.")
        elif risk_score >= 50:
            recommendations.append("Esta IP presenta un riesgo alto. Se recomienda monitorear de cerca cualquier actividad desde esta dirección.")
        elif risk_score >= 30:
            recommendations.append("Esta IP presenta un riesgo moderado. Se recomienda precaución al permitir conexiones desde esta dirección.")
        else:
            recommendations.append("Esta IP presenta un riesgo bajo, pero siempre es recomendable mantener precauciones básicas.")
        
        # Recomendaciones específicas
        
        # VPN/Proxy
        if vpn_proxy.get("is_vpn_proxy", False):
            recommendations.append("Esta IP parece pertenecer a un servicio de VPN o proxy. Considere si esto es esperado según el contexto.")
        
        # AbuseIPDB
        abuseipdb = results.get("analysis", {}).get("abuseipdb", {})
        if abuseipdb.get("success", False) and abuseipdb.get("total_reports", 0) > 0:
            recommendations.append(f"Esta IP ha sido reportada {abuseipdb.get('total_reports')} veces por actividades abusivas. Considere implementar medidas de seguridad adicionales.")
        
        # Shodan
        shodan = results.get("analysis", {}).get("shodan", {})
        if shodan.get("success", False):
            vulns = shodan.get("vulnerabilities", [])
            if vulns:
                recommendations.append(f"Esta IP tiene {len(vulns)} vulnerabilidades conocidas. Si es un servidor bajo su control, aplique los parches de seguridad correspondientes.")
            
            ports = shodan.get("ports", [])
            if ports:
                recommendations.append(f"Esta IP tiene {len(ports)} puertos abiertos. Si es un servidor bajo su control, cierre los puertos innecesarios y asegure los servicios expuestos.")
        
        # Recomendaciones educativas generales
        recommendations.append("Recuerde que las direcciones IP pueden cambiar y ser reasignadas, por lo que esta información puede variar con el tiempo.")
        recommendations.append("Para una mayor seguridad, implemente autenticación de múltiples factores y limite el acceso por IP cuando sea posible.")
        
        return recommendations
    
    def get_country_name(self, country_code: str) -> str:
        """
        Obtiene el nombre del país a partir de su código ISO.
        
        Args:
            country_code: Código ISO del país
            
        Returns:
            str: Nombre del país o el código si no se encuentra
        """
        if not country_code:
            return "Desconocido"
        
        countries = {
            "AF": "Afganistán", "AL": "Albania", "DE": "Alemania", "AD": "Andorra", "AO": "Angola", 
            "AI": "Anguila", "AQ": "Antártida", "AG": "Antigua y Barbuda", "SA": "Arabia Saudita", 
            "DZ": "Argelia", "AR": "Argentina", "AM": "Armenia", "AW": "Aruba", "AU": "Australia", 
            "AT": "Austria", "AZ": "Azerbaiyán", "BS": "Bahamas", "BD": "Bangladés", "BB": "Barbados", 
            "BH": "Baréin", "BE": "Bélgica", "BZ": "Belice", "BJ": "Benín", "BM": "Bermudas", 
            "BY": "Bielorrusia", "BO": "Bolivia", "BA": "Bosnia y Herzegovina", "BW": "Botsuana", 
            "BR": "Brasil", "BN": "Brunéi", "BG": "Bulgaria", "BF": "Burkina Faso", "BI": "Burundi", 
            "BT": "Bután", "CV": "Cabo Verde", "KH": "Camboya", "CM": "Camerún", "CA": "Canadá", 
            "TD": "Chad", "CL": "Chile", "CN": "China", "CY": "Chipre", "VA": "Ciudad del Vaticano", 
            "CO": "Colombia", "KM": "Comoras", "CG": "Congo", "KP": "Corea del Norte", "KR": "Corea del Sur", 
            "CI": "Costa de Marfil", "CR": "Costa Rica", "HR": "Croacia", "CU": "Cuba", "CW": "Curazao", 
            "DK": "Dinamarca", "DM": "Dominica", "EC": "Ecuador", "EG": "Egipto", "SV": "El Salvador", 
            "AE": "Emiratos Árabes Unidos", "ER": "Eritrea", "SK": "Eslovaquia", "SI": "Eslovenia", 
            "ES": "España", "US": "Estados Unidos", "EE": "Estonia", "ET": "Etiopía", "PH": "Filipinas", 
            "FI": "Finlandia", "FJ": "Fiyi", "FR": "Francia", "GA": "Gabón", "GM": "Gambia", 
            "GE": "Georgia", "GH": "Ghana", "GI": "Gibraltar", "GD": "Granada", "GR": "Grecia", 
            "GL": "Groenlandia", "GP": "Guadalupe", "GU": "Guam", "GT": "Guatemala", "GF": "Guayana Francesa", 
            "GG": "Guernsey", "GN": "Guinea", "GQ": "Guinea Ecuatorial", "GW": "Guinea-Bisáu", 
            "GY": "Guyana", "HT": "Haití", "HN": "Honduras", "HK": "Hong Kong", "HU": "Hungría", 
            "IN": "India", "ID": "Indonesia", "IQ": "Irak", "IR": "Irán", "IE": "Irlanda", 
            "IS": "Islandia", "IL": "Israel", "IT": "Italia", "JM": "Jamaica", "JP": "Japón", 
            "JE": "Jersey", "JO": "Jordania", "KZ": "Kazajistán", "KE": "Kenia", "KG": "Kirguistán", 
            "KI": "Kiribati", "KW": "Kuwait", "LA": "Laos", "LS": "Lesoto", "LV": "Letonia", 
            "LB": "Líbano", "LR": "Liberia", "LY": "Libia", "LI": "Liechtenstein", "LT": "Lituania", 
            "LU": "Luxemburgo", "MO": "Macao", "MK": "Macedonia del Norte", "MG": "Madagascar", 
            "MY": "Malasia", "MW": "Malaui", "MV": "Maldivas", "ML": "Malí", "MT": "Malta", 
            "MA": "Marruecos", "MQ": "Martinica", "MU": "Mauricio", "MR": "Mauritania", "YT": "Mayotte", 
            "MX": "México", "FM": "Micronesia", "MD": "Moldavia", "MC": "Mónaco", "MN": "Mongolia", 
            "ME": "Montenegro", "MS": "Montserrat", "MZ": "Mozambique", "MM": "Myanmar", "NA": "Namibia", 
            "NR": "Nauru", "NP": "Nepal", "NI": "Nicaragua", "NE": "Níger", "NG": "Nigeria", 
            "NU": "Niue", "NO": "Noruega", "NC": "Nueva Caledonia", "NZ": "Nueva Zelanda", "OM": "Omán", 
            "NL": "Países Bajos", "PK": "Pakistán", "PW": "Palaos", "PA": "Panamá", "PG": "Papúa Nueva Guinea", 
            "PY": "Paraguay", "PE": "Perú", "PF": "Polinesia Francesa", "PL": "Polonia", "PT": "Portugal", 
            "PR": "Puerto Rico", "QA": "Qatar", "GB": "Reino Unido", "CF": "República Centroafricana", 
            "CZ": "República Checa", "CD": "República Democrática del Congo", "DO": "República Dominicana", 
            "RE": "Reunión", "RW": "Ruanda", "RO": "Rumania", "RU": "Rusia", "EH": "Sahara Occidental", 
            "WS": "Samoa", "AS": "Samoa Americana", "BL": "San Bartolomé", "KN": "San Cristóbal y Nieves", 
            "SM": "San Marino", "MF": "San Martín", "PM": "San Pedro y Miquelón", "VC": "San Vicente y las Granadinas", 
            "SH": "Santa Elena", "LC": "Santa Lucía", "ST": "Santo Tomé y Príncipe", "SN": "Senegal", 
            "RS": "Serbia", "SC": "Seychelles", "SL": "Sierra Leona", "SG": "Singapur", "SX": "Sint Maarten", 
            "SY": "Siria", "SO": "Somalia", "LK": "Sri Lanka", "SZ": "Suazilandia", "ZA": "Sudáfrica", 
            "SD": "Sudán", "SS": "Sudán del Sur", "SE": "Suecia", "CH": "Suiza", "SR": "Surinam", 
            "SJ": "Svalbard y Jan Mayen", "TH": "Tailandia", "TW": "Taiwán", "TZ": "Tanzania", 
            "TJ": "Tayikistán", "IO": "Territorio Británico del Océano Índico", "TF": "Territorios Australes Franceses", 
            "PS": "Territorios Palestinos", "TL": "Timor Oriental", "TG": "Togo", "TK": "Tokelau", 
            "TO": "Tonga", "TT": "Trinidad y Tobago", "TN": "Túnez", "TM": "Turkmenistán", "TR": "Turquía", 
            "TV": "Tuvalu", "UA": "Ucrania", "UG": "Uganda", "UY": "Uruguay", "UZ": "Uzbekistán", 
            "VU": "Vanuatu", "VE": "Venezuela", "VN": "Vietnam", "WF": "Wallis y Futuna", "YE": "Yemen", 
            "DJ": "Yibuti", "ZM": "Zambia", "ZW": "Zimbabue"
        }
        
        return countries.get(country_code.upper(), country_code)
    
    def is_vpn_or_proxy(self, ip_str: str) -> Dict[str, Any]:
        """
        Verifica si una IP probablemente pertenece a un servicio VPN o proxy.
        
        Args:
            ip_str: Dirección IP a verificar
            
        Returns:
            dict: Información sobre la detección de VPN/proxy
        """
        # Este método es un wrapper para mantener compatibilidad
        # En una implementación real, se utilizaría el método completo
        return {
            "is_vpn_proxy": False,
            "confidence": "Baja",
            "educational_note": "La detección de VPN/proxy es aproximada y no siempre precisa. Se basa en listas conocidas y patrones de comportamiento."
        }
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre direcciones IP y privacidad en línea.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "ip_basics": [
                "Las direcciones IP son identificadores numéricos asignados a cada dispositivo en una red",
                "IPv4 utiliza 32 bits y tiene formato xxx.xxx.xxx.xxx",
                "IPv6 utiliza 128 bits y tiene formato xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx",
                "Las IPs pueden ser estáticas (fijas) o dinámicas (cambiantes)",
                "Las direcciones IP públicas son accesibles desde Internet",
                "Las direcciones IP privadas (como 192.168.x.x) solo son accesibles dentro de redes locales",
                "Cada dirección IP puede revelar información aproximada sobre ubicación geográfica",
                "Los proveedores de Internet (ISP) asignan direcciones IP a sus clientes",
                "Los Sistemas Autónomos (AS) son grupos de redes IP bajo una misma administración",
                "Las direcciones IP pueden ser bloqueadas por servicios web como medida de seguridad"
            ],
            "privacy_tips": [
                "Tu dirección IP puede revelar tu ubicación aproximada y proveedor de internet",
                "Utiliza VPNs confiables para ocultar tu IP real cuando necesites privacidad",
                "Las redes Wi-Fi públicas pueden exponer tu tráfico e IP a terceros",
                "Considera usar Tor para mayor anonimato en casos que requieran privacidad extrema",
                "Algunos sitios web pueden rastrear tu actividad a través de tu dirección IP",
                "Los servicios de proxy pueden ocultar tu IP pero no siempre cifran tu tráfico",
                "Verifica la política de registros de tu VPN para saber si mantienen logs de tu actividad",
                "Actualiza regularmente tu router para evitar vulnerabilidades que expongan tu red",
                "Configura correctamente el firewall de tu dispositivo para proteger tu dirección IP",
                "Utiliza DNS sobre HTTPS (DoH) para evitar que tu ISP vea tus consultas DNS"
            ],
            "learning_resources": [
                "https://ipinfo.io/ - Información detallada sobre IPs",
                "https://www.whatismyip.com/ - Verifica tu IP pública actual",
                "https://www.eff.org/issues/privacy - Recursos sobre privacidad de la Electronic Frontier Foundation",
                "https://www.privacytools.io/ - Herramientas y recursos para proteger tu privacidad en línea",
                "https://www.abuseipdb.com/ - Base de datos de IPs reportadas por actividades abusivas",
                "https://www.shodan.io/ - Motor de búsqueda para dispositivos conectados a Internet",
                "https://iknowwhatyoudownload.com/ - Muestra actividad de torrent asociada a una IP",
                "https://www.ipvoid.com/ - Herramientas para análisis de IPs",
                "https://www.maxmind.com/en/geoip-demo - Demo de geolocalización de IPs",
                "https://www.iana.org/numbers - Información sobre asignación de direcciones IP"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    geolocator = GeoLocationIP()
    import asyncio
    
    async def test():
        result = await geolocator.get_ip_info("8.8.8.8")
        print(json.dumps(result, indent=2))
    
    asyncio.run(test())
