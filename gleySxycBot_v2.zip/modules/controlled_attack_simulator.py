"""
Módulo de Simulador de Ataques Controlados (Educativo).

Este módulo proporciona simulaciones *educativas y controladas* de
técnicas de ataque comunes para ayudar a los usuarios a comprender
vectores de ataque y defensas. **NO realiza ataques reales**.

**ADVERTENCIA:** Utiliza este módulo únicamente con fines educativos
y con pleno consentimiento sobre los "objetivos" simulados (que
serán principalmente endpoints controlados o simulados por el bot).
"""

import logging
import os
import re
import json
import random
import asyncio
import socket
import requests
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
from urllib.parse import urlparse

# Importar otros módulos del bot para interactuar
from modules.web_security import WebSecurityTools
from modules.geolocation_ip import GeolocationIP
from modules.osint_tools import OSINTTools

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import CACHE_TTL, ETHICAL_WARNING

# Configuración de logging
logger = logging.getLogger(__name__)

class AttackSimulator:
    """Clase para el simulador de ataques controlados."""
    
    def __init__(self):
        """Inicializa la clase del simulador de ataques."""
        self.headers = {
            "User-Agent": "GleySxycBot/2.0.0 (Educational Security Bot)"
        }
        # Instanciar otros módulos si es necesario interactuar con ellos
        self.web_security = WebSecurityTools()
        self.geolocation = GeolocationIP()
        self.osint = OSINTTools()
        
        # Listas de ejemplo para simulaciones
        self.common_ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1723, 3306, 3389, 5900, 8080]
        self.phishing_templates = [
            "Estimado usuario, hemos detectado actividad sospechosa en su cuenta. Por favor, verifique su identidad en: {url}",
            "¡Felicidades! Ha ganado un premio. Reclámelo ahora en: {url}",
            "Su paquete está en espera. Actualice su dirección de envío aquí: {url}",
            "Alerta de seguridad: Su contraseña ha expirado. Restablézcala inmediatamente en: {url}"
        ]
        self.fake_vulnerabilities = [
            {"cve": "CVE-2024-SIM01", "name": "Simulated SQL Injection Point", "severity": "High", "details": "Un parámetro en la URL parece vulnerable a inyección SQL (simulado)."},
            {"cve": "CVE-2024-SIM02", "name": "Simulated XSS Reflected", "severity": "Medium", "details": "Un campo de búsqueda podría reflejar scripts (simulado)."},
            {"cve": "CVE-2024-SIM03", "name": "Simulated Outdated Library", "severity": "Medium", "details": "El servidor parece usar una versión simulada de una librería con vulnerabilidades conocidas (ej. jQuery 1.x simulada)."},
            {"cve": "CVE-2024-SIM04", "name": "Simulated Directory Listing", "severity": "Low", "details": "Se ha detectado una posible configuración de listado de directorios (simulado)."}
        ]

    async def simulate_port_scan(self, target: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Simula un escaneo de puertos comunes sobre un objetivo (IP o dominio).
        **NO realiza un escaneo real.** Solo verifica conectividad básica en puertos comunes.
        
        Args:
            target: IP o dominio objetivo
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la simulación (opcional)
            
        Returns:
            dict: Resultados de la simulación de escaneo
        """
        logger.warning(f"Iniciando simulación de escaneo de puertos en: {target}. {ETHICAL_WARNING}")
        
        results = {
            "success": True,
            "target": target,
            "ip_address": None,
            "timestamp": datetime.now().isoformat(),
            "simulation_type": "Port Scan (Simulated)",
            "open_ports": [],
            "closed_ports": [],
            "message": "Simulación completada. Se intentó conectar a puertos comunes."
        }
        
        try:
            # Resolver IP si es un dominio
            ip_address = self._resolve_target(target)
            if not ip_address:
                results["success"] = False
                results["message"] = f"No se pudo resolver la IP para {target}"
                return results
            results["ip_address"] = ip_address
            
            # Simular escaneo intentando conectar a puertos comunes
            open_ports = []
            closed_ports = []
            tasks = []
            for port in self.common_ports:
                tasks.append(self._check_port(ip_address, port))
            
            port_results = await asyncio.gather(*tasks)
            
            for port, status in port_results:
                if status == "open":
                    open_ports.append(port)
                else:
                    closed_ports.append(port)
            
            results["open_ports"] = sorted(open_ports)
            # results["closed_ports"] = sorted(closed_ports) # Opcional: puede ser muy largo
            
            if not open_ports:
                results["message"] += " No se encontraron puertos abiertos comunes."
            else:
                 results["message"] += f" Puertos abiertos simulados encontrados: {len(open_ports)}."
                 
        except Exception as e:
            logger.error(f"Error durante la simulación de escaneo de puertos: {e}")
            results["success"] = False
            results["message"] = f"Error durante la simulación: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "simulate_portscan", target, 
                      f"IP: {results.get("ip_address", "N/A")}, Puertos abiertos simulados: {len(results.get("open_ports", []))}")
            
        return results

    async def simulate_phishing_awareness(self, target_user_description: str = "un usuario", db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Genera un ejemplo de correo de phishing para concienciación.
        **NO envía ningún correo.** Solo genera el texto.
        
        Args:
            target_user_description: Descripción del usuario objetivo (ej. "empleado de ACME")
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la simulación (opcional)
            
        Returns:
            dict: Ejemplo de correo de phishing generado
        """
        logger.warning(f"Generando ejemplo de phishing para concienciación. {ETHICAL_WARNING}")
        
        results = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "simulation_type": "Phishing Awareness Example",
            "phishing_email": {
                "subject": None,
                "sender": None,
                "body": None,
                "fake_url": None
            },
            "explanation": "Este es un ejemplo simulado de cómo podría verse un correo de phishing. Analiza los elementos sospechosos."
        }
        
        try:
            # Generar elementos falsos
            fake_sender_name = random.choice(["Soporte Técnico", "Departamento de RH", "Equipo de Seguridad", "Servicio de Correo"])
            fake_sender_domain = random.choice(["support-mail.com", "security-update.net", "company-portal.org", "service-web.info"])
            fake_sender = f"{fake_sender_name} <noreply@{fake_sender_domain}>"
            
            fake_subject = random.choice(["Acción requerida en su cuenta", "Verificación de seguridad urgente", "Notificación importante", "Problema con su último pedido"])
            
            # Crear URL falsa (no funcional)
            fake_domain = random.choice(["login-secure.com", "account-verify.net", "service-update.org", "portal-access.info"])
            fake_path = "/" + ".".join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(8,15)))
            fake_url = f"https://{target_user_description.replace(" ", "-")}.{fake_domain}{fake_path}" # Incluir descripción para hacerlo más "dirigido"
            
            # Seleccionar plantilla y rellenar
            template = random.choice(self.phishing_templates)
            body = template.format(url=fake_url)
            
            results["phishing_email"] = {
                "subject": fake_subject,
                "sender": fake_sender,
                "body": body,
                "fake_url": fake_url
            }
            
        except Exception as e:
            logger.error(f"Error durante la simulación de phishing: {e}")
            results["success"] = False
            results["message"] = f"Error durante la simulación: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "simulate_phishing", target_user_description, 
                      "Ejemplo de correo de phishing generado")
            
        return results

    async def simulate_vulnerability_scan(self, target_url: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Simula un escaneo de vulnerabilidades web básicas.
        **NO realiza un escaneo real.** Identifica tecnologías básicas y reporta
        vulnerabilidades *simuladas* de ejemplo.
        
        Args:
            target_url: URL del sitio web objetivo
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita la simulación (opcional)
            
        Returns:
            dict: Resultados de la simulación de escaneo de vulnerabilidades
        """
        logger.warning(f"Iniciando simulación de escaneo de vulnerabilidades en: {target_url}. {ETHICAL_WARNING}")
        
        results = {
            "success": True,
            "target_url": target_url,
            "timestamp": datetime.now().isoformat(),
            "simulation_type": "Web Vulnerability Scan (Simulated)",
            "detected_technologies": [],
            "simulated_vulnerabilities": [],
            "message": "Simulación completada. Se buscaron tecnologías básicas y se reportaron vulnerabilidades simuladas."
        }
        
        try:
            # Validar y parsear URL
            parsed_url = urlparse(target_url)
            if not parsed_url.scheme or not parsed_url.netloc:
                results["success"] = False
                results["message"] = "URL inválida."
                return results
            
            # Intentar obtener respuesta básica y headers
            detected_tech = []
            try:
                response = requests.get(target_url, headers=self.headers, timeout=10, allow_redirects=True)
                response.raise_for_status()
                
                # Analizar headers para tecnologías comunes
                server = response.headers.get("Server")
                if server: detected_tech.append(f"Server: {server}")
                x_powered_by = response.headers.get("X-Powered-By")
                if x_powered_by: detected_tech.append(f"X-Powered-By: {x_powered_by}")
                # Buscar cookies comunes (ej. PHP SESSID, ASP.NET_SessionId)
                if "PHPSESSID" in response.cookies: detected_tech.append("PHP Session Cookie")
                if "ASP.NET_SessionId" in response.cookies: detected_tech.append("ASP.NET Session Cookie")
                
                # Analizar contenido HTML para frameworks comunes (muy básico)
                content_sample = response.text[:2048].lower()
                if "wordpress" in content_sample or "wp-" in content_sample: detected_tech.append("WordPress (Posible)")
                if "joomla" in content_sample: detected_tech.append("Joomla (Posible)")
                if "drupal" in content_sample: detected_tech.append("Drupal (Posible)")
                if "jquery" in content_sample: detected_tech.append("jQuery")
                
            except requests.exceptions.RequestException as e:
                logger.warning(f"No se pudo obtener respuesta de {target_url}: {e}")
                results["message"] = f"No se pudo conectar a {target_url}. La simulación puede ser limitada."
                # Continuar igualmente para mostrar vulnerabilidades simuladas

            results["detected_technologies"] = list(set(detected_tech))
            
            # Seleccionar aleatoriamente algunas vulnerabilidades simuladas
            num_vulns = random.randint(1, len(self.fake_vulnerabilities))
            results["simulated_vulnerabilities"] = random.sample(self.fake_vulnerabilities, num_vulns)
            
        except Exception as e:
            logger.error(f"Error durante la simulación de escaneo de vulnerabilidades: {e}")
            results["success"] = False
            results["message"] = f"Error durante la simulación: {str(e)}"
        
        # Registrar búsqueda (si aplica)
        if db_session and user_id:
            from utils.db_utils import log_search
            log_search(db_session, user_id, "simulate_vulnscan", target_url, 
                      f"Tecnologías detectadas (simuladas): {len(results.get("detected_technologies", []))}, Vulns simuladas: {len(results.get("simulated_vulnerabilities", []))}")
            
        return results

    def _resolve_target(self, target: str) -> Optional[str]:
        """Resuelve un dominio a una dirección IP."""
        try:
            # Verificar si ya es una IP
            socket.inet_aton(target)
            return target
        except socket.error:
            # No es una IP, intentar resolver dominio
            try:
                ip_address = socket.gethostbyname(target)
                return ip_address
            except socket.gaierror:
                logger.warning(f"No se pudo resolver el dominio: {target}")
                return None

    async def _check_port(self, ip_address: str, port: int) -> Tuple[int, str]:
        """Intenta conectar a un puerto específico (con timeout corto)."""
        try:
            # Usar asyncio para manejar timeouts de forma no bloqueante
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(ip_address, port),
                timeout=1.0 # Timeout corto para simulación rápida
            )
            writer.close()
            await writer.wait_closed()
            return port, "open"
        except (asyncio.TimeoutError, ConnectionRefusedError, OSError):
            return port, "closed"
            
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre simulación de ataques y defensa.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "attack_simulation_basics": [
                "La simulación de ataques controlados ayuda a entender cómo funcionan los ataques reales y a probar defensas.",
                "Es crucial diferenciar entre simulación educativa y ataques reales. Las simulaciones deben ser siempre seguras y consentidas.",
                "El escaneo de puertos busca puertos abiertos en un sistema que podrían ser explotados.",
                "El phishing es una técnica de ingeniería social para engañar a los usuarios y obtener información sensible.",
                "El escaneo de vulnerabilidades busca debilidades conocidas en software y configuraciones.",
                "Las simulaciones deben centrarse en la técnica y la detección, no en causar daño.",
                "Comprender los vectores de ataque comunes (red, web, ingeniería social) es clave para la defensa.",
                "La inteligencia de amenazas (Threat Intelligence) informa sobre actores, TTPs y campañas activas.",
                "El objetivo final de la simulación es mejorar la postura de seguridad y la capacidad de respuesta.",
                f"Recuerda siempre la advertencia ética: {ETHICAL_WARNING}"
            ],
            "defense_tips": [
                "Mantén los sistemas y el software actualizados para parchear vulnerabilidades conocidas.",
                "Utiliza firewalls para controlar el tráfico de red entrante y saliente.",
                "Implementa sistemas de detección y prevención de intrusiones (IDPS).",
                "Educa a los usuarios sobre cómo reconocer correos de phishing y otras tácticas de ingeniería social.",
                "Utiliza contraseñas fuertes y únicas, y habilita la autenticación multifactor (MFA).",
                "Realiza copias de seguridad periódicas y pruébalas.",
                "Monitoriza los registros (logs) del sistema y de la red para detectar actividades sospechosas.",
                "Segmenta las redes para limitar el impacto de una posible brecha.",
                "Realiza auditorías de seguridad y pruebas de penetración (éticas) periódicamente.",
                "Ten un plan de respuesta a incidentes preparado."
            ],
            "learning_resources": [
                "https://attack.mitre.org/ - Base de conocimiento MITRE ATT&CK sobre tácticas y técnicas adversarias",
                "https://owasp.org/ - Open Web Application Security Project (Seguridad de Aplicaciones Web)",
                "https://www.sans.org/top25-software-errors/ - Lista SANS de errores de software peligrosos",
                "https://tryhackme.com/ - Plataforma de aprendizaje práctico de ciberseguridad",
                "https://www.hackthebox.com/ - Plataforma de pentesting y ciberseguridad",
                "https://www.cybrary.it/ - Cursos y recursos de ciberseguridad",
                "https://www.phishing.org/ - Información sobre phishing y cómo prevenirlo",
                "https://nmap.org/ - Herramienta de escaneo de redes (Nmap)",
                "https://www.wireshark.org/ - Analizador de protocolos de red",
                "https://www.cisa.gov/stopransomware - Recursos sobre ransomware de CISA"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    simulator = AttackSimulator()
    import asyncio
    
    async def test():
        # Test port scan simulation (usa un objetivo conocido como google.com)
        port_scan_result = await simulator.simulate_port_scan("google.com")
        print("\n--- Port Scan Simulation ---")
        print(json.dumps(port_scan_result, indent=2))
        
        # Test phishing awareness example
        phishing_result = await simulator.simulate_phishing_awareness("empleado de test")
        print("\n--- Phishing Awareness Simulation ---")
        print(json.dumps(phishing_result, indent=2))
        
        # Test vulnerability scan simulation (usa un objetivo conocido)
        vuln_scan_result = await simulator.simulate_vulnerability_scan("https://www.google.com")
        print("\n--- Vulnerability Scan Simulation ---")
        print(json.dumps(vuln_scan_result, indent=2))
        
        print("\n--- Educational Resources ---")
        edu_resources = simulator.get_educational_resources()
        print(json.dumps(edu_resources, indent=2))
            
    asyncio.run(test())
