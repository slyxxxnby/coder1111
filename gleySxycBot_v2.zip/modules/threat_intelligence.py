"""
Módulo para Inteligencia de Amenazas (Threat Intelligence).

Este módulo integra APIs de servicios de inteligencia de amenazas como
AlienVault OTX y Hybrid Analysis para analizar IPs, dominios, URLs y hashes.
"""

import logging
import requests
import json
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
import urllib.parse

# Importar utilidades
from utils.db_utils import get_cached_result, set_cached_result, log_api_usage
from config.config import get_api_key, has_api_key, CACHE_TTL

# Configuración de logging
logger = logging.getLogger(__name__)

class ThreatIntelligence:
    """Clase para interactuar con APIs de inteligencia de amenazas."""
    
    def __init__(self):
        """Inicializa la clase de inteligencia de amenazas."""
        self.otx_api_key = get_api_key("otx")
        self.hybrid_analysis_api_key = get_api_key("hybrid_analysis")
        
        # URLs de APIs
        self.otx_base_url = "https://otx.alienvault.com/api/v1/indicators/"
        self.hybrid_analysis_base_url = "https://www.hybrid-analysis.com/api/v2/"
        
        # Headers para APIs
        self.headers = {
            "User-Agent": "GleySxycBot/2.0.0 (Educational Security Bot)"
        }
    
    async def analyze_indicator_otx(self, indicator_type: str, indicator_value: str, section: str = "general", db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza un indicador (IP, dominio, URL, hash) usando AlienVault OTX.
        
        Args:
            indicator_type: Tipo de indicador (ipv4, ipv6, domain, url, file_hash_md5, file_hash_sha1, file_hash_sha256)
            indicator_value: Valor del indicador
            section: Sección de información a obtener (general, geo, malware, url_list, passive_dns, http_scans, etc.)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis de OTX
        """
        if not has_api_key("otx"):
            return {
                "success": False,
                "message": "No se ha configurado la clave de API de AlienVault OTX"
            }
        
        # Validar tipo de indicador
        valid_types = ["ipv4", "ipv6", "domain", "hostname", "url", "file"] # OTX usa 'file' para hashes
        otx_type = indicator_type
        if indicator_type.startswith("file_hash"):
            otx_type = "file"
        elif indicator_type not in valid_types:
             return {
                "success": False,
                "message": f"Tipo de indicador no soportado por OTX: {indicator_type}"
            }
        
        # Verificar caché
        cache_key = f"threatintel_otx:{indicator_type}:{indicator_value}:{section}"
        if db_session:
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultado en caché encontrado para OTX: {indicator_value} ({section})")
                return cached_result
        
        logger.info(f"Analizando indicador OTX: {indicator_value} ({indicator_type}), sección: {section}")
        
        url = f"{self.otx_base_url}{otx_type}/{urllib.parse.quote_plus(indicator_value)}/{section}"
        headers = {
            "X-OTX-API-KEY": self.otx_api_key,
            **self.headers
        }
        
        results = {
            "success": True,
            "indicator_type": indicator_type,
            "indicator_value": indicator_value,
            "section": section,
            "timestamp": datetime.now().isoformat(),
            "data": {}
        }
        
        try:
            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()
            data = response.json()
            results["data"] = data
            
            # Registrar uso de API
            if db_session and user_id:
                log_api_usage(db_session, user_id, "otx", f"{otx_type}/{section}", success=True)
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Error al analizar indicador con OTX: {e}")
            # Manejar error 404 (indicador no encontrado)
            if hasattr(e, 'response') and e.response is not None and e.response.status_code == 404:
                 results["success"] = True # No es un error de API, simplemente no hay datos
                 results["data"] = {"message": "Indicador no encontrado en OTX"}
            else:
                results["success"] = False
                results["message"] = f"Error al conectar con OTX: {str(e)}"
            
            if db_session and user_id:
                log_api_usage(db_session, user_id, "otx", f"{otx_type}/{section}", success=False, error_message=str(e))
        
        # Guardar en caché si fue exitoso (incluso si no se encontró)
        if db_session and results["success"]:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                # Simplificar el resumen para el log
                summary = "Encontrado" if results["data"] and results["data"].get("message") != "Indicador no encontrado en OTX" else "No encontrado"
                log_search(db_session, user_id, f"otx_{indicator_type}", indicator_value, f"Sección: {section}, Resultado: {summary}")
        
        return results
    
    async def analyze_hash_hybrid_analysis(self, file_hash: str, db_session=None, user_id=None) -> Dict[str, Any]:
        """
        Analiza un hash de archivo usando Hybrid Analysis.
        
        Args:
            file_hash: Hash del archivo (MD5, SHA1, SHA256)
            db_session: Sesión de base de datos (opcional)
            user_id: ID del usuario que solicita el análisis (opcional)
            
        Returns:
            dict: Resultados del análisis de Hybrid Analysis
        """
        if not has_api_key("hybrid_analysis"):
            return {
                "success": False,
                "message": "No se ha configurado la clave de API de Hybrid Analysis"
            }
        
        # Validar longitud del hash
        hash_len = len(file_hash)
        if hash_len not in [32, 40, 64]: # MD5, SHA1, SHA256
            return {
                "success": False,
                "message": "Hash inválido. Debe ser MD5, SHA1 o SHA256."
            }
        
        # Verificar caché
        cache_key = f"threatintel_ha:{file_hash}"
        if db_session:
            cached_result = get_cached_result(db_session, cache_key)
            if cached_result:
                logger.info(f"Resultado en caché encontrado para Hybrid Analysis: {file_hash}")
                return cached_result
        
        logger.info(f"Analizando hash con Hybrid Analysis: {file_hash}")
        
        url = f"{self.hybrid_analysis_base_url}search/hash"
        headers = {
            "api-key": self.hybrid_analysis_api_key,
            "accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
            **self.headers
        }
        data = {
            "hash": file_hash
        }
        
        results = {
            "success": True,
            "hash": file_hash,
            "timestamp": datetime.now().isoformat(),
            "reports": []
        }
        
        try:
            response = requests.post(url, headers=headers, data=data, timeout=15)
            response.raise_for_status()
            data = response.json()
            
            # Verificar si se encontraron reportes
            if isinstance(data, list) and len(data) > 0:
                results["reports"] = data
            else:
                results["message"] = "No se encontraron reportes para este hash."
            
            # Registrar uso de API
            if db_session and user_id:
                log_api_usage(db_session, user_id, "hybrid_analysis", "search_hash", success=True)
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Error al analizar hash con Hybrid Analysis: {e}")
            # Manejar error 404 (no encontrado)
            if hasattr(e, 'response') and e.response is not None and e.response.status_code == 404:
                 results["success"] = True
                 results["message"] = "No se encontraron reportes para este hash."
            else:
                results["success"] = False
                results["message"] = f"Error al conectar con Hybrid Analysis: {str(e)}"
            
            if db_session and user_id:
                log_api_usage(db_session, user_id, "hybrid_analysis", "search_hash", success=False, error_message=str(e))
        
        # Guardar en caché si fue exitoso (incluso si no se encontró)
        if db_session and results["success"]:
            set_cached_result(db_session, cache_key, results, CACHE_TTL)
            
            # Registrar búsqueda
            if user_id:
                from utils.db_utils import log_search
                log_search(db_session, user_id, "hybrid_analysis_hash", file_hash, f"Reportes: {len(results['reports'])}")
        
        return results
    
    def get_educational_resources(self) -> Dict[str, Any]:
        """
        Obtiene recursos educativos sobre inteligencia de amenazas.
        
        Returns:
            dict: Recursos educativos
        """
        return {
            "threat_intel_basics": [
                "La Inteligencia de Amenazas (Threat Intelligence) es información basada en evidencia sobre amenazas cibernéticas.",
                "Ayuda a las organizaciones a tomar decisiones informadas sobre seguridad.",
                "Incluye mecanismos, indicadores, implicaciones y consejos orientados a la acción.",
                "Los Indicadores de Compromiso (IoCs) son artefactos observados en una red o sistema operativo que indican una intrusión.",
                "Tipos comunes de IoCs: direcciones IP, dominios, hashes de archivos, URLs maliciosas.",
                "Las plataformas de Threat Intelligence agregan y correlacionan datos de múltiples fuentes.",
                "Existen diferentes niveles de inteligencia: estratégica, táctica y operacional.",
                "El ciclo de vida de la inteligencia de amenazas incluye: planificación, recolección, procesamiento, análisis, difusión y retroalimentación.",
                "Compartir inteligencia de amenazas (Threat Sharing) ayuda a la comunidad a defenderse mejor.",
                "Es importante evaluar la calidad y relevancia de la inteligencia de amenazas antes de actuar."
            ],
            "key_concepts": [
                "TTPs (Tácticas, Técnicas y Procedimientos): Describen el comportamiento de los actores de amenazas.",
                "Actores de Amenazas: Individuos o grupos responsables de ciberataques (ej. APTs, cibercriminales).",
                "Campañas: Conjunto de actividades maliciosas coordinadas con objetivos específicos.",
                "Malware: Software diseñado para dañar o explotar sistemas.",
                "Vulnerabilidades: Debilidades en software o hardware que pueden ser explotadas.",
                "Exploits: Código que aprovecha una vulnerabilidad específica.",
                "Zero-Day: Vulnerabilidad desconocida para el proveedor y sin parche disponible.",
                "Phishing: Intento de engañar a usuarios para obtener información sensible.",
                "Ransomware: Malware que cifra archivos y exige un rescate.",
                "Botnet: Red de dispositivos comprometidos controlados por un atacante."
            ],
            "learning_resources": [
                "https://otx.alienvault.com/ - Plataforma abierta de inteligencia de amenazas",
                "https://www.hybrid-analysis.com/ - Análisis de malware y sandbox",
                "https://www.virustotal.com/ - Análisis de archivos y URLs",
                "https://attack.mitre.org/ - Base de conocimiento de tácticas y técnicas adversarias",
                "https://www.first.org/ - Foro de Equipos de Respuesta a Incidentes y Seguridad",
                "https://www.cisa.gov/uscert/ - Equipo de Preparación para Emergencias Informáticas de EE. UU.",
                "https://www.enisa.europa.eu/topics/threat-risk-management - Agencia de la UE para la Ciberseguridad",
                "https://malpedia.caad.fkie.fraunhofer.de/ - Enciclopedia de familias de malware",
                "https://threatmap.checkpoint.com/ - Mapa de ciberataques en tiempo real",
                "https://www.sans.org/reading-room/whitepapers/analyst - Recursos del SANS Institute"
            ]
        }

# Crear instancia si se ejecuta directamente
if __name__ == "__main__":
    threat_intel = ThreatIntelligence()
    import asyncio
    
    async def test():
        # Test OTX IP analysis (requires OTX API key)
        # ip_indicator = "91.198.174.192" # Example: Wikipedia IP
        # otx_ip_result = await threat_intel.analyze_indicator_otx("ipv4", ip_indicator, "general")
        # print("\n--- OTX IP Analysis ---")
        # print(json.dumps(otx_ip_result, indent=2))
        
        # Test OTX Domain analysis (requires OTX API key)
        # domain_indicator = "google.com"
        # otx_domain_result = await threat_intel.analyze_indicator_otx("domain", domain_indicator, "passive_dns")
        # print("\n--- OTX Domain Analysis ---")
        # print(json.dumps(otx_domain_result, indent=2))
        
        # Test Hybrid Analysis hash analysis (requires HA API key)
        # hash_indicator = "c341e115c8f0197e62741717c9b5b3f7" # Example MD5 hash
        # ha_hash_result = await threat_intel.analyze_hash_hybrid_analysis(hash_indicator)
        # print("\n--- Hybrid Analysis Hash Analysis ---")
        # print(json.dumps(ha_hash_result, indent=2))
        
        print("\n--- Educational Resources ---")
        edu_resources = threat_intel.get_educational_resources()
        print(json.dumps(edu_resources, indent=2))
            
    asyncio.run(test())
