# GleySxycBot v2.0

## Bot Educativo Avanzado de Ciberseguridad

GleySxycBot v2.0 es una herramienta educativa completa para el aprendizaje y práctica de conceptos de ciberseguridad, análisis forense, OSINT, y protección digital. Esta versión ha sido completamente rediseñada y mejorada para ofrecer funcionalidades reales, avanzadas y agresivas en el ámbito de la seguridad informática.

## Características Principales

- **Arquitectura modular avanzada**: Diseño flexible y extensible que permite la fácil integración de nuevos módulos y funcionalidades.
- **Análisis de URL y dominios**: Verificación de reputación, análisis de contenido y detección de amenazas en tiempo real.
- **Geolocalización IP avanzada**: Información detallada sobre ubicación, ISP, ASN y datos contextuales de direcciones IP.
- **Herramientas OSINT completas**: Recopilación y análisis de información de fuentes abiertas con múltiples integraciones.
- **Seguridad web interactiva**: Análisis de vulnerabilidades, cabeceras de seguridad y configuraciones de servidores web.
- **Inteligencia de amenazas**: Monitoreo y análisis de amenazas emergentes con datos de múltiples fuentes.
- **Análisis forense digital**: Herramientas para investigación y análisis de evidencias digitales.
- **Criptografía práctica**: Funciones de cifrado, descifrado, hashing y análisis criptográfico.
- **Laboratorio de malware educativo**: Entorno controlado para el estudio de malware y técnicas de análisis.
- **Simulador de ataques controlados**: Simulaciones educativas de técnicas comunes de ataque para comprender vectores y defensas.
- **Comunidad de seguridad**: Acceso a recursos, noticias y desafíos de la comunidad de ciberseguridad.
- **Asistente de seguridad personal**: Evaluación de riesgos y recomendaciones personalizadas para mejorar la seguridad.
- **Herramientas de red avanzadas**: Análisis de tráfico, escaneo de redes, traceroute y análisis DNS/SSL.
- **Seguridad en redes sociales**: Análisis de privacidad y protección de información en plataformas sociales.

## Instalación

### Requisitos

- Python 3.8 o superior
- pip (gestor de paquetes de Python)
- Conexión a Internet para acceder a APIs y servicios externos

### Pasos de instalación

1. Clona el repositorio:
   ```
   git clone https://github.com/usuario/gleySxycBot_v2.git
   cd gleySxycBot_v2
   ```

2. Instala las dependencias:
   ```
   pip install -r requirements.txt
   ```

3. Configura las variables de entorno:
   - Copia el archivo `config/config.example.py` a `config/config.py`
   - Edita `config/config.py` para añadir tus claves API y configuraciones personalizadas

4. Inicia el bot:
   ```
   python main.py
   ```

## Configuración

El archivo `config/config.py` contiene todas las configuraciones necesarias para el funcionamiento del bot:

- **TOKEN_BOT**: Token de Telegram para el bot
- **API_KEYS**: Claves para los diferentes servicios y APIs utilizados
- **CACHE_TTL**: Tiempo de vida de la caché para resultados de consultas
- **LOG_LEVEL**: Nivel de detalle para los registros
- **ETHICAL_WARNING**: Mensaje de advertencia ética para funciones sensibles

## Uso

### Comandos básicos

- `/start` - Inicia la conversación con el bot
- `/help` - Muestra la ayuda y lista de comandos disponibles
- `/menu` - Muestra el menú principal de opciones

### Módulos principales

#### Análisis de URL

```
/url_analyze https://ejemplo.com
```
Realiza un análisis completo de la URL proporcionada, incluyendo reputación, contenido y posibles amenazas.

#### Geolocalización IP

```
/geoip 8.8.8.8
```
Proporciona información detallada sobre la ubicación geográfica de la dirección IP.

#### Herramientas OSINT

```
/osint_domain ejemplo.com
/osint_email usuario@ejemplo.com
/osint_username usuario123
```
Recopila información disponible públicamente sobre dominios, correos electrónicos o nombres de usuario.

#### Seguridad Web

```
/websec_headers https://ejemplo.com
/websec_scan https://ejemplo.com
```
Analiza cabeceras de seguridad y busca vulnerabilidades comunes en sitios web.

#### Inteligencia de Amenazas

```
/threat_check malware.ejemplo.com
/threat_intel latest
```
Verifica indicadores de compromiso y obtiene información sobre amenazas recientes.

#### Análisis Forense

```
/forensic_hash 5f4dcc3b5aa765d61d8327deb882cf99
/forensic_file [adjunto]
```
Analiza hashes y archivos para detectar posibles amenazas o malware.

#### Criptografía

```
/crypto_hash texto_a_hashear
/crypto_encrypt texto_a_cifrar
/crypto_decrypt [texto_cifrado] [clave]
```
Realiza operaciones criptográficas como hashing, cifrado y descifrado.

#### Laboratorio de Malware

```
/malware_info ransomware
/malware_behavior [hash_o_nombre]
```
Proporciona información educativa sobre malware y su comportamiento.

#### Simulador de Ataques

```
/simulate_portscan 192.168.1.1
/simulate_phishing
/simulate_vulnscan https://ejemplo.com
```
Simula técnicas de ataque con fines educativos en entornos controlados.

#### Comunidad de Seguridad

```
/security_news
/community_resources ctf
/security_challenge medium
```
Accede a noticias, recursos y desafíos de la comunidad de ciberseguridad.

#### Asistente de Seguridad

```
/security_assessment
/check_email_breach usuario@ejemplo.com
/check_password_security
```
Evalúa riesgos de seguridad y proporciona recomendaciones personalizadas.

#### Herramientas de Red

```
/network_scan 192.168.1.0/24
/traceroute ejemplo.com
/analyze_dns ejemplo.com
/ssl_certificate ejemplo.com
```
Realiza análisis de redes, rutas, DNS y certificados SSL.

#### Seguridad en Redes Sociales

```
/social_profile_security facebook
/scan_exposed_info [texto]
/privacy_guide instagram
```
Analiza la seguridad y privacidad en plataformas de redes sociales.

## Arquitectura

GleySxycBot v2.0 está construido con una arquitectura modular que facilita la extensibilidad y mantenimiento:

```
gleySxycBot_v2/
├── config/             # Configuraciones y variables de entorno
├── core/               # Núcleo del bot y gestión de comandos
├── modules/            # Módulos funcionales específicos
│   ├── url_analyzer.py
│   ├── geolocation_ip.py
│   ├── osint_tools.py
│   ├── web_security.py
│   ├── threat_intelligence.py
│   ├── forensic_analysis.py
│   ├── cryptography_tools.py
│   ├── malware_lab.py
│   ├── controlled_attack_simulator.py
│   ├── security_community.py
│   ├── security_assistant.py
│   ├── network_tools.py
│   └── social_media_security.py
├── utils/              # Utilidades y funciones auxiliares
├── data/               # Datos y recursos estáticos
├── docs/               # Documentación
└── tests/              # Pruebas unitarias y de integración
```

## Integración de Servicios

GleySxycBot v2.0 integra múltiples servicios gratuitos para proporcionar información completa y actualizada:

- **VirusTotal**: Análisis de URLs, dominios y archivos
- **AbuseIPDB**: Verificación de IPs maliciosas
- **IPinfo.io**: Datos de geolocalización IP
- **Shodan**: Información sobre dispositivos conectados a Internet
- **URLScan.io**: Análisis de contenido web
- **PhishTank**: Detección de sitios de phishing
- **Have I Been Pwned**: Verificación de brechas de datos
- **AlienVault OTX**: Inteligencia de amenazas
- **SecurityTrails**: Información histórica de DNS
- **CIRCL**: Información sobre malware y vulnerabilidades
- **MISP**: Plataforma de intercambio de información sobre amenazas
- **NIST NVD**: Base de datos de vulnerabilidades
- **Censys**: Datos sobre hosts y certificados en Internet
- **DNSdumpster**: Información de DNS
- **Wayback Machine**: Archivos históricos de sitios web

## Consideraciones Éticas

GleySxycBot v2.0 está diseñado exclusivamente con fines educativos y de investigación en ciberseguridad. El uso de las herramientas y funcionalidades proporcionadas debe ser ético y legal:

- Utiliza el bot solo en sistemas y redes sobre los que tengas autorización explícita
- No utilices las herramientas para actividades maliciosas o ilegales
- Respeta la privacidad y los derechos de los demás
- Sigue las mejores prácticas de divulgación responsable de vulnerabilidades
- Las simulaciones de ataques deben realizarse únicamente en entornos controlados y autorizados

## Contribución

Las contribuciones son bienvenidas. Para contribuir:

1. Haz un fork del repositorio
2. Crea una rama para tu funcionalidad (`git checkout -b nueva-funcionalidad`)
3. Realiza tus cambios y añade pruebas
4. Envía un pull request

Por favor, asegúrate de seguir las directrices de código y documentación.

## Licencia

Este proyecto está licenciado bajo la Licencia MIT - ver el archivo LICENSE para más detalles.

## Contacto

Para preguntas, sugerencias o reportes de problemas, por favor abre un issue en el repositorio o contacta al desarrollador principal.

---

**Nota**: GleySxycBot v2.0 es una herramienta educativa. Los autores no se hacen responsables del mal uso que se pueda hacer de la misma.
