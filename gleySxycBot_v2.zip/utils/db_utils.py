"""
Módulo de utilidades para la base de datos del bot.

Este módulo proporciona funciones para interactuar con la base de datos SQLite,
incluyendo la creación de tablas, consultas y gestión de datos de usuario.
"""

import logging
import sqlite3
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime

from sqlalchemy import create_engine, Column, Integer, String, Boolean, DateTime, Text, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, scoped_session
from sqlalchemy.sql import func

# Importar configuración
from config.config import DB_URL

# Configuración de logging
logger = logging.getLogger(__name__)

# Crear motor de base de datos
engine = create_engine(DB_URL)
SessionLocal = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))

# Crear base para modelos
Base = declarative_base()

class User(Base):
    """Modelo para almacenar información de usuarios."""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True, index=True)
    username = Column(String(255), nullable=True)
    first_name = Column(String(255))
    last_name = Column(String(255), nullable=True)
    language_code = Column(String(10), default="es")
    is_premium = Column(Boolean, default=False)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.now())
    last_active = Column(DateTime, default=func.now())
    settings = Column(JSON, default=dict)
    
    # Relaciones
    searches = relationship("Search", back_populates="user")
    api_usage = relationship("ApiUsage", back_populates="user")
    
    def __repr__(self):
        return f"<User {self.telegram_id}: {self.username or self.first_name}>"

class Search(Base):
    """Modelo para almacenar búsquedas de usuarios."""
    __tablename__ = "searches"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    type = Column(String(50))  # url, ip, domain, etc.
    query = Column(String(255))
    result_summary = Column(Text, nullable=True)
    created_at = Column(DateTime, default=func.now())
    
    # Relaciones
    user = relationship("User", back_populates="searches")
    
    def __repr__(self):
        return f"<Search {self.id}: {self.type} - {self.query}>"

class ApiUsage(Base):
    """Modelo para registrar el uso de APIs."""
    __tablename__ = "api_usage"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    api_name = Column(String(50))
    endpoint = Column(String(255))
    success = Column(Boolean, default=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=func.now())
    
    # Relaciones
    user = relationship("User", back_populates="api_usage")
    
    def __repr__(self):
        return f"<ApiUsage {self.id}: {self.api_name} - {self.endpoint}>"

class CachedResult(Base):
    """Modelo para almacenar resultados en caché."""
    __tablename__ = "cached_results"
    
    id = Column(Integer, primary_key=True)
    cache_key = Column(String(255), unique=True, index=True)
    result = Column(JSON)
    created_at = Column(DateTime, default=func.now())
    expires_at = Column(DateTime)
    
    def __repr__(self):
        return f"<CachedResult {self.id}: {self.cache_key}>"

class Plugin(Base):
    """Modelo para almacenar información de plugins."""
    __tablename__ = "plugins"
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True)
    version = Column(String(20))
    enabled = Column(Boolean, default=True)
    settings = Column(JSON, default=dict)
    
    def __repr__(self):
        return f"<Plugin {self.name} v{self.version}>"

def init_db():
    """Inicializa la base de datos creando todas las tablas."""
    Base.metadata.create_all(bind=engine)
    logger.info("Base de datos inicializada")

def get_db():
    """Obtiene una sesión de base de datos."""
    db = SessionLocal()
    try:
        return db
    finally:
        db.close()

def get_or_create_user(db, telegram_user):
    """
    Obtiene o crea un usuario en la base de datos.
    
    Args:
        db: Sesión de base de datos
        telegram_user: Usuario de Telegram
        
    Returns:
        User: Objeto de usuario
    """
    user = db.query(User).filter(User.telegram_id == telegram_user.id).first()
    
    if not user:
        user = User(
            telegram_id=telegram_user.id,
            username=telegram_user.username,
            first_name=telegram_user.first_name,
            last_name=telegram_user.last_name,
            language_code=telegram_user.language_code
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        logger.info(f"Nuevo usuario creado: {user}")
    else:
        # Actualizar información del usuario
        user.username = telegram_user.username
        user.first_name = telegram_user.first_name
        user.last_name = telegram_user.last_name
        user.language_code = telegram_user.language_code
        user.last_active = func.now()
        db.commit()
    
    return user

def log_search(db, user_id, search_type, query, result_summary=None):
    """
    Registra una búsqueda en la base de datos.
    
    Args:
        db: Sesión de base de datos
        user_id: ID del usuario
        search_type: Tipo de búsqueda (url, ip, etc.)
        query: Consulta realizada
        result_summary: Resumen del resultado
        
    Returns:
        Search: Objeto de búsqueda creado
    """
    search = Search(
        user_id=user_id,
        type=search_type,
        query=query,
        result_summary=result_summary
    )
    db.add(search)
    db.commit()
    db.refresh(search)
    return search

def log_api_usage(db, user_id, api_name, endpoint, success=True, error_message=None):
    """
    Registra el uso de una API en la base de datos.
    
    Args:
        db: Sesión de base de datos
        user_id: ID del usuario
        api_name: Nombre de la API
        endpoint: Endpoint utilizado
        success: Si la llamada fue exitosa
        error_message: Mensaje de error si la llamada falló
        
    Returns:
        ApiUsage: Objeto de uso de API creado
    """
    api_usage = ApiUsage(
        user_id=user_id,
        api_name=api_name,
        endpoint=endpoint,
        success=success,
        error_message=error_message
    )
    db.add(api_usage)
    db.commit()
    db.refresh(api_usage)
    return api_usage

def get_cached_result(db, cache_key):
    """
    Obtiene un resultado en caché.
    
    Args:
        db: Sesión de base de datos
        cache_key: Clave de caché
        
    Returns:
        dict: Resultado en caché o None si no existe o ha expirado
    """
    cached = db.query(CachedResult).filter(
        CachedResult.cache_key == cache_key,
        CachedResult.expires_at > func.now()
    ).first()
    
    if cached:
        return cached.result
    return None

def set_cached_result(db, cache_key, result, ttl_seconds=3600):
    """
    Almacena un resultado en caché.
    
    Args:
        db: Sesión de base de datos
        cache_key: Clave de caché
        result: Resultado a almacenar
        ttl_seconds: Tiempo de vida en segundos
        
    Returns:
        CachedResult: Objeto de caché creado
    """
    # Eliminar caché existente con la misma clave
    db.query(CachedResult).filter(CachedResult.cache_key == cache_key).delete()
    
    # Crear nueva entrada en caché
    expires_at = datetime.now().timestamp() + ttl_seconds
    cached = CachedResult(
        cache_key=cache_key,
        result=result,
        expires_at=datetime.fromtimestamp(expires_at)
    )
    db.add(cached)
    db.commit()
    db.refresh(cached)
    return cached

def cleanup_expired_cache(db):
    """
    Elimina entradas de caché expiradas.
    
    Args:
        db: Sesión de base de datos
        
    Returns:
        int: Número de entradas eliminadas
    """
    deleted = db.query(CachedResult).filter(
        CachedResult.expires_at <= func.now()
    ).delete()
    db.commit()
    return deleted

def get_user_stats(db, user_id):
    """
    Obtiene estadísticas de uso para un usuario.
    
    Args:
        db: Sesión de base de datos
        user_id: ID del usuario
        
    Returns:
        dict: Estadísticas del usuario
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        return None
    
    search_count = db.query(Search).filter(Search.user_id == user_id).count()
    api_usage_count = db.query(ApiUsage).filter(ApiUsage.user_id == user_id).count()
    
    # Búsquedas por tipo
    search_types = db.query(Search.type, func.count(Search.id)).filter(
        Search.user_id == user_id
    ).group_by(Search.type).all()
    
    # APIs utilizadas
    api_usage = db.query(ApiUsage.api_name, func.count(ApiUsage.id)).filter(
        ApiUsage.user_id == user_id
    ).group_by(ApiUsage.api_name).all()
    
    return {
        "user": {
            "telegram_id": user.telegram_id,
            "username": user.username,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "created_at": user.created_at.isoformat(),
            "last_active": user.last_active.isoformat(),
            "is_premium": user.is_premium,
            "is_admin": user.is_admin
        },
        "usage": {
            "total_searches": search_count,
            "total_api_calls": api_usage_count,
            "search_types": dict(search_types),
            "api_usage": dict(api_usage)
        }
    }

def get_plugin_settings(db, plugin_name):
    """
    Obtiene la configuración de un plugin.
    
    Args:
        db: Sesión de base de datos
        plugin_name: Nombre del plugin
        
    Returns:
        dict: Configuración del plugin o un diccionario vacío si no existe
    """
    plugin = db.query(Plugin).filter(Plugin.name == plugin_name).first()
    if plugin:
        return plugin.settings
    return {}

def update_plugin_settings(db, plugin_name, settings, version="1.0.0"):
    """
    Actualiza la configuración de un plugin.
    
    Args:
        db: Sesión de base de datos
        plugin_name: Nombre del plugin
        settings: Nueva configuración
        version: Versión del plugin
        
    Returns:
        Plugin: Objeto de plugin actualizado
    """
    plugin = db.query(Plugin).filter(Plugin.name == plugin_name).first()
    
    if not plugin:
        plugin = Plugin(
            name=plugin_name,
            version=version,
            settings=settings
        )
        db.add(plugin)
    else:
        plugin.settings = settings
        plugin.version = version
    
    db.commit()
    db.refresh(plugin)
    return plugin

def update_user_settings(db, telegram_id, settings):
    """
    Actualiza la configuración de un usuario.
    
    Args:
        db: Sesión de base de datos
        telegram_id: ID de Telegram del usuario
        settings: Nueva configuración
        
    Returns:
        User: Objeto de usuario actualizado
    """
    user = db.query(User).filter(User.telegram_id == telegram_id).first()
    if user:
        user.settings = settings
        db.commit()
        db.refresh(user)
        return user
    return None

# Inicializar la base de datos si se ejecuta este módulo directamente
if __name__ == "__main__":
    init_db()
    print("Base de datos inicializada correctamente")
