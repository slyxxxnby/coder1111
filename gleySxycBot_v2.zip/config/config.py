"""
Configuración principal para GleySxycBot v2.

Este módulo contiene la configuración centralizada para todas las funcionalidades
del bot, incluyendo claves de API, configuraciones de base de datos, y opciones
de personalización.
"""

import os
import logging
from pathlib import Path
from dotenv import load_dotenv
import yaml
import json

# Cargar variables de entorno
load_dotenv()

# Rutas de directorios
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
LOGS_DIR = BASE_DIR / "logs"
CACHE_DIR = DATA_DIR / "cache"
DB_DIR = DATA_DIR / "db"
TEMP_DIR = DATA_DIR / "temp"
PLUGINS_DIR = BASE_DIR / "plugins"

# Crear directorios si no existen
for directory in [DATA_DIR, LOGS_DIR, CACHE_DIR, DB_DIR, TEMP_DIR, PLUGINS_DIR]:
    directory.mkdir(exist_ok=True, parents=True)

# Configuración del bot
BOT_NAME = "GleySxycBot"
BOT_VERSION = "2.0.0"
BOT_DESCRIPTION = "Bot avanzado de ciberseguridad para Telegram"
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN', '')

# Configuración de base de datos
DB_URL = f"sqlite:///{DB_DIR}/gleysxycbot.db"

# Configuración de logging
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
LOG_FILE = LOGS_DIR / "bot.log"

# Configuración de caché
CACHE_ENABLED = True
CACHE_TTL = 3600  # Tiempo de vida en segundos (1 hora)
CACHE_MAX_SIZE = 1000  # Número máximo de elementos en caché

# Configuración de APIs
API_KEYS = {
    'virustotal': os.getenv('VIRUSTOTAL_API_KEY', ''),
    'urlscan': os.getenv('URLSCAN_API_KEY', ''),
    'ipinfo': os.getenv('IPINFO_API_KEY', ''),
    'shodan': os.getenv('SHODAN_API_KEY', ''),
    'abuseipdb': os.getenv('ABUSEIPDB_API_KEY', ''),
    'hibp': os.getenv('HIBP_API_KEY', ''),
    'otx': os.getenv('OTX_API_KEY', ''),
    'phishtank': os.getenv('PHISHTANK_API_KEY', ''),
    'securitytrails': os.getenv('SECURITYTRAILS_API_KEY', ''),
    'hybrid_analysis': os.getenv('HYBRID_ANALYSIS_API_KEY', ''),
    'mxtoolbox': os.getenv('MXTOOLBOX_API_KEY', ''),
}

# Configuración de idiomas
DEFAULT_LANGUAGE = 'es'
AVAILABLE_LANGUAGES = ['es', 'en', 'pt', 'fr', 'de']

# Límites y restricciones
RATE_LIMIT = {
    'default': 5,  # Solicitudes por minuto para usuarios normales
    'premium': 20,  # Solicitudes por minuto para usuarios premium
    'admin': 100,   # Solicitudes por minuto para administradores
}

MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB
MAX_TEXT_LENGTH = 4096  # Límite de Telegram para mensajes

# Advertencia ética
ETHICAL_WARNING = """
⚠️ *ADVERTENCIA ÉTICA* ⚠️

Este bot está diseñado con fines *exclusivamente educativos* para aprender sobre ciberseguridad defensiva.

Al usar este bot, te comprometes a:
• Utilizar las herramientas solo con fines educativos
• No usar las funcionalidades para actividades maliciosas
• Respetar la privacidad y seguridad de terceros

El uso indebido de estas herramientas puede tener consecuencias legales.
"""

# Configuración de plugins
ENABLED_PLUGINS = []

def load_plugins_config():
    """Carga la configuración de plugins desde el archivo de configuración."""
    config_file = BASE_DIR / "config" / "plugins.yaml"
    if config_file.exists():
        with open(config_file, 'r') as file:
            try:
                config = yaml.safe_load(file)
                return config.get('plugins', [])
            except Exception as e:
                logging.error(f"Error al cargar configuración de plugins: {e}")
    return []

def save_plugins_config(plugins_config):
    """Guarda la configuración de plugins en el archivo de configuración."""
    config_file = BASE_DIR / "config" / "plugins.yaml"
    with open(config_file, 'w') as file:
        yaml.dump({'plugins': plugins_config}, file)

def get_api_key(service):
    """Obtiene la clave de API para un servicio específico."""
    return API_KEYS.get(service, '')

def has_api_key(service):
    """Verifica si hay una clave de API configurada para un servicio específico."""
    return bool(get_api_key(service))

def get_api_status():
    """Obtiene el estado de configuración de todas las APIs."""
    return {service: bool(key) for service, key in API_KEYS.items()}

def load_user_settings(user_id):
    """Carga la configuración personalizada de un usuario."""
    settings_file = DATA_DIR / "user_settings" / f"{user_id}.json"
    if settings_file.exists():
        with open(settings_file, 'r') as file:
            try:
                return json.load(file)
            except Exception as e:
                logging.error(f"Error al cargar configuración de usuario {user_id}: {e}")
    return {}

def save_user_settings(user_id, settings):
    """Guarda la configuración personalizada de un usuario."""
    settings_dir = DATA_DIR / "user_settings"
    settings_dir.mkdir(exist_ok=True)
    settings_file = settings_dir / f"{user_id}.json"
    with open(settings_file, 'w') as file:
        json.dump(settings, file)

# Cargar configuración de plugins al iniciar
ENABLED_PLUGINS = load_plugins_config()
