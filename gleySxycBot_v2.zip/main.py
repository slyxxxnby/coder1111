"""
Punto de entrada principal para GleySxycBot v2.0.

Este archivo inicia el bot y configura los manejadores de comandos
y funcionalidades principales.
"""

import os
import sys
import logging
import asyncio
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('bot.log')
    ]
)

logger = logging.getLogger(__name__)

# Importar configuración
try:
    from config.config import TOKEN_BOT, LOG_LEVEL
    logging.getLogger().setLevel(LOG_LEVEL)
except ImportError:
    logger.error("Error al importar configuración. Asegúrate de que el archivo config.py existe.")
    sys.exit(1)

# Importar núcleo del bot
try:
    from core.bot import GleySxycBot
except ImportError:
    logger.error("Error al importar el núcleo del bot. Verifica la estructura del proyecto.")
    sys.exit(1)

def main():
    """Función principal para iniciar el bot."""
    logger.info("Iniciando GleySxycBot v2.0...")
    
    try:
        # Crear instancia del bot
        bot = GleySxycBot(TOKEN_BOT)
        
        # Iniciar el bot
        logger.info("Bot iniciado correctamente. Presiona Ctrl+C para detener.")
        bot.run()
        
    except KeyboardInterrupt:
        logger.info("Bot detenido manualmente.")
    except Exception as e:
        logger.error(f"Error al iniciar el bot: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Mostrar banner
    print("""
    ██████╗ ██╗     ███████╗██╗   ██╗███████╗██╗  ██╗██╗   ██╗ ██████╗██████╗  ██████╗ ████████╗
   ██╔════╝ ██║     ██╔════╝╚██╗ ██╔╝██╔════╝╚██╗██╔╝╚██╗ ██╔╝██╔════╝██╔══██╗██╔═══██╗╚══██╔══╝
   ██║  ███╗██║     █████╗   ╚████╔╝ ███████╗ ╚███╔╝  ╚████╔╝ ██║     ██████╔╝██║   ██║   ██║   
   ██║   ██║██║     ██╔══╝    ╚██╔╝  ╚════██║ ██╔██╗   ╚██╔╝  ██║     ██╔══██╗██║   ██║   ██║   
   ╚██████╔╝███████╗███████╗   ██║   ███████║██╔╝ ██╗   ██║   ╚██████╗██████╔╝╚██████╔╝   ██║   
    ╚═════╝ ╚══════╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝╚═════╝  ╚═════╝    ╚═╝   
                                                                                    v2.0
    Bot Educativo Avanzado de Ciberseguridad
    """)
    
    print(f"Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("Iniciando servicios...")
    print("-" * 80)
    
    # Iniciar el bot
    main()
