import nmap
import asyncio
import subprocess
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes
from config import MAX_THREADS, REQUEST_TIMEOUT

async def escanear_red_brutal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manejador principal para escaneos de red con Nmap"""
    if not context.args:
        await update.message.reply_text(
            "Uso: /escanear_red [ip|dominio] [opciones]\n\n"
            "Opciones disponibles:\n"
            "- rapido: Escaneo rápido de puertos comunes (-T4 -F)\n"
            "- completo: Escaneo con detección de servicios (-T4 -A -v)\n"
            "- vulner: Escaneo con scripts de vulnerabilidades (--script vuln)\n"
            "- os: Detección de sistema operativo (-O)\n"
            "- traceroute: Ruta de red al objetivo\n"
            "Ejemplo: /escanear_red 192.168.1.1 rapido completo"
        )
        return

    objetivo_str = context.args[0]
    opciones = context.args[1:] if len(context.args) > 1 else ["rapido"]
    
    mensaje_carga = await update.message.reply_text("💣 Preparando paquete de asalto de red... ¡Puede llevar tiempo!")
    
    respuesta = f"🔌 *ESCANEO DE RED BRUTAL - {objetivo_str.upper()}* 🔌\n\n"
    
    # Verificar e inicializar Nmap
    nm = await inicializar_nmap()
    if nm is None:
        await context.bot.edit_message_text(
            chat_id=mensaje_carga.chat_id, 
            message_id=mensaje_carga.message_id,
            text="❌ Error: Nmap no está instalado o no se encuentra en el PATH del sistema. Esta función requiere Nmap."
        )
        return

    # Resolver objetivo a IP si es necesario
    ip_objetivo = await resolver_objetivo(objetivo_str, context, mensaje_carga)
    if ip_objetivo is None:
        return  # El error ya fue manejado

    respuesta += f"Objetivo: {objetivo_str} -> {ip_objetivo}\n\n"

    # Ejecutar escaneos según las opciones
    if 'rapido' in opciones:
        await actualizar_mensaje(context, mensaje_carga, respuesta + "\nEjecutando escaneo rápido Nmap...")
        respuesta += await ejecutar_escaneo_nmap_rapido(nm, ip_objetivo)
    
    if 'completo' in opciones:
        await actualizar_mensaje(context, mensaje_carga, respuesta + "\nEjecutando escaneo completo Nmap (esto tardará)...")
        respuesta += await ejecutar_escaneo_nmap_completo(nm, ip_objetivo)
    
    if 'vulner' in opciones:
        await actualizar_mensaje(context, mensaje_carga, respuesta + "\nEjecutando escaneo de vulnerabilidades Nmap (esto tardará MUCHO)...")
        respuesta += await ejecutar_escaneo_nmap_vulner(nm, ip_objetivo)

    if 'os' in opciones:
        await actualizar_mensaje(context, mensaje_carga, respuesta + "\nEjecutando detección de OS Nmap...")
        respuesta += await ejecutar_escaneo_nmap_os(nm, ip_objetivo)

    # Ejecutar Traceroute
    if 'traceroute' in opciones:
        await actualizar_mensaje(context, mensaje_carga, respuesta + "\nEjecutando traceroute...")
        respuesta += "\n🛤️ *TRACEROUTE*\n"
        respuesta += await ejecutar_traceroute(ip_objetivo)

    # Limitar longitud de respuesta para Telegram
    if len(respuesta) > 4000:
        respuesta = respuesta[:4000] + "\n\n... (Respuesta truncada por longitud)"

    await context.bot.edit_message_text(
        chat_id=mensaje_carga.chat_id,
        message_id=mensaje_carga.message_id,
        text=respuesta,
        parse_mode="Markdown"
    )

async def inicializar_nmap() -> Optional[nmap.PortScanner]:
    """Inicializa y retorna un objeto Nmap PortScanner"""
    try:
        nm = nmap.PortScanner()
        # Verificar que nmap está realmente disponible
        nm.command_line()  # Esto lanzará una excepción si nmap no está disponible
        return nm
    except (nmap.nmap.PortScannerError, AttributeError):
        return None

async def resolver_objetivo(objetivo_str: str, context, mensaje_carga) -> Optional[str]:
    """Resuelve el objetivo a una dirección IP"""
    if es_ip_valida(objetivo_str):
        return objetivo_str
    
    try:
        ip_objetivo = socket.gethostbyname(objetivo_str)
        return ip_objetivo
    except socket.gaierror:
        await context.bot.edit_message_text(
            chat_id=mensaje_carga.chat_id, 
            message_id=mensaje_carga.message_id,
            text=f"❌ No se pudo resolver el host: {objetivo_str}"
        )
        return None

async def actualizar_mensaje(context, mensaje_carga, texto):
    """Actualiza el mensaje de carga con nuevo texto"""
    try:
        await context.bot.edit_message_text(
            chat_id=mensaje_carga.chat_id,
            message_id=mensaje_carga.message_id,
            text=texto,
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Error actualizando mensaje: {e}")

async def ejecutar_escaneo_nmap_rapido(nm, objetivo):
    """Ejecuta un escaneo rápido de Nmap (-T4 -F)"""
    resultado = "🚀 *RESULTADOS ESCANEO RÁPIDO NMAP (-T4 -F)*\n"
    try:
        nm.scan(hosts=objetivo, arguments='-T4 -F')  # Escaneo rápido de los 100 puertos más comunes
        
        if objetivo not in nm.all_hosts():
            return resultado + "   El host parece estar caído o no responde.\n"
        
        host = nm[objetivo]
        resultado += f"   Estado del Host: {host.state()}\n"
        
        for proto in host.all_protocols():
            resultado += f"\n   Protocolo: {proto.upper()}\n"
            puertos = sorted(host[proto].keys())
            
            for port in puertos:
                info_puerto = host[proto][port]
                resultado += f"     Puerto {port}: {info_puerto['state']}"
                if 'name' in info_puerto: 
                    resultado += f" ({info_puerto['name']})"
                resultado += "\n"
                
                # Mostrar versión si está disponible incluso en escaneo rápido
                if 'version' in info_puerto:
                    resultado += f"       Versión: {info_puerto['version']}\n"
                
                # Mostrar razón si está disponible
                if 'reason' in info_puerto:
                    resultado += f"       Razón: {info_puerto['reason']}\n"
        
        # Información adicional si está disponible
        if 'hostnames' in host and host['hostnames']:
            resultado += f"\n   Nombres de Host: {', '.join(h['name'] for h in host['hostnames'])}\n"
        
        if 'status' in host and host['status']:
            resultado += f"   Estado: {host['status']['state']} (Razón: {host['status']['reason']})\n"
        
    except nmap.nmap.PortScannerError as e:
        resultado += f"   ❌ Error de Nmap: {str(e)}\n"
    except Exception as e:
        resultado += f"   ❌ Error durante el escaneo: {str(e)}\n"
    
    return resultado + "\n"

async def ejecutar_escaneo_nmap_completo(nm, objetivo):
    """Ejecuta un escaneo completo de Nmap (-T4 -A -v)"""
    resultado = "🔍 *RESULTADOS ESCANEO COMPLETO NMAP (-T4 -A -v)*\n"
    try:
        # -A: Detección de OS, versión, script scanning y traceroute
        nm.scan(hosts=objetivo, arguments='-T4 -A -v') 
        
        if objetivo not in nm.all_hosts():
            return resultado + "   El host parece estar caído o no responde.\n"

        host = nm[objetivo]
        resultado += f"   Estado del Host: {host.state()}\n"
        
        for proto in host.all_protocols():
            resultado += f"\n   Protocolo: {proto.upper()}\n"
            puertos = sorted(host[proto].keys())
            
            for port in puertos:
                info_puerto = host[proto][port]
                resultado += f"     Puerto {port}: {info_puerto['state']}"
                if 'name' in info_puerto: 
                    resultado += f" ({info_puerto['name']})"
                
                # Información extendida de servicios
                service_info = []
                if 'product' in info_puerto: 
                    service_info.append(info_puerto['product'])
                if 'version' in info_puerto: 
                    service_info.append(info_puerto['version'])
                if 'extrainfo' in info_puerto: 
                    service_info.append(info_puerto['extrainfo'])
                
                if service_info:
                    resultado += f" - {' '.join(service_info)}"
                
                resultado += "\n"
                
                # Información de scripts si está disponible
                if 'script' in info_puerto:
                    resultado += "       Scripts:\n"
                    for script_name, script_output in info_puerto['script'].items():
                        output_limpio = script_output.replace('\n', '\n         ')
                        resultado += f"       - {script_name}: {output_limpio}\n"
        
        # Detección de OS
        if 'osmatch' in host and host['osmatch']:
            resultado += "\n   🖥️ *DETECCIÓN DE OS (Nmap)*\n"
            for osmatch in host['osmatch'][:3]:  # Mostrar solo las 3 mejores coincidencias
                resultado += f"     - {osmatch['name']} (Precisión: {osmatch['accuracy']}%)\n"
                if 'osclass' in osmatch:
                    for osclass in osmatch['osclass'][:2]:  # Mostrar solo 2 clases por coincidencia
                        resultado += f"       Tipo: {osclass.get('type', 'N/A')}, Vendor: {osclass.get('vendor', 'N/A')}, OS: {osclass.get('osfamily', 'N/A')} {osclass.get('osgen', '')}\n"
        else:
            resultado += "\n   🖥️ *DETECCIÓN DE OS (Nmap)*: No se pudo determinar el OS.\n"
        
        # Traceroute si está disponible
        if 'trace' in host and host['trace']:
            resultado += "\n   🛤️ *TRACEROUTE (Nmap)*\n"
            for hop in host['trace']['hops']:
                resultado += f"     - {hop['host']} ({hop['ipaddr']}) - {hop['rtt']} ms\n"
        
    except nmap.nmap.PortScannerError as e:
        resultado += f"   ❌ Error de Nmap: {str(e)}\n"
    except Exception as e:
        resultado += f"   ❌ Error durante el escaneo: {str(e)}\n"
    
    return resultado + "\n"

async def ejecutar_escaneo_nmap_vulner(nm, objetivo):
    """Ejecuta un escaneo de vulnerabilidades con Nmap (--script vuln)"""
    resultado = "🛡️ *ESCANEO DE VULNERABILIDADES NMAP (-T4 --script vuln)*\n"
    resultado += "   ADVERTENCIA: Este escaneo puede ser intrusivo y tardar mucho.\n"
    
    try:
        nm.scan(hosts=objetivo, arguments='-T4 --script vuln')
        
        if objetivo not in nm.all_hosts():
            return resultado + "   El host parece estar caído o no responde.\n"

        host = nm[objetivo]
        vulnerabilidades_encontradas = False
        
        for proto in host.all_protocols():
            puertos = sorted(host[proto].keys())
            
            for port in puertos:
                if 'script' in host[proto][port]:
                    resultado += f"\n   Vulnerabilidades/Información para Puerto {port} ({proto.upper()}):\n"
                    
                    for script_name, script_output in host[proto][port]['script'].items():
                        output_limpio = script_output.replace('\n', '\n       ')
                        resultado += f"     - {script_name}: {output_limpio}\n"
                        vulnerabilidades_encontradas = True
        
        if not vulnerabilidades_encontradas:
            resultado += "   No se encontraron vulnerabilidades con los scripts 'vuln' de Nmap.\n"
        
        # Recomendaciones adicionales
        resultado += "\n   🔍 *PARA ANÁLISIS DE VULNERABILIDADES AVANZADO:*\n"
        resultado += "   - [OpenVAS](https://www.greenbone.net/en/)\n"
        resultado += "   - [Nessus](https://www.tenable.com/products/nessus)\n"
        resultado += "   - [Nexpose](https://www.rapid7.com/products/nexpose/)\n"
        
    except nmap.nmap.PortScannerError as e:
        resultado += f"   ❌ Error de Nmap: {str(e)}\n"
    except Exception as e:
        resultado += f"   ❌ Error durante el escaneo: {str(e)}\n"
    
    return resultado + "\n"

async def ejecutar_escaneo_nmap_os(nm, objetivo):
    """Ejecuta detección de sistema operativo con Nmap (-O)"""
    resultado = "🖥️ *DETECCIÓN DE OS NMAP (-T4 -O)*\n"
    try:
        # -O para detección de OS. Puede requerir privilegios de root.
        nm.scan(hosts=objetivo, arguments='-T4 -O') 
        
        if objetivo not in nm.all_hosts():
            return resultado + "   El host parece estar caído o no responde.\n"

        host = nm[objetivo]
        
        if 'osmatch' in host and host['osmatch']:
            for osmatch in host['osmatch'][:3]:  # Mostrar solo las 3 mejores coincidencias
                resultado += f"   - {osmatch['name']} (Precisión: {osmatch['accuracy']}%)\n"
                
                if 'osclass' in osmatch:
                    for osclass in osmatch['osclass'][:2]:  # Mostrar solo 2 clases por coincidencia
                        resultado += f"     Tipo: {osclass.get('type', 'N/A')}, Vendor: {osclass.get('vendor', 'N/A')}, Familia OS: {osclass.get('osfamily', 'N/A')}, Gen OS: {osclass.get('osgen', 'N/A')}\n"
        else:
            resultado += "   No se encontraron coincidencias de OS o se requieren privilegios para una detección más precisa.\n"
            
    except nmap.nmap.PortScannerError as e:
        resultado += f"   ❌ Error de Nmap: {str(e)}. La detección de OS podría requerir privilegios de root/administrador.\n"
    except Exception as e:
        resultado += f"   ❌ Error durante el escaneo: {str(e)}\n"
    
    return resultado + "\n"

async def ejecutar_traceroute(objetivo_ip):
    """Ejecuta traceroute/tracert hacia el objetivo"""
    resultado = ""
    
    # Determinar el comando según el sistema operativo
    comando = ['traceroute', objetivo_ip] if os.name != 'nt' else ['tracert', objetivo_ip]
    
    try:
        # Ejecutar en un hilo separado para no bloquear
        proceso = await asyncio.to_thread(
            subprocess.run,
            comando,
            capture_output=True,
            text=True,
            timeout=120,  # Timeout de 2 minutos
            check=False  # No lanzar excepción si falla
        )
        
        if proceso.returncode == 0:
            # Limitar y formatear la salida
            output_lines = proceso.stdout.strip().split('\n')
            
            # Mostrar solo los primeros 15 saltos para no saturar
            max_hops = 15
            if len(output_lines) > max_hops:
                resultado += "\n".join(output_lines[:max_hops]) + f"\n   ... (mostrando {max_hops} de {len(output_lines)} saltos)\n"
            else:
                resultado += proceso.stdout
            
            # Análisis básico de la ruta
            resultado += "\n   🔍 *ANÁLISIS BÁSICO:*\n"
            
            # Contar saltos
            hop_count = len([line for line in output_lines if '*' not in line])
            resultado += f"   - Saltos totales: {hop_count}\n"
            
            # Buscar saltos con alta latencia
            high_latency = False
            for line in output_lines:
                if 'ms' in line:
                    latencies = [float(lat.replace('ms', '')) for lat in line.split() if 'ms' in lat and '*' not in lat]
                    if latencies and max(latencies) > 200:  # Más de 200ms es alta
                        high_latency = True
                        break
            
            if high_latency:
                resultado += "   ⚠️ Se detectaron saltos con alta latencia (>200ms)\n"
            
            # Buscar timeouts (*)
            if any('* * *' in line for line in output_lines):
                resultado += "   ⚠️ Se detectaron timeouts en algunos saltos\n"
            
        else:
            resultado += f"   ❌ Error ejecutando traceroute (código {proceso.returncode}):\n"
            resultado += f"   {proceso.stderr}\n"
            
            # Sugerencias para errores comunes
            if os.name == 'nt' and 'unable to resolve target system name' in proceso.stderr:
                resultado += "   En Windows, tracert puede fallar con IPs si no hay un nombre de host inverso resoluble. Intenta con un dominio si es posible.\n"
    
    except subprocess.TimeoutExpired:
        resultado += "   ❌ Traceroute excedió el tiempo límite (2 minutos).\n"
    except FileNotFoundError:
        resultado += f"   ❌ Comando '{comando[0]}' no encontrado. Asegúrate de que traceroute/tracert esté instalado.\n"
    except Exception as e:
        resultado += f"   ❌ Error ejecutando traceroute: {str(e)}\n"
    
    return resultado