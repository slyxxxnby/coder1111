import re
import asyncio
import concurrent.futures
import requests
import dns.resolver
import hashlib
from urllib.parse import quote_plus, urlparse
from bs4 import BeautifulSoup
from datetime import datetime

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from config import MAX_THREADS, REQUEST_TIMEOUT
from services.geoip import obtener_geolocalizacion
from services.dns_utils import resolver_dns
from services.web_tools import get_random_user_agent, construir_enlace_google_dork

# Lista ampliada de plataformas sociales para verificación
PLATAFORMAS_SOCIALES = {
    "Twitter/X": "https://twitter.com/{}",
    "Instagram": "https://instagram.com/{}",
    "Facebook": "https://facebook.com/{}",
    "GitHub": "https://github.com/{}",
    "TikTok": "https://tiktok.com/@{}",
    "LinkedIn (Perfil)": "https://linkedin.com/in/{}",
    "LinkedIn (Búsqueda)": "https://www.linkedin.com/pub/dir/?firstName={}&lastName={}",
    "Reddit": "https://reddit.com/user/{}",
    "Pinterest": "https://pinterest.com/{}",
    "VK": "https://vk.com/{}",
    "Telegram": "https://t.me/{}",
    "Snapchat": "https://snapchat.com/add/{}",
    "Twitch": "https://twitch.tv/{}",
    "YouTube (Canal)": "https://youtube.com/@{}",
    "YouTube (Búsqueda)": "https://www.youtube.com/results?search_query={}",
    "OnlyFans": "https://onlyfans.com/{}",
    "Flickr": "https://flickr.com/people/{}",
    "Medium": "https://medium.com/@{}",
    "Tumblr": "https://{}.tumblr.com",
    "Wikipedia (Usuario)": "https://es.wikipedia.org/wiki/Usuario:{}",
    "Keybase": "https://keybase.io/{}",
    "HackerNews": "https://news.ycombinator.com/user?id={}",
    "Steam": "https://steamcommunity.com/id/{}",
    "SoundCloud": "https://soundcloud.com/{}",
    "About.me": "https://about.me/{}",
    "SlideShare": "https://slideshare.net/{}",
    "DeviantArt": "https://{}.deviantart.com",
    "Spotify": "https://open.spotify.com/user/{}",
    "Discord": "https://discord.com/users/{}",  # Solo si el ID es conocido
    "GitLab": "https://gitlab.com/{}",
    "Bitbucket": "https://bitbucket.org/{}",
    "Patreon": "https://patreon.com/{}",
    "Kickstarter": "https://kickstarter.com/profile/{}",
    "CodePen": "https://codepen.io/{}",
    "StackOverflow": "https://stackoverflow.com/users/{}",
    "Xbox Live": "https://xboxgamertag.com/search/{}",
    "PlayStation Network": "https://psnprofiles.com/{}",
    "Etsy": "https://etsy.com/people/{}",
    "Goodreads": "https://goodreads.com/{}",
    "Last.fm": "https://last.fm/user/{}",
    "Fiverr": "https://fiverr.com/{}",
    "Upwork": "https://upwork.com/freelancers/{}",
    "Behance": "https://behance.net/{}",
    "Dribbble": "https://dribbble.com/{}",
    "500px": "https://500px.com/{}",
    "Vimeo": "https://vimeo.com/{}",
    "Imgur": "https://imgur.com/user/{}",
    "Pastebin": "https://pastebin.com/u/{}",
    "HubPages": "https://hubpages.com/@{}",
    "Quora": "https://quora.com/profile/{}",
    "Tinder": "https://tinder.com/@{}",  # Puede no funcionar
    "Badoo": "https://badoo.com/profile/{}",  # Puede no funcionar
    "ReverbNation": "https://reverbnation.com/{}",
    "Bandcamp": "https://bandcamp.com/{}",
    "Trakt": "https://trakt.tv/users/{}",
    "Letterboxd": "https://letterboxd.com/{}",
    "MyAnimeList": "https://myanimelist.net/profile/{}",
    "TradingView": "https://tradingview.com/u/{}/",
    "Investing.com": "https://investing.com/traders/{}",
    "Scribd": "https://scribd.com/{}",
    "Slides": "https://slides.com/{}",
    "SpeakerDeck": "https://speakerdeck.com/{}",
    "Academia.edu": "https://independent.academia.edu/{}",
    "ResearchGate": "https://researchgate.net/profile/{}",
    "AngelList": "https://angel.co/{}",
    "Crunchbase": "https://crunchbase.com/person/{}",
    "ProductHunt": "https://producthunt.com/@{}",
    "Gumroad": "https://gumroad.com/{}",
    "PayPal.Me": "https://paypal.me/{}",
    "Venmo": "https://venmo.com/{}",  # Solo EEUU
    "CashApp": "https://cash.app/${}",  # Solo EEUU
    "Patreon": "https://patreon.com/{}",
    "Ko-fi": "https://ko-fi.com/{}",
    "BuyMeACoffee": "https://buymeacoffee.com/{}",
    "Liberapay": "https://liberapay.com/{}",
    "Substack": "https://substack.com/profile/{}",
    "Ghost": "https://{}.ghost.io",
    "Blogger": "https://{}.blogspot.com",
    "WordPress.com": "https://{}.wordpress.com",
    "Wix": "https://{}.wixsite.com/website",
    "Weebly": "https://{}.weebly.com",
    "Jimdo": "https://{}.jimdosite.com",
    "Tilda": "https://{}.tilda.ws",
    "Webflow": "https://{}.webflow.io",
    "Strikingly": "https://{}.strikingly.com",
    "Carrd": "https://{}.carrd.co",
    "Linktree": "https://linktr.ee/{}",
    "Bio.fm": "https://bio.fm/{}",
    "ManyLink": "https://many.link/{}",
    "ContactInBio": "https://contactin.bio/{}",
    "Flow.page": "https://flow.page/{}",
    "Taplink": "https://taplink.cc/{}",
    "Solo.to": "https://solo.to/{}",
    "Milkshake": "https://milkshake.app/{}",
    "Beacons": "https://beacons.ai/{}",
    "Koji": "https://withkoji.com/@{}",
    "Notion": "https://notion.so/{}",
    "Airtable": "https://airtable.com/{}",
    "Coda": "https://coda.io/@{}",
    "Obsidian": "https://forum.obsidian.md/u/{}",
    "RoamResearch": "https://roamresearch.com/#/app/{}",
    "Zotero": "https://zotero.org/{}",
    "Mendeley": "https://mendeley.com/profiles/{}",
    "ORCID": "https://orcid.org/{}",
    "Google Scholar": "https://scholar.google.com/citations?user={}",
    "ResearchGate": "https://researchgate.net/profile/{}",
    "Academia.edu": "https://independent.academia.edu/{}",
    "SSRN": "https://ssrn.com/author={}",
    "arXiv": "https://arxiv.org/a/{}.html",
    "PhilPapers": "https://philpeople.org/profiles/{}",
    "PhilArchive": "https://philarchive.org/a/{}",
    "JSTOR": "https://jstor.org/stable/{}",
    "PubMed": "https://pubmed.ncbi.nlm.nih.gov/?term={}",
    "IEEE Xplore": "https://ieeexplore.ieee.org/author/{}",
    "SpringerLink": "https://link.springer.com/search?query={}",
    "ScienceDirect": "https://sciencedirect.com/search?qs={}",
    "Scopus": "https://scopus.com/authid/detail.uri?authorId={}",
    "Web of Science": "https://webofscience.com/wos/author/record/{}",
    "Microsoft Academic": "https://academic.microsoft.com/author/{}",
    "Semantic Scholar": "https://semanticscholar.org/author/{}",
    "DBLP": "https://dblp.org/pid/{}",
    "arXiv": "https://arxiv.org/a/{}.html",
    "Zenodo": "https://zenodo.org/search?q={}",
    "Figshare": "https://figshare.com/authors/{}/{}",
    "Mendeley": "https://mendeley.com/profiles/{}",
    "Zotero": "https://zotero.org/{}",
    "ORCID": "https://orcid.org/{}",
    "Google Patents": "https://patents.google.com/?inventor={}",
    "USPTO": "https://uspto.gov/patents/search?searchText=IN/{}",
    "EPO": "https://epo.org/search?q=PA/{}",
    "WIPO": "https://patentscope.wipo.int/search/en/search.jsf?query=PA:{}",
    "GitHub Gist": "https://gist.github.com/{}",
    "GitLab Snippets": "https://gitlab.com/users/{}/snippets",
    "Bitbucket Snippets": "https://bitbucket.org/{}/snippets",
    "CodeSandbox": "https://codesandbox.io/u/{}",
    "JSFiddle": "https://jsfiddle.net/user/{}",
    "CodePen": "https://codepen.io/{}",
    "Repl.it": "https://repl.it/@{}",
    "Glitch": "https://glitch.com/@{}",
    "StackBlitz": "https://stackblitz.com/@{}",
    "Observable": "https://observablehq.com/@{}",
    "Kaggle": "https://kaggle.com/{}",
    "Colab": "https://colab.research.google.com/drive/{}",
    "DeepNote": "https://deepnote.com/@{}",
    "Binder": "https://mybinder.org/v2/gh/{}",
    "Nextjournal": "https://nextjournal.com/{}",
    "RStudio Cloud": "https://rstudio.cloud/project/{}",
    "Google Cloud Shell": "https://ssh.cloud.google.com/cloudshell/editor?cloudshell_git_repo={}",
    "IBM Watson Studio": "https://dataplatform.cloud.ibm.com/{}",
    "Azure Notebooks": "https://notebooks.azure.com/{}/library",
    "JupyterHub": "https://jupyter.org/hub/user/{}",
    "Bokeh": "https://bokeh.org/{}",
    "Plotly": "https://plotly.com/~{}",
    "Tableau Public": "https://public.tableau.com/profile/{}",
    "Power BI": "https://app.powerbi.com/groups/me/reports/{}",
    "Google Data Studio": "https://datastudio.google.com/u/0/reporting/{}",
    "Flourish": "https://flourish.studio/@{}",
    "RAWGraphs": "https://rawgraphs.io/{}",
    "Datawrapper": "https://datawrapper.de/user/{}",
    "Infogram": "https://infogram.com/{}",
    "ChartBlocks": "https://chartblocks.com/user/{}",
    "Visme": "https://visme.co/{}",
    "Canva": "https://canva.com/{}",
    "Adobe Creative Cloud": "https://creativecloud.adobe.com/{}",
    "Figma": "https://figma.com/@{}",
    "Sketch": "https://sketch.com/users/{}",
    "InVision": "https://invisionapp.com/{}",
    "Marvel": "https://marvelapp.com/{}",
    "Proto.io": "https://proto.io/{}",
    "Balsamiq": "https://balsamiq.com/users/{}",
    "UXPin": "https://uxpin.com/{}",
    "Framer": "https://framer.com/{}",
    "Webflow": "https://webflow.com/{}",
    "Bubble": "https://bubble.io/user/{}",
    "Glide": "https://glideapps.com/{}",
    "Adalo": "https://adalo.com/{}",
    "Thunkable": "https://thunkable.com/{}",
    "AppGyver": "https://appgyver.com/{}",
    "AppSheet": "https://appsheet.com/{}",
    "OutSystems": "https://outsystems.com/{}",
    "Mendix": "https://mendix.com/{}",
    "Salesforce": "https://salesforce.com/{}",
    "Zoho Creator": "https://zoho.com/creator/{}",
    "Airtable": "https://airtable.com/{}",
    "Notion": "https://notion.so/{}",
    "Coda": "https://coda.io/@{}",
    "Typeform": "https://typeform.com/{}",
    "Google Forms": "https://docs.google.com/forms/d/{}",
    "Microsoft Forms": "https://forms.office.com/Pages/DesignPage.aspx?{}",
    "JotForm": "https://jotform.com/{}",
    "Formstack": "https://formstack.com/{}",
    "Wufoo": "https://wufoo.com/{}",
    "SurveyMonkey": "https://surveymonkey.com/{}",
    "Qualtrics": "https://qualtrics.com/{}",
    "LimeSurvey": "https://limesurvey.org/{}",
    "Google Surveys": "https://surveys.google.com/{}",
    "Poll Everywhere": "https://polleverywhere.com/{}",
    "Mentimeter": "https://mentimeter.com/{}",
    "Slido": "https://slido.com/{}",
    "Kahoot": "https://kahoot.com/user/{}",
    "Quizizz": "https://quizizz.com/{}",
    "Gimkit": "https://gimkit.com/{}",
    "Blooket": "https://blooket.com/{}",
    "Nearpod": "https://nearpod.com/{}",
    "Peardeck": "https://peardeck.com/{}",
    "Edpuzzle": "https://edpuzzle.com/{}",
    "Flipgrid": "https://flipgrid.com/{}",
    "Padlet": "https://padlet.com/{}",
    "Wakelet": "https://wakelet.com/{}",
    "Pinterest": "https://pinterest.com/{}",
    "Trello": "https://trello.com/{}",
    "Asana": "https://asana.com/users/{}",
    "Monday.com": "https://monday.com/users/{}",
    "ClickUp": "https://clickup.com/{}",
    "Basecamp": "https://basecamp.com/{}",
    "Smartsheet": "https://smartsheet.com/{}",
    "Airtable": "https://airtable.com/{}",
    "Notion": "https://notion.so/{}",
    "Coda": "https://coda.io/@{}",
    "Evernote": "https://evernote.com/{}",
    "OneNote": "https://onenote.com/{}",
    "Google Keep": "https://keep.google.com/u/0/#{}",
    "Todoist": "https://todoist.com/users/{}",
    "TickTick": "https://ticktick.com/{}",
    "Any.do": "https://any.do/{}",
    "Habitica": "https://habitica.com/profile/{}",
    "Forest": "https://forestapp.cc/{}",
    "Focus To-Do": "https://focustodo.cn/{}",
    "Microsoft To Do": "https://todo.microsoft.com/{}",
    "Google Tasks": "https://tasks.google.com/{}",
    "Apple Reminders": "https://icloud.com/reminders/{}",
    "Remember The Milk": "https://rememberthemilk.com/{}",
    "Wunderlist": "https://wunderlist.com/{}",
    "Things": "https://culturedcode.com/things/{}",
    "OmniFocus": "https://omnigroup.com/omnifocus/{}",
    "2Do": "https://2doapp.com/{}",
    "Due": "https://dueapp.com/{}",
    "Fantastical": "https://flexibits.com/fantastical/{}",
    "Google Calendar": "https://calendar.google.com/calendar/u/0/r{}",
    "Microsoft Outlook": "https://outlook.live.com/calendar/0/{}",
    "Apple Calendar": "https://icloud.com/calendar/{}",
    "Calendly": "https://calendly.com/{}",
    "Doodle": "https://doodle.com/users/{}",
    "When2Meet": "https://when2meet.com/?{}",
    "TimeTree": "https://timetreeapp.com/{}",
    "Cozi": "https://cozi.com/{}",
    "FamilyWall": "https://familywall.com/{}",
    "Google Family Link": "https://families.google.com/familylink/{}",
    "Life360": "https://life360.com/{}",
    "Find My Friends": "https://icloud.com/find/{}",
    "Glympse": "https://glympse.com/{}",
    "Zenly": "https://zen.ly/{}",
    "Google Maps Timeline": "https://google.com/maps/timeline?pb={}",
    "Strava": "https://strava.com/athletes/{}",
    "Runkeeper": "https://runkeeper.com/user/{}",
    "Nike Run Club": "https://nike.com/running/nrc-app/{}",
    "Adidas Running": "https://runtastic.com/users/{}",
    "MapMyRun": "https://mapmyrun.com/profile/{}",
    "Endomondo": "https://endomondo.com/profile/{}",
    "MyFitnessPal": "https://myfitnesspal.com/{}",
    "Lose It!": "https://loseit.com/{}",
    "Noom": "https://noom.com/{}",
    "Weight Watchers": "https://weightwatchers.com/us/{}",
    "Fitbit": "https://fitbit.com/user/{}",
    "Garmin Connect": "https://connect.garmin.com/modern/profile/{}",
    "Withings": "https://withings.com/{}",
    "Apple Health": "https://apple.com/health/{}",
    "Google Fit": "https://fit.google.com/{}",
    "Samsung Health": "https://samsung.com/health/{}",
    "Peloton": "https://onepeloton.com/{}",
    "Zwift": "https://zwift.com/{}",
    "TrainerRoad": "https://trainerroad.com/{}",
    "Strava": "https://strava.com/athletes/{}",
    "Komoot": "https://komoot.com/user/{}",
    "AllTrails": "https://alltrails.com/members/{}",
    "ViewRanger": "https://viewranger.com/user/{}",
    "Gaia GPS": "https://gaiagps.com/profile/{}",
    "OnX Hunt": "https://onxmaps.com/hunt/app/{}",
    "HuntStand": "https://huntstand.com/{}",
    "Fishbrain": "https://fishbrain.com/{}",
    "iNaturalist": "https://inaturalist.org/people/{}",
    "eBird": "https://ebird.org/profile/{}",
    "Merlin Bird ID": "https://merlin.allaboutbirds.org/{}",
    "Audubon Bird Guide": "https://audubon.org/bird-guide/{}",
    "PlantNet": "https://plantnet.org/{}",
    "PictureThis": "https://picturethisai.com/{}",
    "Seek by iNaturalist": "https://inaturalist.org/pages/seek_app/{}",
    "SkyView": "https://skyviewapp.com/{}",
    "Star Walk": "https://vitotechnology.com/star-walk/{}",
    "Night Sky": "https://nightskyapp.com/{}",
    "Solar Walk": "https://vitotechnology.com/solar-walk/{}",
    "NASA": "https://nasa.gov/{}",
    "Space.com": "https://space.com/{}",
    "Universe Today": "https://universetoday.com/{}",
    "Bad Astronomy": "https://badastronomy.com/{}",
    "SETI@home": "https://setiathome.berkeley.edu/{}",
    "Einstein@Home": "https://einsteinathome.org/{}",
    "BOINC": "https://boinc.berkeley.edu/{}",
    "Folding@home": "https://foldingathome.org/{}",
    "Rosetta@home": "https://boinc.bakerlab.org/{}",
    "World Community Grid": "https://worldcommunitygrid.org/{}",
    "Zooniverse": "https://zooniverse.org/{}",
    "SETI Live": "https://setilive.org/{}",
    "Planet Hunters": "https://planethunters.org/{}",
    "Galaxy Zoo": "https://galaxyzoo.org/{}",
    "Stardust@home": "https://stardustathome.ssl.berkeley.edu/{}",
    "Moon Zoo": "https://moonzoo.org/{}",
    "Solar Stormwatch": "https://solarstormwatch.com/{}",
    "CosmoQuest": "https://cosmoquest.org/{}",
    "Higgs Hunters": "https://higgshunters.org/{}",
    "Space Warps": "https://spacewarps.org/{}",
    "Disk Detective": "https://diskdetective.org/{}",
    "Backyard Worlds": "https://backyardworlds.org/{}",
    "Asteroid Zoo": "https://asteroidzoo.org/{}",
    "Planet Four": "https://planetfour.org/{}",
    "Milky Way Project": "https://milkywayproject.org/{}",
    "Radio Galaxy Zoo": "https://radio.galaxyzoo.org/{}",
    "Gravity Spy": "https://gravityspy.org/{}",
    "Dark Energy Explorers": "https://darkenergyexplorers.org/{}",
    "Muon Hunters": "https://muonhunters.org/{}",
    "Higgs Hunters": "https://higgshunters.org/{}",
    "Quantum Moves": "https://scienceathome.org/games/quantum-moves/{}",
    "Foldit": "https://fold.it/portal/{}",
    "EteRNA": "https://eterna.cmu.edu/web/{}",
    "Phylo": "https://phylo.cs.mcgill.ca/{}",
    "Eyewire": "https://eyewire.org/{}",
    "Cell Slider": "https://cellslider.net/{}",
    "Bat Detective": "https://batdetective.org/{}",
    "Whale FM": "https://whale.fm/{}",
    "Penguin Watch": "https://penguinwatch.org/{}",
    "Snapshot Safari": "https://snapshotsafari.org/{}",
    "Chimp&See": "https://chimpandsee.org/{}",
    "OrcaSound": "https://orcasound.net/{}",
    "Floating Forests": "https://floatingforests.org/{}",
    "Seafloor Explorer": "https://seafloorexplorer.org/{}",
    "Plankton Portal": "https://planktonportal.org/{}",
    "Whale Alert": "https://whalealert.org/{}",
    "Marine Debris Tracker": "https://marinedebris.engr.uga.edu/{}",
    "Coral Reef Watch": "https://coralreefwatch.noaa.gov/{}",
    "Reef Check": "https://reefcheck.org/{}",
    "Reef.org": "https://reef.org/{}",
    "CoralNet": "https://coralnet.ucsd.edu/{}",
    "SeaLight": "https://sealight.io/{}",
    "Ocean Cleanup": "https://theoceancleanup.com/{}",
    "OpenROV": "https://openrov.com/{}",
    "iSeeChange": "https://iseechange.org/{}",
    "ISeeChange": "https://iseechange.org/{}",
    "CoCoRaHS": "https://cocorahs.org/{}",
    "mPING": "https://mping.nssl.noaa.gov/{}",
    "CycloneCenter": "https://cyclonecenter.org/{}",
    "Old Weather": "https://oldweather.org/{}",
    "Weather Rescue": "https://weatherrescue.org/{}",
    "ClimatePrediction.net": "https://climateprediction.net/{}",
    "Globe at Night": "https://globeatnight.org/{}",
    "Loss of the Night": "https://lossofthenight.com/{}",
    "Dark Sky Meter": "https://darkskymeter.com/{}",
    "Light Pollution Map": "https://lightpollutionmap.info/{}",
    "Clear Dark Sky": "https://cleardarksky.com/{}",
    "Dark Site Finder": "https://darksitefinder.com/{}",
    "International Dark-Sky Association": "https://darksky.org/{}",
    "Globe at Night": "https://globeatnight.org/{}",
    "Loss of the Night": "https://lossofthenight.com/{}",
    "Dark Sky Meter": "https://darkskymeter.com/{}",
    "Light Pollution Map": "https://lightpollutionmap.info/{}",
    "Clear Dark Sky": "https://cleardarksky.com/{}",
    "Dark Site Finder": "https://darksitefinder.com/{}",
    "International Dark-Sky Association": "https://darksky.org/{}",
    "Globe at Night": "https://globeatnight.org/{}",
    "Loss of the Night": "https://lossofthenight.com/{}",
    "Dark Sky Meter": "https://darkskymeter.com/{}",
    "Light Pollution Map": "https://lightpollutionmap.info/{}",
    "Clear Dark Sky": "https://cleardarksky.com/{}",
    "Dark Site Finder": "https://darksitefinder.com/{}",
    "International Dark-Sky Association": "https://darksky.org/{}",
}

async def osint_usuario_brutal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manejador principal para investigación OSINT de usuarios"""
    if not context.args:
        await update.message.reply_text("Uso: /osint_usuario [nombre_usuario|email|telefono]")
        return

    objetivo = " ".join(context.args)
    respuesta = f"🔥 *RESULTADOS OSINT BRUTAL PARA {objetivo.upper()}* 🔥\n\n"
    mensaje_carga = await update.message.reply_text("🚀 Lanzando asalto OSINT a gran escala... ¡Esto puede tardar!")

    # 1. Reconocimiento en Redes Sociales
    respuesta += await verificar_redes_sociales(objetivo, mensaje_carga, context)
    
    # 2. Análisis de Email/Teléfono
    if "@" in objetivo or re.match(r'^\+?[\d\s\(\)-]+$', objetivo):
        respuesta += "\n📧 *ANÁLISIS DE EMAIL/TELÉFONO*\n"
        if "@" in objetivo:  # Es un email
            respuesta += await analizar_email_real(objetivo)
        else:  # Es un teléfono
            respuesta += await analizar_telefono_real(objetivo)
    
    # 3. Búsqueda de Fugas de Datos y Pastes
    respuesta += await buscar_fugas_datos(objetivo)
    
    # 4. Búsqueda Inversa de Imágenes
    respuesta += await buscar_imagenes_inversa(objetivo)
    
    # 5. Búsqueda en motores de búsqueda
    respuesta += await buscar_en_motores(objetivo)

    # Enviar respuesta final
    await context.bot.edit_message_text(
        chat_id=mensaje_carga.chat_id,
        message_id=mensaje_carga.message_id,
        text=respuesta,
        parse_mode="Markdown",
        disable_web_page_preview=True
    )

async def verificar_redes_sociales(objetivo, mensaje_carga, context):
    """Verifica la presencia del objetivo en múltiples redes sociales"""
    respuesta = "🌐 *RECONOCIMIENTO EN REDES SOCIALES*\n"
    
    # Preparar URLs para LinkedIn (búsqueda por nombre)
    if ' ' in objetivo:
        nombre, apellido = objetivo.split(' ', 1)
        linkedin_search_url = PLATAFORMAS_SOCIALES["LinkedIn (Búsqueda)"].format(nombre, apellido)
    else:
        linkedin_search_url = None

    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        # Preparar tareas para todas las plataformas
        futures = {}
        for plataforma, url_template in PLATAFORMAS_SOCIALES.items():
            if plataforma == "LinkedIn (Búsqueda)":
                if linkedin_search_url:
                    futures[executor.submit(comprobar_red_social, plataforma, linkedin_search_url)] = plataforma
                continue
            
            # Manejar casos especiales de formato
            if plataforma == "LinkedIn (Perfil)":
                username = objetivo.split(' ')[0] if ' ' in objetivo else objetivo
            else:
                username = objetivo
            
            url = url_template.format(username)
            futures[executor.submit(comprobar_red_social, plataforma, url)] = plataforma
        
        # Procesar resultados a medida que llegan
        for future in concurrent.futures.as_completed(futures):
            plataforma = futures[future]
            try:
                resultado = future.result()
                respuesta += resultado + "\n"
                
                # Actualización periódica para mostrar progreso
                if len(respuesta.split('\n')) % 10 == 0:
                    await context.bot.edit_message_text(
                        chat_id=mensaje_carga.chat_id,
                        message_id=mensaje_carga.message_id,
                        text=respuesta + "\n\n🔍 Continuando búsqueda...",
                        parse_mode="Markdown",
                        disable_web_page_preview=True
                    )
            except Exception as e:
                logger.error(f"Error comprobando {plataforma}: {e}")
                respuesta += f"⚠️ {plataforma}: Error en la comprobación\n"
    
    return respuesta

def comprobar_red_social(plataforma, url):
    """Comprueba si un perfil existe en una red social"""
    headers = {'User-Agent': get_random_user_agent()}
    try:
        # Usar HEAD puede ser bloqueado, GET es más realista pero más pesado
        r = requests.head(url, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=True)
        
        # Algunas plataformas devuelven 200 para perfiles existentes y 404 para no existentes
        if r.status_code == 200:
            # Verificar si la URL final es similar a la original (no redirección a login/home)
            if urlparse(r.url).path.strip('/').lower() == urlparse(url).path.strip('/').lower():
                return f"✅ {plataforma}: [Posible Perfil Encontrado]({r.url})"
            else:
                return f"⚠️ {plataforma}: [Redirección Detectada (Verificar Manualmente)]({r.url})"
        elif r.status_code == 404:
            return f"❌ {plataforma}: No Encontrado (404)"
        else:
            # Si HEAD falla, intentar con GET (más lento pero más preciso)
            r_get = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=True)
            if r_get.status_code == 200:
                # Heurística simple: buscar en el contenido palabras clave como "not found" o "404"
                if any(phrase.lower() in r_get.text.lower() for phrase in ["not found", "404", "no existe", "no encontrado"]):
                    return f"❌ {plataforma}: No Encontrado (200 pero página de error)"
                return f"✅ {plataforma}: [Posible Perfil Encontrado]({r_get.url})"
            return f"❓ {plataforma}: Estado {r_get.status_code} (Verificar)"
    except requests.exceptions.Timeout:
        return f"⏳ {plataforma}: Timeout"
    except requests.exceptions.RequestException:
        return f"⚠️ {plataforma}: Error de Conexión"

async def analizar_email_real(email):
    """Realiza un análisis exhaustivo de una dirección de email"""
    resultado = ""
    dominio = email.split('@')[-1]
    
    # 1. Validez del formato (ya implícito si llega aquí)
    resultado += f"📧 Email: `{email}`\n"
    resultado += f"🏷️ Dominio: `{dominio}`\n"
    
    # 2. Registros MX
    resultado += await verificar_registros_mx(dominio)
    
    # 3. Comprobación de Gravatar
    resultado += await verificar_gravatar(email)
    
    # 4. Google Dorks para el email
    resultado += f"🔍 Búsqueda Google: [Ver si el email aparece públicamente]({construir_enlace_google_dork(f'"{email}"', [])})\n"
    
    # 5. Verificación en HaveIBeenPwned (solo enlace)
    resultado += f"🔓 HaveIBeenPwned: [Comprobar fugas](https://haveibeenpwned.com/account/{quote_plus(email)})\n"
    
    return resultado

async def verificar_registros_mx(dominio):
    """Verifica los registros MX de un dominio"""
    resultado = ""
    try:
        registros_mx = dns.resolver.resolve(dominio, 'MX')
        mx_format = sorted([f"{mx.preference} {mx.exchange.to_text()}" for mx in registros_mx])
        resultado += f"📬 Servidores MX: {', '.join(mx_format)}\n"
        
        # Verificar si usa servicios conocidos
        servicios_email = {
            "google.com": "Google Workspace/Gmail",
            "outlook.com": "Microsoft 365/Outlook",
            "protection.outlook.com": "Microsoft 365 Exchange Online Protection",
            "mail.protection.outlook.com": "Microsoft 365 Exchange Online",
            "mx.yandex.net": "Yandex Mail",
            "mx.zoho.com": "Zoho Mail",
            "mailgun.org": "Mailgun",
            "sendgrid.net": "SendGrid",
            "sparkpostmail.com": "SparkPost",
            "aspmx.l.google.com": "Google Workspace (Gmail)"
        }
        
        for mx in mx_format:
            for servicio, nombre in servicios_email.items():
                if servicio in mx.lower():
                    resultado += f"   🔎 Probable servicio de email: {nombre}\n"
                    break
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
        resultado += "📮 Servidores MX: No encontrados (el dominio podría no manejar emails o no existir).\n"
    except dns.exception.Timeout:
        resultado += "📮 Servidores MX: Timeout al consultar.\n"
    except Exception as e:
        resultado += f"📮 Servidores MX: Error ({e}).\n"
    
    return resultado

async def verificar_gravatar(email):
    """Verifica si el email tiene un perfil Gravatar asociado"""
    resultado = ""
    try:
        hash_email = hashlib.md5(email.lower().encode('utf-8')).hexdigest()
        gravatar_url = f"https://www.gravatar.com/avatar/{hash_email}?d=404"
        r = requests.get(gravatar_url, timeout=REQUEST_TIMEOUT)
        
        if r.status_code == 200:
            # Obtener perfil si existe
            profile_url = f"https://www.gravatar.com/{hash_email}.json"
            r_profile = requests.get(profile_url, timeout=REQUEST_TIMEOUT)
            
            if r_profile.status_code == 200:
                profile_data = r_profile.json()
                name = profile_data.get('entry', [{}])[0].get('displayName', 'N/A')
                resultado += f"👤 Gravatar: [Perfil encontrado](https://www.gravatar.com/{hash_email}) - Nombre: {name}\n"
            else:
                resultado += f"👤 Gravatar: [Avatar encontrado](https://www.gravatar.com/{hash_email}) (sin perfil público)\n"
        else:
            resultado += "👤 Gravatar: No encontrado.\n"
    except Exception:
        resultado += "👤 Gravatar: Error al comprobar.\n"
    
    return resultado

async def analizar_telefono_real(telefono):
    """Realiza un análisis de un número de teléfono"""
    resultado = ""
    # Limpiar número
    limpio = re.sub(r'[^\d+]', '', telefono)
    resultado += f"📱 Número (limpio): `{limpio}`\n"
    
    # Determinar país basado en prefijo (si empieza con +)
    if limpio.startswith('+'):
        prefijo = limpio[:3]  # Simplificación, en realidad hay prefijos de 1-3 dígitos
        paises = {
            '+1': 'EEUU/Canadá',
            '+34': 'España',
            '+52': 'México',
            '+54': 'Argentina',
            '+55': 'Brasil',
            '+56': 'Chile',
            '+57': 'Colombia',
            '+58': 'Venezuela',
            '+51': 'Perú',
            '+593': 'Ecuador',
            '+591': 'Bolivia',
            '+598': 'Uruguay',
            '+595': 'Paraguay',
            '+507': 'Panamá',
            '+506': 'Costa Rica',
            '+503': 'El Salvador',
            '+502': 'Guatemala',
            '+504': 'Honduras',
            '+505': 'Nicaragua',
            '+506': 'Costa Rica',
            '+507': 'Panamá',
            '+509': 'Haití',
            '+53': 'Cuba',
            '+44': 'Reino Unido',
            '+33': 'Francia',
            '+49': 'Alemania',
            '+39': 'Italia',
            '+34': 'España',
            '+351': 'Portugal',
            '+31': 'Países Bajos',
            '+32': 'Bélgica',
            '+41': 'Suiza',
            '+43': 'Austria',
            '+46': 'Suecia',
            '+47': 'Noruega',
            '+45': 'Dinamarca',
            '+358': 'Finlandia',
            '+7': 'Rusia/Kazajistán',
            '+86': 'China',
            '+81': 'Japón',
            '+82': 'Corea del Sur',
            '+91': 'India',
            '+92': 'Pakistán',
            '+93': 'Afganistán',
            '+94': 'Sri Lanka',
            '+95': 'Myanmar',
            '+98': 'Irán',
            '+20': 'Egipto',
            '+27': 'Sudáfrica',
            '+234': 'Nigeria',
            '+254': 'Kenia',
            '+61': 'Australia',
            '+64': 'Nueva Zelanda'
        }
        pais = paises.get(prefijo, 'Desconocido')
        resultado += f"🌍 País probable (por prefijo): {pais}\n"
    
    # Enlaces a buscadores de teléfonos
    resultado += "\n⚠️ La efectividad de estas búsquedas varía y puede requerir interacción manual:\n"
    resultado += f"- [Buscar en Google]({construir_enlace_google_dork(f'"{telefono}"', [])})\n"
    resultado += f"- [TrueCaller (web)](https://www.truecaller.com/search/es/{quote_plus(limpio)}) (Puede requerir login)\n"
    resultado += f"- [NumVerify](https://numverify.com/)\n"
    
    # Enlaces específicos por país
    if limpio.startswith('+34'):  # España
        resultado += f"- [Páginas Blancas (España)](https://www.paginasblancas.es/search/num/{limpio.replace('+34', '')})\n"
        resultado += f"- [Páginas Amarillas (España)](https://www.paginasamarillas.es/search/number/{limpio.replace('+34', '')})\n"
    elif limpio.startswith('+1'):  # EEUU/Canadá
        resultado += f"- [Whitepages (EEUU)](https://www.whitepages.com/phone/{limpio.replace('+1', '')})\n"
        resultado += f"- [AnyWho (EEUU)](https://www.anywho.com/reverse-phone/{limpio.replace('+1', '')})\n"
    elif limpio.startswith('+52'):  # México
        resultado += f"- [Sección Amarilla (México)](https://www.seccionamarilla.com.mx/busqueda/telefono/{quote_plus(limpio.replace('+52', ''))})\n"
    
    return resultado

async def buscar_fugas_datos(objetivo):
    """Busca posibles fugas de datos relacionadas con el objetivo"""
    respuesta = "\n💀 *BÚSQUEDA DE FUGAS DE DATOS Y PASTES (Google Dorks)*\n"
    
    # Google Dorks genéricos
    dorks_fugas = [
        f'"{objetivo}" site:pastebin.com',
        f'"{objetivo}" site:ghostbin.co',
        f'"{objetivo}" site:hastebin.com',
        f'"{objetivo}" site:pastebin.pl',
        f'"{objetivo}" site:codepad.org',
        f'"{objetivo}" site:scribd.com',
        f'"{objetivo}" site:slideshare.net',
        f'"{objetivo}" site:justpaste.it',
        f'"{objetivo}" "password" | "contraseña" | "leak" | "fuga" | "breach"',
        f'"{objetivo}" filetype:sql | filetype:txt | filetype:csv | filetype:xls | filetype:xlsx "dump" | "database" | "backup"',
        f'"{objetivo}" "user list" | "user database" | "customer list"',
        f'intitle:"index of" "{objetivo}" "parent directory"',
        f'inurl:/wp-content/uploads/ "{objetivo}"',
        f'site:github.com "{objetivo}" "password" | "secret" | "api key"',
        f'site:gitlab.com "{objetivo}" "password" | "secret" | "api key"',
        f'site:bitbucket.org "{objetivo}" "password" | "secret" | "api key"',
    ]
    
    # Añadir dorks específicos para emails
    if "@" in objetivo:
        dorks_fugas.extend([
            f'"{objetivo}" "password" | "pass" | "credenciales"',
            f'"{objetivo}" "leaked" | "breach" | "compromised"',
            f'"{objetivo}" "database dump" | "user data"',
            f'filetype:log "{objetivo}" "password" | "login"',
            f'intext:"{objetivo}" intext:"password"',
            f'intext:"{objetivo}" intext:"username" OR "user" OR "login"',
        ])
    
    # Limitar a 15 dorks para no saturar
    for dork in dorks_fugas[:15]:
        respuesta += f"- [Buscar: {dork.split(' ')[0]}...]({construir_enlace_google_dork('', [dork])})\n"
    
    respuesta += "\n🔎 *OTROS SERVICIOS PARA COMPROBAR FUGAS:*\n"
    respuesta += "- [HaveIBeenPwned](https://haveibeenpwned.com/) (para emails)\n"
    respuesta += "- [Dehashed](https://dehashed.com/) (requiere cuenta)\n"
    respuesta += "- [LeakCheck](https://leakcheck.io/) (parcialmente gratuito)\n"
    respuesta += "- [Snusbase](https://snusbase.com/) (requiere cuenta)\n"
    respuesta += "- [BreachDirectory](https://breachdirectory.org/) (parcialmente gratuito)\n"
    
    return respuesta

async def buscar_imagenes_inversa(objetivo):
    """Proporciona enlaces para búsqueda inversa de imágenes"""
    respuesta = "\n🖼️ *BÚSQUEDA INVERSA DE IMÁGENES (Manual)*\n"
    respuesta += "Si tienes una imagen de perfil asociada a este usuario, puedes usar:\n"
    
    servicios_imagenes = [
        ("Google Images", "https://images.google.com/"),
        ("TinEye", "https://tineye.com/"),
        ("Yandex Images", "https://yandex.com/images/"),
        ("Bing Visual Search", "https://www.bing.com/visualsearch"),
        ("Berify", "https://berify.com/"),
        ("Social Catfish", "https://socialcatfish.com/reverse-image-search/"),
        ("PimEyes (rostros)", "https://pimeyes.com/"),
        ("FaceCheck.ID (rostros)", "https://facecheck.id/"),
    ]
    
    for nombre, url in servicios_imagenes:
        respuesta += f"- [{nombre}]({url})\n"
    
    return respuesta

async def buscar_en_motores(objetivo):
    """Proporciona enlaces para búsqueda en varios motores"""
    respuesta = "\n🌐 *BÚSQUEDA EN MÚLTIPLES MOTORES*\n"
    
    motores = [
        ("Google", f"https://www.google.com/search?q={quote_plus(objetivo)}"),
        ("Bing", f"https://www.bing.com/search?q={quote_plus(objetivo)}"),
        ("Yandex", f"https://yandex.com/search/?text={quote_plus(objetivo)}"),
        ("DuckDuckGo", f"https://duckduckgo.com/?q={quote_plus(objetivo)}"),
        ("Startpage", f"https://www.startpage.com/do/search?query={quote_plus(objetivo)}"),
        ("Qwant", f"https://www.qwant.com/?q={quote_plus(objetivo)}"),
        ("Ecosia", f"https://www.ecosia.org/search?q={quote_plus(objetivo)}"),
        ("Swisscows", f"https://swisscows.com/web?query={quote_plus(objetivo)}"),
        ("MetaGer", f"https://metager.org/meta/meta.ger3?eingabe={quote_plus(objetivo)}"),
        ("BoardReader (foros)", f"https://boardreader.com/s/{quote_plus(objetivo)}.html"),
        ("Reddit Search", f"https://www.reddit.com/search/?q={quote_plus(objetivo)}"),
        ("Twitter Search", f"https://twitter.com/search?q={quote_plus(objetivo)}"),
        ("Facebook Search", f"https://www.facebook.com/search/top/?q={quote_plus(objetivo)}"),
        ("LinkedIn Search", f"https://www.linkedin.com/search/results/all/?keywords={quote_plus(objetivo)}"),
        ("Instagram Search", f"https://www.instagram.com/web/search/topsearch/?query={quote_plus(objetivo)}"),
        ("TikTok Search", f"https://www.tiktok.com/search?q={quote_plus(objetivo)}"),
        ("YouTube Search", f"https://www.youtube.com/results?search_query={quote_plus(objetivo)}"),
        ("GitHub Search", f"https://github.com/search?q={quote_plus(objetivo)}"),
        ("GitLab Search", f"https://gitlab.com/search?search={quote_plus(objetivo)}"),
        ("Bitbucket Search", f"https://bitbucket.org/repo/all?name={quote_plus(objetivo)}"),
    ]
    
    for nombre, url in motores[:10]:  # Limitar a 10 para no saturar
        respuesta += f"- [{nombre}]({url})\n"
    
    return respuesta