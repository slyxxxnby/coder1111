import re
import socket
import whois
import dns.resolver
import ssl
import requests
from urllib.parse import urlparse, quote_plus
from bs4 import BeautifulSoup
from datetime import datetime

from telegram import Update
from telegram.ext import ContextTypes
from config import MAX_THREADS, REQUEST_TIMEOUT
from services.geoip import obtener_geolocalizacion
from services.dns_utils import resolver_dns, obtener_registros_dns, escanear_subdominios_basico
from services.web_tools import get_random_user_agent, construir_enlace_google_dork

async def osint_web_brutal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manejador principal para investigación OSINT web"""
    if not context.args:
        await update.message.reply_text("Uso: /web_brutal [dominio.com|ip]")
        return

    objetivo = context.args[0].lower().replace("http://", "").replace("https://", "").split('/')[0]
    respuesta = f"🌐 *RECONOCIMIENTO WEB DEFINITIVO - {objetivo.upper()}* 🌐\n\n"
    mensaje_carga = await update.message.reply_text("🚀 Desplegando suite de reconocimiento web... ¡Paciencia!")

    ip_objetivo = None
    dominio_objetivo = None

    # Determinar si es IP o dominio
    if es_ip_valida(objetivo):
        ip_objetivo = objetivo
        respuesta += await analizar_ip_real(ip_objetivo)
    elif es_dominio_valido(objetivo):
        dominio_objetivo = objetivo
        try:
            ip_objetivo = socket.gethostbyname(dominio_objetivo)
            respuesta += f"🖥️ IP Resuelta: {ip_objetivo}\n"
            respuesta += await analizar_dominio_real(dominio_objetivo, ip_objetivo)
        except socket.gaierror:
            await context.bot.edit_message_text(
                chat_id=mensaje_carga.chat_id, message_id=mensaje_carga.message_id,
                text=f"❌ No se pudo resolver la IP para el dominio: {dominio_objetivo}"
            )
            return
    else:
        await context.bot.edit_message_text(
            chat_id=mensaje_carga.chat_id, message_id=mensaje_carga.message_id,
            text="❌ Objetivo no válido. Proporciona un dominio o IP válidos."
        )
        return
    
    # Información SSL/TLS
    await context.bot.edit_message_text(
        chat_id=mensaje_carga.chat_id, 
        message_id=mensaje_carga.message_id, 
        text=respuesta + "\nObteniendo información SSL...", 
        parse_mode="Markdown", 
        disable_web_page_preview=True
    )
    
    target_ssl = dominio_objetivo if dominio_objetivo else ip_objetivo
    respuesta += "\n🔐 *ANÁLISIS DE CERTIFICADO SSL (Puerto 443)*\n"
    respuesta += await obtener_info_ssl(target_ssl)
    
    # Detección de tecnologías web
    await context.bot.edit_message_text(
        chat_id=mensaje_carga.chat_id, 
        message_id=mensaje_carga.message_id, 
        text=respuesta + "\nDetectando tecnologías web...", 
        parse_mode="Markdown", 
        disable_web_page_preview=True
    )
    
    if dominio_objetivo or ip_objetivo:
        target_tech = dominio_objetivo if dominio_objetivo else ip_objetivo
        respuesta += "\n🛠️ *TECNOLOGÍAS WEB (Básico)*\n"
        respuesta += await detectar_tecnologias_web(target_tech)
        respuesta += "\n🤖 *ROBOTS.TXT*\n"
        respuesta += await obtener_robots_txt(target_tech)
        respuesta += "\n🛡️ *CABECERAS DE SEGURIDAD (HTTP)*\n"
        respuesta += await obtener_cabeceras_seguridad(target_tech)

    # Registros DNS y subdominios
    await context.bot.edit_message_text(
        chat_id=mensaje_carga.chat_id, 
        message_id=mensaje_carga.message_id, 
        text=respuesta + "\nConsultando registros DNS...", 
        parse_mode="Markdown", 
        disable_web_page_preview=True
    )
    
    if dominio_objetivo:
        respuesta += "\n📡 *REGISTROS DNS*\n"
        respuesta += await obtener_registros_dns(dominio_objetivo)
        respuesta += "\n🌐 *BÚSQUEDA DE SUBDOMINIOS (Básica)*\n"
        respuesta += await escanear_subdominios_basico(dominio_objetivo)

    # Wayback Machine y otros archivos
    respuesta += "\n🏛️ *WAYBACK MACHINE (ARCHIVO WEB)*\n"
    respuesta += f"Verifica versiones archivadas de `http://{dominio_objetivo if dominio_objetivo else ip_objetivo}` en [Wayback Machine](https://web.archive.org/web/*/{dominio_objetivo if dominio_objetivo else ip_objetivo})\n"

    # Enviar respuesta final
    await context.bot.edit_message_text(
        chat_id=mensaje_carga.chat_id,
        message_id=mensaje_carga.message_id,
        text=respuesta,
        parse_mode="Markdown",
        disable_web_page_preview=True
    )

def es_ip_valida(ip):
    """Verifica si una cadena es una dirección IP válida"""
    patron = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    return re.match(patron, ip) is not None

def es_dominio_valido(dominio):
    """Verifica si una cadena es un dominio válido"""
    patron = re.compile(
        r'^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*'
        r'([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])\.'
        r'([A-Za-z]{2,})$'
    )
    return re.match(patron, dominio) is not None

async def analizar_ip_real(ip):
    """Realiza un análisis exhaustivo de una dirección IP"""
    resultado = ""
    geo = obtener_geolocalizacion(ip)
    
    if geo:
        if 'error' in geo:
            resultado += f"📍 Geolocalización: {geo['error']}\n"
        else:
            resultado += f"📍 *Geolocalización*\n"
            resultado += f"   País: {geo.get('pais', 'N/A')}\n"
            resultado += f"   Ciudad: {geo.get('ciudad', 'N/A')}\n"
            resultado += f"   Coords: {geo.get('latitud', 'N/A')}, {geo.get('longitud', 'N/A')}\n"
            resultado += f"   Zona Horaria: {geo.get('zona_horaria', 'N/A')}\n\n"
    else:
        resultado += "📍 Geolocalización: No disponible o error.\n\n"

    # DNS Reverso
    try:
        hostname, _, _ = socket.gethostbyaddr(ip)
        resultado += f"🔁 DNS Reverso: {hostname}\n\n"
    except socket.herror:
        resultado += "🔁 DNS Reverso: No encontrado.\n\n"
    except Exception as e:
        resultado += f"🔁 DNS Reverso: Error ({e}).\n\n"
    
    # Información de red usando ipinfo.io
    resultado += await obtener_info_ipinfo(ip)
    
    # Comprobación de puertos comunes
    resultado += "\n🔍 *PUERTOS COMUNES (Escaneo Básico)*\n"
    resultado += await escanear_puertos_basico(ip)
    
    return resultado

async def obtener_info_ipinfo(ip):
    """Obtiene información de red de ipinfo.io"""
    resultado = ""
    try:
        headers = {'User-Agent': get_random_user_agent()}
        r_ipinfo = requests.get(f"https://ipinfo.io/{ip}/json", headers=headers, timeout=REQUEST_TIMEOUT)
        
        if r_ipinfo.status_code == 200:
            data_ipinfo = r_ipinfo.json()
            resultado += f"📶 *Información de Red (ipinfo.io)*\n"
            resultado += f"   ISP: {data_ipinfo.get('org', 'N/A')}\n"
            resultado += f"   Ciudad: {data_ipinfo.get('city', 'N/A')}\n"
            resultado += f"   Región: {data_ipinfo.get('region', 'N/A')}\n"
            resultado += f"   País: {data_ipinfo.get('country', 'N/A')}\n"
            resultado += f"   Localización: {data_ipinfo.get('loc', 'N/A')}\n"
            resultado += f"   Hostname: {data_ipinfo.get('hostname', 'N/A')}\n"
            
            # Información de privacidad
            if data_ipinfo.get('privacy', {}).get('proxy', False):
                resultado += "   ⚠️ Esta IP parece ser un proxy/VPN\n"
            if data_ipinfo.get('privacy', {}).get('hosting', False):
                resultado += "   ⚠️ Esta IP pertenece a un servicio de hosting\n"
            
            resultado += "\n"
        else:
            resultado += "📶 Información de Red (ipinfo.io): No se pudo obtener.\n\n"
    except Exception as e:
        logger.error(f"Error obteniendo info de red para {ip} desde ipinfo.io: {e}")
        resultado += f"📶 Información de Red (ipinfo.io): Error ({e}).\n\n"
    
    return resultado

async def escanear_puertos_basico(ip):
    """Escaneo básico de puertos comunes sin nmap"""
    puertos_comunes = {
        20: "FTP (Data)",
        21: "FTP (Control)",
        22: "SSH",
        23: "Telnet",
        25: "SMTP",
        53: "DNS",
        80: "HTTP",
        110: "POP3",
        143: "IMAP",
        443: "HTTPS",
        465: "SMTPS",
        587: "SMTP (Submission)",
        993: "IMAPS",
        995: "POP3S",
        3306: "MySQL",
        3389: "RDP",
        5432: "PostgreSQL",
        5900: "VNC",
        8080: "HTTP Alt",
        8443: "HTTPS Alt"
    }
    
    resultado = ""
    abiertos = []
    
    async def verificar_puerto(ip, puerto, descripcion):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(2)
                if s.connect_ex((ip, puerto)) == 0:
                    return f"   ✅ {puerto} ({descripcion}) - ABIERTO\n"
        except:
            pass
        return ""
    
    # Verificar puertos en paralelo
    tasks = []
    for puerto, desc in puertos_comunes.items():
        tasks.append(verificar_puerto(ip, puerto, desc))
    
    resultados = await asyncio.gather(*tasks)
    
    for res in resultados:
        if res:
            abiertos.append(res)
    
    if abiertos:
        resultado += "Puertos abiertos detectados:\n" + "".join(abiertos)
    else:
        resultado += "No se detectaron puertos comunes abiertos con escaneo básico.\n"
        resultado += "Para un escaneo completo, usa el comando /escanear_red\n"
    
    return resultado

async def analizar_dominio_real(dominio, ip_asociada):
    """Realiza un análisis exhaustivo de un dominio"""
    resultado = ""
    
    # WHOIS
    resultado += await obtener_info_whois(dominio)
    
    # Geolocalización de la IP asociada
    if ip_asociada:
        resultado += await analizar_ip_real(ip_asociada)
    
    # Cabeceras HTTP (intentar con http y https)
    resultado += await obtener_cabeceras_http(dominio)
    
    # Verificar si es un dominio cortado (expiró recientemente)
    resultado += await verificar_dominio_cortado(dominio)
    
    # Verificar historial de cambios de DNS
    resultado += "\n🕵️ *HISTORIAL DE DNS*\n"
    resultado += f"- [ViewDNS.info](https://viewdns.info/iphistory/?domain={dominio})\n"
    resultado += f"- [SecurityTrails](https://securitytrails.com/domain/{dominio}/dns)\n"
    resultado += f"- [DNSlytics](https://dnslytics.com/domain/{dominio})\n"
    
    return resultado

async def obtener_info_whois(dominio):
    """Obtiene información WHOIS de un dominio"""
    resultado = "📝 *INFORMACIÓN WHOIS*\n"
    try:
        w = whois.whois(dominio)
        
        if w.domain_name:
            resultado += f"   Dominio: {w.domain_name if isinstance(w.domain_name, str) else ', '.join(w.domain_name)}\n"
            resultado += f"   Registrador: {w.registrar}\n"
            
            # Fechas importantes
            if w.creation_date:
                if isinstance(w.creation_date, list):
                    creation_date = w.creation_date[0]
                else:
                    creation_date = w.creation_date
                resultado += f"   Creación: {creation_date}\n"
            
            if w.expiration_date:
                if isinstance(w.expiration_date, list):
                    expiration_date = w.expiration_date[0]
                else:
                    expiration_date = w.expiration_date
                resultado += f"   Expiración: {expiration_date}\n"
            
            if w.updated_date:
                if isinstance(w.updated_date, list):
                    updated_date = w.updated_date[0]
                else:
                    updated_date = w.updated_date
                resultado += f"   Actualización: {updated_date}\n"
            
            # Servidores DNS
            if w.name_servers:
                resultado += f"   Servidores DNS: {', '.join(w.name_servers) if isinstance(w.name_servers, list) else w.name_servers}\n"
            else:
                resultado += "   Servidores DNS: N/A\n"
            
            # Emails (pueden estar protegidos por privacidad)
            if w.emails:
                emails = w.emails if isinstance(w.emails, list) else [w.emails]
                resultado += f"   Emails: {', '.join(emails)}\n"
            else:
                resultado += "   Emails: Protegidos por privacidad o no disponibles\n"
            
            # Estado del dominio
            if w.status:
                statuses = w.status if isinstance(w.status, list) else [w.status]
                resultado += f"   Estado: {', '.join(statuses)}\n"
        else:
            resultado += "   No se pudo obtener información WHOIS detallada (podría estar protegida por privacidad o ser un TLD no estándar).\n"
        
        resultado += "\n"
    except whois.parser.PywhoisError as e:
        resultado += f"   ❌ Error de WHOIS: No se pudo parsear la respuesta para {dominio}. {e}\n\n"
    except Exception as e:
        resultado += f"   ❌ Error de WHOIS: {str(e)}\n\n"
    
    return resultado

async def obtener_cabeceras_http(dominio):
    """Obtiene cabeceras HTTP de un dominio"""
    resultado = ""
    for scheme in ["https", "http"]:
        try:
            url_test = f"{scheme}://{dominio}"
            headers = {
                'User-Agent': get_random_user_agent(),
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            }
            
            response = requests.head(
                url_test, 
                headers=headers, 
                timeout=REQUEST_TIMEOUT, 
                allow_redirects=True
            )
            
            resultado += f"📋 *CABECERAS HTTP ({scheme.upper()})*\n"
            resultado += f"   URL Final: {response.url}\n"
            resultado += f"   Estado: {response.status_code}\n"
            
            # Cabeceras importantes
            cabeceras_interes = [
                'Server', 'X-Powered-By', 'X-Generator', 'Content-Type',
                'Content-Length', 'Last-Modified', 'ETag', 'Accept-Ranges',
                'Cache-Control', 'Expires', 'Vary', 'Set-Cookie', 'Location',
                'Strict-Transport-Security', 'Content-Security-Policy',
                'X-Content-Type-Options', 'X-Frame-Options', 'X-XSS-Protection',
                'Referrer-Policy', 'Feature-Policy', 'Permissions-Policy'
            ]
            
            for header in cabeceras_interes:
                if header in response.headers:
                    valor = response.headers[header]
                    if len(valor) > 100:  # Truncar valores muy largos
                        valor = valor[:100] + "..."
                    resultado += f"   {header}: {valor}\n"
            
            resultado += "\n"
            break  # Si https funciona, no intentar http
        except requests.exceptions.SSLError:
            resultado += f"📋 Cabeceras HTTP ({scheme.upper()}): Error SSL. Reintentando con HTTP si aplica.\n"
            continue
        except requests.RequestException:
            if scheme == "https":
                resultado += f"📋 Cabeceras HTTP ({scheme.upper()}): No se pudieron obtener (quizás el sitio no usa HTTPS o no responde a HEAD).\n"
            else:
                resultado += f"📋 Cabeceras HTTP ({scheme.upper()}): No se pudieron obtener.\n"
    
    return resultado

async def verificar_dominio_cortado(dominio):
    """Verifica si un dominio ha expirado recientemente"""
    resultado = ""
    try:
        # Verificar en whois si el dominio está en estado de redención
        w = whois.whois(dominio)
        
        if w.status and any("redemption" in s.lower() for s in (w.status if isinstance(w.status, list) else [w.status])):
            resultado += "⚠️ *DOMINIO EN REDENCIÓN*: Este dominio ha expirado y está en período de redención.\n"
            resultado += "Puede ser vulnerable a ser registrado por otra persona cuando termine este período.\n\n"
        
        # Verificar en servicios de dominios caducados
        resultado += "🔍 *DOMINIOS CADUCADOS*\n"
        resultado += f"- [ExpiredDomains.net](https://www.expireddomains.net/domain/{dominio})\n"
        resultado += f"- [DomCop](https://www.domcop.com/domains?q={dominio})\n"
        resultado += f"- [NameJet](https://www.namejet.com/Pages/Auctions.aspx#domain={dominio})\n"
        resultado += f"- [DropCatch](https://www.dropcatch.com/search/{dominio})\n\n"
        
    except Exception as e:
        resultado += f"⚠️ Error verificando estado de dominio: {e}\n\n"
    
    return resultado

async def obtener_info_ssl(objetivo_host):
    """Obtiene información del certificado SSL de un host"""
    resultado = ""
    contexto = ssl.create_default_context()
    
    try:
        with socket.create_connection((objetivo_host, 443), timeout=5) as sock:
            with contexto.wrap_socket(sock, server_hostname=objetivo_host if es_dominio_valido(objetivo_host) else None) as ssock:
                cert = ssock.getpeercert()
        
        # Información básica del certificado
        resultado += f"   Emisor: {dict(x[0] for x in cert.get('issuer', [])).get('commonName', 'N/A')}\n"
        resultado += f"   Sujeto: {dict(x[0] for x in cert.get('subject', [])).get('commonName', 'N/A')}\n"
        
        # SANs (Subject Alternative Names)
        if 'subjectAltName' in cert:
            sans = [dns_name for _, dns_name in cert['subjectAltName']]
            resultado += f"   SANs: {', '.join(sans[:3])}"  # Mostrar solo los primeros 3
            if len(sans) > 3:
                resultado += f" ... (+{len(sans)-3} más)"
            resultado += "\n"
        
        # Fechas de validez
        resultado += f"   Válido Desde: {cert.get('notBefore', 'N/A')}\n"
        resultado += f"   Válido Hasta: {cert.get('notAfter', 'N/A')}\n"
        
        # Verificar si está próximo a expirar
        if 'notAfter' in cert:
            expiracion = datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
            dias_restantes = (expiracion - datetime.now()).days
            resultado += f"   Días Restantes: {dias_restantes}\n"
            if dias_restantes < 30:
                resultado += "   ⚠️ ¡CERTIFICADO PRÓXIMO A EXPIRAR!\n"
        
        # Algoritmos
        resultado += f"   Algoritmo Firma: {cert.get('signatureAlgorithm', 'N/A')}\n"
        
        # Versión
        resultado += f"   Versión: {cert.get('version', 'N/A')}\n"
        
        # Enlace para análisis detallado
        resultado += f"   🔍 [Analizar en SSL Labs](https://www.ssllabs.com/ssltest/analyze.html?d={objetivo_host})\n"
        
    except ssl.SSLCertVerificationError as e:
        resultado += f"   ❌ Error de verificación SSL: {e.verify_message} (Código: {e.verify_code}). El certificado podría ser auto-firmado o inválido.\n"
    except socket.timeout:
        resultado += "   ❌ Timeout conectando al puerto 443.\n"
    except ConnectionRefusedError:
        resultado += "   ❌ Conexión rechazada en puerto 443 (probablemente no hay servicio HTTPS).\n"
    except Exception as e:
        resultado += f"   ❌ Error SSL Genérico: {str(e)}\n"
    
    return resultado

async def detectar_tecnologias_web(objetivo_host):
    """Detecta tecnologías web utilizadas por un host"""
    resultado = ""
    tecnologias = set()
    
    try:
        url = f"http://{objetivo_host}"  # Empezar con http, requests manejará https si hay redirect
        headers = {
            'User-Agent': get_random_user_agent(),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        
        response = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=True)
        
        # Cabeceras
        if 'Server' in response.headers: 
            tecnologias.add(f"Servidor: {response.headers['Server']}")
        if 'X-Powered-By' in response.headers: 
            tecnologias.add(f"X-Powered-By: {response.headers['X-Powered-By']}")
        if 'X-Generator' in response.headers: 
            tecnologias.add(f"Generador: {response.headers['X-Generator']}")
        
        # Cookies
        if 'Set-Cookie' in response.headers:
            cookies = response.headers['Set-Cookie'].lower()
            if 'wordpress_' in cookies: tecnologias.add("WordPress (cookie)")
            if 'joomla_' in cookies: tecnologias.add("Joomla (cookie)")
            if 'laravel_session' in cookies: tecnologias.add("Laravel (cookie)")
            if 'django' in cookies: tecnologias.add("Django (cookie)")
            if 'express' in cookies: tecnologias.add("Express.js (cookie)")
            if 'php' in cookies: tecnologias.add("PHP (cookie)")
        
        # Contenido HTML (búsqueda de patrones)
        if response.text:
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Meta tags
            if soup.find("meta", attrs={"name": "generator"}):
                tecnologias.add(f"Generator: {soup.find('meta', attrs={'name': 'generator'}).get('content')}")
            
            # WordPress
            if soup.select('link[href*="wp-content"]'): tecnologias.add("WordPress (wp-content)")
            if soup.select('script[src*="wp-includes"]'): tecnologias.add("WordPress (wp-includes)")
            if '/wp-json/' in response.text: tecnologias.add("WordPress (REST API)")
            
            # Otros CMS
            if '/media/system/' in response.text: tecnologias.add("Joomla (system)")
            if '/media/jui/' in response.text: tecnologias.add("Joomla (jui)")
            if '/sites/all/' in response.text: tecnologias.add("Drupal (sites/all)")
            if '/core/' in response.text and 'Drupal' in response.text: tecnologias.add("Drupal (core)")
            if '/bitrix/' in response.text: tecnologias.add("Bitrix")
            if '/static/version' in response.text: tecnologias.add("Magento")
            
            # Frameworks JS
            if 'react' in response.text.lower(): tecnologias.add("React (texto)")
            if 'vue' in response.text.lower(): tecnologias.add("Vue.js (texto)")
            if 'angular' in response.text.lower(): tecnologias.add("Angular (texto)")
            if 'jquery' in response.text.lower(): tecnologias.add("jQuery (texto)")
            
            # Otras tecnologías
            if 'bootstrap' in response.text.lower(): tecnologias.add("Bootstrap (texto)")
            if 'font-awesome' in response.text.lower(): tecnologias.add("Font Awesome (texto)")
            if 'google-analytics' in response.text.lower(): tecnologias.add("Google Analytics (texto)")
            if 'gtm.js' in response.text.lower(): tecnologias.add("Google Tag Manager (texto)")
        
        # Resultados
        if tecnologias:
            resultado += "Tecnologías detectadas:\n"
            for tech in sorted(tecnologias):
                resultado += f"   - {tech}\n"
        else:
            resultado += "   No se detectaron tecnologías prominentes con métodos básicos.\n"
        
        resultado += "   Para un análisis más profundo:\n"
        resultado += "   - [Wappalyzer](https://www.wappalyzer.com/)\n"
        resultado += "   - [BuiltWith](https://builtwith.com/)\n"
        resultado += "   - [WhatCMS](https://whatcms.org/)\n"
        
    except requests.RequestException as e:
        resultado += f"   ❌ Error detectando tecnologías: {str(e)}\n"
    
    return resultado

async def obtener_robots_txt(objetivo_host):
    """Obtiene y analiza el archivo robots.txt de un host"""
    for scheme in ["http", "https"]:
        url = f"{scheme}://{objetivo_host}/robots.txt"
        try:
            response = requests.get(
                url, 
                headers={'User-Agent': get_random_user_agent()}, 
                timeout=REQUEST_TIMEOUT
            )
            
            if response.status_code == 200 and response.text:
                # Limitar la salida para no inundar el chat
                content = response.text.strip()
                if len(content) > 1000:
                    content = content[:1000] + "\n... (contenido truncado)"
                
                # Analizar directivas importantes
                lines = content.split('\n')
                disallows = [line.split('Disallow:')[1].strip() for line in lines if line.startswith('Disallow:')]
                allows = [line.split('Allow:')[1].strip() for line in lines if line.startswith('Allow:')]
                sitemaps = [line.split('Sitemap:')[1].strip() for line in lines if line.startswith('Sitemap:')]
                
                analysis = f"   Contenido de {url}:\n```\n{content}\n```\n"
                
                if disallows:
                    analysis += "   📌 Directorios bloqueados:\n"
                    for path in disallows[:5]:  # Mostrar solo los primeros 5
                        analysis += f"      - {path}\n"
                
                if sitemaps:
                    analysis += "   🗺️ Sitemaps encontrados:\n"
                    for sitemap in sitemaps[:3]:  # Mostrar solo los primeros 3
                        analysis += f"      - [Ver sitemap]({sitemap})\n"
                
                return analysis
            elif response.status_code == 200 and not response.text:
                return f"   {url} existe pero está vacío.\n"
            
        except requests.RequestException:
            continue  # Si falla http, probará https o viceversa
    
    return f"   No se encontró robots.txt accesible en http o https para {objetivo_host}.\n"

async def obtener_cabeceras_seguridad(objetivo_host):
    """Obtiene y analiza cabeceras de seguridad HTTP"""
    resultado = ""
    cabeceras_seguridad_interes = [
        "Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options",
        "X-Content-Type-Options", "Referrer-Policy", "Permissions-Policy", 
        "Cross-Origin-Embedder-Policy", "Cross-Origin-Opener-Policy", 
        "Cross-Origin-Resource-Policy", "X-XSS-Protection", "Feature-Policy"
    ]
    
    try:
        url = f"https://{objetivo_host}"  # Las cabeceras de seguridad son más relevantes en HTTPS
        response = requests.get(
            url, 
            headers={'User-Agent': get_random_user_agent()}, 
            timeout=REQUEST_TIMEOUT, 
            allow_redirects=True
        )
        
        encontradas = 0
        for cabecera in cabeceras_seguridad_interes:
            if cabecera in response.headers:
                valor = response.headers[cabecera]
                if len(valor) > 150: 
                    valor = valor[:150] + "..."  # Truncar valores largos
                resultado += f"   ✅ {cabecera}: {valor}\n"
                encontradas += 1
            else:
                resultado += f"   ❌ {cabecera}: No presente\n"
        
        if encontradas == 0:
            resultado = "   No se encontraron cabeceras de seguridad notables.\n"
        
        # Análisis de seguridad básico
        resultado += "\n   🔍 *ANÁLISIS DE SEGURIDAD BÁSICO*\n"
        
        # HSTS
        if "Strict-Transport-Security" not in response.headers:
            resultado += "   ⚠️ Falta HSTS (Strict-Transport-Security). Esto puede permitir ataques de downgrade a HTTP.\n"
        
        # CSP
        if "Content-Security-Policy" not in response.headers:
            resultado += "   ⚠️ Falta CSP (Content-Security-Policy). Esto puede permitir ataques XSS.\n"
        
        # X-Frame-Options
        if "X-Frame-Options" not in response.headers:
            resultado += "   ⚠️ Falta X-Frame-Options. Esto puede permitir ataques de clickjacking.\n"
        
        # X-XSS-Protection
        if "X-XSS-Protection" not in response.headers:
            resultado += "   ℹ️ X-XSS-Protection no está presente (obsoleto en navegadores modernos, CSP es mejor).\n"
        
        # Referrer-Policy
        if "Referrer-Policy" not in response.headers:
            resultado += "   ℹ️ Falta Referrer-Policy. Esto puede filtrar información sensible en el referer.\n"
        
        # Enlace para análisis más detallado
        resultado += f"\n   Para un análisis completo: [SecurityHeaders.com](https://securityheaders.com/?q={objetivo_host}&followRedirects=on)\n"
        
    except requests.exceptions.SSLError:
        resultado = "   ❌ Error SSL al intentar obtener cabeceras. El sitio podría no soportar HTTPS correctamente.\n"
    except requests.RequestException as e:
        resultado += f"   ❌ Error obteniendo cabeceras de seguridad: {str(e)}\n"
    
    return resultado