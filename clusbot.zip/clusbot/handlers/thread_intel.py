import re
import socket
import dns.resolver
import requests
from urllib.parse import quote_plus
from typing import List, Optional

from telegram import Update
from telegram.ext import ContextTypes
from config import REQUEST_TIMEOUT
from services.web_tools import get_random_user_agent

async def inteligencia_amenazas(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manejador principal para inteligencia de amenazas"""
    if not context.args:
        await update.message.reply_text("Uso: /amenazas [ip|dominio|hash_archivo]")
        return

    objetivo = context.args[0]
    respuesta = f"🛡️ *INTELIGENCIA DE AMENAZAS - {objetivo.upper()}* 🛡️\n\n"
    mensaje_carga = await update.message.reply_text("🔎 Recopilando inteligencia de amenazas...")

    # Enlaces a servicios de reputación
    respuesta += await obtener_enlaces_reputacion(objetivo)
    
    # Comprobación DNSBL si es IP o Dominio
    if es_ip_valida(objetivo) or es_dominio_valido(objetivo):
        respuesta += "\n🚦 *COMPROBACIÓN DNSBL (Listas Negras DNS)*\n"
        await actualizar_mensaje(context, mensaje_carga, respuesta + "\nConsultando DNSBLs...")
        
        ip_a_comprobar = await resolver_ip_para_dnsbl(objetivo)
        if ip_a_comprobar:
            resultado_dnsbl = await comprobar_dnsbl(ip_a_comprobar)
            
            if not resultado_dnsbl:
                respuesta += "   ✅ No se encontró en las DNSBLs comprobadas.\n"
            else:
                for r in resultado_dnsbl:
                    respuesta += f"   🚨 Listado en: {r}\n"
                
                # Explicación de las listas negras
                respuesta += "\n   ℹ️ *Explicación de Listas Negras:*\n"
                dnsbl_explicaciones = {
                    "zen.spamhaus.org": "Spamhaus ZEN (Combina varias listas de Spamhaus)",
                    "bl.spamcop.net": "SpamCop (Correo no deseado reportado por usuarios)",
                    "dnsbl.sorbs.net": "SORBS (Spam y hosts abusivos)",
                    "b.barracudacentral.org": "Barracuda (Correo no deseado)",
                    "cbl.abuseat.org": "Abuseat CBL (Comprometidos/Infectados)",
                    "dnsbl.dronebl.org": "DroneBL (Servidores abusivos, bots, etc.)",
                    "spam.dnsbl.sorbs.net": "SORBS Spam (Envío de spam)",
                    "http.dnsbl.sorbs.net": "SORBS HTTP (Proxies abiertos HTTP)",
                    "socks.dnsbl.sorbs.net": "SORBS SOCKS (Proxies abiertos SOCKS)",
                    "web.dnsbl.sorbs.net": "SORBS Web (Servidores web abusivos)",
                    "ubl.unsubscore.com": "Unsubscribe Score (Correo no deseado)",
                    "psbl.surriel.com": "Passive Spam Block List (Spam pasivo)",
                }
                
                for lista in resultado_dnsbl:
                    if lista in dnsbl_explicaciones:
                        respuesta += f"     - {lista}: {dnsbl_explicaciones[lista]}\n"
    
    # Enviar respuesta final
    await actualizar_mensaje(
        context, 
        mensaje_carga, 
        respuesta,
        disable_web_page_preview=True
    )

async def obtener_enlaces_reputacion(objetivo: str) -> str:
    """Genera enlaces a servicios de reputación según el tipo de objetivo"""
    resultado = "🔗 *SERVICIOS DE REPUTACIÓN (Comprobación Manual)*:\n"
    
    if es_ip_valida(objetivo) or es_dominio_valido(objetivo):
        encoded_objetivo = quote_plus(objetivo)
        
        # Servicios para IPs/Dominios
        servicios = [
            ("VirusTotal", f"https://www.virustotal.com/gui/search/{encoded_objetivo}"),
            ("Talos Intelligence", f"https://talosintelligence.com/reputation_center/lookup?search={encoded_objetivo}"),
            ("URLScan.io", f"https://urlscan.io/search/#{encoded_objetivo}"),
            ("AbuseIPDB", f"https://www.abuseipdb.com/check/{encoded_objetivo}"),
            ("MXToolBox Blacklist", f"https://mxtoolbox.com/SuperTool.aspx?action=blacklist%3a{encoded_objetivo}"),
            ("IPvoid", f"https://www.ipvoid.com/scan/{objetivo}"),
            ("IPinfo", f"https://ipinfo.io/{objetivo}"),
            ("ThreatCrowd", f"https://www.threatcrowd.org/ip.php?ip={objetivo}"),
            ("AlienVault OTX", f"https://otx.alienvault.com/indicator/ip/{objetivo}"),
            ("GreyNoise", f"https://www.greynoise.io/viz/ip/{objetivo}"),
            ("Shodan", f"https://www.shodan.io/host/{objetivo}"),
            ("Censys", f"https://censys.io/ipv4/{objetivo}"),
            ("SecurityTrails", f"https://securitytrails.com/domain/{objetivo}"),
            ("DNSlytics", f"https://dnslytics.com/ip/{objetivo}"),
            ("ThreatMiner", f"https://www.threatminer.org/host.php?q={objetivo}"),
            ("IBM X-Force", f"https://exchange.xforce.ibmcloud.com/ip/{objetivo}"),
            ("FortiGuard", f"https://fortiguard.com/webfilter?q={objetivo}"),
            ("Sucuri SiteCheck", f"https://sitecheck.sucuri.net/results/{objetivo}"),
            ("Quttera", f"https://quttera.com/sitescan/{objetivo}"),
            ("Zscaler Zulu", f"https://zulu.zscaler.com/submission/{objetivo}"),
        ]
        
        # Limitar a 10 servicios para no saturar
        for nombre, url in servicios[:10]:
            resultado += f"- [{nombre}]({url})\n"
            
    elif len(objetivo) in [32, 40, 64]:  # Posible hash MD5, SHA1, SHA256
        encoded_objetivo = quote_plus(objetivo)
        
        # Servicios para hashes de archivos
        servicios = [
            ("VirusTotal", f"https://www.virustotal.com/gui/file/{encoded_objetivo}/detection"),
            ("MalwareBazaar", f"https://bazaar.abuse.ch/browse.php?search=sha256%3A{encoded_objetivo}"),
            ("Hybrid Analysis", f"https://www.hybrid-analysis.com/search?query={encoded_objetivo}"),
            ("Cape Sandbox", f"https://www.capesandbox.com/search/?q={encoded_objetivo}"),
            ("Joe Sandbox", f"https://www.joesandbox.com/search?q={encoded_objetivo}"),
            ("Intezer Analyze", f"https://analyze.intezer.com/analyses/{encoded_objetivo}"),
            ("AnyRun", f"https://any.run/report/{encoded_objetivo}"),
            ("UnpacMe", f"https://www.unpac.me/#/results/{encoded_objetivo}"),
            ("Triage", f"https://tria.ge/reports/search?q={encoded_objetivo}"),
            ("VirusBay", f"https://beta.virusbay.io/sample/browse?q={encoded_objetivo}"),
        ]
        
        for nombre, url in servicios[:5]:  # Limitar a 5 para hashes
            resultado += f"- [{nombre}]({url})\n"
            
    else:
        resultado += "   El objetivo no parece ser una IP, dominio o hash común. Los enlaces pueden no ser relevantes.\n"
    
    return resultado + "\n"

async def resolver_ip_para_dnsbl(objetivo: str) -> Optional[str]:
    """Resuelve un objetivo a IP para comprobación DNSBL"""
    if es_ip_valida(objetivo):
        return objetivo
    
    try:
        return socket.gethostbyname(objetivo)
    except socket.gaierror:
        return None

async def comprobar_dnsbl(ip: str) -> List[str]:
    """Comprueba una IP en múltiples listas negras DNS"""
    dnsbls_a_chequear = [
        "zen.spamhaus.org", "bl.spamcop.net", "dnsbl.sorbs.net", 
        "b.barracudacentral.org", "all.s5h.net", "spam.abuse.ch",
        "cbl.abuseat.org", "dnsbl.dronebl.org", "http.dnsbl.sorbs.net",
        "misc.dnsbl.sorbs.net", "socks.dnsbl.sorbs.net", "web.dnsbl.sorbs.net",
        "spam.dnsbl.sorbs.net", "zombie.dnsbl.sorbs.net", "dul.dnsbl.sorbs.net",
        "ubl.unsubscore.com", "psbl.surriel.com"
    ]
    
    ip_reversa = '.'.join(reversed(ip.split('.')))
    listado_en = []
    
    resolver = dns.resolver.Resolver()
    resolver.timeout = 2
    resolver.lifetime = 2

    async def chequear_lista(dnsbl_host: str) -> Optional[str]:
        """Verifica si una IP está listada en una DNSBL específica"""
        try:
            query = f"{ip_reversa}.{dnsbl_host}"
            respuesta = await asyncio.to_thread(resolver.resolve, query, 'A')
            
            # Si resuelve, está listado. Los códigos de retorno varían según la DNSBL.
            # Por simplicidad, solo reportamos que está listado.
            return dnsbl_host
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
            return None
        except (dns.exception.Timeout, dns.exception.DNSException):
            return None
    
    # Ejecutar todas las comprobaciones en paralelo
    tasks = [chequear_lista(dnsbl) for dnsbl in dnsbls_a_chequear]
    resultados = await asyncio.gather(*tasks)
    
    # Filtrar resultados no nulos
    for res in resultados:
        if res:
            listado_en.append(res)
    
    return listado_en

async def actualizar_mensaje(context, mensaje_carga, texto, **kwargs):
    """Actualiza el mensaje de carga con nuevo texto"""
    try:
        await context.bot.edit_message_text(
            chat_id=mensaje_carga.chat_id,
            message_id=mensaje_carga.message_id,
            text=texto,
            parse_mode="Markdown",
            **kwargs
        )
    except Exception as e:
        logger.error(f"Error actualizando mensaje: {e}")

def es_ip_valida(ip: str) -> bool:
    """Verifica si una cadena es una dirección IP válida"""
    patron = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    return re.match(patron, ip) is not None

def es_dominio_valido(dominio: str) -> bool:
    """Verifica si una cadena es un dominio válido"""
    patron = re.compile(
        r'^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*'
        r'([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])\.'
        r'([A-Za-z]{2,})$'
    )
    return re.match(patron, dominio) is not None