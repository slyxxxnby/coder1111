import os
from colorama import init, Fore

# Inicializar colorama
init()

# --- Configuración General ---
TOKEN = "TU_TOKEN_DE_TELEGRAM_AQUÍ"
MAX_THREADS = 20  # Hilos para operaciones concurrentes
REQUEST_TIMEOUT = 15  # Tiempo máximo para solicitudes HTTP

# --- Rutas de Archivos ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
GEOIP_DB_PATH = os.path.join(BASE_DIR, "GeoLite2-City.mmdb")

# --- Configuración de Logging ---
LOG_CONFIG = {
    'version': 1,
    'formatters': {
        'detailed': {
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        },
    },
    'handlers': {
        'file': {
            'class': 'logging.FileHandler',
            'filename': 'osint_bot.log',
            'encoding': 'utf-8',
            'formatter': 'detailed',
        },
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'detailed',
        },
    },
    'root': {
        'handlers': ['file', 'console'],
        'level': 'INFO',
    },
}

# Mensajes de inicio
STARTUP_MESSAGE = f"""
{Fore.RED}🔥 OSINT BOT ULTIMATE - VERSIÓN MEJORADA 🔥{Fore.RESET}
{Fore.GREEN}🚀 Cargando módulos de inteligencia de fuentes abiertas{Fore.RESET}
{Fore.CYAN}💻 Todos los sistemas operativos - Listo para recopilación{Fore.RESET}
{Fore.YELLOW}⚠️ ADVERTENCIA: Usa este poder con responsabilidad y ética{Fore.RESET}
"""

def check_dependencies():
    """Verifica dependencias necesarias"""
    warnings = []
    
    # Verificar GeoIP DB
    if not os.path.exists(GEOIP_DB_PATH):
        warnings.append(
            f"{Fore.YELLOW}ADVERTENCIA: GeoLite2-City.mmdb no encontrado. "
            f"Descárgalo de MaxMind y colócalo en {GEOIP_DB_PATH}{Fore.RESET}"
        )
    
    # Verificar Nmap
    try:
        import nmap
        nmap.PortScanner()
    except ImportError:
        warnings.append(
            f"{Fore.YELLOW}ADVERTENCIA: Nmap no está instalado. "
            f"El módulo de escaneo de red no funcionará.{Fore.RESET}"
        )
    
    return warnings