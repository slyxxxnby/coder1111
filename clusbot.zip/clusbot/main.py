import logging
import logging.config
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler
from telegram.error import TelegramError

from config import LOG_CONFIG, STARTUP_MESSAGE, check_dependencies
from handlers import (
    start, 
    mostrar_menu,
    manejador_menu,
    osint_usuario_brutal,
    osint_web_brutal,
    escanear_red_brutal,
    busqueda_fugas_datos,
    inteligencia_amenazas,
    analisis_contrasena,
    manejador_errores
)

def setup_logging():
    """Configura el sistema de logging"""
    logging.config.dictConfig(LOG_CONFIG)
    return logging.getLogger(__name__)

def main():
    logger = setup_logging()
    
    # Verificar dependencias
    warnings = check_dependencies()
    for warning in warnings:
        logger.warning(warning)
        print(warning)
    
    print(STARTUP_MESSAGE)
    
    try:
        # Construir aplicaci��n
        app = ApplicationBuilder().token(TOKEN).build()
        
        # Manejadores de comandos
        app.add_handler(CommandHandler("start", start))
        app.add_handler(CommandHandler("menu", mostrar_menu))
        app.add_handler(CommandHandler("osint_usuario", osint_usuario_brutal))
        app.add_handler(CommandHandler("web_brutal", osint_web_brutal))
        app.add_handler(CommandHandler("escanear_red", escanear_red_brutal))
        app.add_handler(CommandHandler("fugas_datos", busqueda_fugas_datos))
        app.add_handler(CommandHandler("amenazas", inteligencia_amenazas))
        app.add_handler(CommandHandler("analizar_pwd", analisis_contrasena))
        
        # Manejador de men�� interactivo
        app.add_handler(CallbackQueryHandler(manejador_menu))
        
        # Manejador de errores
        app.add_error_handler(manejador_errores)
        
        # Iniciar bot
        logger.info("Iniciando bot...")
        app.run_polling()
        
    except Exception as e:
        logger.critical(f"Error fatal al iniciar el bot: {e}", exc_info=True)
        raise

if __name__ == '__main__':
    main()