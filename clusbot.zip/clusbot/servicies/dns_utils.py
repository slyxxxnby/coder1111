import dns.resolver
import socket
import concurrent.futures
from typing import List, Optional

from config import MAX_THREADS
from services.web_tools import get_random_user_agent

async def resolver_dns(dominio: str, tipo: str = 'A') -> List[str]:
    """Resuelve un registro DNS específico para un dominio"""
    resolver = dns.resolver.Resolver()
    resolver.timeout = 3
    resolver.lifetime = 3
    
    try:
        respuestas = await asyncio.to_thread(resolver.resolve, dominio, tipo)
        return [r.to_text() for r in respuestas]
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
        return []
    except dns.exception.DNSException as e:
        logger.error(f"Error DNS para {dominio} tipo {tipo}: {e}")
        return []

async def obtener_registros_dns(dominio: str) -> str:
    """Obtiene múltiples registros DNS para un dominio"""
    resultado = ""
    tipos_registro = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA', 'SRV', 'CAA']
    
    for rtype in tipos_registro:
        try:
            respuestas = await resolver_dns(dominio, rtype)
            
            if respuestas:
                resultado += f"{rtype} Records:\n"
                
                # Formatear según el tipo de registro
                if rtype == 'MX':
                    mx_sorted = sorted([r.split() for r in respuestas], key=lambda x: int(x[0]))
                    for mx in mx_sorted[:5]:  # Mostrar solo los primeros 5 MX
                        resultado += f"   - Pref {mx[0]} → {mx[1]}\n"
                elif rtype == 'TXT':
                    for txt in respuestas[:3]:  # Mostrar solo los primeros 3 TXT
                        resultado += f"   - {txt[:100]}{'...' if len(txt) > 100 else ''}\n"
                elif rtype == 'SOA':
                    soa_parts = respuestas[0].split()
                    resultado += f"   - MNAME: {soa_parts[0]}\n"
                    resultado += f"   - RNAME: {soa_parts[1]}\n"
                    resultado += f"   - Serial: {soa_parts[2]}\n"
                else:
                    for r in respuestas[:5]:  # Mostrar solo los primeros 5 registros
                        resultado += f"   - {r}\n"
                
                if len(respuestas) > 5:
                    resultado += f"   ... (mostrando 5 de {len(respuestas)} registros)\n"
                
                resultado += "\n"
        
        except Exception as e:
            resultado += f"{rtype} Records: Error ({e})\n\n"
    
    return resultado if resultado.strip() else "   No se encontraron registros DNS comunes o hubo errores.\n"

async def escanear_subdominios_basico(dominio: str) -> str:
    """Realiza una búsqueda básica de subdominios comunes"""
    resultado = "Realizando una búsqueda rápida de subdominios comunes:\n"
    
    # Lista ampliada de subdominios comunes
    subdominios_comunes = [
        "www", "mail", "ftp", "cpanel", "webmail", "blog", "dev", "shop",
        "test", "admin", "portal", "owa", "vpn", "m", "api", "assets",
        "cdn", "static", "media", "img", "images", "js", "css", "download",
        "secure", "ssl", "docs", "support", "help", "status", "dashboard",
        "app", "apps", "beta", "staging", "demo", "git", "svn", "ssh",
        "db", "database", "internal", "intranet", "extranet", "partner",
        "partners", "client", "clients", "customer", "customers", "backup",
        "backups", "old", "new", "temp", "tmp", "test", "testing", "stage",
        "prod", "production", "live", "chat", "forum", "forums", "community",
        "news", "events", "calendar", "wiki", "kb", "knowledgebase", "helpdesk",
        "ticket", "tickets", "submit", "upload", "download", "files", "share",
        "shared", "storage", "sync", "account", "accounts", "billing", "invoice",
        "payment", "payments", "shop", "store", "cart", "checkout", "buy",
        "sell", "market", "markets", "trade", "trading", "exchange", "wallet",
        "crypto", "bitcoin", "ethereum", "blockchain", "node", "nodes", "miner",
        "mining", "pool", "pools", "explorer", "scan", "scanner", "monitor",
        "monitoring", "alert", "alerts", "report", "reports", "analytics",
        "stats", "statistics", "graph", "graphs", "chart", "charts", "map",
        "maps", "geo", "location", "track", "tracking", "trace", "tracing",
        "log", "logs", "logger", "debug", "debugging", "error", "errors",
        "fail", "failure", "fails", "crash", "crashes", "bug", "bugs",
        "issue", "issues", "feature", "features", "request", "requests",
        "feedback", "suggest", "suggestion", "suggestions", "vote", "votes",
        "poll", "polls", "survey", "surveys", "quiz", "quizzes", "game",
        "games", "play", "player", "players", "score", "scores", "leaderboard",
        "rank", "ranking", "ratings", "review", "reviews", "comment", "comments",
        "discuss", "discussion", "discussions", "talk", "chat", "chats",
        "message", "messages", "mail", "email", "emails", "contact", "contacts",
        "about", "aboutus", "team", "teams", "career", "careers", "hire",
        "hiring", "job", "jobs", "work", "works", "project", "projects",
        "task", "tasks", "todo", "todos", "list", "lists", "note", "notes",
        "doc", "docs", "document", "documents", "file", "files", "folder",
        "folders", "archive", "archives", "backup", "backups", "save", "saves",
        "config", "configuration", "settings", "setup", "install", "installation",
        "update", "updates", "upgrade", "upgrades", "patch", "patches", "fix",
        "fixes", "hotfix", "hotfixes", "security", "secure", "auth", "authentication",
        "login", "logins", "logout", "signin", "signout", "register", "registration",
        "signup", "verify", "verification", "confirm", "confirmation", "reset",
        "password", "passwords", "recovery", "forgot", "remember", "change",
        "profile", "profiles", "user", "users", "member", "members", "account",
        "accounts", "admin", "admins", "administrator", "administrators", "mod",
        "moderator", "moderators", "root", "superuser", "superusers", "sysadmin",
        "sysadmins", "webmaster", "webmasters", "owner", "owners", "creator",
        "creators", "founder", "founders", "ceo", "cto", "cfo", "cio", "cm",
        "manager", "managers", "director", "directors", "executive", "executives",
        "office", "offices", "headquarters", "hq", "branch", "branches", "local",
        "locale", "location", "locations", "region", "regions", "country", "countries",
        "city", "cities", "state", "states", "province", "provinces", "district",
        "districts", "county", "counties", "town", "towns", "village", "villages",
        "address", "addresses", "street", "streets", "road", "roads", "avenue",
        "avenues", "boulevard", "boulevards", "lane", "lanes", "drive", "drives",
        "court", "courts", "place", "places", "square", "squares", "circle",
        "circles", "park", "parks", "garden", "gardens", "plaza", "plazas",
        "center", "centers", "central", "station", "stations", "terminal",
        "terminals", "stop", "stops", "hub", "hubs", "depot", "depots", "yard",
        "yards", "dock", "docks", "pier", "piers", "wharf", "wharfs", "port",
        "ports", "airport", "airports", "train", "trains", "bus", "buses",
        "subway", "subways", "metro", "metros", "tram", "trams", "lightrail",
        "ferry", "ferries", "ship", "ships", "boat", "boats", "yacht", "yachts",
        "marina", "marinas", "harbor", "harbors", "canal", "canals", "river",
        "rivers", "lake", "lakes", "pond", "ponds", "stream", "streams", "brook",
        "brooks", "creek", "creeks", "falls", "waterfall", "waterfalls", "bridge",
        "bridges", "tunnel", "tunnels", "highway", "highways", "freeway", "freeways",
        "expressway", "expressways", "turnpike", "turnpikes", "parkway", "parkways",
        "bypass", "bypasses", "beltway", "beltways", "loop", "loops", "circle",
        "circles", "square", "squares", "plaza", "plazas", "mall", "malls",
        "market", "markets", "bazaar", "bazaars", "fair", "fairs", "festival",
        "festivals", "carnival", "carnivals", "expo", "expos", "exhibition",
        "exhibitions", "show", "shows", "display", "displays", "gallery",
        "galleries", "museum", "museums", "library", "libraries", "archive",
        "archives", "records", "history", "historical", "historic", "antique",
        "antiques", "artifact", "artifacts", "relic", "relics", "monument",
        "monuments", "memorial", "memorials", "statue", "statues", "sculpture",
        "sculptures", "art", "arts", "culture", "cultural", "heritage", "tradition",
        "traditional", "custom", "customs", "festival", "festivals", "holiday",
        "holidays", "celebration", "celebrations", "ceremony", "ceremonies",
        "ritual", "rituals", "religion", "religious", "spiritual", "spirituality",
        "church", "churches", "temple", "temples", "mosque", "mosques", "synagogue",
        "synagogues", "shrine", "shrines", "altar", "altars", "sanctuary",
        "sanctuaries", "chapel", "chapels", "cathedral", "cathedrals", "basilica",
        "basilicas", "monastery", "monasteries", "convent", "convents", "abbey",
        "abbeys", "priory", "priories", "parish", "parishes", "diocese", "dioceses",
        "archdiocese", "archdioceses", "bishop", "bishops", "cardinal", "cardinals",
        "pope", "papal", "vatican", "catholic", "protestant", "orthodox", "anglican",
        "lutheran", "methodist", "baptist", "presbyterian", "pentecostal", "evangelical",
        "fundamentalist", "charismatic", "adventist", "mormon", "jehovah", "scientology",
        "hindu", "hinduism", "buddhist", "buddhism", "taoist", "taoism", "confucian",
        "confucianism", "shinto", "jain", "jainism", "sikh", "sikhism", "zoroastrian",
        "zoroastrianism", "bahai", "bahai", "druze", "druze", "yazidi", "yazidi",
        "pagan", "paganism", "wiccan", "wicca", "druid", "druidry", "shaman", "shamanism",
        "voodoo", "santeria", "candomble", "umbanda", "hoodoo", "rootwork", "conjure",
        "magic", "occult", "esoteric", "mysticism", "mystic", "kabbalah", "gnostic",
        "gnosticism", "alchemy", "astrology", "astronomy", "cosmology", "philosophy",
        "philosopher", "thinker", "thought", "idea", "ideas", "concept", "concepts",
        "theory", "theories", "hypothesis", "hypotheses", "thesis", "theses", "dissertation",
        "dissertations", "research", "researcher", "researchers", "scientist", "scientists",
        "science", "sciences", "technology", "technologies", "engineering", "engineer",
        "engineers", "mathematics", "mathematician", "mathematicians", "physics", "physicist",
        "physicists", "chemistry", "chemist", "chemists", "biology", "biologist", "biologists",
        "geology", "geologist", "geologists", "astronomy", "astronomer", "astronomers",
        "meteorology", "meteorologist", "meteorologists", "oceanography", "oceanographer",
        "oceanographers", "geography", "geographer", "geographers", "anthropology",
        "anthropologist", "anthropologists", "archaeology", "archaeologist", "archaeologists",
        "paleontology", "paleontologist", "paleontologists", "psychology", "psychologist",
        "psychologists", "sociology", "sociologist", "sociologists", "economics", "economist",
        "economists", "political", "politics", "politician", "politicians", "government",
        "governments", "administration", "administrations", "bureaucracy", "bureaucracies",
        "diplomacy", "diplomat", "diplomats", "embassy", "embassies", "consulate", "consulates",
        "ministry", "ministries", "department", "departments", "agency", "agencies", "bureau",
        "bureaus", "office", "offices", "division", "divisions", "section", "sections", "unit",
        "units", "branch", "branches", "subsidiary", "subsidiaries", "affiliate", "affiliates",
        "partner", "partners", "associate", "associates", "collaborator", "collaborators",
        "colleague", "colleagues", "team", "teams", "group", "groups", "organization",
        "organizations", "association", "associations", "society", "societies", "club",
        "clubs", "foundation", "foundations", "institute", "institutes", "academy", "academies",
        "university", "universities", "college", "colleges", "school", "schools", "education",
        "educational", "learning", "teach", "teaching", "teacher", "teachers", "professor",
        "professors", "instructor", "instructors", "lecturer", "lecturers", "student", "students",
        "pupil", "pupils", "alumni", "alumnus", "alumna", "alumnae", "graduate", "graduates",
        "postgraduate", "postgraduates", "phd", "doctorate", "doctoral", "master", "masters",
        "bachelor", "bachelors", "degree", "degrees", "diploma", "diplomas", "certificate",
        "certificates", "license", "licenses", "qualification", "qualifications", "training",
        "trainings", "course", "courses", "class", "classes", "lesson", "lessons", "lecture",
        "lectures", "seminar", "seminars", "workshop", "workshops", "conference", "conferences",
        "symposium", "symposiums", "congress", "congresses", "summit", "summits", "forum",
        "forums", "meeting", "meetings", "event", "events", "gathering", "gatherings", "assembly",
        "assemblies", "convention", "conventions", "exhibition", "exhibitions", "fair", "fairs",
        "festival", "festivals", "carnival", "carnivals", "celebration", "celebrations", "party",
        "parties", "reception", "receptions", "banquet", "banquets", "dinner", "dinners", "lunch",
        "lunches", "breakfast", "breakfasts", "brunch", "brunches", "tea", "teas", "coffee",
        "coffees", "bar", "bars", "pub", "pubs", "tavern", "taverns", "inn", "inns", "hotel",
        "hotels", "motel", "motels", "resort", "resorts", "spa", "spas", "salon", "salons",
        "clinic", "clinics", "hospital", "hospitals", "medical", "medicine", "doctor", "doctors",
        "physician", "physicians", "surgeon", "surgeons", "dentist", "dentists", "nurse", "nurses",
        "pharmacist", "pharmacists", "therapist", "therapists", "psychiatrist", "psychiatrists",
        "psychologist", "psychologists", "counselor", "counselors", "social", "worker", "workers",
        "health", "healthcare", "care", "cares", "wellness", "fitness", "exercise", "exercises",
        "gym", "gyms", "yoga", "pilates", "meditation", "massage", "acupuncture", "chiropractic",
        "physical", "therapy", "therapies", "rehabilitation", "rehab", "recovery", "treatment",
        "treatments", "cure", "cures", "heal", "healing", "prevention", "preventive", "vaccine",
        "vaccines", "immunization", "immunizations", "pharmacy", "pharmacies", "drug", "drugs",
        "medicine", "medicines", "pill", "pills", "tablet", "tablets", "capsule", "capsules",
        "injection", "injections", "shot", "shots", "vaccination", "vaccinations", "test", "tests",
        "testing", "laboratory", "laboratories", "lab", "labs", "research", "researches", "study",
        "studies", "experiment", "experiments", "trial", "trials", "clinical", "clinic", "clinics",
        "hospital", "hospitals", "medical", "medicine", "doctor", "doctors", "physician", "physicians",
        "surgeon", "surgeons", "dentist", "dentists", "nurse", "nurses", "pharmacist", "pharmacists",
        "therapist", "therapists", "psychiatrist", "psychiatrists", "psychologist", "psychologists",
        "counselor", "counselors", "social", "worker", "workers", "health", "healthcare", "care",
        "cares", "wellness", "fitness", "exercise", "exercises", "gym", "gyms", "yoga", "pilates",
        "meditation", "massage", "acupuncture", "chiropractic", "physical", "therapy", "therapies",
        "rehabilitation", "rehab", "recovery", "treatment", "treatments", "cure", "cures", "heal",
        "healing", "prevention", "preventive", "vaccine", "vaccines", "immunization", "immunizations",
        "pharmacy", "pharmacies", "drug", "drugs", "medicine", "medicines", "pill", "pills", "tablet",
        "tablets", "capsule", "capsules", "injection", "injections", "shot", "shots", "vaccination",
        "vaccinations", "test", "tests", "testing", "laboratory", "laboratories", "lab", "labs",
        "research", "researches", "study", "studies", "experiment", "experiments", "trial", "trials",
        "clinical", "clinic", "clinics", "hospital", "hospitals", "medical", "medicine", "doctor",
        "doctors", "physician", "physicians", "surgeon", "surgeons", "dentist", "dentists", "nurse",
        "nurses", "pharmacist", "pharmacists", "therapist", "therapists", "psychiatrist", "psychiatrists",
        "psychologist", "psychologists", "counselor", "counselors", "social", "worker", "workers",
        "health", "healthcare", "care", "cares", "wellness", "fitness", "exercise", "exercises", "gym",
        "gyms", "yoga", "pilates", "meditation", "massage", "acupuncture", "chiropractic", "physical",
        "therapy", "therapies", "rehabilitation", "rehab", "recovery", "treatment", "treatments", "cure",
        "cures", "heal", "healing", "prevention", "preventive", "vaccine", "vaccines", "immunization",
        "immunizations", "pharmacy", "pharmacies", "drug", "drugs", "medicine", "medicines", "pill",
        "pills", "tablet", "tablets", "capsule", "capsules", "injection", "injections", "shot", "shots",
        "vaccination", "vaccinations", "test", "tests", "testing", "laboratory", "laboratories", "lab",
        "labs", "research", "researches", "study", "studies", "experiment", "experiments", "trial",
        "trials", "clinical", "clinic", "clinics", "hospital", "hospitals", "medical", "medicine",
        "doctor", "doctors", "physician", "physicians", "surgeon", "surgeons", "dentist", "dentists",
        "nurse", "nurses", "pharmacist", "pharmacists", "therapist", "therapists", "psychiatrist",
        "psychiatrists", "psychologist", "psychologists", "counselor", "counselors", "social", "worker",
        "workers", "health", "healthcare", "care", "cares", "wellness", "fitness", "exercise",
        "exercises", "gym", "gyms", "yoga", "pilates", "meditation", "massage", "acupuncture",
        "chiropractic", "physical", "therapy", "therapies", "rehabilitation", "rehab", "recovery",
        "treatment", "treatments", "cure", "cures", "heal", "healing", "prevention", "preventive",
        "vaccine", "vaccines", "immunization", "immunizations", "pharmacy", "pharmacies", "drug",
        "drugs", "medicine", "medicines", "pill", "pills", "tablet", "tablets", "capsule", "capsules",
        "injection", "injections", "shot", "shots", "vaccination", "vaccinations", "test", "tests",
        "testing", "laboratory", "laboratories", "lab", "labs", "research", "researches", "study",
        "studies", "experiment", "experiments", "trial", "trials", "clinical", "clinic", "clinics",
        "hospital", "hospitals", "medical", "medicine", "doctor", "doctors", "physician", "physicians",
        "surgeon", "surgeons", "dentist", "dentists", "nurse", "nurses", "pharmacist", "pharmacists",
        "therapist", "therapists", "psychiatrist", "psychiatrists", "psychologist", "psychologists",
        "counselor", "counselors", "social", "worker", "workers", "health", "healthcare", "care",
        "cares", "wellness", "fitness", "exercise", "exercises", "gym", "gyms", "yoga", "pilates",
        "meditation", "massage", "acupuncture", "chiropractic", "physical", "therapy", "therapies",
        "rehabilitation", "rehab", "recovery", "treatment", "treatments", "cure", "cures", "heal",
        "healing", "prevention", "preventive", "vaccine", "vaccines", "immunization", "immunizations",
        "pharmacy", "pharmacies", "drug", "drugs", "medicine", "medicines", "pill", "pills", "tablet",
        "tablets", "capsule", "capsules", "injection", "injections", "shot", "shots", "vaccination",
        "vaccinations", "test", "tests", "testing", "laboratory", "laboratories", "lab", "labs",