import os
import geoip2.database
from typing import Dict, Optional

from config import GEOIP_DB_PATH

def obtener_geolocalizacion(ip: str) -> Optional[Dict]:
    """Obtiene información geográfica de una dirección IP usando GeoLite2"""
    if not os.path.exists(GEOIP_DB_PATH):
        logger.warning(f"Archivo GeoIP DB no encontrado en {GEOIP_DB_PATH}. Descárgalo de MaxMind.")
        return None
    
    try:
        with geoip2.database.Reader(GEOIP_DB_PATH) as reader:
            response = reader.city(ip)
            
            return {
                'pais': response.country.name,
                'codigo_pais': response.country.iso_code,
                'ciudad': response.city.name,
                'codigo_postal': response.postal.code,
                'latitud': response.location.latitude,
                'longitud': response.location.longitude,
                'zona_horaria': response.location.time_zone,
                'continente': response.continent.name,
                'subdivision': response.subdivisions.most_specific.name if response.subdivisions else None,
                'es_proxy': response.traits.is_anonymous_proxy or response.traits.is_satellite_provider,
                'red': f"{response.traits.network}" if hasattr(response.traits, 'network') else None,
                'asn': response.traits.autonomous_system_number if hasattr(response.traits, 'autonomous_system_number') else None,
                'organizacion': response.traits.autonomous_system_organization if hasattr(response.traits, 'autonomous_system_organization') else None,
            }
    
    except geoip2.errors.AddressNotFoundError:
        logger.info(f"Geolocalización no encontrada para IP: {ip}")
        return {'error': 'Información de geolocalización no encontrada para esta IP.'}
    
    except Exception as e:
        logger.error(f"Error de geolocalización para {ip}: {e}")
        return None